import concurrent.futures,hashlib,json,pathlib,subprocess,time
root=pathlib.Path('/shared/codex-1/vakint_rustred/workspace/validation')
base=json.loads((root/'hpl-legacy-reference.json').read_text())
words=sorted({tuple(e['indices']) for e in base['entries']})
folder=root/'hpl-20k-batches';folder.mkdir(exist_ok=True)
binary='/shared/codex-1/vakint_rustred/workspace/build/hpl-validation/release/hpl-validation'
count=16
word_to_batch={w:min(i*count//len(words),count-1) for i,w in enumerate(words)}
jobs=[]
for part in range(count):
 indices=[i for i,e in enumerate(base['entries']) if word_to_batch[tuple(e['indices'])]==part]
 data={**base,'entries':[base['entries'][i] for i in indices]}
 inp=folder/f'input-{part:02}.json';inp.write_text(json.dumps(data))
 jobs.append((part,indices,inp,folder/f'report-{part:02}.json',folder/f'values-{part:02}.tsv',folder/f'log-{part:02}.txt'))
def run(job):
 part,indices,inp,report,values,log=job
 with log.open('w') as output:
  p=subprocess.run([binary,str(inp),'20000',str(report),str(values)],stdout=output,stderr=subprocess.STDOUT)
 if p.returncode:
  print('FAIL batch',part,'exit',p.returncode,log.read_text()[-1500:],flush=True)
 else:print('Completed batch',part,'projections',len(indices),flush=True)
 return job,p.returncode
start=time.time();completed=[]
print('Starting',count,'disjoint batches:',len(words),'words,',len(base['entries']),'projections',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=count) as pool:
 for result in concurrent.futures.as_completed([pool.submit(run,j) for j in jobs]):completed.append(result.result())
reports=[];passed=True;entries=[]
for job,returncode in sorted(completed):
 part,indices,inp,path,values,log=job
 if returncode:passed=False;continue
 report=json.loads(path.read_text());reports.append(report);passed &= report['passed']
 entries.extend({**e,'index':indices[e['index']],'batch':part} for e in report['entries'])
summary={'digits':20000,'method':'16 disjoint word batches; unchanged relative tolerance 1e-20000','source_sha256':hashlib.sha256((root/'hpl-legacy-reference.json').read_bytes()).hexdigest(),'validator_sha256':hashlib.sha256(pathlib.Path(binary).read_bytes()).hexdigest(),'elapsed_seconds':time.time()-start,'projection_count':len(entries),'word_count':len(words),'passed':passed and len(entries)==len(base['entries']),'sum_batch_seconds':sum(r['elapsed_seconds'] for r in reports),'entries':sorted(entries,key=lambda e:e['index'])}
(root/'hpl-parity-20000.json').write_text(json.dumps(summary,indent=2))
if summary['passed']:
 (root/'hpl-values-20000.tsv').write_text(''.join(j[4].read_text() for j in jobs))
print('FINAL',json.dumps({k:v for k,v in summary.items() if k!='entries'}),flush=True)
raise SystemExit(0 if summary['passed'] else 1)
