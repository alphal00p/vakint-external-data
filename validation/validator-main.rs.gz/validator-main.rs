use std::{collections::{BTreeMap,HashMap},env,fs,time::Instant};
use symbolica::{domains::float::{Float,Real},transcendental::SixthRootHplEvaluator};
use tinyjson::JsonValue;
fn main() -> Result<(),Box<dyn std::error::Error>> {
    let args=env::args().collect::<Vec<_>>();
    let digits:u32=args[2].parse()?;
    let bits=((digits+24) as f64*std::f64::consts::LOG2_10).ceil() as u32;
    let input:JsonValue=fs::read_to_string(&args[1])?.parse()?;
    let entries=input["entries"].get::<Vec<JsonValue>>().unwrap();
    let mut words=BTreeMap::new();
    let mut ordered=vec![];
    for entry in entries {
        let w=entry["indices"].get::<Vec<JsonValue>>().unwrap().iter().map(|x|*x.get::<f64>().unwrap() as i8).collect::<Vec<_>>();
        if !words.contains_key(&w) {words.insert(w.clone(),ordered.len());ordered.push(w);}
    }
    eprintln!("evaluating {} words / {} projections at {} digits ({} bits)",ordered.len(),entries.len(),digits,bits);
    let start=Instant::now();
    let values=SixthRootHplEvaluator::new(&ordered)?.evaluate(1,bits)?;
    let elapsed=start.elapsed().as_secs_f64();
    let tolerance=Float::parse(&format!("1e-{digits}"),Some(bits)).unwrap();
    let mut failed=vec![];
    let mut max_error=Float::new(bits);
    let mut diagnostics=vec![];
    for (index,entry) in entries.iter().enumerate() {
        let word=entry["indices"].get::<Vec<JsonValue>>().unwrap().iter().map(|x|*x.get::<f64>().unwrap() as i8).collect::<Vec<_>>();
        let value=&values[words[&word]];
        let projection=entry["projection"].get::<String>().unwrap();
        let actual=if projection=="real" {&value.re} else {&value.im};
        let expected=Float::parse(entry["value"].get::<String>().unwrap(),Some(bits)).unwrap();
        let delta=(actual.clone()-&expected).norm();
        let error=if expected==Float::new(bits) {delta} else {delta/expected.norm()};
        let pass=error<tolerance;
        if !pass {failed.push(index);eprintln!("FAIL entry{index} {word:?} {projection}:relative_error_exponent={:?}",error.as_raw().get_exp());}
        if error>max_error {max_error=error.clone();}
        diagnostics.push(JsonValue::from(HashMap::from([
            ("index".into(),JsonValue::Number(index as f64)),
            ("pass".into(),JsonValue::Boolean(pass)),
            ("relative_error_binary_exponent".into(),error.as_raw().get_exp().map(|x|JsonValue::Number(x as f64)).unwrap_or(JsonValue::Null)),
        ])));
    }
    let report=JsonValue::from(HashMap::from([
        ("digits".into(),JsonValue::Number(digits as f64)),
        ("bits".into(),JsonValue::Number(bits as f64)),
        ("word_count".into(),JsonValue::Number(ordered.len() as f64)),
        ("projection_count".into(),JsonValue::Number(entries.len() as f64)),
        ("elapsed_seconds".into(),JsonValue::Number(elapsed)),
        ("passed".into(),JsonValue::Boolean(failed.is_empty())),
        ("entries".into(),JsonValue::Array(diagnostics)),
    ]));
    fs::write(&args[3],report.format()?)?;
    if let Some(output)=args.get(4) {
        let mut lines=String::new();
        for (word,value) in ordered.iter().zip(&values) {lines.push_str(&format!("{word:?}\t{}\t{}\n",value.re,value.im));}
        fs::write(output,lines)?;
    }
    eprintln!("{} / {} passed, elapsed {:.3}s; max error exponent={:?}",entries.len()-failed.len(),entries.len(),elapsed,max_error.as_raw().get_exp());
    if !failed.is_empty() {std::process::exit(1);}
    Ok(())
}
