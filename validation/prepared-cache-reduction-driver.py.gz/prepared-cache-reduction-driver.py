"""One fresh cached/uncached process per request against published v0.1.0 packs."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

root = Path('/shared/codex-1/vakint_rustred')
out = root / 'workspace/validation/cache-delivery-summary'
artifacts = []
for line in (out / 'benchmark-build.jsonl').read_text().splitlines():
    try:
        item = json.loads(line)
    except ValueError:
        continue
    if item.get('reason') == 'compiler-artifact' and item.get('target', {}).get('name') == 'vakint' and item.get('profile', {}).get('test') and item.get('executable'):
        artifacts.append(item['executable'])
assert len(artifacts) == 1, artifacts
binary = Path(artifacts[0])
test = 'rustred_evaluation::published_cache_benchmark::published_cache_reduction_timing'
cases = ['1:0:3', '2:0:2', '3:0:2'] + [f'4:{n}:{p}' for p in (2, 4) for n in range(4)]
affinity = sorted(os.sched_getaffinity(0))
taskset = shutil.which('taskset')
started = time.monotonic()
results = []

def run(spec):
    case, mode, slot = spec
    label = case.replace(':', '-') + '-' + mode
    result = out / (label + '.json')
    assert not result.exists(), result
    log = out / (label + '.log')
    env = os.environ.copy()
    env.update(VAKINT_TEST_EXTERNAL_DATA=str(root / 'vakint-external-data'),
               VAKINT_CACHE_BENCH_CASE=case, VAKINT_CACHE_BENCH_MODE=mode,
               VAKINT_CACHE_BENCH_RESULT=str(result), RAYON_NUM_THREADS='1',
               OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
    argv = [str(binary), '--exact', test, '--nocapture', '--test-threads=1']
    cpu = affinity[slot % len(affinity)] if taskset else None
    if taskset:
        argv = [taskset, '-c', str(cpu), *argv]
    wall = time.monotonic()
    with log.open('w') as stream:
        process = subprocess.run(argv, cwd=out, env=env, stdout=stream,
                                 stderr=subprocess.STDOUT, timeout=900)
    elapsed = time.monotonic() - wall
    assert process.returncode == 0 and result.is_file(), (label, process.returncode, str(log))
    data = json.loads(result.read_text())
    data.update(process_exit_code=process.returncode, process_wall_seconds=elapsed,
                cpu_affinity=cpu, log=str(log), log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    result.write_text(json.dumps(data, indent=2) + '\n')
    print(json.dumps({k: data[k] for k in ('case', 'mode', 'first_reduction_seconds', 'attach_seconds', 'prepared_entry_hits', 'prepared_descendant_hits')}), flush=True)
    return data

try:
    with ThreadPoolExecutor(max_workers=2) as executor:
        for case in cases:
            pair = list(executor.map(run, [(case, 'uncached', 0), (case, 'cached', 1)]))
            results.extend(pair)
            (out / 'published-cache-timing-progress.json').write_text(json.dumps(results, indent=2) + '\n')
    summary = []
    for case in cases:
        cold = next(r for r in results if r['case'] == case and r['mode'] == 'uncached')
        cached = next(r for r in results if r['case'] == case and r['mode'] == 'cached')
        assert cached['exact_uncached_parity']
        summary.append(dict(case=case, uncached_seconds=cold['first_reduction_seconds'],
                            cached_seconds=cached['first_reduction_seconds'],
                            reduction_ratio=cold['first_reduction_seconds'] / cached['first_reduction_seconds'],
                            seconds_saved=cold['first_reduction_seconds'] - cached['first_reduction_seconds'],
                            attach_seconds=cached['attach_seconds'],
                            cached_ram_median_seconds=sorted(cached['repeat_reduction_seconds'])[1],
                            entry_hits=cached['prepared_entry_hits'], descendant_hits=cached['prepared_descendant_hits']))
    receipt = dict(captured_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   validation_passed=True, source_provenance=str(out / 'benchmark-source-provenance.json'),
                   binary=str(binary), binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                   driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                   test=test, external_release='v0.1.0', selected_cases=cases,
                   process_count=len(results), elapsed_seconds=time.monotonic()-started,
                   scope='Single matched fresh-process pair per request, on two fixed cores when taskset is available; no OS page-cache flush; no statistical guarantee. Public Retain reduction only, excluding source/program setup, pack attachment, repeat checks and exact reference validation; no numerical master/HPL evaluation.',
                   summary=summary, runs=results)
    (out / 'published-cache-reduction-timings.json').write_text(json.dumps(receipt, indent=2) + '\n')
    (out / 'published-cache-reduction-timings.exit').write_text('0\n')
except BaseException:
    (out / 'published-cache-reduction-timings.exit').write_text('1\n')
    raise
