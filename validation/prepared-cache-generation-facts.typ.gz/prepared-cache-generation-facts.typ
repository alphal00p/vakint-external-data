= Prepared cache delivery facts

All byte figures below are exact file-content lengths. Native files are already compressed chunk payloads plus binary indexes; cache JSON metadata is counted separately. Whole-loop release archives include IBPs, masters and graphs as well as the cache.

#table(columns: 7, align: right,
  [Loops], [Native bytes], [Metadata bytes], [Primer roots], [Distinct records], [Outside primer], [Whole-pack gzip bytes],
  [1], [1235], [5964], [5], [5], [0], [48045],
  [2], [3854], [6445], [77], [77], [0], [107633],
  [3], [160651], [22749], [2320], [2352], [32], [370372],
  [4], [90887721], [4564269], [164352], [286527], [122175], [111922455],
)

Each loop uses `nL/cache/bundle.rrindex`, `nL/cache/bindings/<binding-id>/cache.rrindex`, and hash-named `chunks/*.rrchunk.gz`; `nL/cache.json` preserves generation diagnostics. The full exact file inventory and per-binding family mappings are in `native-cache-file-inventory.json` and `cache-inventory.json`.

The default finite primer spans every physical parent pinch, at most two total extra positive powers above the surviving unit lines, and numerator rank at most one. Four-loop H, FG, BMW and X parents have 9, 8, 8 and 9 physical lines respectively; auxiliary axes never become positive. Complete guarded intermediate descendants are saved while those roots reduce, allowing later roots and held-out inputs to reuse shortcut rules. This workload is an operational cache population policy, not stronger IBP coverage.

The public reproduction driver is `crates/vakint/examples/prepare_bundled_caches.rs`, invoked with a loop count, fresh output directory and optional external-data checkout (required for 4L). Its `prepare_cache` input is the loop count and default primer options, not one selected integral. The smaller `native_cache.rs` workflow evaluates `topo(I1L(4,3))` after preparation to demonstrate an in-primer hit, then `topo(I1L(4,5))` to demonstrate an outside-primer resident-overlay snapshot. Both use the same mass label; the powers distinguish a prepared root from held-out work.

Do not add completed roots to intermediate publications: 703 selected 3L roots and 73,274 selected 4L roots were already stored descendants. Independently decoded index counts are therefore 1,617 + 735 = 2,352 at 3L and 91,078 + 195,449 = 286,527 at 4L. This leaves 32 and 122,175 distinct keys outside their respective primers.

Native preparation times recorded by the published reports are 0.004732599, 0.007471699, 1.767896594 and 653.071538837 seconds. These are generation durations, not reduction speedup measurements. The outer producer timings also include startup and publication work. One 4L root exhausted optional intermediate metadata capture, while all 164,352 selected roots completed and both failure fields are null.

All native file hashes and sizes agree with the loop manifests. The published whole-loop archives agree with the sealed release checksums. External-data remote main was independently checked at `9fbcd9a6bcc63ac39c342b623b394c118ac318b1`; immutable release payload provenance is `fced6061d2037272bc76c15bd0396b9ac7287bf7`. No cache generation or scientific computation was started for this audit.

Runtime namespaces are 0=H, 1=FG, 2=BMW, 3=X, as defined by `FourLoopPrograms::load`. The manifest family array uses H, X, BMW, FG instead. Direct CSV row counts confirm the physical-line association; binding-record counts in this audit use exact family fingerprints rather than either array position.
