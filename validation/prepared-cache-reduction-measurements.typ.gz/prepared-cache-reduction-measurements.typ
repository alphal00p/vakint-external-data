= Published prepared-cache reduction measurements

These measurements use the published v0.1.0 caches with the d538 runtime source and dependency pins. The development-only probe adds one isolated unit-test module; no production runtime source is changed. The Cargo test profile is unoptimized, with debug information and assertions. Each case/mode runs in a fresh process, on one assigned CPU; two processes run concurrently on a shared host. This is one matched pair per request, not a statistical release-build benchmark.

The public RustRed call uses Retain mode, unit mass and FMFT/MATAD normalization. All engine/data/program initialization, cache-index attachment, three RAM repeats and exact uncached-reference comparisons are outside the first-call timings. Numerical master and HPL evaluation are excluded. All 22 processes exited zero; all 11 cached values agreed exactly with uncached references.

#table(columns: 7,
  [Family], [First power], [Uncached s], [Prepared s], [Ratio], [Entry hits], [Descendant hits],
  [1L], [3], [0.010444], [0.010304], [1.014], [1], [0],
  [2L], [2], [0.012492], [0.012369], [1.010], [1], [0],
  [3L], [2], [0.254533], [0.094634], [2.690], [1], [0],
  [4L/H], [2], [34.154138], [0.123183], [277.264], [1], [0],
  [4L/FG], [2], [2.537141], [0.135310], [18.751], [1], [0],
  [4L/BMW], [2], [0.056794], [0.064122], [0.886], [1], [0],
  [4L/X], [2], [157.714177], [0.318779], [494.744], [1], [0],
  [4L/H], [4], [47.442782], [24.538869], [1.933], [0], [2983],
  [4L/FG], [4], [4.582351], [0.919546], [4.983], [0], [52],
  [4L/BMW], [4], [26.793927], [6.579722], [4.072], [0], [888],
  [4L/X], [4], [249.320210], [81.082004], [3.075], [0], [8460],
)

All other physical denominators have power one, and auxiliary powers are zero. Runtime namespace order is H, FG, BMW, X; manifest family-array order differs. Power two is in the primer. The four-loop power-four requests are held out and have no exact entry hits, so their positive descendant hits demonstrate intermediate shortcuts.

Every prepared primer call has a backing entry hit and zero native IBP rule applications. The BMW primer request also requires zero ordinary native rules: its small timing difference is no evidence of an IBP speedup. The sampled 1L and 2L public calls are similarly dominated by ordinary call overhead.

Separate common first-use four-loop data/program setup ranges from 74.91 to 98.93 seconds in these fresh test processes. Cache attachment takes 0.140–0.168 seconds. Those costs must be included when estimating an entire one-shot calculation; the cache attachment is amortized over subsequent requests to the loaded engine.

The complete raw receipt, source provenance, Cargo profile, per-process logs and source code accompany this table. The receipt SHA256 is `6f52b5abe09c18a7b7630d12bb6d93abdb2cfc9c1ff6e08187463e400ec19a80`.
