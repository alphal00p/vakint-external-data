"""Inventory every FMFT numerical coefficient and export the finite omitted orders.

The six factorized primitive classes use the archived scalar graphs:
unit Jacobian loop-momentum blocks, unit propagator powers, no numerator or
additional symmetry factor. No general Gamma-only series extension is exported.
"""
import argparse,ast,collections,decimal,hashlib,importlib.util,itertools,json,pathlib,re,time
from symbolica import E,Float

spec=importlib.util.spec_from_file_location('lower_export',pathlib.Path(__file__).with_name('export_known_laurent_coefficients.py'))
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
P=helper.parse;EP=helper.EP

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def graph_blocks(master,data):
    graph=data/master['directory']/'graph.dot';contents=graph.read_text()
    match=re.search(r'loop_momentum_basis=("(?:\\.|[^"\\])*")',contents)
    basis=json.loads(json.loads(match.group(1)));signatures=basis['edge_signatures']
    count=master['loop_count'];parent=list(range(count))
    def find(i):
        while parent[i]!=i:i=parent[i]
        return i
    for entry in signatures.values():
        assert not any(entry['external'])
        support=[i for i,x in enumerate(entry['loops']) if x];assert support
        for i in support[1:]:parent[find(i)]=find(support[0])
    components=collections.defaultdict(list)
    for i in range(count):components[find(i)].append(i)
    endpoints={int(edge):(left,right) for left,right,edge in re.findall(r'(\w+)\s*->\s*(\w+)\s*\[id=(\d+)',contents)}
    blocks=[]
    for axes in components.values():
        edges={i:entry['loops'] for i,entry in signatures.items() if any(entry['loops'][j] for j in axes)}
        rows=[[row[j] for j in axes] for row in edges.values()]
        for j in range(len(axes)):
            assert any(abs(row[j])==1 and all(row[k]==0 for k in range(len(axes)) if k!=j) for row in rows)
        blocks.append({'loop_axes':axes,'edge_ids':sorted(map(int,edges)),'rows':rows,'endpoints':[endpoints[int(i)] for i in edges]})
    return graph,blocks

def canonical_graph(edges):
    vertices=sorted({v for edge in edges for v in edge})
    candidates=[]
    for permutation in itertools.permutations(range(len(vertices))):
        mapping=dict(zip(vertices,permutation))
        candidates.append(tuple(sorted(tuple(sorted((mapping[a],mapping[b]))) for a,b in edges)))
    return min(candidates)

def graph_certificate(master,data,kind,references):
    graph,blocks=graph_blocks(master,data)
    definition=master['graph_definition']
    assert all(power==1 for _,power in definition['edge_powers'])
    assert all(str(definition[k])=='1' for k in ['numerator','overall_factor','symmetry_factor'])
    for block in blocks:
        shape=(len(block['loop_axes']),len(block['edge_ids']));reference=references[shape]
        reference_graph,reference_blocks=graph_blocks(reference,data)
        reference_edges=[edge for b in reference_blocks for edge in b['endpoints']]
        assert canonical_graph(block['endpoints'])==canonical_graph(reference_edges),(master['name'],shape,'graph mismatch')
        block['reference_master_id']=reference['master_id'];block['reference_graph']=str(reference_graph.relative_to(data));block['reference_graph_sha256']=digest(reference_graph)
    return {'graph':str(graph.relative_to(data)),'sha256':digest(graph),'blocks':blocks,'unit_jacobian':True,'unit_powers':True}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--write',action='store_true')
    parser.add_argument('--vakint-source',type=pathlib.Path,default=helper.SRC)
    parser.add_argument('--data',type=pathlib.Path,default=helper.DATA)
    parser.add_argument('--validation',type=pathlib.Path,default=helper.WORK)
    args=parser.parse_args();src,data,work=args.vakint_source,args.data,args.validation
    start=time.time();manifest=json.loads((data/'provenance/original-root/manifest.json').read_text())
    fmft=(src/'fmft_numerics.rs').read_text();split=fmft.index('pub static MASTERS_NUMERIC_SUBSTITUTIONS')
    expansions=dict(re.findall(helper.PAT,fmft[:split]));numbers=dict(re.findall(helper.PAT,fmft[split:]))
    # Inventory every stored RHS, including unused consumer entries and partial values.
    inventory=[];tails={}
    for key,value in expansions.items():
        found=re.findall(r'Oep\(([-\d]+),\s*(\w+)',value)
        if found:tails[key]=int(found[0][0])
    for key,value in numbers.items():
        dependencies=sorted(set(re.findall(r'\b(?:PR\w+|T1ep\d*|D6|S2|Oep)\b',value)))
        declared=[float(p) for p in re.findall(r'`([0-9.]+)',value)]
        status='partial_unknown_tail' if 'Oep' in dependencies else ('resolved_from_miT111_epsilon4' if 'T1ep4' in dependencies else 'finite')
        inventory.append({'lhs':key,'dependencies':dependencies,'status':status,'minimum_declared_digits':min(declared) if declared else None})
    assert len(inventory)==38
    assert {i['lhs'] for i in inventory if i['dependencies']}=={'PR3ep2','PR13ep1'}
    finite_max={'PR1':2,'PR2':3,'PR3':2,'PR6':2,'PR8':2,'PR13':1}
    actual_tails={**tails,**{k:v+1 for k,v in finite_max.items()}}
    shape_to_kind={((1,1),(1,1),(1,1),(1,1)):'PR1',((1,1),(3,4)):'PR2',((1,1),(1,1),(2,3)):'PR3',((1,1),(3,5)):'PR6',((2,3),(2,3)):'PR8',((1,1),(3,6)):'PR13'}
    lower=[m for m in manifest['masters'] if m.get('loop_count',99)<=3]
    references={(1,1):next(m for m in lower if m['loop_count']==1), (2,3):next(m for m in lower if m['loop_count']==2 and 'miT111' in m.get('exact_basis_expression','')), (3,4):next(m for m in lower if m['loop_count']==3 and m.get('exact_basis_expression')=='miBN'), (3,5):next(m for m in lower if m['loop_count']==3 and 'miD5' in m.get('exact_basis_expression','')), (3,6):next(m for m in lower if m['loop_count']==3 and m.get('exact_basis_expression')=='miD6')}
    master_audit=[];selected=[];factorized=[]
    for m in manifest['masters']:
        if m.get('loop_count')!=4:continue
        basis=P(m['exact_basis_expression']).expand();requirements=[]
        _,blocks=graph_blocks(m,data)
        if len(blocks)>1:
            shape=tuple(sorted((len(b['loop_axes']),len(b['edge_ids'])) for b in blocks));kind=shape_to_kind[shape]
            assert basis==P(kind),(m['name'],'factorization/basis mismatch')
            factorized.append((m,kind))
        for primitive,tail in actual_tails.items():
            coefficient=basis.coefficient(P(primitive)).together()
            if coefficient==0:continue
            coefficient_terms=helper.coefficient_map(coefficient,6)
            leading=min(p for p,v in coefficient_terms.items() if v!=0)
            requirements.append({'primitive':primitive,'coefficient_valuation':leading,'first_unknown_power':tail+leading})
        assert requirements,(m['name'],'no primitive classified')
        known=min(x['first_unknown_power'] for x in requirements)-1
        archive_last=m['epsilon_range'][1]
        master_audit.append({'master_id':m['master_id'],'name':m['name'],'archive_last_power':archive_last,'fmft_known_last_power':known,'requirements':requirements})
        if known>archive_last:
            kind=next(k for k in finite_max if basis==P(k))
            assert known==finite_max[kind]
            selected.append((m,kind))
    assert len(selected)==20 and len(factorized)==22
    matad=(src/'matad.rs').read_text();a=matad.index('pub static MASTERS_EXPANSION');b=matad.index('pub static MASTERS_SUBSTITUTION')
    master_expansions=dict(re.findall(helper.PAT,matad[a:b]));master_substitutions=dict(re.findall(helper.PAT,matad[b:matad.index('impl MATAD')]))
    direct=dict(re.findall(helper.PAT,(src/'matad_numerics.rs').read_text()))
    def compact_gamma(value):
        value=re.sub(r'\s+','',value)
        for n in [2,3]:value=value.replace(f'exp({n}*ep*EulerGamma)*Gamma(1+ep)^{n}',f'Gam(1,1)^{n}')
        return value
    gamma_log='+'.join(f'({(-1)**n})*symbolica::zeta({n})/{n}*ep^{n}' for n in range(2,8))
    gamma=P('exp('+gamma_log+')').series(EP,0,7).to_expression()
    tad='(-Gam(1,1)/(ep*(ep-1)))'
    five_line=references[(3,5)]['exact_basis_expression']
    factorizations={'PR1':tad+'^4','PR2':tad+'*miBN','PR3':tad+'^2*(-miT111)','PR6':tad+'*('+five_line+')','PR8':'miT111^2','PR13':tad+'*miD6'}
    refs=json.loads(helper.read_text(work/'hpl-legacy-reference.json'))['entries'];native_values={}
    for line in helper.read_text(work/'hpl-values-20000.tsv').splitlines():
        word,real,imag=line.split('\t');native_values[tuple(ast.literal_eval(word))]=(real,imag)
    maps=[]
    for use_native,digits in [(True,240),(False,280)]:
        parameters={}
        for ref in refs:
            word=tuple(ref['indices']);projection=0 if ref['projection']=='real' else 1
            head='HR' if projection==0 else 'HI';label=P(head+'('+','.join(map(str,word))+',om1)')
            value=native_values[word][projection] if use_native else ref['value']
            parameters[label]=Float(value,decimal_digits=digits)
        maps.append(parameters)
    generated={};epsilon2_checks=[]
    for kind,basis in factorizations.items():
        symbolic=P(basis);numeric=symbolic
        for lhs,rhs in master_expansions.items():symbolic=symbolic.replace(P(lhs),P(compact_gamma(rhs)))
        for lhs,rhs in direct.items():numeric=numeric.replace(P(lhs),P(re.sub(r'`[0-9.]+','`300.',rhs)))
        symbolic=symbolic.replace(P('Gam(1,1)'),gamma);numeric=numeric.replace(P('Gam(1,1)'),gamma)
        known=finite_max[kind]
        exact_coeffs=helper.coefficient_map(symbolic,known);numeric_coeffs=helper.coefficient_map(numeric,known);values={}
        for power in range(-4,known+1):
            formula=exact_coeffs.get(power,E('0'))
            for lhs,rhs in master_substitutions.items():formula=formula.replace(P(lhs),P(rhs))
            formula=formula.expand();assert 'Oep' not in helper.text(formula)
            x=helper.scalar(formula,maps[0],240);y=helper.scalar(formula,maps[1],280);z=helper.scalar(numeric_coeffs.get(power,E('0')),{},280)
            with decimal.localcontext() as ctx:
                ctx.prec=300;scale=abs(y) if y else decimal.Decimal(1)
                assert abs(x-y)<scale*decimal.Decimal('1e-200'),(kind,power,'HPL refinement')
                assert abs(x-z)<scale*decimal.Decimal('1e-200'),(kind,power,'direct-table path')
                values[power]=(helper.text(formula.replace(helper.OM1,helper.OMEGA)),format(y,'.208e'))
        # Check each complete stored epsilon^2 RHS independently. PR6/PR8
        # are supplied by graph factorization and lower-loop known coefficients.
        if kind+'ep2' in numbers:
            rhs=P(re.sub(r'`[0-9.]+','`120.',numbers[kind+'ep2']))
            t1ep4=helper.coefficient_map(P(direct['miT111']),4)[4]
            rhs=rhs.replace(P('T1ep4'),t1ep4)
            existing=helper.scalar(rhs,{},100)
            with decimal.localcontext() as ctx:
                ctx.prec=300;computed=decimal.Decimal(values[2][1]);relative=abs((computed-existing)/computed)
                assert relative<decimal.Decimal('1e-50'),(kind,'stored epsilon2 RHS',relative.adjusted())
            epsilon2_checks.append({'primitive':kind,'stored_lhs':kind+'ep2','checked_digits':50,'relative_error_exponent':relative.adjusted(),'factorization':basis})
        generated[kind]=values;print('Validated',kind,'through epsilon',known,'from independent lower-loop formulas',flush=True)
    updates=[];masters=[];prefix_checks=[];symbolic_prefix_checks=[];certificates=[]
    for m,kind in factorized:
        certificates.append({'master_id':m['master_id'],'primitive':kind,**graph_certificate(m,data,kind,references)})
        directory=data/m['directory'];symbolic=json.loads((directory/'symbolic.json').read_text());numeric=json.loads((directory/'numerical.json').read_text())
        for power,old in numeric:
            ok,exp,rounded=helper.matches_stored(decimal.Decimal(generated[kind][power][1]),old,min(200,m['significant_digits']))
            assert ok,(m['name'],power,'prefix mismatch',exp)
            prefix_checks.append({'master_id':m['master_id'],'power':power,'relative_error_exponent':exp,'rounded_literal_match':rounded})
        # A FORM consumer's old Oep cutoff does not determine exactness of the
        # separately archived symbolic data. Check every existing coefficient,
        # including PR13 epsilon1, against the verified factorization authority.
        assert set(dict(symbolic))==set(dict(numeric)),(m['name'],'missing exact prefix')
        for power,old in symbolic:
            assert not re.search(r'`|\b(?:Oep|PR\w*|T1ep\w*|D6)\b',old),(m['name'],power,'opaque symbolic prefix')
            existing=P(old);derived=P(generated[kind][power][0])
            exact_match=(existing-derived).expand().together()==0
            evaluated=helper.scalar(existing.replace(helper.OMEGA,helper.OM1),maps[0],240)
            ok,exp,rounded=helper.matches_stored(evaluated,generated[kind][power][1],200)
            assert ok,(m['name'],power,'symbolic prefix mismatch',exp)
            symbolic_prefix_checks.append({'master_id':m['master_id'],'power':power,'algebraic_identity':exact_match,'checked_digits':200,'relative_error_exponent':exp})
        rows=[]
        for power in range(m['epsilon_range'][1]+1,finite_max[kind]+1):
            assert power not in dict(numeric) and power not in dict(symbolic)
            symbolic.append([power,generated[kind][power][0]]);numeric.append([power,generated[kind][power][1]])
            rows.append({'epsilon_power':power,'symbolic':True,'numerical':True,'significant_digits':200})
        if rows:
            updates.append((directory,symbolic,numeric));masters.append({'master_id':m['master_id'],'coefficients':rows})
    assert sum(len(m['coefficients']) for m in masters)==24
    receipt={'schema':'vakint.external-data.coefficient-supplement.v1','provenance':{
        'method':'Complete FMFT numerical-lhs inventory; all finite omitted data for PR1,PR2,PR3,PR6,PR8 verified through independent exact lower-loop factorizations',
        'source_sha256':{name:digest(src/name) for name in ['fmft_numerics.rs','matad.rs','matad_numerics.rs']},
        'known_consumer_limit':'PR3 consumer Oep(2) predates the existing PR3ep2 RHS; its T1ep4 dependency is resolved from the already available miT111 epsilon4 coefficient',
        'factorizations':factorizations,'graph_certificates':certificates,
        'validation':'200 digits verified through native-vs-legacy HPL data and existing direct MATAD tables; legacy FMFT epsilon2 RHS checked at its declared 50 digits; all 132 existing numerical and symbolic prefix coefficients retained and checked',
        'existing_exactness_upgrades':0,
        'existing_exactness_explanation':'All 22 factorized masters already contain complete exact formulas through epsilon1, including PR13; no numeric-only coefficient needs an exactness upgrade',
        'gamma_policy':'Only the bounded auxiliary normalized-Gamma expansion through epsilon7 required by finite inherited coefficients is used',
        'exporter_sha256':digest(pathlib.Path(__file__)),
    },'masters':masters}
    (work/'coefficient-supplement-four-loop.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    report={'passed':True,'elapsed_seconds':time.time()-start,'new_coefficients':24,'existing_exactness_upgrades':0,'prefix_checks':prefix_checks,'symbolic_prefix_checks':symbolic_prefix_checks,'epsilon2_checks':epsilon2_checks,'numerical_lhs_inventory':inventory,'master_availability_inventory':master_audit,'announced_tails':tails,'effective_tails':actual_tails}
    (work/'coefficient-supplement-four-loop-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    if args.write:
        for directory,symbolic,numeric in updates:
            (directory/'symbolic.json').write_text(json.dumps(sorted(symbolic),ensure_ascii=False,indent=2)+'\n')
            (directory/'numerical.json').write_text(json.dumps(sorted(numeric),ensure_ascii=False,indent=2)+'\n')
    print('PASS: complete38-lhs/74-master inventory;24 new coefficients;132prefixchecks;write=',args.write,flush=True)

if __name__=='__main__':main()
