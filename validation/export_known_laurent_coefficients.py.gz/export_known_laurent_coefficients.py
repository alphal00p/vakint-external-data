"""Extend only already-known finite MATAD-derived coefficients; never invoke FORM.

Runtime inputs and original coefficient bytes are archived by the data producer.
This development exporter derives the new orders from the retained exact MATAD
formulas and verifies them independently against its existing numerical table.
"""
import argparse,ast,decimal,gzip,hashlib,json,pathlib,re,time
from symbolica import E,Float

ROOT=pathlib.Path('/shared/codex-1/vakint_rustred')
SRC=ROOT/'gammaloop_vakint_rustred/crates/vakint/src'
DATA=ROOT/'vakint-external-data'
WORK=ROOT/'workspace/validation'
PAT=r'vk_parse!\("([^"]+)"\)\.unwrap\(\),\s*(?:\(\s*)?vk_parse!\("([^"]+)"\)'
EP=E('vakint::ep');OMEGA=E('(1+sqrt(3)*𝑖)/2');OM1=E('vakint::om1')

def native(text):
    return (text.replace('EulerGamma','symbolica::euler_gamma')
            .replace('Gamma(','symbolica::gamma(').replace('Zeta(','symbolica::zeta(')
            .replace('Sqrt(','symbolica::sqrt('))

def parse(text):return E(native(text),default_namespace='vakint')

def read_text(path):
    if path.exists():return path.read_text()
    with gzip.open(str(path)+'.gz','rt') as stream:return stream.read()

def text(value):
    return value.format(max_terms=None,max_line_length=None,color_top_level_sum=False,
                        color_builtin_symbols=False,bracket_level_colors=None,show_namespaces=True)

def coefficient_map(value,order):
    expanded=value.series(EP,0,order).to_expression().expand()
    monomials={EP**power:power for power in range(-32,order+1)}
    return {monomials[k]:v for k,v in expanded.coefficient_list(EP)}

def scalar(value,parameters,digits):
    x=value.evaluate(parameters,digits)
    assert abs(x.imag.to_decimal())<decimal.Decimal(10)**(-digits+8),str(x.imag)[:100]
    return x.real.to_decimal()

def matches_stored(value,stored,digits):
    old=decimal.Decimal(stored)
    with decimal.localcontext() as ctx:
        ctx.prec=max(digits+40,len(old.as_tuple().digits)+20)
        delta=abs(value-old)
        scale=abs(old) if old else decimal.Decimal(1)
        relative=delta/scale
        rounded=value.quantize(decimal.Decimal(1).scaleb(old.as_tuple().exponent))==old
        return relative<decimal.Decimal(10)**(-digits) or rounded,relative.adjusted(),rounded

def main():
    global SRC,DATA,WORK
    parser=argparse.ArgumentParser()
    parser.add_argument('--write',action='store_true')
    parser.add_argument('--vakint-source',type=pathlib.Path,default=SRC,help='Vakint src directory containing the authoritative MATAD tables')
    parser.add_argument('--data',type=pathlib.Path,default=DATA,help='External-data repository root')
    parser.add_argument('--validation',type=pathlib.Path,default=WORK,help='HPL reference/native-value files, plain or .gz, and validation output')
    args=parser.parse_args();SRC=args.vakint_source;DATA=args.data;WORK=args.validation
    start=time.time();source=(SRC/'matad.rs').read_text()
    exp=source[source.index('pub static MASTERS_EXPANSION'):source.index('pub static MASTERS_SUBSTITUTION')]
    sub=source[source.index('pub static MASTERS_SUBSTITUTION'):source.index('impl MATAD')]
    expansions=dict(re.findall(PAT,exp));substitutions=dict(re.findall(PAT,sub))
    direct=dict(re.findall(PAT,(SRC/'matad_numerics.rs').read_text()))
    def compact_gamma(value):
        value=re.sub(r'\s+','',value)
        for n in [2,3]:
            value=value.replace(f'exp({n}*ep*EulerGamma)*Gamma(1+ep)^{n}',f'Gam(1,1)^{n}')
        return value
    master_rules=[(parse(k),parse(compact_gamma(v))) for k,v in expansions.items()]
    value_rules=[(parse(k),parse(v)) for k,v in substitutions.items()]
    direct_rules_by_digits={}
    # Maximum required order is 4+3=7: the deepest pole is epsilon^-3.
    # Expand the exact normalized Gamma logarithm only to this bounded order.
    gamma_log='+'.join(f'({(-1)**n})*symbolica::zeta({n})/{n}*ep^{n}' for n in range(2,8))
    gamma_series=parse('exp('+gamma_log+')').series(EP,0,7).to_expression()
    gamma_rule=(parse('Gam(1,1)'),gamma_series)
    references=json.loads(read_text(WORK/'hpl-legacy-reference.json'))['entries']
    native_values={}
    for line in read_text(WORK/'hpl-values-20000.tsv').splitlines():
        word,real,imag=line.split('\t');native_values[tuple(ast.literal_eval(word))]=(real,imag)
    manifest=json.loads((DATA/'provenance/original-root/manifest.json').read_text())
    selected=[]
    for m in manifest['masters']:
        loop=m.get('loop_count');basis=m.get('exact_basis_expression','')
        if loop==2 and 'miT111' in basis:kind,known,digits='sunset',4,20000
        elif loop==3 and 'miD5' in basis:kind,known,digits='five_line',3,200
        elif loop==3 and 'miT111' in basis:kind,known,digits='sunset_times_tadpole',3,200
        elif loop==3 and 'miBN' in basis:kind,known,digits='four_line_miBN',4,200
        else:continue
        if m['epsilon_range'][1]<known:selected.append((m,kind,known,digits))
    generated={};checks=[];updates=[];supplement=[]
    for m,kind,known,digits in selected:
        key=(m['exact_basis_expression'],known,digits)
        if key not in generated:
            exact=parse(m['exact_basis_expression']);numerical=exact
            for lhs,rhs in master_rules:exact=exact.replace(lhs,rhs)
            if digits not in direct_rules_by_digits:
                direct_rules_by_digits[digits]=[(parse(k),parse(re.sub(r'`[0-9.]+',f'`{digits+80}.',v))) for k,v in direct.items()]
            for lhs,rhs in direct_rules_by_digits[digits]:numerical=numerical.replace(lhs,rhs)
            exact=exact.replace(*gamma_rule);numerical=numerical.replace(*gamma_rule)
            print('Expanding exact',kind,flush=True)
            exact_coeffs=coefficient_map(exact,known)
            print('Expanding numerical check',kind,flush=True)
            direct_coeffs=coefficient_map(numerical,known)
            maps=[]
            for native_source,work_digits in [(True,digits+24),(False,digits+48)]:
                parameters={}
                for entry in references:
                    word=tuple(entry['indices']);projection=0 if entry['projection']=='real' else 1
                    head='HR' if projection==0 else 'HI'
                    label=parse(head+'('+','.join(map(str,word))+',om1)')
                    value=native_values[word][projection] if native_source else entry['value']
                    parameters[label]=Float(value,decimal_digits=work_digits)
                maps.append(parameters)
            values={}
            for power,formula in exact_coeffs.items():
                if power>known:continue
                for lhs,rhs in value_rules:formula=formula.replace(lhs,rhs)
                formula=formula.expand()
                assert 'Oep' not in text(formula),(kind,power,'unsupported tail')
                a=scalar(formula,maps[0],digits+24)
                b=scalar(formula,maps[1],digits+48)
                c=scalar(direct_coeffs[power],{},digits+48)
                with decimal.localcontext() as ctx:
                    ctx.prec=digits+60
                    tolerance=decimal.Decimal(10)**(-digits)
                    scale=abs(b) if b else decimal.Decimal(1)
                    assert abs(a-b)<scale*tolerance,(kind,power,'HPL refinement disagreement')
                    assert abs(a-c)<scale*tolerance,(kind,power,'direct numerical-table disagreement')
                    values[power]=(text(formula.replace(OM1,OMEGA)),format(b,f'.{digits+8}e'))
            generated[key]=values
            print('Derived',kind,'through epsilon',known,'at',digits,'digits',flush=True)
        values=generated[key];directory=DATA/m['directory']
        symbolic=json.loads((directory/'symbolic.json').read_text());numerical=json.loads((directory/'numerical.json').read_text())
        previous_powers={p for p,_ in numerical}
        for power,stored in numerical:
            if power not in values:continue
            value=decimal.Decimal(values[power][1]);ok,exp,rounded=matches_stored(value,stored,min(digits,m['significant_digits']))
            assert ok,(m['name'],kind,power,'old prefix differs',exp)
            checks.append({'master_id':m['master_id'],'epsilon_power':power,'relative_error_exponent':exp,'rounded_literal_match':rounded})
        rows=[]
        for power in range(m['epsilon_range'][1]+1,known+1):
            assert power not in previous_powers,(m['name'],power,'already present; refusing duplicate')
            symbolic.append([power,values[power][0]]);numerical.append([power,values[power][1]])
            rows.append({'epsilon_power':power,'symbolic':True,'numerical':True,'significant_digits':digits})
        updates.append((directory,symbolic,numerical))
        supplement.append({'master_id':m['master_id'],'coefficients':rows})
    assert sum(len(m['coefficients']) for m in supplement)==25
    payload={'schema':'vakint.external-data.coefficient-supplement.v1','provenance':{
        'method':'Existing MATAD exact master expansions and master substitutions, including rational prefactors; independent DIRECT_SUBSTITUTIONS verification',
        'source_sha256':{name:hashlib.sha256((SRC/name).read_bytes()).hexdigest() for name in ['matad.rs','matad_numerics.rs']},
        'hpl_reference_sha256':hashlib.sha256(read_text(WORK/'hpl-legacy-reference.json').encode()).hexdigest(),
        'hpl_native_values_sha256':hashlib.sha256(read_text(WORK/'hpl-values-20000.tsv').encode()).hexdigest(),
        'precision_validation':'Native-HPL symbolic evaluation, higher-precision legacy-HPL evaluation, and existing direct MATAD numerical coefficients agree at every stated precision',
        'normalization_validation':'All existing numerical prefix coefficients checked before appending; original JSON payloads archived separately',
        'closed_form_gamma_policy':'No Gamma-only master coefficients exported; auxiliary exp(sum((-1)^n*zeta(n)*epsilon^n/n,n=2..7)) suffices for known epsilon^4 combined with pole order3',
        'exporter_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
    },'masters':supplement}
    (WORK/'coefficient-supplement.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    (WORK/'coefficient-supplement-validation.json').write_text(json.dumps({'passed':True,'new_coefficients':25,'updated_masters':len(updates),'elapsed_seconds':time.time()-start,'prefix_checks':checks},indent=2)+'\n')
    if args.write:
        for directory,symbolic,numerical in updates:
            (directory/'symbolic.json').write_text(json.dumps(sorted(symbolic),ensure_ascii=False,indent=2)+'\n')
            (directory/'numerical.json').write_text(json.dumps(sorted(numerical),ensure_ascii=False,indent=2)+'\n')
    print('PASS:',25,'new coefficients;',len(checks),'existing-prefix checks; write=',args.write,flush=True)

if __name__=='__main__':main()
