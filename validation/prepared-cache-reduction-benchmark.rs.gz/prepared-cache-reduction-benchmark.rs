//! Development-only timing probe; included only in the isolated unit-test build.
use crate::{EvaluationMethod, EvaluationOrder, LoopNormalizationFactor, RustRedEvaluationOptions,
    RustRedMasterMode, Vakint, VakintSettings, vakint_parse};
use std::{path::PathBuf, time::Instant};
use symbolica::atom::AtomCore;

#[test]
fn published_cache_reduction_timing() {
    let case = std::env::var("VAKINT_CACHE_BENCH_CASE").unwrap();
    let mode = std::env::var("VAKINT_CACHE_BENCH_MODE").unwrap();
    assert!(matches!(mode.as_str(), "cached" | "uncached"));
    let fields = case.split(':').collect::<Vec<_>>();
    let loops = fields[0].parse::<usize>().unwrap();
    let namespace = fields[1].parse::<usize>().unwrap();
    let power = fields[2].parse::<i64>().unwrap();
    let start = Instant::now();
    let engine = if loops == 4 { super::cache_tests::external_engine() } else { Vakint::new().unwrap() };
    if loops == 4 {
        let _ = super::four_loop::cache::programs(&engine).unwrap();
    } else {
        let family = super::artifact::shipped_family_for_loop_count(loops).unwrap();
        let _ = engine.rustred_data().unwrap().artifact(family).unwrap();
    }
    let input = if loops == 4 {
        let parents = super::four_loop::cache::parent_masks(&engine).unwrap();
        let mut powers = parents[namespace].1.iter().map(|p| i64::from(*p)).collect::<Vec<_>>();
        powers[0] = power;
        super::four_loop::cache::test_input(namespace, &powers, 1)
    } else {
        let text = match loops {
            1 => format!("topo(I1L(1,{power}))"),
            2 => format!("topo(I2L(1,{power},1,1))"),
            3 => format!("topo(I3L(1,{power},1,1,1,1,1))"),
            _ => unreachable!(),
        };
        vakint_parse!(&text).unwrap()
    };
    let setup_seconds = start.elapsed().as_secs_f64();
    let settings = VakintSettings {
        evaluation_order: EvaluationOrder(vec![EvaluationMethod::RustRed(RustRedEvaluationOptions {
            master_mode: RustRedMasterMode::Retain,
        })]),
        integral_normalization_factor: LoopNormalizationFactor::FMFTandMATAD,
        form_exe_path: "/cache-benchmark-must-not-use-form".into(),
        use_dot_product_notation: true,
        ..Default::default()
    };
    assert!(!engine.cache_statistics(loops).unwrap().attached);
    let start = Instant::now();
    if mode == "cached" {
        engine.load_cache(loops, PathBuf::from(std::env::var_os("VAKINT_TEST_EXTERNAL_DATA").unwrap())
            .join(format!("{loops}L/cache")), &Default::default()).unwrap();
    }
    let attach_seconds = start.elapsed().as_secs_f64();
    let ordinary_before = if loops == 4 { format!("{:?}", super::four_loop::cache::ordinary_statistics(namespace)) } else { String::new() };
    let start = Instant::now();
    let value = engine.evaluate_integral(&settings, input.as_view()).unwrap();
    let first_seconds = start.elapsed().as_secs_f64();
    let first_stats = engine.cache_statistics(loops).unwrap();
    let ordinary_after = if loops == 4 { format!("{:?}", super::four_loop::cache::ordinary_statistics(namespace)) } else { String::new() };
    let mut repeats = Vec::new();
    for _ in 0..3 {
        let start = Instant::now();
        let repeated = engine.evaluate_integral(&settings, input.as_view()).unwrap();
        repeats.push(start.elapsed().as_secs_f64());
        assert!((&value - repeated).expand().together().is_zero());
    }
    // Exact scientific parity is outside all recorded reduction timings.
    let parity = if mode == "cached" {
        let reference = if loops == 4 { super::cache_tests::external_engine() } else { Vakint::new().unwrap() };
        assert!(!reference.cache_statistics(loops).unwrap().attached);
        let expected = reference.evaluate_integral(&settings, input.as_view()).unwrap();
        assert!((&value - expected).expand().together().is_zero());
        true
    } else { false };
    if mode == "cached" && power <= 3 {
        assert!(first_stats.native.backing_hits > 0);
        assert_eq!(first_stats.native.work.rule_applications(), 0);
        if loops == 4 { assert_eq!(ordinary_before, ordinary_after); }
    }
    let result = serde_json::json!({
        "case": case, "mode": mode, "loops": loops, "namespace": namespace, "power": power,
        "input": input.to_string(), "setup_seconds": setup_seconds,
        "attach_seconds": attach_seconds, "first_reduction_seconds": first_seconds,
        "repeat_reduction_seconds": repeats, "exact_uncached_parity": parity,
        "prepared_entry_hits": first_stats.native.backing_hits,
        "prepared_descendant_hits": first_stats.native.descendant_backing_hits,
        "ram_hits_after_first": first_stats.native.ram_hits,
        "native_rule_applications": first_stats.native.work.rule_applications(),
        "ordinary_statistics_before": ordinary_before, "ordinary_statistics_after": ordinary_after,
        "scope": "fresh process per case/mode; setup/attachment and parity excluded; Retain; no FORM or numerical masters; OS page cache not flushed"
    });
    std::fs::write(std::env::var_os("VAKINT_CACHE_BENCH_RESULT").unwrap(), serde_json::to_vec_pretty(&result).unwrap()).unwrap();
    println!("PUBLISHED_CACHE_TIMING {result}");
}
