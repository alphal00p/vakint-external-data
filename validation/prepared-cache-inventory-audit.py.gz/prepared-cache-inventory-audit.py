"""Read-only inventory of published native cache containers and saved receipts."""
from pathlib import Path
import datetime, hashlib, json, subprocess

ROOT = Path('/shared/codex-1/vakint_rustred')
DATA = ROOT / 'vakint-external-data'
OUT = ROOT / 'workspace/validation/cache-delivery-summary'

class Index:
    def __init__(self, path):
        self.data = path.read_bytes()
        assert self.data[:16] == b'RR-CACHE-PACK-03'
        self.pos = 16
    def raw(self, n):
        result = self.data[self.pos:self.pos+n]
        assert len(result) == n
        self.pos += n
        return result
    def uint(self):
        tag = self.raw(1)[0]
        if tag < 251:
            return tag
        assert tag in (251, 252, 253, 254)
        return int.from_bytes(self.raw({251:2, 252:4, 253:8, 254:16}[tag]), 'little')
    def string(self):
        return self.raw(self.uint()).decode()
    def key(self):
        stage = self.uint()
        assert stage <= 2
        self.raw(self.uint())  # Vec<bool> owner support
        for _ in range(self.uint()):
            self.uint()  # zigzag-encoded powers need no algebra for this census
    def counts(self):
        self.raw(32)
        family = self.string()
        arity = self.uint()
        layer = self.string()
        assert self.raw(1)[0] in (0, 1)
        generation = self.uint()
        runs = self.uint()
        chunks = records = encoded = decoded = 0
        for _ in range(runs):
            for _ in range(self.uint()):
                self.raw(32)
                encoded += self.uint()
                self.raw(32)
                decoded += self.uint()
                count = self.uint()
                records += count
                chunks += 1
                self.key()
                self.key()
                tag = self.raw(1)[0]
                assert tag in (0, 1)
                if tag:
                    assert self.uint() == count
                    for _ in range(count):
                        self.uint()
        assert self.pos == len(self.data) - 32
        return dict(records=records, chunks=chunks, encoded_chunk_bytes=encoded,
                    decoded_chunk_bytes=decoded, runs=runs, generation=generation,
                    physical_arity=arity, layer=layer, family_fingerprint=family)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

release = json.loads((ROOT/'workspace/validation/external-data-release-validation.json').read_text())
loops = []
all_files = []
for count in range(1, 5):
    base = DATA / f'{count}L'
    manifest = json.loads((base/'manifest.json').read_text())
    metadata = json.loads((base/'cache.json').read_text())
    report = metadata['preparation_report']
    files = sorted(p for p in (base/'cache').rglob('*') if p.is_file())
    by_suffix = {}
    for path in files:
        rel = str(path.relative_to(base))
        info = manifest['files'][rel]
        assert path.stat().st_size == info['bytes']
        assert sha(path) == info['sha256']
        kind = 'native_chunk_gzip' if path.name.endswith('.rrchunk.gz') else 'native_binary_index'
        assert path.name.endswith('.rrchunk.gz') or path.name.endswith('.rrindex')
        by_suffix.setdefault(kind, {'files':0,'bytes':0})
        by_suffix[kind]['files'] += 1
        by_suffix[kind]['bytes'] += path.stat().st_size
        all_files.append({'loop_count':count, 'path':str(path.relative_to(DATA)),
                          'kind':kind, 'bytes':path.stat().st_size, 'sha256':info['sha256']})
    native_bytes = sum(p.stat().st_size for p in files)
    assert native_bytes == metadata['bytes']
    assert len(files) == metadata['files']
    assert len(files) == len(metadata['files_sha256'])
    bindings = []
    for binding in sorted((base/'cache/bindings').iterdir()):
        idx = binding/'cache.rrindex'
        census = Index(idx).counts()
        family_fingerprint = census.pop('family_fingerprint')
        family = [f for f in manifest['families'] if f['fingerprint'] == family_fingerprint]
        assert len(family) == 1
        census['family_aliases'] = family[0]['aliases']
        census['family_sha256'] = family[0]['sha256']
        chunk_files = list((binding/'chunks').glob('*.rrchunk.gz'))
        assert census['chunks'] == len(chunk_files)
        assert census['encoded_chunk_bytes'] == sum(p.stat().st_size for p in chunk_files)
        bindings.append({'binding_id':binding.name,
                         'index':str(idx.relative_to(DATA)),
                         'chunk_pattern':str((binding/'chunks/*.rrchunk.gz').relative_to(DATA)),
                         **census})
    records = sum(b['records'] for b in bindings)
    assert records == report['newly_stored_roots'] + report['newly_stored_intermediates']
    assert report['completed_roots'] == report['newly_stored_roots'] + report['reused_roots']
    asset = next(p for p in release['packs'] if p['loop_count']==count)
    archive = ROOT/'workspace/releases/v0.1.0'/asset['archive']
    assert archive.stat().st_size == asset['archive_bytes']
    assert sha(archive) == asset['archive_sha256']
    loops.append({'loop_count':count,'container':f'{count}L/cache',
                  'bundle_index':f'{count}L/cache/bundle.rrindex',
                  'metadata':f'{count}L/cache.json',
                  'native_files':len(files),'native_bytes':native_bytes,
                  'native_components':by_suffix,
                  'metadata_bytes':(base/'cache.json').stat().st_size,
                  'native_plus_metadata_bytes':native_bytes+(base/'cache.json').stat().st_size,
                  'bindings':bindings,
                  'status':report['status'],'selected_roots':report['total_roots'],
                  'completed_roots':report['completed_roots'],
                  'new_root_publications':report['newly_stored_roots'],
                  'selected_roots_reused_from_descendants':report['reused_roots'],
                  'new_intermediate_publications':report['newly_stored_intermediates'],
                  'native_index_record_count':records,
                  'records_outside_selected_primer':records-report['completed_roots'],
                  'capture_metadata_exhausted_roots':report['capture_metadata_exhausted_roots'],
                  'capture_native_skipped_records':report['capture_native_skipped_records'],
                  'preparation_seconds_native_report':report['elapsed_seconds'],
                  'producer_outer_elapsed_seconds':metadata['elapsed_seconds'],
                  'failure':report['failure'], 'checkpoint_failure':report['checkpoint_failure'],
                  'capture_metadata_limit_bytes_per_request':report['options']['capture_metadata_limit_bytes_per_request'],
                  'release_pack':asset,
                  'release_pack_note':'Whole loop pack: includes IBPs, masters, graphs, metadata and native cache; not a cache-only compression size.',
                  'cache_metadata_sha256':sha(base/'cache.json')})

head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=DATA,text=True).strip()
remote = subprocess.check_output(['git','rev-parse','origin/main'],cwd=DATA,text=True).strip()
assert head == remote
assert not subprocess.check_output(['git','status','--porcelain'],cwd=DATA)
summary = {
    'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'read_only':True,'new_reductions_or_cache_generation_performed':False,
    'external_repository':'https://github.com/alphal00p/vakint-external-data',
    'local_head':head,'local_tracking_origin_main':remote,
    'release_data_commit':release['source_commit'],'release':'v0.1.0',
    'immutable_release':release['immutable_release'],'latest_release':release['latest_release'],
    'loops':loops,
    'totals':{'native_bytes':sum(x['native_bytes'] for x in loops),
              'metadata_bytes':sum(x['metadata_bytes'] for x in loops),
              'native_files':sum(x['native_files'] for x in loops),
              'native_index_records':sum(x['native_index_record_count'] for x in loops)},
    'accounting':'Distinct published records are newly_stored_roots + newly_stored_intermediates. Reused selected roots already occur among earlier captured descendants; completed_roots + intermediates double-counts them.',
    'index_census':'Read-only independent Bincode-standard structural decode of every RR-CACHE-PACK-03 index. Consumed exactly all structural bytes, checked chunk counts and encoded sizes, and authenticated each native file against loop-manifest SHA256; no coefficient payload evaluation.',
    'workload':{'selector':'RustRedCacheWorkload::Primer (default)',
                'physical_supports':'all pinches of each authenticated physical parent support; auxiliary slots are never made positive',
                'max_extra_positive_powers_total_above_surviving_unit_lines':2,
                'max_numerator_rank_total_negative_power_degree':1,
                'intermediate_capture':True,
                'rationale':'Finite reusable operational primer covering ordinary unit/dotted/pinched roots and rank-one numerators. Native reductions publish complete guarded descendants along the paths they actually visit, so later roots and held-out inputs can use shortcut rules. It is not a rectangular campaign domain or a proof of stronger IBP coverage.',
                'coverage_claim':False},
    'drivers':{'release_cache_reproduction_example':'crates/vakint/examples/prepare_bundled_caches.rs',
               'reproduction_usage':'cargo run --release -p vakint --example prepare_bundled_caches -- LOOP NEW_OUTPUT_DIRECTORY [DATA_CHECKOUT]',
               'input_to_prepare_cache':'Loop count, output directory, default primer/storage options, cancellation flag and progress callback; no single hand-picked numerator/integral is used as the population workload.',
               'four_loop_data':'Current reproduction driver requires explicit external-data checkout for 4L.',
               'small_public_workflow_example':'crates/vakint/examples/native_cache.rs',
               'small_example_probes':{'prepared_root':'topo(I1L(4,3))','held_out_root':'topo(I1L(4,5))','reason':'The prepared root demonstrates a normal primer hit; the held-out higher power demonstrates explicit resident-overlay snapshot/reload. These probes are demonstrations after preparation, not the workload used to populate all released packs.'},
               'historical_producer':{'source_vakint_revision':json.loads((DATA/'1L/cache.json').read_text())['source_vakint_revision'],
                                      'rustred_revision':json.loads((DATA/'1L/cache.json').read_text())['RustRed_revision'],
                                      'producer_binary_sha256':json.loads((DATA/'1L/cache.json').read_text())['producer_binary_sha256'],
                                      'numerical_master_evaluation':False,
                                      'qualification':'Published cache.json receipts are the provenance for the generation run; current prepare_bundled_caches is the public reproduction driver, not a claim that its later Git path existed at that historical source revision.'}},
    'limitations':['One 4L selected root exhausted optional intermediate metadata capture; every selected root is nevertheless complete and failure/checkpoint_failure are null.',
                   'Caches contain strict complete guarded reductions, not numerical master values or a certification of arbitrary-index closure.',
                   '5L has no prepared cache in the initial release.'],
    'speedup':'Root is independently auditing measured benchmark results; no speedup is inferred from preparation durations or file sizes.'}
# Keep the two independent orderings explicit: namespaces are runtime owners,
# while manifests list data families in their publication order.
source_rows = []
for namespace, name in enumerate(['h', 'fg', 'bmw', 'x']):
    csv = DATA / '4L/ibps' / (name + '.csv')
    rows = [list(map(int, line.strip().split(',')))
            for line in csv.read_text().splitlines()
            if line.strip() and not line.strip().startswith('#')]
    physical = [i for i, row in enumerate(rows) if row[:2] != [0, 0]]
    source_rows.append({'runtime_namespace': namespace, 'name': name.upper(),
                        'csv': str(csv.relative_to(DATA)), 'sha256': sha(csv),
                        'physical_lines': len(physical),
                        'physical_slots_zero_based': physical,
                        'auxiliary_slots_zero_based': [i for i in range(len(rows)) if i not in physical]})
summary['workload']['four_loop_runtime_namespaces'] = source_rows
summary['workload']['four_loop_manifest_family_array_order'] = ['h', 'x', 'bmw', 'fg']
summary['workload']['ordering_note'] = 'Runtime namespace order h,fg,bmw,x is defined by FourLoopPrograms::load; manifest family-array order h,x,bmw,fg is not runtime order. Cache bindings here are associated by exact family fingerprint, not array position.'
summary['workload']['source_evidence'] = {
    'runtime_order': 'crates/vakint/src/rustred_evaluation/four_loop.rs:80',
    'physical_masks': 'crates/vakint/src/rustred_evaluation/four_loop/cache.rs:39',
    'physical_count_assertion': 'crates/vakint/src/rustred_evaluation/four_loop/cache.rs:149'}
summary['size_conventions'] = 'Primary bytes are exact logical file lengths matching authenticated manifests. Additional allocated-byte fields sum POSIX st_blocks*512 for this checkout filesystem, not deduplicated physical storage or RAM.'
for loop in summary['loops']:
    base = DATA / f"{loop['loop_count']}L"
    loop['native_allocated_bytes_posix_st_blocks'] = sum(p.stat().st_blocks*512 for p in (base/'cache').rglob('*') if p.is_file())
    loop['metadata_allocated_bytes_posix_st_blocks'] = (base/'cache.json').stat().st_blocks*512
    loop['release_pack_allocated_bytes_posix_st_blocks'] = (ROOT/'workspace/releases/v0.1.0'/loop['release_pack']['archive']).stat().st_blocks*512
summary['remote_main_verified'] = subprocess.check_output(['git', 'ls-remote', 'origin', 'refs/heads/main'], cwd=DATA, text=True).split()[0]
assert summary['remote_main_verified'] == head
summary['drivers']['small_example_probes']['power_rationale'] = 'I1L uses the same mass label4 in both probes: power3 lies inside the1L two-extra-dots primer; power5 deliberately lies outside. These expressions are evaluated after prepare_cache, not passed as its workload.'

(OUT/'cache-inventory.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'native-cache-file-inventory.json').write_text(json.dumps(all_files,indent=2)+'\n')
for x in loops:
    print(x['loop_count'],x['native_bytes'],x['metadata_bytes'],x['native_index_record_count'],x['records_outside_selected_primer'],x['release_pack']['archive_bytes'])
print('summary_sha256',sha(OUT/'cache-inventory.json'))
