#!/usr/bin/env python3
"""Separate PR9 higher-guard source and complete matching certificate."""
import argparse,json,sys,time
from pathlib import Path
from flint import arb,ctx
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from endpoint_sources import load_native_endpoints,sha
from pr9_source_recipes import build
from three_loop_boundary import load_plan,sparse,dot,key,ANCESTOR
from source_recipes import read
from logjet_map import FactorJet
from expanded_boundary import ExpandedBoundary

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--three-loop-input',required=True);ap.add_argument('--three-loop-sha256',required=True)
    ap.add_argument('--sunset-input',required=True);ap.add_argument('--sunset-sha256',required=True)
    ap.add_argument('--working-digits',type=int,default=20800);ap.add_argument('--maximum-error-power',type=int,default=20550);ap.add_argument('--output-prefix',required=True);a=ap.parse_args()
    if not __debug__:raise RuntimeError('Source acceptance requires assertions enabled')
    prefix=Path(a.output_prefix)
    if any(prefix.with_suffix(s).exists() for s in ['.json','.guard-validation.json']):raise ValueError('Preserve all existing higher-guard artifacts')
    if a.working_digits<a.maximum_error_power+40:raise ValueError('A fixed arithmetic guard is required')
    ctx.dps=a.working_digits;ctx.threads=1;start=time.monotonic()
    primitives,source=load_native_endpoints(a.three_loop_input,a.three_loop_sha256,{'native::L3_P13':(-3,2),'native::L3_P14':(-3,2)})
    sunset=Path(a.sunset_input)
    if sha(sunset)!=a.sunset_sha256:raise ValueError('Higher-guard sunset checksum mismatch')
    s=read(sunset)
    if s['error_quality']!='rigorous-bound' or s['validated_analytic_truncation_and_rounding'] is not True:raise ValueError('A bounded accepted sunset source is required')
    rows=s['coefficients']['native_raw']
    if [r['epsilon_power'] for r in rows]!=list(range(-2,4)):raise ValueError('Six contiguous sunset raw orders required')
    values=tuple(arb(r['ball']) for r in rows)
    if any(not v.is_finite() for v in values):raise ValueError('Nonfinite sunset source enclosure')
    primitives['native::L2_P2']=FactorJet(-2,values,'Unchanged accepted exact sunset recurrence/Cauchy proof at higher precision','native::L2_P2; '+a.sunset_sha256)
    factors,recipe=build();matching=read(ANCESTOR/'pr9-22-matching.json');inventory=HERE.parent/'pr9-22-inventory.json'
    plan=load_plan(inventory,matching['inventory_sha256'],'masters_4l::{}::epsilon');compiled=ExpandedBoundary(plan,factors,max_log_power=matching['max_exact_log_degree'])
    required,_=compiled.required_primitive_orders(primitives,last_epsilon_power=1);raw=compiled.evaluate(primitives,first_epsilon_power=-4,last_epsilon_power=1)
    values={}
    for (i,alpha,p,l),v in raw.items():
        if alpha.denominator!=1:raise ValueError('Noninteger regional source power')
        values[i,int(alpha),p,l]=v
    labels=matching['all_boundary_selectors'];keys=[key(r) for r in labels];wanted=set(keys)
    for k,v in values.items():
        if k not in wanted and not v.contains(0):raise ValueError('Forbidden prepared source support '+str(k))
    rhs=[values[key(r)] for r in matching['selected_selectors']];constants=[dot(r,rhs) for r in sparse(matching['boundary_inverse'])]
    for k,row in zip(keys,sparse(matching['all_boundary_matrix'])):
        if not (dot(row,constants)-values[k]).contains(0):raise ValueError('Inconsistent higher-guard PR9source '+str(k))
    maximum=max(v.rad() for v in constants)
    if not maximum.upper()<(arb(10)**-a.maximum_error_power).lower():
        raise ValueError('Measured source/matching error lacks required guard: '+maximum.str(35))
    sourcefiles=[Path(__file__),HERE/'api_native_bridge.py',HERE.parent/'endpoint_sources.py',HERE.parent/'pr9_source_recipes.py']
    payload={'schema':'vakint.pr9.higher-guard-complete-source-boundary.v1','normalization':'native_raw','error_quality':'rigorous-bound','inventory_sha256':sha(inventory),
      'matching_sha256':sha(ANCESTOR/'pr9-22-matching.json'),'coefficient_count':len(keys),'free_constants':132,'working_decimal_digits':a.working_digits,
      'source_recipe_receipt':recipe,'primitive_provenance':[source,{'source':str(sunset.resolve()),'sha256':a.sunset_sha256,'error_quality':'rigorous-bound','normalization':'native_raw'}],
      'required_raw_primitive_through':required,'coefficients':[{**label,'real_ball':values[k].str(a.working_digits+12,more=True)} for label,k in zip(labels,keys)],
      'free_constant_balls':[v.str(a.working_digits+12,more=True) for v in constants],'all_prepared_rows_checked':True,'all_overdetermined_residuals_contain_zero':True,
      'maximum_constant_radius':maximum.upper().str(45,more=True),'source_error_guard_power':a.maximum_error_power,'wall_seconds':time.monotonic()-start,
      'implementation_sha256':{str(p):sha(p) for p in sourcefiles},'scientific_whole_master_accuracy_claimed':False}
    out=prefix.with_suffix('.json');out.write_text(json.dumps(payload,indent=2)+'\n')
    receipt={'schema':'vakint.pr9.higher-guard-source-acceptance.v1','accepted':True,'boundary_sha256':sha(out),'source':source,
      'sunset_sha256':a.sunset_sha256,'all557rows_consistent':True,'all132constants_finite':all(v.is_finite() for v in constants),
      'maximum_constant_radius':payload['maximum_constant_radius'],'source_error_guard_power':a.maximum_error_power,'working_decimal_digits':a.working_digits,
      'producer_sha256':sha(Path(__file__)),'whole_PR11d_accuracy_claimed':False}
    prefix.with_suffix('.guard-validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('ACCEPTED:557rows/132constants; maximumradius',payload['maximum_constant_radius'],'seconds',time.monotonic()-start,flush=True)
if __name__=='__main__':main()
