#!/usr/bin/env python3
"""Coherent exact source registry for the 324 native regional factors.

This optional development registry reuses authenticated native admissions and
independently derived helper reductions. No master value is evaluated here.
"""
import hashlib,json
from fractions import Fraction
from pathlib import Path
from gamma_ast import GammaExpression,Monomial,from_basis_expression
from gamma_jets import GammaRecipe,GammaArgument,tadpole,radial,Rat,rat,E
from logjet_map import parse,EPS

HERE=Path(__file__).resolve().parent
HELPER=HERE.parent.parent/'pr11d/numerator-helper'

def read(path):return json.loads(path.read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def primitive(name):return GammaExpression([Monomial(Rat(1),(),(name,))],identity=name)
def gamma_expression(recipe):return GammaExpression([Monomial(recipe.prefactor,recipe.gammas)],identity=recipe.identity)
def polynomial(values):return sum((rat(Fraction(c))*E**i for i,c in enumerate(values)),Rat(0))

def build_factor_expressions():
    inputs=[HERE/'factor-requests.json',HERE/'factor-singlemass.json',HERE/'factor-products.json',
      HELPER/'massless-followup/all-212-trees.json',HELPER/'massless-followup/product-seeds/bindings.json',
      HELPER/'scalar-followup/all-ten-bindings.json',HELPER/'corrected-v2/exact-reductions.json']
    requests=read(inputs[0])['factor_requests'];request_by_key={r['factor_key']:r for r in requests}
    assert len(request_by_key)==324
    children_data=read(inputs[3]);children={}
    assert children_data['source_sha256']==sha(HERE/'massless-child-requests.json')
    for row in children_data['children']:
        key=row['child_key']
        if key in children:raise ValueError('Duplicate child source identity')
        if row['raw_native_minkowski_signs_included'] is not True:raise ValueError('Missing raw-native child convention')
        children[key]=GammaExpression.from_tree(row['expression'],identity=key)
    assert len(children)==212
    out={};counts={}
    def insert(key,value,category):
        if key in out or key not in request_by_key:raise ValueError('Duplicate or unrequested native source '+key)
        out[key]=value;counts[category]=counts.get(category,0)+1
    for row in read(inputs[1])['proofs']:
        proof=row['proof'];key=row['factor_key'];status=proof['status']
        if status=='actual_native_single_mass_plan_proved':
            insert(key,children[proof['child_key']].multiply_recipe(radial(proof)),'single_mass')
        elif status=='existing_one_loop_tadpole_terminal_shape_proved':
            source=request_by_key[key]
            assert source['loops']==1 and len(source['powers'])==1
            insert(key,gamma_expression(tadpole(source['powers'][0])),'tadpole')
    seed_data=read(inputs[4]);seeds={}
    assert seed_data['source_sha256']==sha(HERE/'factor-products.json')
    for row in seed_data['seeds']:
        definition=row['definition'];fields=seed_data['definition_fields']
        canonical=json.dumps({k:definition[k] for k in fields},sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
        assert hashlib.sha256(canonical).hexdigest()==row['definition_sha256']
        if row['label'] in ['T1','T2']:
            expr=gamma_expression(tadpole(int(row['label'][1:])))
        else:
            ev=row['evaluation'];expr=primitive(f"native::L{ev['catalog_loop_count']}_{ev['catalog_name']}").scale(polynomial(ev['coefficient_epsilon_polynomial']))
        seeds[row['definition_sha256']]=expr
    product_source=read(inputs[2])['proofs']
    for row in seed_data['products']:
        original=product_source[row['source_proof_index_zero_based']]
        assert original['factor_key']==row['factor_key'] and original['proof']['status']=='native_vacuum_product_proved'
        expr=GammaExpression([Monomial(parse(row['coefficient'],'masters_4l::{}::epsilon','unused_eta'))],identity='native vacuum product coefficient')
        assert len(original['proof']['factors'])==len(row['ordered_seed_definition_sha256'])
        for definition,key in zip(original['proof']['factors'],row['ordered_seed_definition_sha256']):
            canonical=json.dumps({k:definition[k] for k in seed_data['definition_fields']},sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
            assert hashlib.sha256(canonical).hexdigest()==key
            expr=expr.multiply(seeds[key])
        insert(row['factor_key'],expr,'product')
    scalar=read(inputs[5])
    for row in scalar['bindings']:
        key=row['factor_key'];loops=row['loop_count']
        if 'catalog_master' in row:
            cat=row['catalog_master']
            if loops==4:expr=from_basis_expression(cat['exact_basis_expression'])
            else:expr=primitive(f"native::L{loops}_{cat['name']}")
        else:
            assert loops==3
            expr=primitive('native::L3_'+row['catalog']).scale(polynomial(row['coefficient_epsilon_polynomial']))
        insert(key,expr,'connected_scalar')
    numerator=read(inputs[6]);by_prefix={r['key'][:8]:r['key'] for r in numerator['reductions']}
    T1=gamma_expression(tadpole(1));T1sq=T1.multiply(T1);T1cube=T1sq.multiply(T1)
    B=primitive('native::L3_P13');S=primitive('native::L2_P2')
    zero=GammaExpression([],identity='exact odd-tadpole zero')
    recipes={
      '137be97d':zero,
      '461349f3':T1sq.scale(-(Rat(1)-E)),
      'bf5a7d9c':B.scale(E/rat(4)).add(T1cube.scale(-(Rat(1)-E)/rat(2))),
      'f868af0f':T1.multiply(S).add(T1cube).scale(-(Rat(1)-E)),
    }
    normalized44=GammaRecipe(-E*(Rat(1)-E)**4/(rat(4)*(Rat(1)+E)*(rat(2)+E)),
      [GammaArgument(1,-1,2),GammaArgument(1,2,1),GammaArgument(1,3,1),GammaArgument(1,1,-3)],identity='authenticated numerator44/T1^3 Gamma identity')
    normalized94=GammaRecipe((Rat(1)-E)**4/(rat(6)*(Rat(1)-rat(2)*E)),
      [GammaArgument(1,-1,3),GammaArgument(1,-3,1),GammaArgument(1,3,1),GammaArgument(1,1,-1),GammaArgument(1,-2,-2)],identity='authenticated numerator94/T1^3 Gamma identity')
    recipes['44b30383']=gamma_expression(normalized44).multiply(T1cube)
    recipes['94bf9416']=gamma_expression(normalized94).multiply(T1cube)
    for prefix,expr in recipes.items():insert(by_prefix[prefix],expr,'rank_one_numerator')
    assert set(out)==set(request_by_key)
    assert counts=={'single_mass':286,'tadpole':3,'product':19,'connected_scalar':10,'rank_one_numerator':6}
    return out,{'counts':counts,'source_sha256':{str(p):sha(p) for p in inputs},'normalization':'Every recipe is raw native Minkowski; primitive inputs must use the same convention; no Euler conversion occurs here.'}

if __name__=='__main__':
    expressions,receipt=build_factor_expressions()
    receipt['distinct_primitive_ids']=sorted({p for e in expressions.values() for _,_,keys in e.terms for p in keys})
    (HERE/'source-recipes-preflight.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('Complete exact factor registry:',receipt['counts']);print('Primitive sources:',receipt['distinct_primitive_ids'])
