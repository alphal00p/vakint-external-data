#!/usr/bin/env python3
"""Exact complete231factor source registry for the PR9 ancestor hierarchy."""
import json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'pr11-boundary'))
from source_recipes import build_factor_expressions,gamma_expression,HELPER,read,sha
from gamma_jets import tadpole,radial
from gamma_ast import GammaExpression,Monomial
from logjet_map import parse,EPS
NEW=HELPER/'ancestor-followup'

def build():
    old,old_receipt=build_factor_expressions();requested={r['key']:r for r in read(HERE/'pr9-22-inventory.json')['factors']}
    out={k:old[k] for k in requested if k in old};children={};source_paths=[]
    for path,field in [(HELPER/'massless-followup/all-212-trees.json','expression'),(HERE/'massless-one-two-loop/exact-trees.json','exact_tree'),(NEW/'all-109-three-loop-trees.json','expression')]:
        source_paths.append(path)
        for row in read(path)['children']:children[row['child_key']]=GammaExpression.from_tree(row[field],identity=row['child_key'])
    for row in read(HERE/'pr9-22-singlemass.json')['proofs']:
        key=row['factor_key'];proof=row['proof']
        if key in out:continue
        if proof['status']=='actual_native_single_mass_plan_proved':out[key]=children[proof['child_key']].multiply_recipe(radial(proof))
        elif proof['status']=='existing_one_loop_tadpole_terminal_shape_proved':
            source=requested[key];assert source['family']['propagators']==[{'constant':'-1','scalar_products':['1']}]
            out[key]=gamma_expression(tadpole(source['powers'][0]))
    seeds_path=NEW/'product-seed-bindings.json';source_paths.append(seeds_path);seeds=read(seeds_path)
    assert seeds['source_sha256']==sha(HERE/'pr9-22-products.json')
    by_hash={s['definition_sha256']:GammaExpression.from_tree(s['expression'],identity=s['definition_sha256']) for s in seeds['seeds']}
    for row in seeds['products']:
        key=row['factor_key']
        if key in out:continue
        coefficient=row['native_coefficient'].replace('rustred::{}::d','(4-2*'+EPS+')')
        expr=GammaExpression([Monomial(parse(coefficient,EPS,'unused'))],identity='native vacuum product coefficient')
        for h in row['seed_definition_hashes']:expr=expr.multiply(by_hash[h])
        out[key]=expr
    for name in ['all-19-numerator-trees.json','all-scalar-trees.json']:
        path=NEW/name;source_paths.append(path)
        for row in read(path)['factors']:
            key=row['factor_key']
            if key not in requested:continue
            expr=GammaExpression.from_tree(row['expression'],identity=key)
            if key in out:
                from gamma_jets import rat
                difference=out[key].add(expr.scale(rat(-1)))
                if difference.terms:raise ValueError('Conflicting exact source admissions for '+key)
            else:out[key]=expr
    missing=set(requested)-set(out)
    if missing:raise ValueError('Missing exact PR9source recipes '+','.join(sorted(missing)))
    assert len(out)==231
    return out,{'schema':'vakint.pr9.complete-source-recipes.v1','factor_count':231,'source_sha256':{str(p):sha(p) for p in source_paths},'X8_source_receipt':old_receipt,
      'inventory_sha256':sha(HERE/'pr9-22-inventory.json'),'native_singlemass_sha256':sha(HERE/'pr9-22-singlemass.json'),'native_products_sha256':sha(HERE/'pr9-22-products.json'),'primitive_ids':sorted({p for expr in out.values() for _,_,keys in expr.terms for p in keys}),'normalization':'raw_native_no_Euler'}

if __name__=='__main__':
    out,receipt=build();(HERE/'pr9-source-recipes-preflight.json').write_text(json.dumps(receipt,indent=2)+'\n');print('Complete231factor registry; primitives',receipt['primitive_ids'])
