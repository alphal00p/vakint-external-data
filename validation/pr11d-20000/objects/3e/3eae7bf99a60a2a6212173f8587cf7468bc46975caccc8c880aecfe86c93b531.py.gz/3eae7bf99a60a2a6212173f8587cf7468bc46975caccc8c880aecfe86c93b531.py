#!/usr/bin/env python3
"""Exact schema conversion from reviewed X8 simple/double-pole residues to RPF."""
from pathlib import Path
from fractions import Fraction as Q
from math import lcm
import hashlib,json
from flint import fmpq_poly,fmpq
HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
if not __debug__:raise RuntimeError('Exact verification requires assertions')
def q(v):
 value=Q(v);return fmpq(value.numerator,value.denominator)
def main():
 source=HERE/'partial-fractions-regular-gauge.json';polynomial=HERE/'polynomial-connection-regular-gauge.json'
 pf=json.loads(source.read_text());original=json.loads(polynomial.read_text());assert pf['source_polynomial_connection_sha256']==sha(polynomial)
 assert pf['dimension']==original['dimension']==42 and pf['epsilon_jet_count']==original['epsilon_jet_count']==6
 assert pf['regular_epsilon_gauge']==original['regular_epsilon_gauge'];assert pf['all_exact_polynomial_reconstruction_identities_verified']
 factors=[{'index':i,'coefficients':[str(-p['location']),'1'],'maximum_power':p['maximum_order']} for i,p in enumerate(pf['poles'])];indices={p['location']:i for i,p in enumerate(pf['poles'])}
 assert len(indices)==len(factors)==6 and all(f['maximum_power'] in (1,2) for f in factors)
 D=fmpq_poly([q(s) for s in original['denominator_coefficients']]);expected={}
 for entry in original['entries']:
  key=(entry['row'],entry['column'],entry['epsilon_power']);assert key not in expected
  terms=[fmpq(0)]*(original['numerator_degree']+1)
  for t in entry['terms']:terms[t['eta_power']]+=fmpq(int(t['numerator']),int(t['denominator']))
  expected[key]=fmpq_poly(terms)
 entries=[];seen=set();term_count=0;denominators=[]
 for entry in pf['residue_entries']:
  key=(entry['row'],entry['column'],entry['epsilon_power']);assert key not in seen and key in expected;seen.add(key);reconstructed=fmpq_poly([]);terms=[];constant=Q(0)
  for t in entry['terms']:
   pole,order,value=t['pole'],t['pole_order'],Q(t['value']);denominators.append(value.denominator);term_count+=1
   if pole is None:
    assert order==0;constant+=value;reconstructed+=D*q(value);continue
   factor=fmpq_poly([-pole,1])**order;quotient,remainder=divmod(D,factor)
   assert not remainder and order<=factors[indices[pole]]['maximum_power'];reconstructed+=quotient*q(value)
   terms.append({'factor_index':indices[pole],'factor_power':order,'numerator_coefficients':[str(value)]})
  assert reconstructed==expected[key],('Exact rational entry mismatch',key)
  entries.append({'row':key[0],'column':key[1],'epsilon_power':key[2],'polynomial_part':[str(constant)] if constant else [],'terms':terms})
 assert seen==set(expected) and len(entries)==648 and term_count==2088
 result={'schema':'vakint.pr11d.rational-PF-schema-conversion.v1','source_polynomial_connection_sha256':sha(polynomial),'source_linear_double_PF_sha256':sha(source),'dimension':42,'epsilon_jet_count':6,'denominator_factors':factors,'entries':entries,'all_exact_polynomial_reconstruction_identities_verified':True,'common_rational_residue_denominator':str(lcm(*denominators)),'maximum_polynomial_part_degree':0 if any(e['polynomial_part'] for e in entries) else -1,'native_evaluator_available':True,'regular_epsilon_gauge':original['regular_epsilon_gauge'],'converter_sha256':sha(Path(__file__)),'scope':'Exact representation conversion only: every one of648 rational epsilon-jet entries reconstructed against original D,N;2088 unchanged residues. No numerical value or precision promotion.'}
 output=HERE/'x8-ordinary-rational-pf.json'
 with output.open('x') as stream:stream.write(json.dumps(result,indent=2)+'\n')
 print('X8 RPFexactconversion PASS648entries/2088residues')
if __name__=='__main__':main()
