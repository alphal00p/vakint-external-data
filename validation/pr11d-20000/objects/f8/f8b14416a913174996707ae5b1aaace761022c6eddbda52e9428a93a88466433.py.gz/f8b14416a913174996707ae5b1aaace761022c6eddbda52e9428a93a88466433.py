#!/usr/bin/env python3
"""Fail-closed production-B aggregate; reads reviewed saved artifacts only."""
from pathlib import Path
import argparse,hashlib,json,sys
from flint import arb,acb,ctx
if not __debug__:raise RuntimeError('Assertions required')
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
INITIAL=ROOT/'helper/frobenius-transport/pr9-API20600-eta256-guard20500-v1.json'
ENDPOINT=ROOT/'hierarchy-transport/pr9-production-B-endpoints.json'
CHAIN=ROOT/'hierarchy-transport/pr9-production-API20600-substeps3-v9'
INITIAL_SHA='cdfe1cd91fa448fd6d65352689c170a7f52c538097b68ad9784bdf61bfafcf87'
ENDPOINT_SHA='4f905a9a27d3b756cc551cff0ed893d1448e71dff9578d4143998578aebfbba2'
END_REVIEW=HERE/'endpoint-review/review.json'
PINS={}
RELOCATIONS={}
def require(condition,message):
 if not condition:raise ValueError(message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pin(path,digest=None):
 path=Path(path).resolve();actual=sha(path);require(digest is None or actual==digest,'Changed artifact '+str(path));require(str(path) not in PINS or PINS[str(path)]==actual,'Conflicting pin '+str(path));PINS[str(path)]=actual;return path
def read(path,digest=None):return json.loads(pin(path,digest).read_text())
def merge(d):
 for path,digest in d.items():
  original=str(Path(path).resolve())
  if original in RELOCATIONS:
   replacement,expected=RELOCATIONS[original]
   require(digest==expected,'Unreviewed hash in canonical snapshot relocation')
   pin(replacement,digest)
  else:pin(path,digest)
def write(path,data):
 with path.open('x') as stream:json.dump(data,stream,indent=2);stream.write('\n')

def certificate_gates(chain,end,initial,fresh):
 require(chain['accepted_for_ordinary_chain_data'] is True,'Ordinary-chain review not accepted')
 require(chain['steps_verified']==36 and [s['index'] for s in chain['steps']]==list(range(36)),'Incomplete ordinary chain')
 require(chain['initial_artifact_sha256']==INITIAL_SHA and chain['endpoint_artifact_sha256']==ENDPOINT_SHA,'Chain endpoints mismatch')
 require(chain['input_full_complex_box_containments']==chain['output_full_complex_box_containments']==4752,'Incomplete boundary preservation')
 require(chain['all_step_outward_driver_serializations_byte_identical'] is True and chain['all_constant_scalings_masks_row_aggregations_schedules_and_worker_profiles_verified'] is True,'Unverified ordinary conversions/profile')
 require(chain['all_final_component_radii_meet_target'] is True and chain['final_required_absolute_digits']==20250,'Unaccepted ordinary final width')
 require(end['accepted'] is True and end['endpoint_payload_sha256']==ENDPOINT_SHA,'Endpoint review not accepted')
 require(end['terminal_boundary_sha256']==chain['steps'][-1]['boundary_sha256'],'Projection is not on the admitted terminal')
 require(end['all_seven_canonical_name_edges_closed'] is True and len(end['canonical_mapping_checks'])==7 and all(v['canonical_name_edge_closed'] is True for v in end['canonical_mapping_checks']),'Missing canonical physical identity')
 require({v['symbol'] for v in end['canonical_mapping_checks']}=={'native::PR3','native::PR4','native::PR4d','native::PR5','native::PR7','native::PR9','native::PR9d'},'Missing or duplicate canonical target name')
 require(end['coefficient_count']==42 and end['all42_full_complex_ball_convolutions_contained'] is True and end['original20400digit_projection_and20408digit_strings_byte_identical'] is True,'Incomplete projection replay')
 require(end['all42_strict_total_l1_radii_and_diameters_below_1e_minus20000'] is True,'Endpoint total widths unaccepted')
 require(initial['accepted'] is True and initial['accepted_source_seed_and_initial_output'] is True,'Initial source/seed/output not independently admitted')
 require(initial['accepted_for_physical_source_and_freshly_replayed_INIT_contract'] is True,'Initial physical scope not admitted')
 for field,wanted in [('dimension',132),('boundary_row_count',557),('native_working_bits',69429),('native_local_tail_target_digits',20600),('saved_native_accepted_order',17000),('absolute_INIT_radius_target_digits',20500),('source_working_decimal_digits',20800),('source_outward_row_strings_replayed_exactly',557),('source_outward_matched_constant_strings_replayed_exactly',132),('complete_exact_rational_source_boxes_contained_by_actual_native_seeds',132),('native_seed_strings_and_binary_midpoint_radius_replayed_exactly',132),('saved_J_and_Y_complex_boxes_below_absolute_radius_target',264),('wrapper_preserves_full_native_Y_decimal_boxes_exactly',132)]:
  require(type(initial[field]) is int and initial[field]==wanted,'Initial coverage/profile mismatch '+field)
 require(initial['source_error_quality']=='rigorous-bound','Initial source quality mismatch')
 require(initial['source_boundary_sha256']=='217596105b32c1e49a104489db6d2811a9dacf97af3a6daacd4756b08b412838','Initial source boundary mismatch')
 for field in ['source_row_assembly_replayed','native_engine_freshly_replayed_same_saved_input','all_528_fresh_native_outward_scalar_strings_equal_original','whole_output_bytes_identical_after_replacing_only_five_telemetry_fields','all_certificate_log_fields_equal_except_elapsed_seconds']:
  require(initial[field] is True,'Initial review lacks '+field)
 require(initial['wrapper_sha256']==INITIAL_SHA,'Initial review binds another wrapper')
 require(initial['native_input_sha256']=='4bc6ce44b56b1ac828ff7f74c6444f770ef700cf19eeb332dff50c5267c2bebf','Initial native input mismatch')
 require(initial['native_output_sha256']=='3d03bb5deba210cb61b6dc1beb33a27bf0ee240a77407535c3f9b4f17b9f7955','Initial native output mismatch')
 require(fresh['accepted'] is True and type(fresh['returncode']) is int and fresh['returncode']==0 and fresh['timed_out'] is False,'Fresh initial invocation not successfully accepted')
 require(fresh['all_original_inputs_sources_and_outputs_unchanged'] is True,'Fresh invocation pins changed')
 comparison=fresh['comparison']
 for field in ['all_numerical_and_semantic_fields_exactly_equal','all_certificate_log_fields_exact_except_elapsed_seconds','all_528_scalar_outward_strings_identical','local_tail_certified']:require(comparison[field] is True,'Fresh invocation failed '+field)
 require(comparison['accepted_order']==17000,'Fresh initial accepted order mismatch')
 require(fresh['pre_artifact_sha256']['input']['sha256']==initial['native_input_sha256'] and fresh['pre_artifact_sha256']['original_output']['sha256']==initial['native_output_sha256'] and fresh['pre_artifact_sha256']['wrapper']['sha256']==INITIAL_SHA,'Fresh invocation does not close admitted initial')
 require(fresh['pre_artifact_sha256']['binary']['sha256']=='ff3d297816b301c010fb8ee4645207ecdec0f74cf8e7a8678b678d5bfb3175c3','Fresh invocation used another native engine')
 return True

def invocation_binding_gates(initial,fresh,start):
 require(start['actual_proc_command_matches'] is True and start['proc_executable_sha256']==fresh['pre_artifact_sha256']['binary']['sha256'],'Direct execution identity absent')
 require(start['pre_artifact_sha256']==fresh['pre_artifact_sha256'],'Invocation start/end artifact sets differ')
 require(type(fresh['command']) is list and len(fresh['command'])==3,'Native argv shape mismatch')
 command=fresh['command'];pre=fresh['pre_artifact_sha256']
 require(command[:2]==[pre['binary']['path'],pre['input']['path']],'Native command does not use admitted binary and input')
 require(start['command']==command,'Native start/end argv mismatch')
 require(bool(fresh['new_artifacts']) and command[2] in fresh['new_artifacts'] and fresh['new_artifacts'][command[2]]==initial['fresh_replay_output_sha256'],'Fresh output not bound to actual invocation')
 require(bool(fresh['mapped_file_sha256']),'Missing loaded-library provenance')
 require(type(fresh['observed_max_process_task_count']) is int and fresh['observed_max_process_task_count']==4,'Initial native observed worker profile mismatch')
 require(start['controlled_environment']['OMP_NUM_THREADS']=='4' and start['controlled_environment']['OPENBLAS_NUM_THREADS']=='1','Initial native controlled environment mismatch')
 return True

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--aggregate-checker-review',type=Path,required=True);ap.add_argument('--aggregate-checker-review-sha256',required=True);ap.add_argument('--chain-review',type=Path,default=HERE/'chain-review/review.json');ap.add_argument('--chain-review-sha256',required=True);ap.add_argument('--endpoint-review',type=Path,default=END_REVIEW);ap.add_argument('--endpoint-review-sha256',required=True);ap.add_argument('--initial-review',type=Path,required=True);ap.add_argument('--initial-review-sha256',required=True);ap.add_argument('--output',type=Path,default=HERE/'admission.json');a=ap.parse_args()
 require(not a.output.exists(),'Immutable output already exists')
 independent=read(a.aggregate_checker_review,a.aggregate_checker_review_sha256)
 require(independent['accepted'] is True and independent['checker_sha256']==sha(Path(__file__)),'Independent aggregate checker review not accepted for this exact code')
 pin(Path(__file__),independent['checker_sha256'])
 chain=read(a.chain_review,a.chain_review_sha256);end=read(a.endpoint_review,a.endpoint_review_sha256);initial=read(a.initial_review,a.initial_review_sha256)
 if 'source_pin_relocation' in end:
  relocation=end['source_pin_relocation']
  original=Path('/shared/codex-1/vakint_rustred/vakint-external-data/4L/manifest.json').resolve()
  replacement=ROOT/'ancestor-flows/four-loop-production-A-admission-v1/endpoint-replay/canonical-routing/immutable-inputs/4L-manifest-b40adfb8.json'
  digest='b40adfb858f4a10852d341aab0a8550de93e3c7526b953a6c4b21cbc7bb8f9b9'
  require(relocation=={'original_path':str(original),'replacement_path':str(replacement),'sha256':digest},'Unreviewed source-pin relocation')
  pin(replacement,digest);RELOCATIONS[str(original)]=(str(replacement),digest)

 fresh=read(initial['fresh_invocation_review_path'],initial['fresh_invocation_review_sha256'])
 certificate_gates(chain,end,initial,fresh)
 pole_path=ROOT/'ancestor-flows/four-loop-production-A-admission-v1/review/lineage/pole22/review.json'
 pole=read(pole_path,'5d84e2484d3c5ab73dc495d861d99301d37543f070281d0c1303dfe10970e7d7')
 require(pole['accepted'] is True and pole['raw_22_basis_pole_bound_verified'] is True and pole['basis_size']==22 and pole['positive_scalar_rows']==21 and pole['numerator_exception_components']==[7],'Selected22 physical pole support not admitted')
 require(pole['raw_source_sha256']=='88290b3fe7015e350046044c3a93236700eb180e8141af5781fdfd5dfbfd9c88','Pole proof source mismatch')
 raw22=read(ROOT/'ancestor-flows/pr9-22.json',pole['raw_source_sha256'])
 require([row['powers'] for row in pole['basis_graph_checks']]==raw22['basis'],'Pole proof does not cover every actual selected state')
 require(pole['numerator_reduction']['epsilon_singular_coefficients_introduced'] is False,'Numerator pole reduction introduces singular epsilon factors')
 merge(pole['source_and_checker_sha256'])
 source=read(INITIAL,INITIAL_SHA);endpoint=read(ENDPOINT,ENDPOINT_SHA);run=read(CHAIN/'run-binding.json');complete=read(CHAIN/'complete.json');terminal=read(CHAIN/'step-035-boundary.json',end['terminal_boundary_sha256'])
 require(run['initial_sha256']==INITIAL_SHA and run['dimension']==22 and run['epsilon_jet_count']==6 and run['substeps_per_halving']==3 and run['native_worker_threads']==8,'Actual run geometry/profile mismatch')
 require(source['normalization']==endpoint['normalization']==terminal['normalization']=='native_raw' and source['error_quality']==endpoint['error_quality']==terminal['error_quality']=='rigorous-bound','Source normalization/quality mismatch')
 require(endpoint['boundary_sha256']==end['terminal_boundary_sha256']==complete['final_boundary_sha256'],'Endpoint continuation mismatch')
 require(endpoint['source_sha256']==run['source_equation_sha256']=='88290b3fe7015e350046044c3a93236700eb180e8141af5781fdfd5dfbfd9c88','Physical source equation mismatch')
 merge(chain['source_pins']);merge(end['source_and_implementation_pins']);merge(initial['artifact_sha256'])
 arithmetic=read(end['arithmetic_review'],end['arithmetic_review_sha256']);merge(arithmetic['source_and_implementation_pins'])
 route=read(end['canonical_routing_witness'],end['canonical_routing_witness_sha256']);require(route['accepted'] is True,'Canonical routing witness unaccepted');merge(route['source_pins'])
 controls=read(end['canonical_routing_negative_control_receipt'],end['canonical_routing_negative_control_receipt_sha256']);require(controls['all_rejected'] is True,'Routing rejection tests unaccepted')
 for role,entry in fresh['pre_artifact_sha256'].items():
  require(fresh['post_artifact_sha256'][role]==entry['sha256'],'Fresh pre/post artifact disagreement');pin(entry['path'],entry['sha256'])
 merge(fresh['new_artifacts']);merge(fresh['mapped_file_sha256']);start=read(fresh['start_receipt']['path'],fresh['start_receipt']['sha256'])
 invocation_binding_gates(initial,fresh,start)
 ctx.dps=21000;maximum=arb(0);count=0
 require(set(endpoint['coefficients'])=={'native::PR3','native::PR4','native::PR4d','native::PR5','native::PR7','native::PR9','native::PR9d'},'Wrong physical target set')
 for symbol,rows in endpoint['coefficients'].items():
  require(len(rows)==6 and [r['epsilon_power'] for r in rows]==list(range(-4,2)),'Wrong Laurent support for '+symbol)
  for row in rows:
   value=acb(arb(row['ball']),arb(row['imaginary_ball']));require(value.is_finite() and value.imag.contains(0),'Invalid complex physical source box')
   radius=value.real.rad()+value.imag.rad();require(2*radius<arb('1e-20000'),'Strict final total diameter failed');maximum=max(maximum,radius);count+=1
 require(count==42,'Missing endpoint coefficients')
 pin(Path(__file__))
 for path,digest in PINS.items():require(sha(path)==digest,'Reviewed data changed during aggregate '+path)
 result={'schema':'vakint.PR9-production-B-complete-physical-source-admission.v1','accepted':True,'whole_chain_physical_source_admitted':True,'status':'passed_all_source_INIT_36_transport_steps_canonical_targets_and_42_projections','scope':'Seven canonical native-raw four-loop master jets epsilon^-4..epsilon^1 from independently admitted API20600 source rows, exact matched native seeds, a fresh witnessed identical INIT invocation,36 reviewed scheduled-RPF ordinary steps and seven admitted20400 adjoints.','endpoint_path':str(ENDPOINT),'endpoint_sha256':ENDPOINT_SHA,'initial_path':str(INITIAL),'initial_sha256':INITIAL_SHA,'aggregate_checker_review_path':str(a.aggregate_checker_review.resolve()),'aggregate_checker_review_sha256':sha(a.aggregate_checker_review),'initial_review_path':str(a.initial_review.resolve()),'initial_review_sha256':sha(a.initial_review),'fresh_initial_invocation_review_sha256':initial['fresh_invocation_review_sha256'],'chain_review_path':str(a.chain_review.resolve()),'chain_review_sha256':sha(a.chain_review),'endpoint_review_path':str(a.endpoint_review.resolve()),'endpoint_review_sha256':sha(a.endpoint_review),'source_pin_relocation':end.get('source_pin_relocation'),'canonical_routing_witness_sha256':end['canonical_routing_witness_sha256'],'selected22_physical_lower_pole_review_path':str(pole_path),'selected22_physical_lower_pole_review_sha256':sha(pole_path),'six_jet_closure':'All22 complete physical integrals start at epsilon^-4, including the numerator state via an epsilon-regular scalar/tadpole reduction. The ordinary connection and all7 endpoint rows are epsilon-regular, so the six jets through epsilon^1 omit no required lower state.','normalization':'native_raw','error_quality':'rigorous-bound','canonical_masters':sorted(endpoint['coefficients']),'epsilon_powers':list(range(-4,2)),'coefficient_count':42,'ordinary_steps':36,'ordinary_workers':8,'ordinary_final_absolute_radius_gate_digits':20250,'all_final_endpoint_complex_L1_radii_and_diameters_below':'1e-20000','maximum_endpoint_complex_L1_radius':maximum.str(50,more=True),'source_input_native_rounding_adjoint_tail_and_convolution_radii_preserved':True,'exact_zeros_not_inferred_from_small_values':True,'canonical_PR9d_alias':'Exact determinant+1 loop transformation preserves every active quadratic, mass and dotted power; no dimension-dependent measure factor.','fresh_initial_invocation_replaces_unattested_historical_execution':True,'new_native_invocations_by_this_aggregate':0,'new_HPL_preparer_or_production_recurrence_runs_by_this_aggregate':0,'data_precision_caps_modified':False,'main_PR11d_published_precision_cap':200,'whole_PR11d_20000_accuracy_claimed':False,'native_solver_contract':'Frozen independently reviewed implementations, exact source/input data replay, full ball preservation, local residual certification and actual total-width gates. INIT additionally has fresh same-input same-binary execution and exact numerical/log replay.','IBP_trust_scope':'Inherits the authenticated raw differential/IBP system and exact old-to-selected map; does not regenerate its IBP relations.','artifact_sha256':PINS}
 write(a.output,result);print(a.output);print(sha(a.output))
if __name__=='__main__':main()
