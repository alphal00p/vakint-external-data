#!/usr/bin/env python3
"""Source-specific admission of the frozen production-A PR9 initialization.

Reuses independently reviewed physical primitive and exact outward boundary
assembly proofs. Independently propagates full literal decimal source boxes
through exact matching into the actual 68100-bit native seeds. Does not run a
preparer, primitive evaluator, HPL evaluator, or numerical native engine.
"""
import argparse
from fractions import Fraction as Q
import hashlib
import json
import math
from pathlib import Path
import re
import resource
import sys
import time

from flint import acb, arb, ctx, fmpq

if not __debug__:
    raise RuntimeError("Checks require assertions")
sys.set_int_max_str_digits(300000)
HERE = Path(__file__).resolve().parent
PR11 = HERE.parents[2]
PERIODS = PR11.parent
NATIVE = PR11 / "helper/frobenius-transport/native"
BOUNDARY = PERIODS / "bessel/ancestor-boundary"
EXPECTED = {
    "initial": (PR11 / "helper/frobenius-transport/pr9-API20280-eta256-guard20220-v1.json", "e82c3c649f9e48df240d4be2b058e78148a75bde273197ca7299f6a26c13ed7f"),
    "source": (BOUNDARY / "pr9-boundary-API20280-working20400.json", "8b35db3637aed6c4654a8b86bd3501b6357bff64c719aa52dc352b72eb4bc9b9"),
    "source_review": (PR11 / "helper/pr9-api-boundary-review/pr9-source-review-receipt.json", "2190357dd5232fe4d44b056ac555a711136f0f42af31ce3a30ce613e05b9282e"),
    "outward_source_review": (PR11 / "helper/pr9-proto1000-init-review/source-box-review.json", "3a024807e6b37ee7b0aede682b31d8daa3f134da223c0cc90b7b8089c186066e"),
    "input": (NATIVE / "pr9-API20280-init-v1.in", "826de190c795c5fd8a5b6b36bf63715a8b98a997e4825d8ec6aa222f3ee72ce8"),
    "metadata": (NATIVE / "pr9-API20280-init-v1.json", "260d3ebe44bcb33ce6666860820831547d1cad6b956baef3dd206e7b1945405f"),
    "output": (NATIVE / "pr9-API20280-init-v1-output.json", "91186644e6a7c04862dab7c53127caaeea2cca71d6ff50b0839511cf18372b6b"),
    "native_source": (NATIVE / "contracted_v2.c", "5f9c381280172f1d388a3661fb13a3a799848391c29b334e5c1ebc150879ff60"),
    "native_binary": (NATIVE / "contracted-native-v2", "ff3d297816b301c010fb8ee4645207ecdec0f74cf8e7a8678b678d5bfb3175c3"),
    "wrapper": (NATIVE / "validate_pr9_API20280_v2.py", "36015cc649bc915c05cfdb8d5cd5c47655e882fbb08818ac287fc18acd3b8ef1"),
    "engine_review": (NATIVE / "v2-implementation-review.json", "c3500028c1431bd672b24378d8f0bfd7ae834c65a28bafb5ba99c832656a5ce7"),
    "engine_build": (NATIVE / "build-v2.sh", "1465e799f366514feca310a0bf96c8dc963e99624a8bc0edfc670daf72ba5de5"),
    "native_port_review": (NATIVE.parent / "bound-review/native-port-review.json", "ac5b06658a56df3b9887d8ba257ea6d0fb976c816e6992105c93d3f1bf4a16ca"),
    "mathematical_review": (NATIVE.parent / "bound-review/contracted-frobenius-review.json", "962f745d35f65754016c1b114995700ed452e1f53c5ced43afc85cb7adf7caf5"),
    "python_review": (NATIVE.parent / "bound-review/contracted-python-review.json", "0d1785f2e0d68581543a2bf4f26be7de4371402adcb29b2dee435bb1df1dabb0"),
}
PINS = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pin(path, digest):
    path = Path(path)
    require(path.is_absolute() and path.is_file() and not path.is_symlink(), "Nonregular pin: " + str(path))
    require(sha(path) == digest, "Pin mismatch: " + str(path))
    require(str(path) not in PINS or PINS[str(path)] == digest, "Conflicting pin: " + str(path))
    PINS[str(path)] = digest


def read(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate JSON key: " + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Nonfinite JSON: " + value)))


def declared_pins(data):
    """Recheck every declared scientific graph edge of the reused proofs."""
    for field in ["artifact_sha256"]:
        for row in data.get(field, {}).values():
            if isinstance(row, dict):
                pin(row["path"], row["sha256"])
    for field in ["nested_source_pins", "transitive_sunset_source_pins", "transitive_recipe_source_pins"]:
        for row in data.get(field, []):
            pin(row["path"], row["sha256"])
    for field in ["nested_source_sha256", "source_sha256", "input_sha256"]:
        mapping = data.get(field)
        if isinstance(mapping, dict):
            for path, digest in mapping.items():
                pin(path, digest)


def decimal_box(text):
    if text.startswith("["):
        match = re.fullmatch(r"\[(?:(.*?) )?\+/- (.*?)\]", text)
        require(match is not None, "Invalid decimal ball")
        center, radius = Q(match[1]) if match[1] else Q(0), Q(match[2])
    else:
        center, radius = Q(text), Q(0)
    require(radius >= 0, "Negative radius")
    return center, radius


def source_checks():
    for path, digest in EXPECTED.values():
        pin(path, digest)
    initial, source, review, outward, metadata, output = [read(EXPECTED[k][0]) for k in
                                                       ["initial", "source", "source_review", "outward_source_review", "metadata", "output"]]
    require(review["accepted_for_source_and_native_input_scope"] and review["source_error_quality"] == "rigorous-bound", "Source proof rejected")
    require(review["boundary_sha256"] == EXPECTED["source"][1] and review["native_input_sha256"] == EXPECTED["input"][1], "Source proof binding differs")
    require(review["actual_absolute_source_guard_digits"] == 20240 and review["intended_final_transport_width_digits"] == 20220, "Source guard contract differs")
    require(review["API_exports_full_metadata_formula_and_exact_binary_enclosure_chain_verified"] and review["FMFT_to_raw_Euler_conversions"] == 1 and review["downstream_additional_Euler_conversions"] == 0, "Physical API admission or normalization differs")
    for row in review["receipts"]:
        pin(row["path"], row["sha256"])
        declared_pins(read(row["path"]))
    api_audit_path = PERIODS / "bessel/API-ancestor-source-review/audit.json"
    api_audit = read(api_audit_path)
    pin(api_audit_path.parent / "audit.py", api_audit["review_script_sha256"])
    declared_pins(outward)
    require(outward["accepted"] and outward["accepted_source_chain_revalidated"] and not outward["overlap_used_as_acceptance"], "Exact source assembly proof rejected")
    require(outward["source_working_decimal_digits"] == 20400 and outward["source_boundary_outward_strings_reproduced_exactly"] == 557 and outward["source_matched_constant_outward_strings_reproduced_exactly"] == 132, "Full outward source replay absent")
    require(outward["artifact_sha256"]["source_boundary"]["sha256"] == EXPECTED["source"][1], "Outward proof is for another source")
    # The reused proof's lower-precision seed part is not used for this input.
    # This review independently checks the actual production-A high-bit seeds.
    matching_path = PR11 / "ancestor-flows/pr9-22-matching.json"
    matching = read(matching_path)
    pin(matching_path, source["matching_sha256"])
    require(source["normalization"] == "native_raw" and source["error_quality"] == "rigorous-bound", "Source convention differs")
    require(source["coefficient_count"] == 557 and source["free_constants"] == 132 and source["working_decimal_digits"] == 20400, "Source dimensions differ")
    for field, value in {"schema": "vakint.pr9.guarded-ordinary-boundary.v2", "basis": "original_raw_epsilon_jets", "dimension": 22, "jets": 6, "epsilon_min_power": -4, "epsilon_max_power": 1, "eta_center": ["0", "256"], "normalization": "native_raw", "error_quality": "rigorous-bound", "source_boundary_sha256": EXPECTED["source"][1], "independent_source_review_sha256": EXPECTED["source_review"][1], "native_preparation_sha256": EXPECTED["metadata"][1], "native_input_sha256": EXPECTED["input"][1], "native_output_sha256": EXPECTED["output"][1], "native_source_sha256": EXPECTED["native_source"][1], "native_binary_sha256": EXPECTED["native_binary"][1], "validator_sha256": EXPECTED["wrapper"][1], "local_tail_certified": True, "all_132_normalized_and_original_total_radii_below_1e_minus20220": True, "whole_master_accuracy_claimed": False}.items():
        require(initial[field] == value, "Initial wrapper field differs: " + field)
    for key in ["original_source_equation", "ordinary_polynomial_connection", "source_boundary", "independent_source_review", "independent_three_loop_flow_crosscheck"]:
        pin(initial[key + "_path"], initial[key + "_sha256"])
    require(initial["values"] == output["original_Y_values"], "Initial does not preserve native raw values")
    require(metadata["seed_binding"] == EXPECTED["source"][1] and metadata["input_sha256"] == EXPECTED["input"][1], "Preparation binding differs")
    require(metadata["z0"] == ["0", "-1/256"] and metadata["bits"] == 68100 and metadata["requested_digits"] == 20320, "Preparation precision/center differs")
    for relative, digest in metadata["source_sha256"].items():
        pin((NATIVE.parent / relative).resolve(), digest)
    prefix = read(PR11 / "helper/pr9-api-boundary-review/native-input-receipt.json")
    require(prefix["accepted"] and prefix["input_sha256"] == EXPECTED["input"][1] and prefix["all_serialized_seed_midpoints_and_radii_equal"], "Independent actual-input proof missing")
    pin(PR11 / "helper/pr9-api-boundary-review/audit_native_input.py", prefix["audit_implementation_sha256"])
    engine = read(EXPECTED["engine_review"][0])
    require(engine["source_sha256"] == EXPECTED["native_source"][1] and engine["binary_sha256"] == EXPECTED["native_binary"][1] and engine["build_sha256"] == EXPECTED["engine_build"][1], "Frozen native proof binds another engine")
    pin(NATIVE / "contracted.c", engine["baseline_source_sha256"])
    pin(NATIVE / "contracted-native", engine["baseline_binary_sha256"])
    python_review = read(EXPECTED["python_review"][0])
    pin(NATIVE.parent / "contracted.py", python_review["implementation_sha256"])
    port = read(EXPECTED["native_port_review"][0])
    require(port["source_sha256"] == engine["baseline_source_sha256"] and port["binary_sha256"] == engine["baseline_binary_sha256"], "Baseline port proof differs")
    fields = ("component", "integer_z_power", "epsilon_power", "log_power")
    key = lambda row: tuple(row[f] for f in fields)
    saved = {key(row): row["real_ball"] for row in source["coefficients"]}
    require(len(saved) == len(source["coefficients"]) == 557, "Duplicate source row")
    require(set(saved) == {key(row) for row in matching["all_boundary_selectors"]}, "Source row set differs")
    selected = [decimal_box(saved[key(row)]) for row in matching["selected_selectors"]]
    lines = EXPECTED["input"][0].read_text().splitlines()
    header = lines[0].split()
    require(header[0] == "FROB_V1", "Wrong input codec")
    dim, logs, blocks, count, nmin, nmax, dd, bd, npoly, nres, nstartup, bits, digits, maxorder, every = map(int, header[1:])
    require((dim, logs, count, nmin, nmax, bits, digits) == (132, 9, 132, -4, -1, 68100, 20320), "Actual native input shape differs")
    require(lines[1] == "0 -1 256", "Actual native center differs")
    seed_offset = 5 + dd + 1 + npoly * (bd + 2) + 1 + nres + nstartup + dim
    require(len(lines) - seed_offset == count, "Actual seed count differs")
    ctx.prec = bits
    ctx.threads = 1
    selected_balls = [arb(saved[key(row)]) for row in matching["selected_selectors"]]
    for index, (row, line) in enumerate(zip(matching["boundary_inverse"], lines[seed_offset:], strict=True)):
        real, imaginary = line.split("|")
        require(imaginary == "0", "Nonzero native imaginary seed")
        center = sum((Q(q) * selected[j][0] for j, q in enumerate(row) if q != "0"), Q(0))
        radius = sum((abs(Q(q)) * selected[j][1] for j, q in enumerate(row) if q != "0"), Q(0))
        native = arb(real)
        require(native.is_finite(), "Nonfinite seed")
        nc, nr = Q(str(native.mid().fmpq())), Q(str(native.rad().fmpq()))
        require(nc - nr <= center - radius and nc + nr >= center + radius, "Full source box escapes seed " + str(index))
        fresh = sum((selected_balls[j] * arb(fmpq(q)) for j, q in enumerate(row) if q != "0"), arb(0))
        require(fresh.str(math.ceil(bits * math.log10(2)) + 10) == real, "Exact native seed serialization differs " + str(index))
        require(native.rad().upper() < (arb(10) ** -20240).lower(), "Source guard lost")
    ctx.dps = 20600
    require(output["dimension"] == 132 and output["maximum_log_degree"] == 8 and output["startup_power_range"] == [-4, -1], "Output shape differs")
    require(output["working_bits"] == bits and output["digits"] == digits and output["target_absolute_digits"] == digits and output["order"] == 16500, "Output precision/order differs")
    require(output["local_tail_certified"] and output["exact_residue_identity_verified"], "Native local proof missing")
    maxima = {}
    for field in ["normalized_J_values", "original_Y_values"]:
        values = [acb(arb(real), arb(imaginary)) for real, imaginary in output[field]]
        require(len(values) == 132 and all(z.is_finite() for z in values), "Nonfinite or incomplete output")
        radii = [z.real.rad() + z.imag.rad() for z in values]
        require(all(r < arb("1e-20220") for r in radii), "Initial total radius contract fails")
        maxima[field] = max(radii).str(40)
    require(maxima == initial["maximum_total_radius"], "Wrapper total radius metadata differs")
    for path, digest in list(PINS.items()):
        pin(path, digest)
    return {"initial_artifact_sha256": EXPECTED["initial"][1], "source_boundary_sha256": EXPECTED["source"][1], "native_input_sha256": EXPECTED["input"][1], "native_output_sha256": EXPECTED["output"][1], "source_working_decimal_digits": 20400, "native_working_bits": bits, "native_local_tail_target_digits": digits, "absolute_source_guard_digits": 20240, "initial_total_width_target_digits": 20220, "source_boundary_rows_exactly_replayed_by_blessed_proof": 557, "matched_constants_exactly_replayed_by_blessed_proof": 132, "all_132_seed_full_source_boxes_contained": True, "all_132_actual_native_seed_strings_reproduced_exactly": True, "all_132_normalized_and_raw_initial_total_radii_below_1e_minus20220": True, "maximum_total_radius": maxima, "physical_primitive_API_and_sunset_proofs_revalidated": True, "overlap_used_as_physical_acceptance": False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-only", action="store_true")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--independent-review", type=Path)
    parser.add_argument("--independent-review-sha256")
    args = parser.parse_args()
    output = args.output
    require(output.is_absolute() and output.parent.resolve() == HERE and not output.exists() and not output.is_symlink(), "Output must be fresh inside owned review directory")
    require(args.source_only or (args.independent_review is not None and args.independent_review_sha256 is not None), "Final admission requires an explicitly blessed independent checker/data review")
    resource.setrlimit(resource.RLIMIT_AS, (2 << 30, 2 << 30))
    resource.setrlimit(resource.RLIMIT_CPU, (180, 185))
    started = time.monotonic()
    result = source_checks()
    result.update({"schema": "vakint.pr9.production-A.physical-initial-admission.v1", "accepted": False, "status": "source_admitted_pending_fresh_native_invocation", "source_only": args.source_only, "initial_physical_source_admitted": True, "preparer_or_primitive_or_HPL_or_native_engine_rerun_by_checker": False, "subsequent_RPF_steps_or_adjoints_reviewed": False, "whole_period_or_20k_claimed": False, "independent_IBP_validation_claimed": False, "inherited_IBP_qualification": "Physical source and native numerical acceptance inherit the authenticated source IBP systems and certified selected Frobenius solution; this review does not independently derive those IBPs."})
    if not args.source_only:
        invocation_path = HERE / "invocation.json"
        invocation = read(invocation_path)
        pin(invocation_path, sha(invocation_path))
        require(invocation["accepted_same_input_same_binary_replay"] and invocation["returncode"] == 0 and invocation["all_numerical_history_and_contract_fields_equal"], "Fresh native replay did not pass")
        require(invocation["environment_overrides"]["OMP_NUM_THREADS"] == "4" and invocation["address_space_limit_bytes"] == 2 << 30 and len(invocation["cpu_affinity"]) == 4, "Native invocation resource contract differs")
        require(invocation["command"] == [str(EXPECTED["native_binary"][0]), str(EXPECTED["input"][0]), str(HERE / "replayed-native-output.json")], "Invocation is for another input or binary")
        expected_invocation_pins = {str(EXPECTED[key][0]): EXPECTED[key][1] for key in ["input", "native_source", "native_binary", "output"]}
        for field in ["source_sha256_before", "source_sha256_after"]:
            require(invocation[field] == expected_invocation_pins, "Invocation source pin set differs")
            for path, digest in invocation[field].items():
                pin(path, digest)
        require(invocation["source_files_unchanged"] and invocation["source_sha256_before"] == invocation["source_sha256_after"], "Invocation changed original files")
        for name, field in [("replay.py", "runner_sha256"), ("replayed-native-output.json", "output_sha256"), ("native.stderr", "stderr_sha256"), ("native.stdout", "stdout_sha256")]:
            pin(HERE / name, invocation[field])
        fresh = read(HERE / "replayed-native-output.json")
        original = read(EXPECTED["output"][0])
        excluded = ["seconds", "setup_seconds", "initialization_seconds", "certificate_seconds", "peak_rss_bytes"]
        require(invocation["excluded_timing_and_resource_fields_only"] == excluded, "Unexpected field comparison exclusions")
        require({k: v for k, v in fresh.items() if k not in excluded} == {k: v for k, v in original.items() if k not in excluded}, "Fresh numerical/contract fields differ")
        independent_path = args.independent_review
        pin(independent_path, args.independent_review_sha256)
        independent = read(independent_path)
        require(independent["accepted"] and independent["status"] == "passed_for_frozen_production_A_initial_admission_checker_and_data", "Independent checker/data review did not pass")
        require(independent["validator_sha256"] == sha(__file__), "Independent review is for another checker")
        require(independent["initial_artifact_sha256"] == EXPECTED["initial"][1] and independent["native_invocation_sha256"] == sha(invocation_path), "Independent review is for another physical initial or invocation")
        for field in ["all_source_and_wrapper_bindings_verified", "all_132_exact_source_seed_boxes_verified", "fresh_same_input_same_binary_replay_verified"]:
            require(independent[field] is True, "Independent review omits acceptance: " + field)
        require(isinstance(independent.get("source_pins"), dict) and independent["source_pins"], "Independent review omits source graph")
        for path, digest in independent["source_pins"].items():
            pin(path, digest)
        for key in ["initial", "source", "input", "output", "native_source", "native_binary"]:
            path, digest = EXPECTED[key]
            require(independent["source_pins"].get(str(path)) == digest, "Independent review omits required source pin: " + key)
        require(independent["source_pins"].get(str(invocation_path)) == sha(invocation_path), "Independent review omits actual invocation pin")
        result.update({"accepted": True, "status": "passed_for_frozen_production_A_physical_initial", "fresh_native_invocation_path": str(invocation_path), "fresh_native_invocation_sha256": sha(invocation_path), "fresh_native_output_sha256": sha(HERE / "replayed-native-output.json"), "all_numerical_history_fields_identical": True, "both_132_normalized_and_raw_vectors_byte_identical": True, "actual_fresh_native_wall_seconds": invocation["wall_seconds"]})
        result.update({"independent_review_path": str(independent_path), "independent_review_sha256": args.independent_review_sha256})
    result["source_pins"] = dict(sorted(PINS.items()))
    result["artifact_sha256"] = {name: {"path": str(path), "sha256": digest} for name, (path, digest) in EXPECTED.items()}
    result["implementation_sha256"] = {str(Path(__file__).resolve()): sha(__file__), str(HERE / "replay.py"): sha(HERE / "replay.py")}
    result["seconds"] = time.monotonic() - started
    result["peak_rss_bytes"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
    for path, digest in PINS.items():
        require(sha(path) == digest, "Source changed during review")
    with output.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"output": str(output), "sha256": sha(output), "accepted": result["accepted"], "source_pins": len(PINS), "seconds": result["seconds"]}, indent=2))


if __name__ == "__main__":
    main()
