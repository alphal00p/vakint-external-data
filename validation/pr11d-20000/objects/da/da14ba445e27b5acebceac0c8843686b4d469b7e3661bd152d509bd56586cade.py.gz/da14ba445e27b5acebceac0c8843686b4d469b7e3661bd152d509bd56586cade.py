#!/usr/bin/env python3
"""Invoke frozen source consumers with one explicitly pinned production profile."""
import argparse,hashlib,json,os,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
BASE=HERE.parent;PERIODS=BASE.parents[1];PR11=PERIODS/'pr11d'
MANIFEST=BASE/'production-source-profiles-v1.json'
MANIFEST_SHA='d1132ed3218ad71b28053956b61217e83b18fb44d0e198b6d0661165421b8987'
ENDPOINTS={'A':('pr9-production-A-endpoints.json','2b33f543f27e42ba6963fd6abc488b225a1f30d54c92fa1b2770bb42f6f839c1'),'B':('pr9-production-B-endpoints.json','4f905a9a27d3b756cc551cff0ed893d1448e71dff9578d4143998578aebfbba2')}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--profile',choices=['A','B'],required=True);ap.add_argument('--action',choices=['compare','assemble'],required=True);a=ap.parse_args()
    if not __debug__:raise RuntimeError('Scientific source validation cannot run under optimization')
    assert sha(MANIFEST)==MANIFEST_SHA
    manifest=json.loads(MANIFEST.read_text());profile=manifest['profiles'][a.profile];pins={str(MANIFEST):MANIFEST_SHA}
    for item in profile.values():
        if isinstance(item,dict)and'path'in item:pins[item['path']]=item['sha256']
    endpoint=PR11/'hierarchy-transport'/ENDPOINTS[a.profile][0];digest=ENDPOINTS[a.profile][1];pins[str(endpoint)]=digest
    for p,h in pins.items():assert sha(p)==h,'Frozen profile changed: '+p
    directory=HERE/a.profile;directory.mkdir(exist_ok=True);work={'A':20800,'B':21200}[a.profile]
    log=directory/(a.action+'.log');receipt=directory/(a.action+'-invocation.json')
    if log.exists()or receipt.exists():raise ValueError('Never replace a production source invocation')
    if a.action=='compare':
        validator=BASE/'compare_four_loop_bessel.py';target=directory/'independent-Bessel20000.json';argv=[sys.executable,str(validator),'--endpoints',str(endpoint),'--endpoints-sha256',digest,'--working-digits',str(work),'--minimum-agreement-digits','20000','--output',str(target)]
    else:
        validator=Path(profile['assembler']['path']);target=directory/'x8-source.boundary.json';argv=[sys.executable,str(validator),'--three-loop-input',profile['three_loop']['path'],'--three-loop-sha256',profile['three_loop']['sha256'],'--four-loop-input',str(endpoint),'--four-loop-sha256',digest,'--working-digits',str(work),'--output-prefix',str(directory/'x8-source')]
        if a.profile=='B':
            for role in ['sunset','p853']:argv+=['--'+role+'-input',profile[role]['path'],'--'+role+'-sha256',profile[role]['sha256']]
            argv+=['--p853-validation',profile['p853_acceptance']['path']]
    if target.exists():raise ValueError('Never overwrite scientific output')
    pins[str(validator)]=sha(validator);start=time.monotonic();env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
    with log.open('w')as stream:
        proc=subprocess.Popen(argv,env=env,cwd=PERIODS.parents[1],stdout=stream,stderr=subprocess.STDOUT);pid=proc.pid;code=proc.wait(timeout=900)
    for p,h in pins.items():assert sha(p)==h,'Frozen profile changed during invocation: '+p
    data={'schema':'vakint.X8-explicit-source-profile-invocation.v1','profile':a.profile,'action':a.action,'success':code==0,'argv':argv,'process_id':pid,'exit_code':code,'wall_seconds':time.monotonic()-start,'working_decimal_digits':work,'artifact_sha256':pins,'log_sha256':sha(log),'runner_sha256':sha(__file__),'physical_4L_chain_admission_pending':True,'source_profiles_mixed':False,'whole_PR11d_20000_accuracy_claimed':False}
    if target.exists():data['output_path']=str(target);data['output_sha256']=sha(target)
    receipt.write_text(json.dumps(data,indent=2)+'\n');print(a.profile,a.action,'exit',code,'seconds',data['wall_seconds'],flush=True)
    if code:raise SystemExit(code)
if __name__=='__main__':main()
