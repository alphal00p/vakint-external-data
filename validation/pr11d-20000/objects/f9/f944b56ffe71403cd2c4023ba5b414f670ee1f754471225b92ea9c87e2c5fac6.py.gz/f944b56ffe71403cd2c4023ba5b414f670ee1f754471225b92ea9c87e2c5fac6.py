#!/usr/bin/env python3
"""Execute only the A49 worker guard extracted from its frozen source AST."""
import ast
import copy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
ADMISSION = HERE.parents[1]
REPLAY = ADMISSION / 'replay.py'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
data = json.loads((HERE/'actual-data-v1.json').read_text())
assert sha(REPLAY) == data['admission_replay_sha256']
tree = ast.parse(REPLAY.read_text())
selected = [node for node in ast.walk(tree) if isinstance(node, ast.If)
            and ast.unparse(node.test) == 'segment_index == 3'
            and any(isinstance(child, ast.Constant) and child.value == 'openmp_actual_threads'
                    for child in ast.walk(node))]
assert len(selected) == 1
code = compile(ast.fix_missing_locations(ast.Module(body=selected, type_ignores=[])), str(REPLAY), 'exec')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def run(native, segment):
    exec(code, {'native': native, 'segment_index': segment, 'c': SimpleNamespace(require=require)})


good = {'openmp_requested_threads': 8, 'openmp_actual_threads': 8, 'openmp_thread_cap': 16}
run(good, 3)
run({}, 2)
controls = []
for label, changes in [
    ('forged_cap4_actual4', {'openmp_thread_cap': 4, 'openmp_actual_threads': 4}),
    ('actual4', {'openmp_actual_threads': 4}),
    ('requested4', {'openmp_requested_threads': 4}),
    ('cap8', {'openmp_thread_cap': 8}),
    ('actual_float', {'openmp_actual_threads': 8.0}),
    ('requested_float', {'openmp_requested_threads': 8.0}),
    ('cap_float', {'openmp_thread_cap': 16.0}),
    ('actual_bool', {'openmp_actual_threads': True}),
    ('missing_actual', {'openmp_actual_threads': None}),
]:
    value = copy.deepcopy(good)
    value.update(changes)
    if label == 'missing_actual':
        del value['openmp_actual_threads']
    try:
        run(value, 3)
    except (ValueError, KeyError) as error:
        controls.append({'mutation': label, 'rejected': True, 'exception': type(error).__name__, 'reason': str(error)})
    else:
        raise AssertionError('Accepted worker-profile mutation: ' + label)
assert sha(REPLAY) == data['admission_replay_sha256']
result = {'schema': 'vakint.PR9-A49-worker-guard-source-rejections.v1',
          'status': 'passed', 'replay_sha256': sha(REPLAY), 'test_sha256': sha(__file__),
          'guard_first_line': selected[0].lineno, 'positive_controls': 2,
          'negative_controls': controls, 'imported_or_invoked_producer': False,
          'native_preparer_HPL_calls': 0,
          'method': 'Executed the exact strict worker guard AST from the hashed admission replay in an isolated namespace; no parent function or module import.'}
output = HERE/'replay-guard-rejections-v1.json'
with output.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'positive_controls': 2, 'negative_controls': len(controls), 'output_sha256': sha(output)}))
