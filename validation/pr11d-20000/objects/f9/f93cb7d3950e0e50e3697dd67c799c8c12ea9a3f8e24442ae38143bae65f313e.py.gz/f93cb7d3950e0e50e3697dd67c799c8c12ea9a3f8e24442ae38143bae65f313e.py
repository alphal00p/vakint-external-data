from pathlib import Path
from types import SimpleNamespace
from dataclasses import replace
import ast,copy,hashlib,importlib.util,json,sys,time
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];BASE=ROOT.parent/'bessel/generic-rpf-admission';V1=BASE/'exact_step.py';V2=BASE/'exact_step_v2.py'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
def require(ok,msg):
 if not ok:raise ValueError(msg)
def main():
 start=time.monotonic();assert sha(V1)=='e489443fd72e505bab55fe88380510e3aaf4f46767898ec021819a0ac1625970';assert sha(V2)=='c7f14c52d39f05821dd3bf0ffbaadd46df95ea40ff0d896143bd8de813b1c617'
 tree=ast.parse(V2.read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_check');nodes=[];take=False
 for n in fn.body:
  if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='pairs' for t in n.targets):take=True
  if take and isinstance(n,ast.FunctionDef) and n.name=='mu':break
  if take:nodes.append(n)
 gate=compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(V2),'exec')
 mask=[{0,2,7},{1,4}];bank=[([1,1],1),([1,0,1],2)];states=12
 complete={'auxiliary_mask_verified':True,'auxiliary_active_states_by_factor':[[0,2,7],[1,4]],'auxiliary_total_factor_state_pairs':24,'auxiliary_computed_factor_state_pairs':5,'auxiliary_skipped_factor_state_pairs':19,'auxiliary_total_cascade_state_levels':36,'auxiliary_computed_cascade_state_levels':7,'auxiliary_skipped_cascade_state_levels':29};keys=sorted(complete);cases=0
 def evaluate(required,result):
  env={'k':SimpleNamespace(mask_metadata_required=required),'result':result,'mask':mask,'bank':bank,'states':states,'require':require}
  try:exec(gate,env);return True,env['mask_checked']
  except ValueError:return False,None
 for required in [False,True]:
  for subset in range(256):
   result={k:copy.deepcopy(complete[k]) for i,k in enumerate(keys) if subset>>i&1};accepted,checked=evaluate(required,result)
   expect=subset==255 or (not required and subset==0)
   assert accepted==expect
   if accepted:assert checked==(subset==255)
   cases+=1
 negatives=[]
 for required in [None,0,1,'false']:
  assert evaluate(required,complete)[0] is False;negatives.append('non_boolean_profile_'+repr(required))
 for required in [False,True]:
  for key,value in [('auxiliary_mask_verified',False),('auxiliary_computed_factor_state_pairs',5.0),('auxiliary_computed_factor_state_pairs',True),('auxiliary_computed_factor_state_pairs',6),('auxiliary_active_states_by_factor',[[0,2],[1,4]])]:
   bad=copy.deepcopy(complete);bad[key]=value;assert evaluate(required,bad)[0] is False;negatives.append(str(required)+':'+key+':'+str(value))
 # Actual preserved baseline input, using no engine or preparer.
 spec=importlib.util.spec_from_file_location('review_mask_v2',V2);E=importlib.util.module_from_spec(spec);sys.modules[spec.name]=E;spec.loader.exec_module(E)
 d=ROOT/'hierarchy-transport/pr9-production-API20280-v5';run=read(d/'run-binding.json');cp=ROOT/'ancestor-flows/pr9-22-ordinary-polynomial.json';fp=ROOT/'ancestor-flows/pr9-22-ordinary-rational-pf.json';mp=ROOT/'ancestor-flows/pr9-22-matching.json';w=read(mp)['gauge_weights'][:22];w=tuple(x-min(w) for x in w);initial=ROOT/'helper/frobenius-transport/pr9-API20280-eta256-guard20220-v1.json'
 bits=int((d/'step-000.in').read_text().splitlines()[0].split()[5]);contract=E.StepContract(22,6,-4,sha(cp),sha(fp),run['source_equation_sha256'],bits,run['local_target_digits'],run['local_target_digits']+run['guard_digits'],sha(d/'run-binding.json'),run['initial_sha256'],'imaginary_center_power',w,mask_metadata_required=False)
 args=[d/'step-000.in',d/'step-000.json',initial,cp,fp,d/'step-000-native.json',d/'step-000-boundary.json'];before=E.ctx.prec;actual=E.check_step(*args,contract);assert E.ctx.prec==before and actual['mask_metadata_checked'] is False and actual['unmasked_baseline_implementation_admission_required'] is True
 try:E.check_step(*args,replace(contract,mask_metadata_required=True))
 except ValueError as exc:assert 'mask metadata' in str(exc)
 else:raise AssertionError('Default strict mask allowed absence')
 assert E.ctx.prec==before
 pins=actual['artifact_sha256'].copy();pins.update({str(p):sha(p) for p in [V1,V2,BASE/'regression-v2.json',BASE/'regression_v2.py',HERE/'audit.py',ROOT/'helper/generic-rpf-step-review/review.json']})
 for p,h in pins.items():assert sha(p)==h
 report={'schema':'vakint.generic-RPF-v2-mask-delta-independent-review.v1','accepted':True,'status':'passed_explicit_unmasked_profile_delta','checker_sha256':sha(V2),'predecessor_checker_sha256':sha(V1),'predecessor_independent_review_sha256':sha(ROOT/'helper/generic-rpf-step-review/review.json'),'mask_subset_policy_truth_table_cases':cases,'additional_false_type_counter_index_rejections':len(negatives),'actual_baseline0_all_source_bound_box_and_serialization_checks_passed':True,'actual_baseline_default_strict_profile_rejected':True,'all_other_mathematical_bound_and_conversion_gates_preserved':True,'source_pins':pins,'caller_obligation':'mask_metadata_required=False admits data only for a separately authenticated full-auxiliary baseline implementation. Complete absent mask metadata is allowed; any present field forces the entire correct true block. Nativeimplementation/physicalorigin admission remains false.','accepted_mask_paths':'True default requires complete correct block. False permits complete absence or a complete correct block; every partial or false block rejects. Counts are strict integers.','scope':'Additive mask-metadata delta only. It does not repair or accept the independent clear_factor==1 bound serialization corner; that is the separately reviewedv3 policy delta.','native_prefix_preparer_or_transport_run':False,'producer_files_modified':False,'seconds':time.monotonic()-start}
 (HERE/'review.json').write_text(json.dumps(report,indent=2)+'\n');print('MASK DELTA PASS',sha(HERE/'review.json'),report['seconds'],'seconds')
if __name__=='__main__':main()
