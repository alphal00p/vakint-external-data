#!/usr/bin/env python3
"""Append exact scaled RPF data without changing a saved ordinary IVP."""
import argparse,hashlib,json,math
from fractions import Fraction as Q
from pathlib import Path
if not __debug__:raise RuntimeError('Assertions required')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pair(values):
    den=math.lcm(*(q.denominator for q in values));return [int(q*den) for q in values]+[den]
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True);ap.add_argument('--metadata',type=Path,required=True);ap.add_argument('--rational-pf',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    if a.output.exists() or a.output.with_suffix('.json').exists():raise ValueError('Refusing to replace a saved input')
    m=json.loads(a.metadata.read_text());p=json.loads(a.rational_pf.read_text());prefix=a.input.read_text()
    assert m['input_sha256']==sha(a.input)
    assert p['source_polynomial_connection_sha256']==m['polynomial_connection_sha256']
    dim,jets,degree,entry_count,block_count,bits,digits,max_order,check_every=map(int,prefix.splitlines()[0].split())
    assert dim==p['dimension']==m['dimension'] and jets==p['epsilon_jet_count']==m['jets']
    assert len(prefix.splitlines())==3+(degree+1)+entry_count*(degree+2)+dim*jets
    scales=[Q(v) for v in m.get('constant_component_scale',['1']*dim)];assert len(scales)==dim and all(scales)
    factors={f['index']:f for f in p['denominator_factors']};bank=[];indices={};terms=[]
    for e in p['entries']:
        ratio=scales[e['column']]/scales[e['row']]
        if e['polynomial_part']:terms.append((e,-1,[Q(q)*ratio for q in e['polynomial_part']]))
        for t in e['terms']:
            key=t['factor_index'],t['factor_power']
            if key not in indices:indices[key]=len(bank);bank.append((factors[key[0]],key[1]))
            terms.append((e,indices[key],[Q(q)*ratio for q in t['numerator_coefficients']]))
    denominator=math.lcm(*(q.denominator for _,_,row in terms for q in row))
    rows=[f'RPF_V1 {len(bank)} {len(terms)}',' '.join(map(str,pair([Q(x) for x in m['center']]))),' '.join(map(str,pair([Q(x) for x in m['step']]))),str(denominator)]
    for factor,power in bank:
        coeff=[Q(q) for q in factor['coefficients']];den=math.lcm(*(q.denominator for q in coeff))
        rows += [f'{len(coeff)-1} {power} {den}',' '.join(str(int(q*den)) for q in coeff)]
    for e,index,coeff in terms:
        rows += [f"{e['row']} {e['column']} {e['epsilon_power']} {index} {len(coeff)-1}",' '.join(str(int(q*denominator)) for q in coeff)]
    a.output.write_text(prefix.rstrip('\n')+'\n'+'\n'.join(rows)+'\n')
    metadata={**m,'schema':'vakint.constant-scaled-rational-pf-step.v1','saved_polynomial_input_path':str(a.input.resolve()),'saved_polynomial_input_sha256':sha(a.input),'saved_polynomial_metadata_sha256':sha(a.metadata),'rational_pf_source_sha256':sha(a.rational_pf),'input_sha256':sha(a.output),'rpf_constant_scale_rule':'Each original eta numerator multiplied exactly by S_column/S_row; denominator factors and their powers unchanged.','rpf_shared_numerator_denominator':str(denominator),'rpf_factor_bank_count':len(bank),'rpf_term_count':len(terms),'appender_sha256':sha(__file__)}
    a.output.with_suffix('.json').write_text(json.dumps(metadata,indent=2)+'\n');print('prepared',a.output,'sha256',sha(a.output))
if __name__=='__main__':main()
