#!/usr/bin/env python3
"""Read-only replay of the frozen physical four-loop production-A endpoint.

No producer module is imported and no prefix, recurrence, transport, preparer,
native executable or HPL evaluator is run.  This component admits only the
endpoint convolution; the physical initial/ordinary-chain theorem is separate.
"""
import argparse
import hashlib
import importlib.util
import json
import re
import time
from fractions import Fraction
from pathlib import Path

from flint import acb, arb, ctx

HERE = Path(__file__).resolve().parent
ANCESTOR = HERE.parents[1]
PR11D = ANCESTOR.parent
WORKSPACE = PR11D.parents[1]
ENDPOINT = PR11D / "hierarchy-transport/pr9-production-A-endpoints.json"
BOUNDARY = PR11D / "hierarchy-transport/pr9-production-API20280-actual8-v9/step-043-boundary.json"
RAW = ANCESTOR / "pr9-22.json"
PROOF = ANCESTOR / "pr9-22-endpoint-adjoints.json"
POLYNOMIAL = ANCESTOR / "pr9-22-ordinary-polynomial.json"
MAPPING = Path("/shared/codex-2/vacuum_masters/MASTERS/4L/artifacts/PR9-generic-epsilon-native-verification-v1/v2-proof.json")
DPS = 20400
PRINT_DIGITS = 20408
FAMILY = "693719b1bc3d2f1d4d32c9312df66ced667a542591a2ada6f6498844fc5d0de1"
TARGETS = {
    "PR3": (11, 2, [0,0,0,1,1,1,1,0,1,0]),
    "PR4": (47, 8, [0,0,1,1,1,1,0,0,1,0]),
    "PR4d": (104, 17, [0,0,3,1,0,0,1,1,1,0]),
    "PR5": (35, 5, [0,0,1,0,1,1,1,1,1,0]),
    "PR7": (55, 10, [0,0,1,1,1,1,1,0,1,0]),
    "PR9": (79, 12, [0,0,1,1,1,1,1,1,1,0]),
    "PR9d": (89, 20, [0,0,1,2,1,1,1,1,1,0]),
}
PINS = {
    ENDPOINT: "2b33f543f27e42ba6963fd6abc488b225a1f30d54c92fa1b2770bb42f6f839c1",
    BOUNDARY: "6e7c42db481bad8f83c09245cbb179f9bdd8be825a6bc0eb3add126cf94f757a",
    RAW: "88290b3fe7015e350046044c3a93236700eb180e8141af5781fdfd5dfbfd9c88",
    PROOF: "512d1b3a79a782103540819a1fa37a8642f7c7bcddfa09dd9829ae13a34d2da0",
    POLYNOMIAL: "701b6c7b09257c46924354433027ff19effb8426fb1fd731e3b161cc2daa0aac",
    MAPPING: "bf46ece2c03d8df288ee2a63dc2be0e43fcacee01c37d509f1215439cc8f24cd",
    ANCESTOR / "project_endpoint.py": "40ed888459569d4e243842d1966fcaa5e8f9ae6226aaa0e61fa7350527c0eaae",
    ANCESTOR / "production-native-input-audit.json": "d44b384d73689c84a2fea0a57b7b2a05c8d25f6d9cdc7a542fe5fb8282ee9eb1",
    ANCESTOR / "endpoint-review/review.json": "9afea657dbcf3c5a71570ddeb31be07e0f04a94b2f58f6f9ffeb363aabc076c8",
    ANCESTOR / "endpoint-review/native/review.json": "7c5253c513949b97d007f0284433086a9fb8d5564da1078e54c0503063cd585b",
    HERE / "canonical-routing/check_snapshot.py": "a37ff991d3ae20f6f34794be73bfa5a25e8588af2c0260224b2e9e56eb24501e",
    HERE / "canonical-routing/witness-snapshot.json": "2381970b5a108eb7627dfc42ea49e43e843a32793652c025caa43237f4ed9586",
}
ADJOINT_SHA = {
    "PR3": "114c3c331318d980588acd192f1b06ebeeb515993bfad4b22562da559550bb83",
    "PR4": "b2319d1480c116d8c8e0cef80374e221ce33bc236a927f97275490b742ab8a9e",
    "PR4d": "63078a08788311c074197401a63d8af6538072faace48a9645e4cf8be5a586b9",
    "PR5": "c9dd58a1c8239768b1a8e2ad443e693345bf8b381159d92abd3cca395b917d34",
    "PR7": "5d77843a43b183b6d4fa7c116813c656babefd69c1a718df8eaee0630f08aab0",
    "PR9": "cd3486e3ecfaaadd0c6dcd8886da80d61017ee3037faf5625e1c70c92df52080",
    "PR9d": "0d26620493f0ff760001487fb3263fcc971ccc37388da1f376ab869ca866512f",
}
for _name, _digest in ADJOINT_SHA.items():
    PINS[ANCESTOR / f"{_name}-native-adjoint-20400.json"] = _digest


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _object_pairs(pairs):
    out = {}
    for k, v in pairs:
        require(k not in out, f"duplicate JSON object key: {k}")
        out[k] = v
    return out


def read_json(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=_object_pairs,
                      parse_constant=lambda text: (_ for _ in ()).throw(ValueError(f"nonfinite JSON: {text}")))


def _hash_graph(pins):
    """Verify and traverse explicit reviewed path/hash graphs, without imports.

    Source-code hash maps, path/sha256 records, native input/output paths and
    paired review references are recognized.  Unpaired scalar semantic hashes
    (for example a family identity) are not mistaken for filesystem paths.
    """
    pins = dict(pins)
    done = set()
    def add(path, digest, parent):
        require(isinstance(path, str) and isinstance(digest, str) and
                re.fullmatch(r"[0-9a-f]{64}", digest), f"bad hash edge in {parent}")
        p = Path(path)
        require(p.is_absolute(), f"relative source graph path in {parent}: {path}")
        # Historical review references predate the producer's read-only move.
        # This is a fixed namespace relocation, always authenticated by the
        # original digest, never a filename/hash search or a mutable fallback.
        for loop in ("3L", "4L"):
            old = f"/common/dev/rustred/DO_NOT_PUSH_MASTERS_COMPUTATIONS/{loop}/"
            if path.startswith(old):
                p = Path(f"/shared/codex-2/vacuum_masters/MASTERS/{loop}/artifacts") / path[len(old):]
        require(not p.is_symlink() and p.is_file(), f"missing/symlink source graph input: {p}")
        require(p.resolve() == p, f"noncanonical source graph input: {p}")
        require(p not in pins or pins[p] == digest, f"conflicting source hashes: {p}")
        pins[p] = digest
    def edges(obj, parent):
        if isinstance(obj, list):
            for v in obj: edges(v, parent)
        elif isinstance(obj, dict):
            for k, v in obj.items():
                if isinstance(k, str) and k.startswith("/") and isinstance(v, str) and re.fullmatch(r"[0-9a-f]{64}", v):
                    add(k, v, parent)
                if isinstance(v, str) and v.startswith("/"):
                    candidates = [k + "_sha256"]
                    if k == "path": candidates.append("sha256")
                    if k.endswith("_path"): candidates.append(k[:-5] + "_sha256")
                    for dk in candidates:
                        if dk in obj: add(v, obj[dk], parent)
                edges(v, parent)
            if isinstance(obj.get("native_input"), str) and "native_input_metadata" in obj:
                add(obj["native_input"], obj["native_input_metadata"]["input_sha256"], parent)
    while set(pins) - done:
        p = sorted(set(pins) - done)[0]
        require(not p.is_symlink() and p.is_file() and p.resolve() == p, f"invalid pinned source: {p}")
        require(sha(p) == pins[p], f"source hash mismatch: {p}")
        done.add(p)
        if p.suffix == ".json": edges(read_json(p), p)
    return {str(p): pins[p] for p in sorted(pins)}


def _center(value):
    require(isinstance(value, list) and len(value) == 2, "center must have exactly two components")
    return tuple(Fraction(x) for x in value)


def _balls(values, dimension, label):
    require(isinstance(values, list) and len(values) == dimension, f"{label}: wrong vector length")
    out = []
    for pair in values:
        require(isinstance(pair, list) and len(pair) == 2 and all(isinstance(x, str) for x in pair), f"{label}: malformed complex interval")
        z = acb(arb(pair[0]), arb(pair[1]))
        require(z.is_finite(), f"{label}: nonfinite interval")
        out.append(z)
    return out


def replay_payload(endpoint, boundary, raw, proof, adjoints, mapping):
    """Validate/replay already authenticated dictionaries; useful for negatives.

    This function alone is not an admission receipt: `validate` first checks
    the immutable source/hash graph and every accepted production audit.
    """
    require(endpoint["schema"] == "vakint.ancestor.certified-canonical-master-jets.v1" and endpoint["name"] == "pr9-22", "endpoint schema/name mismatch")
    require(endpoint["normalization"] == boundary["normalization"] == "native_raw", "normalization mismatch")
    require(endpoint["error_quality"] == boundary["error_quality"] == "rigorous-bound", "error quality mismatch")
    require(endpoint["whole_PR11d_accuracy_claimed"] is False and boundary["whole_PR11d_20000_accuracy_claimed"] is False, "unexpected whole-period precision claim")
    require(boundary["schema"] == "vakint.certified-ancestor-ordinary-boundary.v1" and boundary["basis"] == "original_raw_epsilon_jets", "boundary schema/basis mismatch")
    require(boundary["dimension"] == 22 and boundary["epsilon_min_power"] == -4 and boundary["epsilon_max_power"] == 1, "boundary dimension/order mismatch")
    require(boundary["local_truncation_rigorously_enclosed"] is True and _center(boundary["eta_center"]) == (Fraction(0), Fraction(1,16)), "boundary center/tail mismatch")
    require(proof["schema"] == "vakint.ancestor.exact-endpoint-adjoints.v1" and proof["name"] == "pr9-22" and proof["dimension"] == 22 and proof["loop_count"] == 4 and proof["epsilon_jet_count"] == 6, "projector proof dimensions mismatch")
    require(proof["raw_epsilon_range"] == [-4,1] and proof["no_extra_epsilon_factor_required"] is True and proof["squarefree_residue_annihilator_verified"] is True, "projector proof contract mismatch")
    require(mapping["source_family_sha256"] == FAMILY and mapping["deformed_slot_zero_based"] == 2, "canonical family/deformation mismatch")
    require(raw["basis"] == mapping["selected_old_basis"] and len(raw["basis"]) == 22, "raw and canonical selected family basis differ")
    require(list(endpoint["coefficients"]) == ["native::" + s for s in TARGETS], "missing, reordered or extra target symbols")
    require(list(adjoints) == list(TARGETS), "missing, reordered or extra adjoints")
    require(endpoint["target_bindings"] == proof["target_bindings"], "endpoint target bindings differ from exact proof")
    bindings = proof["target_bindings"]
    require(isinstance(bindings, list) and len(bindings) == 7 and [b["master"] for b in bindings] == list(TARGETS), "projector target inventory mismatch")
    for b, (name, (old, selected, powers)) in zip(bindings, TARGETS.items()):
        require((b["old_component"], b["selected_component"], b["powers"]) == (old, selected, powers), f"{name}: canonical powers/components mismatch")
        require(raw["basis"][selected] == powers, f"{name}: selected family/power identity failure")
        # The old endpoint may use a symmetry-related ordered power vector.
        # Its accepted exact mapping must be the literal selected unit row;
        # canonical catalog aliases are admitted separately by exact witnesses.
        require(mapping["old_from_selected_old"][old] == [str(int(i == selected)) for i in range(22)], f"{name}: old endpoint is not the exact selected unit row")
        require(b["required_jet_count"] == 6 and b["common_raw_leading_epsilon_power"] == -4 and b["raw_requested_epsilon_through"] == b["ordinary_raw_required_epsilon_through"] == 1, f"{name}: order binding failure")
    old_precision = ctx.prec
    try:
        ctx.dps = DPS
        working_bits = ctx.prec
        Y = _balls(boundary["values"], 132, "boundary")
        values = []
        summaries = []
        real_min = None
        max_radius = arb(0)
        for name, adj in adjoints.items():
            require(adj["schema"] == "vakint.ancestor.analytic-endpoint-adjoint.v1" and adj["name"] == "pr9-22" and adj["symbol"] == "native::" + name, f"{name}: adjoint identity mismatch")
            require(adj["dimension"] == 132 and adj["base_dimension"] == 22 and adj["loop_count"] == 4 and adj["epsilon_range"] == [0,5], f"{name}: adjoint dimensions/orders mismatch")
            require(adj["order"] == 24000 and adj["working_bits"] == working_bits and adj["tail_bound_added"] is True and adj["whole_PR11d_accuracy_claimed"] is False, f"{name}: adjoint precision/tail contract mismatch")
            require(_center(adj["eta_center"]) == _center(boundary["eta_center"]), f"{name}: adjoint center mismatch")
            W = _balls(adj["complex_balls"], 132, name)
            rows = endpoint["coefficients"]["native::" + name]
            require(isinstance(rows, list) and len(rows) == 6, f"{name}: wrong coefficient count")
            bits_by_order = []
            for p in range(6):
                # Preserve project_endpoint.py's exact product/addition order.
                v = sum((W[22*j+i] * Y[22*(p-j)+i] for j in range(p+1) for i in range(22)), acb(0))
                require(v.is_finite() and v.imag.contains(0), f"{name} eps{p-4}: nonfinite/nonphysical convolution")
                expected = {"epsilon_power": p-4, "ball": v.real.str(PRINT_DIGITS, more=True), "imaginary_ball": v.imag.str(PRINT_DIGITS, more=True), "relative_accuracy_bits": int(v.real.rel_accuracy_bits()), "absolute_radius": v.real.rad().str(35, more=True)}
                require(rows[p] == expected, f"{name} eps{p-4}: saved strings or precision metadata differ from original-order replay")
                values.append((name, p-4, v, rows[p]))
                bits = int(v.real.rel_accuracy_bits())
                bits_by_order.append(bits)
                if not v.real.contains(0): real_min = bits if real_min is None else min(real_min, bits)
                max_radius = max(max_radius, v.real.rad(), v.imag.rad())
            summaries.append({"symbol": "native::" + name, "raw_family_sha256": FAMILY, "ordered_powers": TARGETS[name][2], "epsilon_powers": list(range(-4,2)), "real_relative_accuracy_bits": bits_by_order})
        # Parse rounded decimal boxes at higher precision, then test complete
        # interval containment.  Midpoint agreement/overlap is insufficient.
        ctx.dps = DPS + 80
        component_containments = 0
        for name, power, v, row in values:
            for label, exact_computed in (("ball", v.real), ("imaginary_ball", v.imag)):
                saved = arb(row[label])
                require(saved.is_finite() and saved.contains(exact_computed), f"{name} eps{power}: serialized {label} does not contain full computed interval")
                component_containments += 1
        return {"working_decimal_digits": DPS, "working_bits": working_bits, "serialization_decimal_digits": PRINT_DIGITS, "master_count": 7, "complex_coefficient_count": len(values), "component_full_box_containments": component_containments, "byte_identical_component_strings": 84, "byte_identical_radius_strings": 42, "matched_accuracy_metadata": 42, "minimum_nonzero_real_relative_accuracy_bits": real_min, "maximum_component_radius": max_radius.str(45, more=True), "targets": summaries, "exact_original_convolution_product_count": 7*22*sum(range(1,7)), "all_imaginary_intervals_contain_zero": True}
    finally:
        ctx.prec = old_precision


def validate(endpoint_path=ENDPOINT, boundary_path=BOUNDARY):
    start = time.monotonic()
    require(Path(endpoint_path).absolute() == ENDPOINT and Path(boundary_path).absolute() == BOUNDARY, "only the frozen production-A endpoint/boundary are admitted")
    pins = _hash_graph(PINS)
    endpoint, boundary, raw, proof, mapping = map(read_json, (ENDPOINT, BOUNDARY, RAW, PROOF, MAPPING))
    for d, k, p in ((endpoint,"boundary_sha256",BOUNDARY),(endpoint,"source_sha256",RAW),(endpoint,"adjoint_proof_sha256",PROOF),(boundary,"source_equation_sha256",RAW),(proof,"source_sha256",RAW)):
        require(d[k] == pins[str(p)], f"source binding mismatch: {k}")
    require((PR11D / endpoint["boundary_source"]).resolve() == BOUNDARY, "endpoint boundary path mismatch")
    audit = read_json(ANCESTOR / "production-native-input-audit.json")
    require(audit["schema"] == "vakint.ancestor.production-native-input-audit.v1" and audit["all_completed_production_inputs_valid"] is True and audit["pending_symbols"] == [] and audit["whole_PR11d_accuracy_claimed"] is False, "production adjoint audit not accepted")
    require(len(audit["checks"]) == 9 and len({c["symbol"] for c in audit["checks"]}) == 9, "production audit inventory is not nine unique operators")
    adjoints = {}
    require(len(endpoint["adjoint_inputs"]) == 7, "endpoint adjoint input count mismatch")
    for name, record in zip(TARGETS, endpoint["adjoint_inputs"]):
        p = ANCESTOR / f"{name}-native-adjoint-20400.json"
        require((PR11D / record["path"]).resolve() == p and record["sha256"] == ADJOINT_SHA[name] and record["order"] == 24000 and record["source_polynomial_sha256"] == pins[str(POLYNOMIAL)], f"{name}: endpoint adjoint source binding mismatch")
        a = read_json(p)
        require(a["source_polynomial_sha256"] == pins[str(POLYNOMIAL)] and a["endpoint_projector_proof_sha256"] == pins[str(PROOF)], f"{name}: adjoint polynomial/projector source mismatch")
        checks = [c for c in audit["checks"] if c["symbol"] == "native::"+name]
        require(len(checks) == 1 and checks[0]["path"] == str(p) and checks[0]["sha256"] == ADJOINT_SHA[name] and checks[0]["dimension"] == 132 and checks[0]["order"] == 24000 and checks[0]["working_bits"] == 67771 and checks[0]["all_required_residual_coefficients_retained"] is True and checks[0]["all_input_output_source_hashes_match"] is True, f"{name}: production audit does not accept this exact operator")
        adjoints[name] = a
    result = replay_payload(endpoint, boundary, raw, proof, adjoints, mapping)
    # Only this pinned, isolated exact-algebra module is loaded; no producer
    # preparer/evaluator/transport code can be imported by a shadowed basename.
    routing_path = HERE / "canonical-routing/check_snapshot.py"
    spec = importlib.util.spec_from_file_location("frozen_production_A_canonical_routing", routing_path)
    routing = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(routing)
    require(Path(routing.__file__).resolve() == routing_path, "routing module origin mismatch")
    canonical = routing.validate()
    require(canonical == read_json(HERE / "canonical-routing/witness-snapshot.json"), "exact canonical binding replay differs from frozen witness")
    return {"schema": "vakint.pr11d.physical-4L-production-A-endpoint-replay.v1", "status": "passed_for_frozen_42_endpoint_coefficients", "accepted": True, "validator_sha256": sha(Path(__file__).resolve()), "endpoint_path": str(ENDPOINT), "endpoint_sha256": pins[str(ENDPOINT)], "final_boundary_path": str(BOUNDARY), "final_boundary_sha256": pins[str(BOUNDARY)], "source_pins": pins, "source_pin_count": len(pins), "endpoint_replay": result, "canonical_binding_proof_path": str(HERE/"canonical-routing/witness-snapshot.json"), "canonical_binding_proof_sha256": pins[str(HERE/"canonical-routing/witness-snapshot.json")], "canonical_binding_count": len(canonical["proof"]["canonical_bindings"]), "all_source_and_adjoint_review_hashes_verified": True, "all_canonical_family_power_and_order_bindings_verified": True, "all_serialized_complex_boxes_fully_enclose_original_convolutions": True, "all_original_coefficient_and_metadata_strings_byte_identical": True, "physical_initial_and_transport_chain_admitted_here": False, "independent_IBP_validation_claimed": False, "whole_PR11d_20000_accuracy_claimed": False, "PR11d_validated_decimal_cap": 200, "seconds": time.monotonic()-start}


def write_receipt(output, receipt):
    p = Path(output).absolute()
    require(p.parent.resolve() == HERE and not p.is_symlink(), "output must be a fresh nonsymlink directly inside endpoint-replay")
    require(not p.exists(), "refusing to overwrite output")
    with p.open("x") as stream:
        json.dump(receipt, stream, indent=2, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    # Reject protected/alias outputs before expensive replay.
    require(args.output.absolute().parent.resolve() == HERE and not args.output.exists() and not args.output.is_symlink(), "output must be fresh in the owned endpoint-replay directory")
    receipt = validate()
    write_receipt(args.output, receipt)
    print(json.dumps({"status": receipt["status"], "coefficients": receipt["endpoint_replay"]["complex_coefficient_count"], "source_pins": receipt["source_pin_count"], "seconds": receipt["seconds"]}, indent=2))
