#!/usr/bin/env python3
"""Exact affine-Gamma Laurent recipes for native boundary source factors.

Integer shifts and epsilon divisors remain exact rational expressions. Only the
analytic log-Gamma Taylor coefficients are evaluated numerically, using Arb.
No finite epsilon samples, missing-order zeros or source-data padding are used.
"""
from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction
from flint import arb,fmpq
from logjet_map import Rat,exact,parse,valuation,rational_coefficients,as_arb,FactorJet

def rat(q):
    q=Fraction(q);return Rat(exact.CTX.constant(fmpq(q.numerator,q.denominator)))
E=Rat(exact.CTX.gen(0))

@dataclass(frozen=True)
class GammaArgument:
    intercept:int
    slope:Fraction
    exponent:int
    def __post_init__(self):
        if type(self.intercept) is not int or type(self.exponent) is not int:
            raise ValueError('Gamma intercepts and exponents must be exact integers')
        object.__setattr__(self,'slope',Fraction(self.slope))

class GammaRecipe:
    """R(eps) times a finite product Gamma(a+b*eps)^n with integer a,n."""
    def __init__(self,prefactor=None,gammas=(),*,identity='exact affine-Gamma recipe'):
        self.prefactor=Rat(1) if prefactor is None else prefactor
        counts=defaultdict(int)
        for g in gammas:counts[g.intercept,g.slope]+=g.exponent
        self.gammas=tuple(GammaArgument(a,b,n) for (a,b),n in sorted(counts.items()) if n)
        self.identity=identity
        self.rational=self.prefactor;slopes=defaultdict(int)
        for g in self.gammas:
            a,b,n=g.intercept,g.slope,g.exponent
            if a<=0 and not b:raise ValueError('Undefined fixed Gamma pole in recipe: '+identity)
            slopes[b]+=n
            if a>=1:
                for j in range(1,a):self.rational=self.rational*(rat(j)+rat(b)*E)**n
            else:
                for j in range(a,1):self.rational=self.rational*(rat(j)+rat(b)*E)**(-n)
        self.slopes={b:n for b,n in slopes.items() if n and b}

    def __mul__(self,other):
        if not isinstance(other,GammaRecipe):return NotImplemented
        return GammaRecipe(self.prefactor*other.prefactor,self.gammas+other.gammas,identity=self.identity+' * '+other.identity)

    def normalized_by_tadpoles(self,loops):
        if type(loops) is not int or loops<0:raise ValueError('Invalid tadpole power')
        return self*GammaRecipe((E*(Rat(1)-E))**loops,[GammaArgument(1,Fraction(1),-loops)],identity=f'/T1^{loops}')

    @property
    def first_power(self):return valuation(self.rational)

    def coefficients(self,through):
        if type(through) is not int:raise ValueError('The highest Laurent order must be an integer')
        first=self.first_power
        if first is None:return {}
        if through<first:return {}
        depth=through-first
        q=[arb(0) for _ in range(depth+1)]
        if depth:
            linear=sum((n*b for b,n in self.slopes.items()),Fraction(0))
            q[1]=-arb.const_euler()*as_arb(linear)
        for k in range(2,depth+1):
            exact_moment=sum((n*b**k for b,n in self.slopes.items()),Fraction(0))
            if exact_moment:q[k]=as_arb(exact_moment)*((-1)**k)*arb(k).zeta()/k
        exp=[arb(1)]+[arb(0) for _ in range(depth)]
        for k in range(1,depth+1):exp[k]=sum(j*q[j]*exp[k-j] for j in range(1,k+1))/k
        rr=rational_coefficients(self.rational,through)
        return {p:sum((as_arb(rr.get(j,Fraction(0)))*exp[p-j] for j in range(first,p+1)),arb(0)) for p in range(first,through+1)}

    def exact_polynomial_coefficients(self,through,context):
        """Formal coefficients in independent symbols gamma,zeta2,zeta3,... .

        Identically zero polynomials certify cancellations without identifying
        a tiny numerical enclosure with exact zero. Nonzero polynomials do not
        assert algebraic independence of the special constants.
        """
        first=self.first_power
        if first is None or through<first:return {}
        depth=through-first;zero=context.constant(0);one=context.constant(1)
        q=[zero for _ in range(depth+1)]
        if depth:
            c=-sum((n*b for b,n in self.slopes.items()),Fraction(0))
            q[1]=context.gen(0)*fmpq(c.numerator,c.denominator)
        for k in range(2,depth+1):
            c=sum((n*b**k for b,n in self.slopes.items()),Fraction(0))*Fraction((-1)**k,k)
            q[k]=context.gen(k-1)*fmpq(c.numerator,c.denominator)
        exp=[one]+[zero for _ in range(depth)]
        for k in range(1,depth+1):exp[k]=sum((j*q[j]*exp[k-j] for j in range(1,k+1)),zero)/k
        rr=rational_coefficients(self.rational,through)
        return {p:sum((exp[p-j]*fmpq(rr[j].numerator,rr[j].denominator) for j in range(first,p+1)),zero) for p in range(first,through+1)}

    def factor_jet(self,through,*,source_identity=None):
        first=self.first_power
        if first is None:raise ValueError('Represent identically zero factors separately with an explicit certified range')
        coeff=self.coefficients(through)
        if not coeff:raise ValueError('Requested range precedes the exact Gamma valuation')
        return FactorJet(first,tuple(coeff[p] for p in range(first,through+1)),
          'Exact Gamma recurrence divisor: '+str(self.rational)+'; Gamma(1+b*epsilon) is analytic and nonzero at epsilon=0',
          source_identity or self.identity)

    def proof(self):
        return {'identity':self.identity,'prefactor':str(self.prefactor),'gamma_factors':[{'intercept':g.intercept,'slope':str(g.slope),'exponent':g.exponent} for g in self.gammas],
          'exact_recurrence_rational_factor':str(self.rational),'exact_gamma_log_slopes':{str(b):n for b,n in self.slopes.items()},'certified_first_laurent_power':self.first_power,
          'normalization':'raw native Minkowski measure; no Euler exponential or tadpole normalization unless explicitly included'}

def tadpole(power):
    if type(power) is not int or power<1:raise ValueError('Only positive integer tadpole powers are supported')
    return GammaRecipe(rat((-1)**power),[GammaArgument(power-2,1,1),GammaArgument(power,0,-1)],identity=f'T{power}=(-1)^{power}Gamma({power}-2+epsilon)/Gamma({power})')

def radial(proof):
    if proof['status']!='actual_native_single_mass_plan_proved':raise ValueError('An exact native single-mass proof is required')
    if proof['mass_squared']!='1' or Fraction(proof['massive_scale'])!=1 or abs(Fraction(proof['routing_determinant']))!=1:
        raise ValueError('Nonunit mass, scale or Jacobian needs its explicit dimensional power')
    loops=int(proof['parent_loops']);remaining=int(proof['remaining_power']);a=int(proof['massive_power'])
    if loops<2 or a<1 or proof['child_loops']!=loops-1:raise ValueError('Invalid native radial proof')
    return GammaRecipe(rat((-1)**a),[
      GammaArgument(2*loops-remaining,-loops,1),GammaArgument(a+remaining-2*loops,loops,1),
      GammaArgument(2,-1,-1),GammaArgument(a,0,-1)],identity='Native SingleMassPlan radial prefactor')
