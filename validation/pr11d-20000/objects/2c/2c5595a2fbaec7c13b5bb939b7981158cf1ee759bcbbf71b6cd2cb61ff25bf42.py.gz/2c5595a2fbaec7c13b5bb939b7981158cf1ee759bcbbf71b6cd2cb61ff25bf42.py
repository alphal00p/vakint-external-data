#!/usr/bin/env python3
"""Collect the actual current scientific read-set, never historical catalog closure.

The complete receipts and catalogs remain authenticated data. Only explicit
current-admission pin maps and the verifier's named scientific roles are edges.
The independently reviewed result is hard-pinned by the delivery verifier.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re

if not __debug__:
    raise RuntimeError("Read-set classification requires assertions")
ROOT = Path(__file__).resolve().parent.parent
HEX = re.compile(r"[0-9a-f]{64}\Z")
MAP_FIELDS = ("source_pins", "artifact_sha256", "implementation_sha256", "transitive_source_sha256", "implementation_and_source_dependency_sha256")


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for part in iter(lambda: stream.read(1 << 20), b""):
            h.update(part)
    return h.hexdigest()


def unique(items):
    result = {}
    for key, value in items:
        assert key not in result, "Duplicate JSON key"
        result[key] = value
    return result


def read(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=unique)


def escape(key):
    return key.replace("~", "~0").replace("/", "~1")


class ReadSet:
    def __init__(self):
        self.files, self.nodes = {}, {}
        self.implementation_paths = {str(ROOT / "accepted20000/verify_bundle.py"): "verify_bundle", str(ROOT / "accepted20000/assemble.py"): "assemble"}

    def add(self, path, digest=None, role="current-admission-input", declared_by=None):
        path = str(Path(path).resolve(strict=True))
        assert path not in self.implementation_paths, "Final implementation hashes are deliberately outside the cyclic science read-set"
        digest = digest or sha(path)
        assert HEX.fullmatch(digest) and sha(path) == digest, ("Current required proof input is missing or changed", path)
        assert path not in self.files or self.files[path] == digest, ("Conflicting current proof hashes", path)
        self.files[path] = digest
        node = self.nodes.setdefault(path, {"sha256": digest, "roles": [], "consumed_json_pointers": [], "required_references": [], "embedded_provenance_policy": "Authenticated full bytes; no claim to replay every embedded historical validator, campaign catalog, or runtime cache inventory."})
        if role not in node["roles"]:
            node["roles"].append(role)
        if declared_by and declared_by not in node["required_references"]:
            node["required_references"].append(declared_by)
        return path

    def document(self, path, digest=None, role="current-proof-record", consumed=()):
        path = self.add(path, digest, role)
        data = read(path)
        self.nodes[path]["schema"] = data.get("schema")
        self.nodes[path]["portable_operation"] = "semantic_json_read"
        # The current verifier consumes this entire typed record as data. This
        # does not turn every embedded historical pathname into a dependency.
        for pointer in ("", *consumed):
            if pointer not in self.nodes[path]["consumed_json_pointers"]:
                self.nodes[path]["consumed_json_pointers"].append(pointer)
        return path, data

    def edge(self, owner, target, digest, digest_pointer, path_pointer=None, target_from_key=False, relative_base=None):
        resolved = Path(target)
        if not resolved.is_absolute():
            assert relative_base is not None, "Relative evidence needs a declared schema-specific base"
            resolved = relative_base / resolved
        target = self.add(resolved, digest)
        edge = {"owner": owner, "target": target, "sha256": digest, "digest_json_pointer": digest_pointer, "path_json_pointer": path_pointer, "target_from_map_key": target_from_key}
        if relative_base is not None:
            edge["relative_reference_base"] = str(relative_base)
        self.nodes[owner]["required_references"].append(edge)
        return target

    def maps(self, path, data):
        for field in MAP_FIELDS:
            pins = data.get(field, {})
            assert isinstance(pins, dict)
            for target, digest in pins.items():
                assert Path(target).is_absolute() and HEX.fullmatch(digest), ("Malformed current proof map", path, field, target)
                self.edge(path, target, digest, "/" + field + "/" + escape(target), target_from_key=True)
            if pins and "/" + field not in self.nodes[path]["consumed_json_pointers"]:
                self.nodes[path]["consumed_json_pointers"].append("/" + field)

    def pair(self, owner, data, stem, role="current-proof-record", consumed=()):
        target = self.edge(owner, data[stem + "_path"], data[stem + "_sha256"], "/" + stem + "_sha256", "/" + stem + "_path")
        return self.document(target, data[stem + "_sha256"], role, consumed)

    def projection(self, path):
        owner, data = self.document(path, role="final-bounded-projection", consumed=("/coefficients", "/source_equation_sha256", "/normalization", "/error_quality", "/working_decimal_precision", "/working_bits", "/serialization_decimal_digits"))
        assert data["schema"] == "vakint.pr11d.bounded-finite-endpoint-projection.v1"
        chain_path, chain = self.pair(owner, data, "chain_acceptance", consumed=("/status", "/initial_physical_provenance_verified", "/initial_physical_boundary_sha256", "/final_boundary_sha256"))
        assert chain["status"] == "passed_for_frozen_completed_physical_chain"
        self.maps(chain_path, chain)
        reviewer, review = self.pair(chain_path, chain, "independent_validator_review")
        self.maps(reviewer, review)
        for stem in ("boundary", "transport_receipt", "adjoint", "adjoint_acceptance"):
            child, record = self.pair(owner, data, stem, role="final-numerical-input" if stem != "adjoint_acceptance" else "endpoint-admission", consumed=("",))
            if stem == "adjoint_acceptance":
                self.maps(child, record)

    def science(self):
        review_path, review = self.document(ROOT / "helper/physical-poles-review/review.json", role="fixed-physical-poles-review", consumed=("/scientific_conclusions", "/source_identity", "/raw_pole_certificate_sha256", "/finiteness_certificate_sha256"))
        self.maps(review_path, review)
        self.pair(review_path, review, "raw_pole_certificate", role="raw42-pole-certificate", consumed=("",))
        cert_path, cert = self.pair(review_path, review, "finiteness_certificate", role="exact-P17-finiteness", consumed=("",))
        self.pair(cert_path, cert, "original_X8_source", role="exact-differential-family-and-target-data", consumed=("/family", "/basis", "/target_reductions", "/source_family_sha256"))
        self.pair(cert_path, cert, "canonical_reference_input", role="canonical-physical-master-identity", consumed=("/master_id", "/powers", "/family_sha256"))
        ibp_path, ibp = self.document(ROOT / "kira-identity-audit/REPLAY_RECEIPT.json", role="fixed-partial-independent-IBP-review", consumed=("/source_system_sha256", "/source_family_sha256", "/target_relations_independently_proved", "/de_rows_independently_proved", "/de_rows_still_trusting_external_Kira", "/remaining_scope"))
        for relative, digest in ibp["files_sha256"].items():
            self.edge(ibp_path, relative, digest, "/files_sha256/" + escape(relative), target_from_key=True, relative_base=Path(ibp_path).parent)
        oracle_path, oracle = self.document(ROOT / "amflow-oracle/acceptance.json", role="practical-independent-ordinary-solver-check", consumed=("/finite_real_central_value", "/status", "/reference_is_postsolve_only", "/independence_scope", "/resources"))
        manifest_path, manifest = self.document(ROOT / "amflow-oracle/files.json", role="scoped-AMFlow-source-inventory", consumed=("/files", "/private_license_configuration_excluded", "/acceptance_sha256"))
        assert manifest["acceptance_sha256"] == sha(oracle_path) and manifest["private_license_configuration_excluded"] is True
        for i, row in enumerate(manifest["files"]):
            self.edge(manifest_path, row["path"], row["sha256"], f"/files/{i}/sha256", f"/files/{i}/path", relative_base=Path(manifest_path).parent)
        for relative, digest in oracle["source_hashes"].items():
            self.edge(oracle_path, relative, digest, "/source_hashes/" + escape(relative), target_from_key=True, relative_base=Path(oracle_path).parent)
        for i, resource in enumerate(oracle["resources"]):
            for name in ("process", "result"):
                digest = resource[name + "_sha256"]
                matches = [p for p, h in self.files.items() if h == digest]
                assert matches, "The practical oracle resource is missing from its scoped inventory"
                self.edge(oracle_path, matches[0], digest, f"/resources/{i}/{name}_sha256")
        self.add(Path(__file__), role="read-set-classification-implementation")
        self.add(ROOT / "p853/validate.py", role="independently-checked-decimal-rounding-helper")
        self.add(ROOT / "endpoint-adjoint/project_v2.py", role="final-projection-implementation")
        projection_review, projection_data = self.document(ROOT / "helper/endpoint-review/final-projection/project-v2-delta-review.json", role="projection-implementation-review", consumed=("",))
        self.maps(projection_review, projection_data)
        bessel_path, bessel = self.document(ROOT.parent / "bessel/ancestor-boundary/production-runs-v1/Bessel20000-comparison-readset.json", role="scoped-independent-Bessel-controls", consumed=("/files_sha256", "/comparisons", "/JSON_roles"))
        for target, digest in bessel["files_sha256"].items():
            self.edge(bessel_path, target, digest, "/files_sha256/" + escape(target), target_from_key=True)
        for target, description in bessel["JSON_roles"].items():
            node = self.nodes[target]
            node["current_control_role"] = description["role"]
            for pointer in description["consumed_json_pointers"]:
                if pointer not in node["consumed_json_pointers"]:
                    node["consumed_json_pointers"].append(pointer)

    def finish(self, draft=False):
        for path, node in self.nodes.items():
            node.setdefault("portable_operation", "hash_only_current_admission_input")
            if Path(path).suffix == ".json":
                data = read(path)
                node["schema"] = data.get("schema") if isinstance(data, dict) else "JSON-array-data"
                if node["schema"] == "vakint.external-data.loop.v1":
                    node["content_classification"] = "immutable_external_loop_identity_catalog"
                    node["catalog_semantics"] = "Canonical family, ordered powers, aliases, and normalization are identity data selected by the current authenticated lookup/routing witnesses. This proof does not replay unrelated masters, reductions, cache workloads, or old producer campaigns merely because their paths occur in this catalog. All files actually opened by current admissions remain separately required."
                    node["informational_reference_scopes"] = [{"json_pointer": "/" + key, "classification": "unreplayed_runtime_or_historical_inventory", "reason": node["catalog_semantics"]} for key in ("files", "cache", "ibps", "coverage", "provenance", "producer_update", "numerical_precision_supplement") if key in data]
                    # Scope identity lookups to the actual rows consumed by the
                    # reviewed routing/API audits, not every runtime master.
                    loop_count = data['loop_count']
                    if loop_count == 4:
                        assert node['sha256'] == 'b40adfb858f4a10852d341aab0a8550de93e3c7526b953a6c4b21cbc7bb8f9b9'
                        selected_masters = [2, 4, 5, 6, 7, 10, 14]
                        selected_families = [1]
                        assert [data['masters'][i]['name'] for i in selected_masters] == ['P3','P5','P6','P7','P8','P11','P15']
                        node['selection_authority'] = 'Exact canonical routing witness consumed family1 and the seven named master identity/power/exact-basis rows; no runtime file/cache dereference.'
                    else:
                        assert loop_count == 3
                        selected_masters = [i for i, row in enumerate(data['masters']) if row['name'] in ('P13','P14')]
                        assert [data['masters'][i]['name'] for i in selected_masters] == ['P13','P14']
                        selected_hashes = {data['masters'][i]['family_sha256'] for i in selected_masters}
                        selected_families = [i for i, row in enumerate(data['families']) if row['sha256'] in selected_hashes]
                        node['selection_authority'] = 'Current AP source auditors compare complete P13/P14 metadata rows to copied snapshots and authenticate selected symbolic payload bindings; global runtime paths are not resolved as copied snapshot paths.'
                    node['selected_master_indices'] = selected_masters
                    node['selected_family_indices'] = selected_families
                    pointers = ['/' + key for key in ('schema','version','loop_count','dimension','normalization','unit_mass_squared') if key in data]
                    pointers += ['/masters/' + str(i) for i in selected_masters]
                    pointers += ['/families/' + str(i) for i in selected_families]
                    node['consumed_json_pointers'] = pointers
                    node['informational_reference_scopes'] += [{'json_pointer':'/masters/'+str(i),'classification':'unselected_master_catalog_row','reason':node['selection_authority']} for i in range(len(data['masters'])) if i not in selected_masters]
                    node['informational_reference_scopes'] += [{'json_pointer':'/families/'+str(i),'classification':'unselected_family_catalog_row','reason':node['selection_authority']} for i in range(len(data['families'])) if i not in selected_families]
                    node['portable_operation'] = 'authenticated_catalog_identity_data'
                elif node['schema'] == 'vakint.external-data.v1':
                    node['content_classification'] = 'immutable_release_identity_catalog'
                    selected = [i for i, row in enumerate(data['loop_packs']) if row['loop_count'] == 3]
                    assert len(selected) == 1
                    node['consumed_json_pointers'] = ['/version', '/loop_packs/'+str(selected[0])+'/loop_count', '/loop_packs/'+str(selected[0])+'/manifest_sha256']
                    node['informational_reference_scopes'] = [{'json_pointer':'/loop_packs/'+str(i),'classification':'unselected_release_pack','reason':'Only the authenticated3L snapshot is consumed by the current P13/P14 source audit; this PR11 proof does not download or validate other runtime packs.'} for i in range(len(data['loop_packs'])) if i not in selected]
                    node['portable_operation'] = 'authenticated_catalog_identity_data'
                elif Path(path).name == 'master-metadata.json' and isinstance(data, dict) and data.get('loop_count') == 3 and data.get('name') in ('P13','P14'):
                    node['content_classification'] = 'selected_API_master_metadata_snapshot'
                    node['portable_operation'] = 'semantic_json_read'
                    node['consumed_json_pointers'] = ['']
                    node['snapshot_binding_policy'] = 'Metadata equality is checked against the selected manifest row. Payloads are bound by copied filename and digest, never by guessing global manifest runtime paths.'
                    # Old20280 audit consumes all copied bindings. The guard20600
                    # audit consumes symbolic.json; other payloads remain bytes
                    # in the complete flat host/admission read-set if declared.
                    filenames = list(data['files']) if '/guard20600/' not in path else ['symbolic.json']
                    node['required_snapshot_payload_bindings'] = []
                    for filename in filenames:
                        binding = data['files'][filename]
                        preferred = str(Path(path).parent / filename)
                        assert self.files.get(preferred) == binding['sha256'], ('Missing exact sibling snapshot consumed by the current source auditor', path, filename)
                        target = preferred
                        self.edge(path, target, binding['sha256'], '/files/'+escape(filename)+'/sha256')
                        node['required_snapshot_payload_bindings'].append({'filename':filename,'required_actual_snapshot_path':target,'sha256':binding['sha256']})
                    node['informational_reference_scopes'] = [{'json_pointer':'/files/'+escape(filename)+'/path','classification':'global_runtime_location_not_a_copied_snapshot_path','reason':node['snapshot_binding_policy']} for filename in data['files']]
                elif node["portable_operation"] == "hash_only_current_admission_input":
                    node["content_classification"] = "retained_exact_input_of_the_current_admission_readset"
                    node["informational_reference_scopes"] = [{"json_pointer": "", "classification": "not_a_recursive_execution_request", "reason": "The complete file is a required authenticated input to a named current admission. Its current dependencies are the explicit reviewed flat read-set; preserving this input does not claim to rerun its historical campaigns, inventories, or every nested provenance reference."}]
                else:
                    node["content_classification"] = "current_typed_semantic_proof_record"
                    node["informational_reference_scopes"] = []
                # Every declared semantic pointer is checked, including root.
                for pointer in node["consumed_json_pointers"]:
                    value = data
                    for part in pointer[1:].split("/") if pointer else ():
                        part = part.replace("~1", "/").replace("~0", "~")
                        value = value[int(part)] if isinstance(value, list) else value[part]
            else:
                node["content_classification"] = "source_binary_or_exact_text_input"
                node["schema"] = None
                node["informational_reference_scopes"] = []
            node["roles"].sort()
            node["consumed_json_pointers"].sort()
        return {"schema": "vakint.pr11d.scientific-proof-read-set.v1", "status": "draft_current_inputs_only" if draft else "complete_current_scientific_proof_read_set", "scope": "Complete actual current mathematical/source/admission read-set. Original catalogs and historical receipts are retained in full, but unconsumed history and unrelated runtime/cache inventories are not recursively replayed.", "files_sha256": dict(sorted(self.files.items())), "nodes": dict(sorted(self.nodes.items())), "implementation_paths": self.implementation_paths, "required_file_count": len(self.files), "required_uncompressed_bytes": sum(Path(p).stat().st_size for p in self.files), "source_cap_promoted_by_this_file": False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--first-projection", type=Path)
    parser.add_argument("--second-projection", type=Path)
    parser.add_argument("--draft-current-record", type=Path, action="append", default=[])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert args.output.resolve().is_relative_to(ROOT / "accepted20000") and not args.output.exists()
    result = ReadSet()
    result.science()
    draft = bool(args.draft_current_record)
    if draft:
        assert args.first_projection is None and args.second_projection is None
        for record in args.draft_current_record:
            owner, data = result.document(record, role="draft-current-admission-record", consumed=("",))
            result.maps(owner, data)
    else:
        assert args.first_projection and args.second_projection and args.first_projection.resolve() != args.second_projection.resolve()
        result.projection(args.first_projection)
        result.projection(args.second_projection)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result.finish(draft), indent=2) + "\n")
    print("READ-SET", len(result.files), "files", sha(args.output), "DRAFT" if draft else "COMPLETE CANDIDATE PENDING INDEPENDENT REVIEW")


if __name__ == "__main__":
    main()
