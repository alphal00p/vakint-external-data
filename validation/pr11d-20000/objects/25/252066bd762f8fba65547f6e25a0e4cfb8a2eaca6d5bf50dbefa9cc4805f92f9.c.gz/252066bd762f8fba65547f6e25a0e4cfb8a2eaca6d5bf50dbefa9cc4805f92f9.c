#define _POSIX_C_SOURCE 200809L
#include <flint/acb.h>
#include <flint/arb.h>
#include <flint/fmpz.h>
#include <flint/fmpq.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/resource.h>
#include <omp.h>

typedef struct { fmpz_t re, im; } gaussian;
typedef struct { int row, col, jet; gaussian c[17]; arb_t bound; } coupling;
static int dim,jets,blocks,degree,ring_size,entry_count,*block_of;
static slong precision;
static gaussian D[17];
static coupling *N;
static acb_ptr history,total,work;
static arb_t denominator_lower;
static double seconds(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+1e-9*t.tv_nsec;}
static void die(const char *message){fprintf(stderr,"%s\n",message);exit(2);}
static void read_gaussian(FILE *f,gaussian *g){char re[8192],im[8192];fmpz_init(g->re);fmpz_init(g->im);if(fscanf(f,"%8191s %8191s",re,im)!=2)die("invalid Gaussian coefficient");if(fmpz_set_str(g->re,re,10)||fmpz_set_str(g->im,im,10))die("invalid Gaussian integer");}
static void addmul(acb_t result,const acb_t value,const gaussian *g,int subtract){
    if(!subtract){
        arb_addmul_fmpz(acb_realref(result),acb_realref(value),g->re,precision);
        arb_addmul_fmpz(acb_imagref(result),acb_imagref(value),g->re,precision);
        if(!fmpz_is_zero(g->im)){
            arb_submul_fmpz(acb_realref(result),acb_imagref(value),g->im,precision);
            arb_addmul_fmpz(acb_imagref(result),acb_realref(value),g->im,precision);
        }
    }else{
        arb_submul_fmpz(acb_realref(result),acb_realref(value),g->re,precision);
        arb_submul_fmpz(acb_imagref(result),acb_imagref(value),g->re,precision);
        if(!fmpz_is_zero(g->im)){
            arb_addmul_fmpz(acb_realref(result),acb_imagref(value),g->im,precision);
            arb_submul_fmpz(acb_imagref(result),acb_realref(value),g->im,precision);
        }
    }
}
static acb_ptr coefficient(long n){return history+(n%ring_size)*(dim*jets);}
static void upper(arb_t out,const arb_t value){arf_t x;arf_init(x);arb_get_ubound_arf(x,value,128);arb_set_arf(out,x);arf_clear(x);}
static void magnitude(arb_t out,const acb_t value){mag_t m;mag_init(m);acb_get_mag(m,value);arf_set_mag(arb_midref(out),m);mag_zero(arb_radref(out));mag_clear(m);}

/* Residual supersolution: (m+1)v >= F+|A|v. The block-triangular
 * connection is solved in physical-block order and then epsilon-jet order.
 * Exact low residual coefficients vanish by the Taylor recurrence. Their ball
 * enclosures are never replaced by midpoints. */
static int certify(long m,arb_ptr budgets,arb_t maximum){
    int states=dim*jets;
    acb_ptr residual=_acb_vec_init(states);
    arb_ptr forcing=_arb_vec_init(states),mu=_arb_vec_init(blocks);
    arb_t tmp,sum,den,best;arb_init(tmp);arb_init(sum);arb_init(den);arb_init(best);
    gaussian scaled;fmpz_init(scaled.re);fmpz_init(scaled.im);
    for(long power=m;power<=m+degree;power++){
        _acb_vec_zero(residual,states);
        for(int k=0;k<=degree;k++){
            long index=power-k+1;
            if(index>=1&&index<=m){
                fmpz_mul_ui(scaled.re,D[k].re,index);fmpz_mul_ui(scaled.im,D[k].im,index);
                acb_ptr row=coefficient(index);
                for(int i=0;i<states;i++)addmul(residual+i,row+i,&scaled,0);
            }
        }
        for(int e=0;e<entry_count;e++)for(int k=0;k<=degree;k++){
            long index=power-k;if(index<0||index>m)continue;
            acb_ptr row=coefficient(index);
            for(int jet=N[e].jet;jet<jets;jet++)addmul(residual+jet*dim+N[e].row,row+(jet-N[e].jet)*dim+N[e].col,&N[e].c[k],1);
        }
        for(int i=0;i<states;i++){magnitude(tmp,residual+i);arb_add(forcing+i,forcing+i,tmp,128);}
    }
    for(int i=0;i<states;i++){arb_div(tmp,forcing+i,denominator_lower,128);upper(forcing+i,tmp);}
    for(int b=0;b<blocks;b++)for(int row=0;row<dim;row++)if(block_of[row]==b){
        arb_zero(sum);
        for(int e=0;e<entry_count;e++)if(N[e].row==row&&N[e].jet==0&&block_of[N[e].col]==b)arb_add(sum,sum,N[e].bound,128);
        upper(tmp,sum);arb_max(mu+b,mu+b,tmp,128);
    }
    int valid=1;
    _arb_vec_zero(budgets,blocks*jets);arb_zero(maximum);
    for(int b=0;b<blocks;b++){
        arb_set_ui(den,m+1);arb_sub(den,den,mu+b,128);
        if(!arb_is_positive(den)){valid=0;break;}
        for(int jet=0;jet<jets;jet++){
            arb_zero(best);
            for(int row=0;row<dim;row++)if(block_of[row]==b){
                arb_set(sum,forcing+jet*dim+row);
                for(int e=0;e<entry_count;e++)if(N[e].row==row&&N[e].jet<=jet){
                    int source_block=block_of[N[e].col];
                    if(source_block==b&&N[e].jet==0)continue;
                    if(source_block>b)die("connection is not block triangular");
                    arb_addmul(sum,N[e].bound,budgets+source_block*jets+jet-N[e].jet,128);
                }
                upper(tmp,sum);arb_max(best,best,tmp,128);
            }
            arb_div(tmp,best,den,128);upper(budgets+b*jets+jet,tmp);
            arb_max(maximum,maximum,budgets+b*jets+jet,128);
        }
    }
    _acb_vec_clear(residual,states);_arb_vec_clear(forcing,states);_arb_vec_clear(mu,blocks);
    arb_clear(tmp);arb_clear(sum);arb_clear(den);arb_clear(best);fmpz_clear(scaled.re);fmpz_clear(scaled.im);
    return valid;
}

/* Exact rational partial fractions supply both connection majorants and a
 * short auxiliary recurrence. The polynomial residual certificate is unchanged. */
#define RPF_NUM_DEGREE 4
#define RPF_MAX_COEFFICIENTS 21
typedef struct { fmpq_t re,im; } rpf_complex;
typedef struct {
    int base_degree,power;
    fmpq_t coefficients[3],minimum_squared,minimum_parameter;
    rpf_complex base_local[3];
    rpf_complex local[17],quotient[17];
    gaussian base_integer[3];
    fmpz_t base_denominator,base_constant_norm;
    acb_ptr auxiliary;
    arb_t minimum_lower;
} rpf_factor;
typedef struct {
    int row,col,jet,factor_index,num_degree,next;
    rpf_complex local_numerator[5];
    gaussian numerator_integer[5];
    fmpz_t numerator_denominator;
} rpf_term;
static int rpf_factor_count,rpf_term_count;
static int rpf_active_term_count,*rpf_head;
static rpf_factor *rpf_factors;
static rpf_term *rpf_terms;
static rpf_complex rpf_center,rpf_step;
static fmpz_t rpf_denominator;
static arb_t polynomial_mu,rpf_mu,chosen_mu;

static void rpf_read_integer(FILE *f,fmpz_t out){
    char text[8192];if(fscanf(f,"%8191s",text)!=1||fmpz_set_str(out,text,10))die("invalid RPF integer");
}
static void rc_init(rpf_complex *a){fmpq_init(a->re);fmpq_init(a->im);}
static void rc_clear(rpf_complex *a){fmpq_clear(a->re);fmpq_clear(a->im);}
static void rc_zero(rpf_complex *a){fmpq_zero(a->re);fmpq_zero(a->im);}
static int rc_is_zero(const rpf_complex *a){return fmpq_is_zero(a->re)&&fmpq_is_zero(a->im);}
static void rc_set(rpf_complex *a,const rpf_complex *b){fmpq_set(a->re,b->re);fmpq_set(a->im,b->im);}
/* Keep the exact startup helper out of line: GCC16's inlined object-size
 * analysis mistakes fmpq's numerator subobject for the complete rational. */
__attribute__((noinline)) static void rc_add(rpf_complex *a,const rpf_complex *b,const rpf_complex *c){fmpq_add(a->re,b->re,c->re);fmpq_add(a->im,b->im,c->im);}
static void rc_sub(rpf_complex *a,const rpf_complex *b,const rpf_complex *c){fmpq_sub(a->re,b->re,c->re);fmpq_sub(a->im,b->im,c->im);}
static void rc_mul(rpf_complex *out,const rpf_complex *a,const rpf_complex *b){
    fmpq_t re,im,tmp;fmpq_init(re);fmpq_init(im);fmpq_init(tmp);
    fmpq_mul(re,a->re,b->re);fmpq_mul(tmp,a->im,b->im);fmpq_sub(re,re,tmp);
    fmpq_mul(im,a->re,b->im);fmpq_mul(tmp,a->im,b->re);fmpq_add(im,im,tmp);
    fmpq_set(out->re,re);fmpq_set(out->im,im);fmpq_clear(re);fmpq_clear(im);fmpq_clear(tmp);
}
static void rc_norm_squared(fmpq_t out,const rpf_complex *a){
    fmpq_t tmp;fmpq_init(tmp);fmpq_mul(out,a->re,a->re);fmpq_mul(tmp,a->im,a->im);fmpq_add(out,out,tmp);fmpq_clear(tmp);
}
static void rc_div(rpf_complex *out,const rpf_complex *a,const rpf_complex *b){
    fmpq_t re,im,norm,tmp;fmpq_init(re);fmpq_init(im);fmpq_init(norm);fmpq_init(tmp);
    rc_norm_squared(norm,b);if(fmpq_is_zero(norm))die("zero exact RPF polynomial divisor");
    fmpq_mul(re,a->re,b->re);fmpq_mul(tmp,a->im,b->im);fmpq_add(re,re,tmp);
    fmpq_mul(im,a->im,b->re);fmpq_mul(tmp,a->re,b->im);fmpq_sub(im,im,tmp);
    fmpq_div(out->re,re,norm);fmpq_div(out->im,im,norm);
    fmpq_clear(re);fmpq_clear(im);fmpq_clear(norm);fmpq_clear(tmp);
}
static rpf_complex *rc_vec(int count){
    rpf_complex *out=calloc((size_t)count,sizeof(rpf_complex));if(count&&!out)die("RPF allocation failure");
    for(int i=0;i<count;i++)rc_init(out+i);
    return out;
}
static void rc_vec_clear(rpf_complex *a,int count){for(int i=0;i<count;i++)rc_clear(a+i);free(a);}
/* Convert once, exactly, to Gaussian integers over one positive scalar.
 * Iterative arithmetic then multiplies ball values only by exact integers. */
static void rpf_integer_polynomial(gaussian *out,fmpz_t denominator,const rpf_complex *input,int count){
    fmpz_init(denominator);fmpz_one(denominator);
    for(int k=0;k<count;k++){
        fmpz_lcm(denominator,denominator,fmpq_denref(input[k].re));
        fmpz_lcm(denominator,denominator,fmpq_denref(input[k].im));
    }
    if(fmpz_sgn(denominator)<=0)die("invalid converted RPF denominator");
    fmpz_t scale;fmpz_init(scale);
    for(int k=0;k<count;k++){
        fmpz_init(out[k].re);fmpz_init(out[k].im);
        fmpz_divexact(scale,denominator,fmpq_denref(input[k].re));
        fmpz_mul(out[k].re,fmpq_numref(input[k].re),scale);
        fmpz_divexact(scale,denominator,fmpq_denref(input[k].im));
        fmpz_mul(out[k].im,fmpq_numref(input[k].im),scale);
    }
    fmpz_clear(scale);
}
static acb_ptr rpf_auxiliary_coefficient(const rpf_factor *factor,int power,long n){
    return factor->auxiliary+((slong)(power-1)*ring_size+n%ring_size)*(dim*jets);
}
static void rpf_divide_gaussian(acb_t out,const acb_t value,const gaussian *divisor,const fmpz_t norm,arb_t re,arb_t im){
    arb_mul_fmpz(re,acb_realref(value),divisor->re,precision);
    arb_addmul_fmpz(re,acb_imagref(value),divisor->im,precision);
    arb_mul_fmpz(im,acb_imagref(value),divisor->re,precision);
    arb_submul_fmpz(im,acb_realref(value),divisor->im,precision);
    arb_div_fmpz(acb_realref(out),re,norm,precision);
    arb_div_fmpz(acb_imagref(out),im,norm,precision);
}
static void rpf_read_complex(FILE *f,rpf_complex *out){
    fmpz_t re,im,den;fmpz_init(re);fmpz_init(im);fmpz_init(den);
    rpf_read_integer(f,re);rpf_read_integer(f,im);rpf_read_integer(f,den);
    if(fmpz_sgn(den)<=0)die("invalid RPF Gaussian denominator");
    fmpq_set_fmpz_frac(out->re,re,den);fmpq_set_fmpz_frac(out->im,im,den);
    fmpz_clear(re);fmpz_clear(im);fmpz_clear(den);
}
/* Exact Horner composition of a real polynomial with center+step*t. */
static void rpf_compose(rpf_complex *out,const fmpq *coeff,int n){
    rpf_complex a,b;rc_init(&a);rc_init(&b);
    for(int k=0;k<=n;k++)rc_zero(out+k);
    fmpq_set(out[0].re,coeff+n);
    int current=0;
    for(int j=n-1;j>=0;j--){
        for(int k=current+1;k>=0;k--){
            if(k<=current)rc_mul(&a,out+k,&rpf_center);else rc_zero(&a);
            if(k>=1)rc_mul(&b,out+k-1,&rpf_step);else rc_zero(&b);
            rc_add(out+k,&a,&b);
        }
        fmpq_set(a.re,coeff+j);fmpq_zero(a.im);
        rc_add(out,out,&a);current++;
    }
    rc_clear(&a);rc_clear(&b);
}
static void rpf_poly_multiply(rpf_complex *out,const rpf_complex *a,int na,const rpf_complex *b,int nb){
    rpf_complex product;rc_init(&product);
    for(int k=0;k<=na+nb;k++)rc_zero(out+k);
    for(int i=0;i<=na;i++)for(int j=0;j<=nb;j++){rc_mul(&product,a+i,b+j);rc_add(out+i+j,out+i+j,&product);}
    rc_clear(&product);
}
static int rpf_actual_degree(const rpf_complex *poly,int upper_degree){
    while(upper_degree>=0&&rc_is_zero(poly+upper_degree))upper_degree--;
    return upper_degree;
}
static void rpf_divide_D(rpf_factor *factor,const rpf_complex *polynomial){
    int nd=rpf_actual_degree(polynomial,degree),nq=rpf_actual_degree(factor->local,degree);
    if(nq<1||nd<nq)die("RPF factor does not divide polynomial denominator");
    rpf_complex *remainder=rc_vec(degree+1),product;rc_init(&product);
    for(int k=0;k<=degree;k++)rc_set(remainder+k,polynomial+k);
    for(int k=nd-nq;k>=0;k--){
        rc_div(factor->quotient+k,remainder+nq+k,factor->local+nq);
        for(int j=0;j<=nq;j++){rc_mul(&product,factor->quotient+k,factor->local+j);rc_sub(remainder+k+j,remainder+k+j,&product);}
    }
    for(int k=0;k<=degree;k++)if(!rc_is_zero(remainder+k))die("nonzero exact RPF division remainder");
    rc_clear(&product);rc_vec_clear(remainder,degree+1);
}
static void rpf_factor_minimum(rpf_factor *factor,const rpf_complex *base_local){
    fmpq_t tmp,x,lo,hi,y1,beta,aa,den,dot;fmpq_init(tmp);fmpq_init(x);fmpq_init(lo);fmpq_init(hi);fmpq_init(y1);fmpq_init(beta);fmpq_init(aa);fmpq_init(den);fmpq_init(dot);
    if(factor->base_degree==1){
        /* Minimize the modulus of q(center+step*t) directly. Its leading
         * coefficient and rational denominator are already included. */
        rc_norm_squared(den,base_local+1);if(fmpq_cmp_si(den,0)<=0)die("invalid linear RPF factor slope");
        fmpq_mul(dot,base_local[0].re,base_local[1].re);fmpq_mul(tmp,base_local[0].im,base_local[1].im);fmpq_add(dot,dot,tmp);
        fmpq_neg(dot,dot);fmpq_div(x,dot,den);
        if(fmpq_cmp_si(x,0)<0)fmpq_zero(x);else if(fmpq_cmp_si(x,1)>0)fmpq_one(x);
        rpf_complex point;rc_init(&point);
        fmpq_mul(point.re,base_local[1].re,x);fmpq_add(point.re,point.re,base_local[0].re);
        fmpq_mul(point.im,base_local[1].im,x);fmpq_add(point.im,point.im,base_local[0].im);
        rc_norm_squared(factor->minimum_squared,&point);rc_clear(&point);
    }else{
        if(!fmpq_is_zero(rpf_center.re)||!fmpq_is_zero(rpf_step.re))die("quadratic RPF bound requires imaginary-axis center and step");
        fmpq_add(y1,rpf_center.im,rpf_step.im);
        fmpq_mul(lo,rpf_center.im,rpf_center.im);fmpq_mul(hi,y1,y1);
        if(fmpq_cmp(lo,hi)>0){fmpq_set(tmp,lo);fmpq_set(lo,hi);fmpq_set(hi,tmp);}
        if((fmpq_cmp_si(rpf_center.im,0)<=0&&fmpq_cmp_si(y1,0)>=0)||(fmpq_cmp_si(y1,0)<=0&&fmpq_cmp_si(rpf_center.im,0)>=0))fmpq_zero(lo);
        fmpq_mul(aa,factor->coefficients[2],factor->coefficients[2]);
        fmpq_mul(beta,factor->coefficients[1],factor->coefficients[1]);
        fmpq_mul(tmp,factor->coefficients[2],factor->coefficients[0]);fmpq_add(tmp,tmp,tmp);fmpq_sub(beta,beta,tmp);
        fmpq_add(den,aa,aa);fmpq_neg(tmp,beta);fmpq_div(x,tmp,den);
        if(fmpq_cmp(x,lo)<0)fmpq_set(x,lo);else if(fmpq_cmp(x,hi)>0)fmpq_set(x,hi);
        fmpq_mul(tmp,aa,x);fmpq_add(tmp,tmp,beta);fmpq_mul(factor->minimum_squared,tmp,x);
        fmpq_mul(tmp,factor->coefficients[0],factor->coefficients[0]);fmpq_add(factor->minimum_squared,factor->minimum_squared,tmp);
    }
    fmpq_set(factor->minimum_parameter,x);
    if(fmpq_cmp_si(factor->minimum_squared,0)<=0)die("RPF factor vanishes on the segment");
    arb_t value;arb_init(value);arb_set_fmpq(value,factor->minimum_squared,128);arb_sqrt(value,value,128);
    arf_t lower;arf_init(lower);arb_get_lbound_arf(lower,value,128);arb_set_arf(factor->minimum_lower,lower);
    if(!arb_is_positive(factor->minimum_lower))die("positive RPF factor minimum unresolved");
    arf_clear(lower);arb_clear(value);
    fmpq_clear(tmp);fmpq_clear(x);fmpq_clear(lo);fmpq_clear(hi);fmpq_clear(y1);fmpq_clear(beta);fmpq_clear(aa);fmpq_clear(den);fmpq_clear(dot);
}
static void rpf_maximum_mu(arb_t out,arb_srcptr alternate){
    arb_t sum,tmp;arb_init(sum);arb_init(tmp);arb_zero(out);
    for(int row=0;row<dim;row++){
        arb_zero(sum);
        for(int e=0;e<entry_count;e++)if(N[e].row==row&&N[e].jet==0&&block_of[N[e].col]==block_of[row])arb_add(sum,sum,alternate?alternate+e:N[e].bound,128);
        upper(tmp,sum);arb_max(out,out,tmp,128);
    }
    arb_clear(sum);arb_clear(tmp);
}
static void read_rpf(FILE *input){
    char marker[16];
    if(fscanf(input,"%15s %d %d",marker,&rpf_factor_count,&rpf_term_count)!=3||strcmp(marker,"RPF_V1")||rpf_factor_count<0||rpf_factor_count>48||rpf_term_count<0||rpf_term_count>50000)die("invalid RPF header");
    rc_init(&rpf_center);rc_init(&rpf_step);rpf_read_complex(input,&rpf_center);rpf_read_complex(input,&rpf_step);
    if(rc_is_zero(&rpf_step))die("zero RPF step");
    fmpz_init(rpf_denominator);rpf_read_integer(input,rpf_denominator);if(fmpz_sgn(rpf_denominator)<=0)die("invalid common RPF denominator");
    int map_size=dim*dim*jets,*entry_map=malloc((size_t)map_size*sizeof(int));if(!entry_map)die("RPF allocation failed");
    for(int k=0;k<map_size;k++)entry_map[k]=-1;
    for(int e=0;e<entry_count;e++){int key=(N[e].jet*dim+N[e].row)*dim+N[e].col;if(entry_map[key]>=0)die("duplicate RPF polynomial key");entry_map[key]=e;}
    arb_init(polynomial_mu);arb_init(rpf_mu);arb_init(chosen_mu);rpf_maximum_mu(polynomial_mu,NULL);
    rpf_complex *Dlocal=rc_vec(degree+1),*replayed=rc_vec(entry_count*RPF_MAX_COEFFICIENTS);
    for(int k=0;k<=degree;k++){fmpq_set_fmpz(Dlocal[k].re,D[k].re);fmpq_set_fmpz(Dlocal[k].im,D[k].im);}
    rpf_factors=calloc((size_t)rpf_factor_count,sizeof(rpf_factor));if(rpf_factor_count&&!rpf_factors)die("RPF allocation failed");
    rpf_terms=calloc((size_t)rpf_term_count,sizeof(rpf_term));if(rpf_term_count&&!rpf_terms)die("RPF term allocation failed");
    rpf_head=malloc((size_t)dim*sizeof(int));int *term_tail=malloc((size_t)dim*sizeof(int));
    if(!rpf_head||!term_tail)die("RPF row allocation failed");
    for(int row=0;row<dim;row++)rpf_head[row]=term_tail[row]=-1;
    fmpz_t denominator,integer;fmpz_init(denominator);fmpz_init(integer);
    rpf_complex *base=rc_vec(17),*power=rc_vec(17),*next=rc_vec(17);
    for(int a=0;a<rpf_factor_count;a++){
        rpf_factor *factor=rpf_factors+a;
        if(fscanf(input,"%d %d",&factor->base_degree,&factor->power)!=2||factor->base_degree<1||factor->base_degree>2||factor->power<1||factor->power>3||factor->base_degree*factor->power>degree)die("invalid RPF factor shape");
        rpf_read_integer(input,denominator);if(fmpz_sgn(denominator)<=0)die("invalid RPF factor denominator");
        for(int k=0;k<3;k++){fmpq_init(factor->coefficients[k]);if(k<=factor->base_degree){rpf_read_integer(input,integer);fmpq_set_fmpz_frac(factor->coefficients[k],integer,denominator);}}
        if(fmpq_is_zero(factor->coefficients[factor->base_degree]))die("zero leading RPF factor coefficient");
        for(int earlier=0;earlier<a;earlier++)if(rpf_factors[earlier].base_degree==factor->base_degree&&rpf_factors[earlier].power==factor->power){
            int identical=1;for(int k=0;k<=factor->base_degree;k++)if(!fmpq_equal(rpf_factors[earlier].coefficients[k],factor->coefficients[k]))identical=0;
            if(identical)die("duplicate RPF factor/power bank entry");
        }
        fmpq_init(factor->minimum_squared);fmpq_init(factor->minimum_parameter);arb_init(factor->minimum_lower);
        for(int k=0;k<17;k++){rc_init(factor->local+k);rc_init(factor->quotient+k);rc_zero(base+k);rc_zero(power+k);rc_zero(next+k);}
        rpf_compose(base,(fmpq *)factor->coefficients,factor->base_degree);fmpq_one(power[0].re);
        for(int k=0;k<3;k++){rc_init(factor->base_local+k);rc_set(factor->base_local+k,base+k);}
        rpf_integer_polynomial(factor->base_integer,factor->base_denominator,factor->base_local,3);
        fmpz_init(factor->base_constant_norm);
        fmpz_mul(factor->base_constant_norm,factor->base_integer[0].re,factor->base_integer[0].re);
        fmpz_addmul(factor->base_constant_norm,factor->base_integer[0].im,factor->base_integer[0].im);
        if(fmpz_is_zero(factor->base_constant_norm))die("singular RPF base factor at center");
        int current=0;
        for(int j=0;j<factor->power;j++){
            rpf_poly_multiply(next,power,current,base,factor->base_degree);current+=factor->base_degree;
            for(int k=0;k<=current;k++)rc_set(power+k,next+k);
        }
        for(int k=0;k<=current;k++)rc_set(factor->local+k,power+k);
        rpf_divide_D(factor,Dlocal);
        /* Geometry is exact; its positive outward bounds are not installed
         * until all rational-PF reconstruction identities have passed. */
        rpf_factor_minimum(factor,base);
    }
    rc_vec_clear(base,17);rc_vec_clear(power,17);rc_vec_clear(next,17);
    arb_ptr proposed=_arb_vec_init(entry_count);arb_t h_upper,value,numerator_bound,den,sum;arb_init(h_upper);arb_init(value);arb_init(numerator_bound);arb_init(den);arb_init(sum);
    fmpq_t norm,absolute,coefficients[5];fmpq_init(norm);fmpq_init(absolute);for(int k=0;k<5;k++)fmpq_init(coefficients[k]);
    rc_norm_squared(norm,&rpf_step);arb_set_fmpq(value,norm,128);arb_sqrt(value,value,128);upper(h_upper,value);
    rpf_complex *numerator=rc_vec(5),product,tmp;rc_init(&product);rc_init(&tmp);
    for(int term=0;term<rpf_term_count;term++){
        int row,col,jet,factor_index,num_degree;
        if(fscanf(input,"%d %d %d %d %d",&row,&col,&jet,&factor_index,&num_degree)!=5||row<0||row>=dim||col<0||col>=dim||jet<0||jet>=jets||factor_index< -1||factor_index>=rpf_factor_count||num_degree<0||num_degree>RPF_NUM_DEGREE||block_of[col]>block_of[row])die("invalid RPF term header");
        int index=entry_map[(jet*dim+row)*dim+col];
        int nonzero=0;
        for(int k=0;k<=num_degree;k++){rpf_read_integer(input,integer);fmpq_set_fmpz(coefficients[k],integer);if(!fmpz_is_zero(integer))nonzero=1;}
        if(!nonzero)continue;
        if(index<0)die("RPF term absent from polynomial connection");
        rpf_compose(numerator,(fmpq *)coefficients,num_degree);
        rpf_complex *quotient=factor_index<0?Dlocal:rpf_factors[factor_index].quotient;
        for(int i=0;i<=num_degree;i++)for(int j=0;j<=degree;j++){
            rc_mul(&product,numerator+i,quotient+j);rc_add(replayed+index*RPF_MAX_COEFFICIENTS+i+j,replayed+index*RPF_MAX_COEFFICIENTS+i+j,&product);
        }
        arb_zero(numerator_bound);
        for(int k=0;k<=num_degree;k++){
            fmpq_abs(absolute,numerator[k].re);arb_set_fmpq(value,absolute,128);arb_add(numerator_bound,numerator_bound,value,128);
            fmpq_abs(absolute,numerator[k].im);arb_set_fmpq(value,absolute,128);arb_add(numerator_bound,numerator_bound,value,128);
        }
        arb_mul(value,h_upper,numerator_bound,128);arb_div_fmpz(value,value,rpf_denominator,128);
        if(factor_index>=0){
            arb_pow_ui(den,rpf_factors[factor_index].minimum_lower,rpf_factors[factor_index].power,128);
            if(!arb_is_positive(den))die("invalid RPF factor-power lower bound");
            arb_div(value,value,den,128);
        }
        arb_add(sum,proposed+index,value,128);upper(proposed+index,sum);
        rpf_term *saved=rpf_terms+rpf_active_term_count;
        saved->row=row;saved->col=col;saved->jet=jet;saved->factor_index=factor_index;saved->num_degree=num_degree;saved->next=-1;
        for(int k=0;k<5;k++){
            rc_init(saved->local_numerator+k);
            if(k<=num_degree){
                rc_mul(saved->local_numerator+k,numerator+k,&rpf_step);
                fmpq_div_fmpz(saved->local_numerator[k].re,saved->local_numerator[k].re,rpf_denominator);
                fmpq_div_fmpz(saved->local_numerator[k].im,saved->local_numerator[k].im,rpf_denominator);
            }
        }
        rpf_integer_polynomial(saved->numerator_integer,saved->numerator_denominator,saved->local_numerator,5);
        if(term_tail[row]<0)rpf_head[row]=rpf_active_term_count;
        else rpf_terms[term_tail[row]].next=rpf_active_term_count;
        term_tail[row]=rpf_active_term_count++;
    }
    char extra[2];if(fscanf(input,"%1s",extra)==1)die("unexpected trailing RPF input");
    /* Compare high degrees against zero as well: polynomial-part products can
     * reach degree+4 even when the final matrix is lower-degree. */
    for(int e=0;e<entry_count;e++)for(int k=0;k<=degree+RPF_NUM_DEGREE;k++){
        rc_mul(&tmp,replayed+e*RPF_MAX_COEFFICIENTS+k,&rpf_step);
        fmpq_div_fmpz(tmp.re,tmp.re,rpf_denominator);fmpq_div_fmpz(tmp.im,tmp.im,rpf_denominator);
        if(k<=degree){if(!fmpq_equal_fmpz(tmp.re,N[e].c[k].re)||!fmpq_equal_fmpz(tmp.im,N[e].c[k].im))die("RPF reconstruction differs from polynomial connection");}
        else if(!rc_is_zero(&tmp))die("RPF reconstruction has unmatched high-degree coefficients");
    }
    rpf_maximum_mu(rpf_mu,proposed);
    /* Both are valid componentwise upper bounds after exact reconstruction.
     * Retain the sharper bound even when large PF terms cancel exactly. */
    for(int e=0;e<entry_count;e++){
        arb_min(value,N[e].bound,proposed+e,128);upper(N[e].bound,value);
    }
    rpf_maximum_mu(chosen_mu,NULL);
    char *old=arb_get_str(polynomial_mu,15,0),*new=arb_get_str(rpf_mu,15,0),*chosen=arb_get_str(chosen_mu,15,0);
    fprintf(stderr,"exact RPF identity verified: %d terms, %d factor powers; internal row bound polynomial %s, RPF %s, chosen %s\n",rpf_term_count,rpf_factor_count,old,new,chosen);flint_free(old);flint_free(new);flint_free(chosen);
    rc_clear(&product);rc_clear(&tmp);rc_vec_clear(numerator,5);rc_vec_clear(Dlocal,degree+1);rc_vec_clear(replayed,entry_count*RPF_MAX_COEFFICIENTS);free(entry_map);free(term_tail);
    _arb_vec_clear(proposed,entry_count);arb_clear(h_upper);arb_clear(value);arb_clear(numerator_bound);arb_clear(den);arb_clear(sum);
    fmpq_clear(norm);fmpq_clear(absolute);for(int k=0;k<5;k++)fmpq_clear(coefficients[k]);fmpz_clear(denominator);fmpz_clear(integer);
}

int main(int argc,char **argv){
    if(argc!=3)die("usage: transport-rpf INPUT OUTPUT_JSON");
    struct rlimit memory={2ULL<<30,2ULL<<30};if(setrlimit(RLIMIT_AS,&memory))die("cannot set address-space cap");
    double start=seconds();FILE *input=fopen(argv[1],"r");if(!input)die("cannot read input");
    int digits,max_order,check_every;long bits;
    if(fscanf(input,"%d %d %d %d %d %ld %d %d %d",&dim,&jets,&degree,&entry_count,&blocks,&bits,&digits,&max_order,&check_every)!=9)die("invalid header");
    if(dim<1||dim>42||jets<1||jets>6||degree<0||degree>16||entry_count<0||entry_count>dim*dim*jets||blocks<1||blocks>dim||bits<64||bits>1000000||digits<1||digits>300000||max_order<1||max_order<degree||max_order>1000000||check_every<1)die("input limits");
    precision=bits;ring_size=(degree>RPF_NUM_DEGREE?degree:RPF_NUM_DEGREE)+1;int states=dim*jets;
    omp_set_dynamic(0);if(omp_get_max_threads()>4)omp_set_num_threads(4);
    char *line=NULL;size_t capacity=0;if(getline(&line,&capacity,input)<0||getline(&line,&capacity,input)<0)die("missing denominator lower bound");
    arb_init(denominator_lower);if(arb_set_str(denominator_lower,line,128)||!arb_is_positive(denominator_lower))die("invalid denominator lower bound");
    block_of=calloc(dim,sizeof(int));int *block_sizes=calloc(blocks,sizeof(int));
    if(!block_of||!block_sizes)die("allocation failed");
    for(int i=0;i<dim;i++){
        if(fscanf(input,"%d",block_of+i)!=1||block_of[i]<0||block_of[i]>=blocks)die("invalid blocks");
        block_sizes[block_of[i]]++;
    }
    for(int b=0;b<blocks;b++)if(!block_sizes[b])die("empty physical block");
    free(block_sizes);
    for(int k=0;k<=degree;k++)read_gaussian(input,D+k);
    N=calloc(entry_count,sizeof(coupling));if(entry_count&&!N)die("allocation failed");
    unsigned char *seen=calloc((size_t)dim*dim*jets,1);if(!seen)die("allocation failed");
    arb_t bound,tmp;arb_init(bound);arb_init(tmp);fmpz_t integer;fmpz_init(integer);
    for(int e=0;e<entry_count;e++){
        if(fscanf(input,"%d %d %d",&N[e].row,&N[e].col,&N[e].jet)!=3||N[e].row<0||N[e].row>=dim||N[e].col<0||N[e].col>=dim||N[e].jet<0||N[e].jet>=jets)die("invalid coupling");
        if(block_of[N[e].col]>block_of[N[e].row])die("connection is not block triangular");
        int key=(N[e].jet*dim+N[e].row)*dim+N[e].col;
        if(seen[key])die("duplicate polynomial coupling");
        seen[key]=1;
        arb_init(N[e].bound);arb_zero(bound);
        for(int k=0;k<=degree;k++){
            read_gaussian(input,N[e].c+k);
            fmpz_abs(integer,N[e].c[k].re);arb_set_fmpz(tmp,integer);arb_add(bound,bound,tmp,128);
            fmpz_abs(integer,N[e].c[k].im);arb_set_fmpz(tmp,integer);arb_add(bound,bound,tmp,128);
        }
        arb_div(tmp,bound,denominator_lower,128);upper(N[e].bound,tmp);
    }
    free(seen);
    history=_acb_vec_init((slong)ring_size*states);total=_acb_vec_init(states);work=_acb_vec_init(states);
    if(getline(&line,&capacity,input)<0)die("missing boundary line separator");
    for(int i=0;i<states;i++){
        if(getline(&line,&capacity,input)<0)die("missing boundary");
        char *bar=strchr(line,'|');if(!bar)die("boundary separator");*bar=0;
        if(arb_set_str(acb_realref(history+i),line,precision)||arb_set_str(acb_imagref(history+i),bar+1,precision)||!acb_is_finite(history+i))die("invalid boundary ball");
        acb_set(total+i,history+i);
    }
    read_rpf(input);
    fclose(input);free(line);
    for(int a=0;a<rpf_factor_count;a++)rpf_factors[a].auxiliary=_acb_vec_init((slong)rpf_factors[a].power*ring_size*states);
    fmpz_t dnorm;fmpz_init(dnorm);fmpz_mul(dnorm,D[0].re,D[0].re);fmpz_addmul(dnorm,D[0].im,D[0].im);if(fmpz_is_zero(dnorm))die("singular center");
    arb_ptr budgets=_arb_vec_init(blocks*jets);arb_t maximum,target;arb_init(maximum);arb_init(target);arb_set_ui(target,10);arb_pow_ui(target,target,digits,128);arb_inv(target,target,128);arb_div_ui(target,target,16,128);
    int passed=0,order=0;double certificate_seconds=0;
    for(int n=0;n<max_order;n++){
        /* First finish every cascade Z_j=Z_(j-1)/q, with Z_0=Y.
         * A bank/state pair owns its entire chain. With q=Q/scale,
         * Q_0 Z_j[n]=scale Z_(j-1)[n]-sum_(k>=1)Q_k Z_j[n-k]. */
        #pragma omp parallel
        {
            arb_t local_re,local_im;arb_init(local_re);arb_init(local_im);
            #pragma omp for schedule(dynamic,4)
            for(int task=0;task<rpf_factor_count*states;task++){
                int a=task/states,i=task%states;rpf_factor *factor=rpf_factors+a;
                for(int power=1;power<=factor->power;power++){
                    acb_ptr source=power==1?coefficient(n):rpf_auxiliary_coefficient(factor,power-1,n);
                    acb_ptr destination=rpf_auxiliary_coefficient(factor,power,n)+i;
                    acb_mul_fmpz(destination,source+i,factor->base_denominator,precision);
                    for(int k=1;k<=factor->base_degree&&k<=n;k++)
                        addmul(destination,rpf_auxiliary_coefficient(factor,power,n-k)+i,factor->base_integer+k,1);
                    rpf_divide_gaussian(destination,destination,factor->base_integer,factor->base_constant_norm,local_re,local_im);
                    if(!acb_is_finite(destination))die("nonfinite RPF auxiliary coefficient");
                }
            }
            arb_clear(local_re);arb_clear(local_im);
        }
        /* The preceding parallel-region barrier makes every Z[n] available.
         * Only the finite numerator convolution consumes the auxiliary rings. */
        #pragma omp parallel
        {
            acb_t term_sum;acb_init(term_sum);
            #pragma omp for schedule(dynamic,4)
            for(int i=0;i<states;i++){
                int row=i%dim,jet=i/dim;acb_zero(work+i);
                for(int e=rpf_head[row];e>=0;e=rpf_terms[e].next){
                    const rpf_term *term=rpf_terms+e;if(term->jet>jet)continue;
                    int source_index=(jet-term->jet)*dim+term->col;acb_zero(term_sum);
                    for(int k=0;k<=term->num_degree&&k<=n;k++){
                        acb_ptr source;
                        if(term->factor_index<0)source=coefficient(n-k);
                        else{
                            const rpf_factor *factor=rpf_factors+term->factor_index;
                            source=rpf_auxiliary_coefficient(factor,factor->power,n-k);
                        }
                        addmul(term_sum,source+source_index,term->numerator_integer+k,0);
                    }
                    acb_div_fmpz(term_sum,term_sum,term->numerator_denominator,precision);
                    acb_add(work+i,work+i,term_sum,precision);
                }
            }
            acb_clear(term_sum);
        }
        /* Finish all reads before overwriting a Y ring slot. Its width also
         * preserves every coefficient needed by the unchanged residual. */
        acb_ptr next=coefficient(n+1);
        #pragma omp parallel for schedule(static)
        for(int i=0;i<states;i++){
            acb_div_ui(next+i,work+i,n+1,precision);
            if(!acb_is_finite(next+i))die("nonfinite RPF coefficient");
            acb_add(total+i,total+i,next+i,precision);
        }
        order=n+1;
        if(order>=degree&&(order%check_every==0||order==max_order)){
            double tick=seconds();int valid=certify(order,budgets,maximum);certificate_seconds+=seconds()-tick;
            char *error=arb_get_str(maximum,8,0);fprintf(stderr,"order %d seconds %.3f residual_bound %s valid %d\n",order,seconds()-start,error,valid);flint_free(error);
            if(valid&&arb_lt(maximum,target)){passed=1;break;}
        }
    }
    if(passed)for(int jet=0;jet<jets;jet++)for(int i=0;i<dim;i++)acb_add_error_arb(total+jet*dim+i,budgets+block_of[i]*jets+jet);
    slong accuracy=WORD_MAX;for(int i=0;i<states;i++)if(!acb_is_zero(total+i)){slong a=acb_rel_accuracy_bits(total+i);if(a<accuracy)accuracy=a;}
    struct rusage usage;getrusage(RUSAGE_SELF,&usage);FILE *out=fopen(argv[2],"w");if(!out)die("output open");
    char *error=arb_get_str(maximum,25,0);
    fprintf(out,"{\"schema\":\"vakint.pr11d.arb-local-transport-pilot.v1\",\"local_tail_certified\":%s,\"order\":%d,\"working_bits\":%ld,\"target_absolute_digits\":%d,\"seconds\":%.9f,\"certificate_seconds\":%.9f,\"peak_rss_bytes\":%ld,\"minimum_relative_accuracy_bits\":%ld,\"tail_upper_enclosure\":\"%s\",\"no_PR11d_value_claimed\":true,\"values\":[",passed?"true":"false",order,(long)precision,digits,seconds()-start,certificate_seconds,usage.ru_maxrss*1024L,(long)accuracy,error);flint_free(error);
    for(int i=0;i<states;i++){
        char *r=arb_get_str(acb_realref(total+i),digits+30,0),*s=arb_get_str(acb_imagref(total+i),digits+30,0);
        fprintf(out,"%s[\"%s\",\"%s\"]",i?",":"",r,s);flint_free(r);flint_free(s);
    }
    char *old_mu=arb_get_str(polynomial_mu,25,0),*new_mu=arb_get_str(rpf_mu,25,0),*selected_mu=arb_get_str(chosen_mu,25,0);
    fprintf(out,"],\"coefficient_method\":\"exact rational-factor auxiliary cascades\",\"coefficient_ring_width\":%d,\"connection_bound_method\":\"entrywise minimum of polynomial and exact rational-factor segment bounds\",\"polynomial_maximum_internal_row_bound\":\"%s\",\"rpf_maximum_internal_row_bound\":\"%s\",\"chosen_maximum_internal_row_bound\":\"%s\",\"rational_pf_identity_verified\":true,\"factor_minimum_certificates\":[",ring_size,old_mu,new_mu,selected_mu);
    flint_free(old_mu);flint_free(new_mu);flint_free(selected_mu);
    for(int a=0;a<rpf_factor_count;a++){
        char *parameter=fmpq_get_str(NULL,10,rpf_factors[a].minimum_parameter),*minimum=fmpq_get_str(NULL,10,rpf_factors[a].minimum_squared);
        fprintf(out,"%s{\"factor_index\":%d,\"base_degree\":%d,\"power\":%d,\"parameter_kind\":\"%s\",\"minimizing_parameter\":\"%s\",\"minimum_factor_modulus_squared\":\"%s\"}",a?",":"",a,rpf_factors[a].base_degree,rpf_factors[a].power,rpf_factors[a].base_degree==1?"t":"y_squared",parameter,minimum);
        flint_free(parameter);flint_free(minimum);
    }
    fprintf(out,"]}\n");fclose(out);return passed?0:1;
}
