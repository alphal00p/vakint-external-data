#!/usr/bin/env python3
"""Verify completed conditional A/B startup contracts without rerunning kernels."""
from pathlib import Path
import hashlib,json,math
from flint import arb,acb,ctx
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];N=ROOT/'helper/frobenius-transport/native'
PINS={}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p,h=None):
 p=Path(p).resolve();actual=sha(p);assert h is None or h==actual,(p,h,actual);assert str(p) not in PINS or PINS[str(p)]==actual;PINS[str(p)]=actual;return p
def load(p,h=None):return json.loads(pin(p,h).read_text())
def merge(pins):
 for p,h in pins.items():pin(p,h)
launcher=load(HERE/'review.json','c0d1a9b031186c175bae31887ed19f5d425a6a86a35e8ea5837001491e2f2334');assert launcher['accepted'] is True
prefixpath=ROOT/'helper/x8-production-native-input-review/review.json';prefix=load(prefixpath,'fcba248b819478e80763b0094163f6054112b582c5d439459c1a847ba1d6171b');assert prefix['accepted_for_native_input_provenance'] is True and prefix['total_literal_seed_identities']==prefix['total_exact_decimal_box_containments']==504
merge(launcher['artifact_sha256']);merge(prefix['source_and_implementation_pins'])
source_replay=load(prefix['source_replay_receipt'],prefix['source_replay_receipt_sha256'])
expected={'A':'e68d82518214ffae10879beb129001c7233552d69e2b544c0a17fe2dc9a6d447','B':'c789f3587d02ecd3d9ca9ee0eb699120aa209c5bee88901c32d5c22068dc37b9'}
records=[]
for tag,expectedhash in expected.items():
 out=N.parent/f'x8-production-{tag}-scheduled-v1';contract=load(out/'run-contract.json');start=load(out/'invocation-start.json');inv=load(out/'native-invocation.json');meta=load(out/'native.json');gate=load(out/'numerical-gate.json');handoff=load(out/'conditional-initial.json',expectedhash);native=load(out/'native-output.json');args=contract['settings']
 merge(contract['source_pins']);merge(start['source_pins']);merge(inv['source_pins']);pin(out/'native.log');pin(out/'prepare.log')
 assert inv['returncode']==0 and inv['requested_workers']==inv['actual_workers']==8 and inv['input_source_binary_wrapper_unchanged_after_invocation'] is True
 assert inv['command']==start['command']==[str(N/'contracted-native-v2-scheduled'),str(out/'native.in'),str(out/'native-output.json')]
 assert inv['start_receipt_sha256']==sha(out/'invocation-start.json') and inv['output_sha256']==sha(out/'native-output.json')
 for role in ['input','source','binary','wrapper']:assert inv[role+'_sha256']==start[role+'_sha256']==sha(inv[role+'_path'])
 assert start['controlled_environment']=={'OMP_NUM_THREADS':'8','OPENBLAS_NUM_THREADS':'1'}
 assert native['local_tail_certified'] is True and native['dimension']==252 and native['constant_count']==252 and native['maximum_log_degree']==8 and native['startup_power_range']==[-8,0]
 assert native['requested_workers']==native['configured_workers']==native['actual_workers']==8
 assert native['working_bits']==native['precision_max_bits']==meta['bits']==math.ceil(args['working_digits']*math.log2(10))
 assert native['target_absolute_digits']==native['digits']==meta['requested_digits']==args['local_tail_digits']
 assert native['order']==17000 and native['order']<=args['max_order'] and native['order']%args['check_every']==0
 assert native['coefficient_precision_slope_bits_per_order']==4 and native['schedule_radius_ratio_squared']=='65536/225' and native['schedule_factorization_verified'] is True
 assert native['minimum_coefficient_precision_bits_used']==max(1024,native['precision_max_bits']-4*native['order']) and native['full_precision_startup_total_certificate_and_output'] is True and native['schedule_is_accuracy_guarantee'] is False
 assert native['physical_PR11d_claimed'] is False and native['exact_residue_identity_verified'] is True
 ctx.dps=args['working_digits']+100
 tail=arb(native['tail_upper_enclosure']);assert tail.is_finite() and tail>=0 and tail<arb(10)**(-args['local_tail_digits'])/100
 maxima={}
 for field in ['normalized_J_values','original_Y_values']:
  values=[acb(arb(re),arb(im)) for re,im in native[field]];assert len(values)==252 and all(v.is_finite() for v in values)
  maxima[field]=max(v.real.rad()+v.imag.rad() for v in values)
 assert maxima['original_Y_values']<arb(10)**(-args['raw_total_digits'])
 encoded={k:v.str(40) for k,v in maxima.items()}
 assert gate['local_tail_certified'] is True and gate['raw_total_width_gate_passed'] is True and gate['raw_total_digits_target']==args['raw_total_digits']
 assert gate['maximum_total_radii']==handoff['maximum_total_radius']==encoded and gate['native_output_sha256']==sha(out/'native-output.json')
 assert handoff['schema']=='vakint.x8.conditional-guarded-ordinary-boundary.v1' and handoff['basis']=='original_raw_epsilon_jets'
 assert handoff['dimension']==42 and handoff['jets']==6 and handoff['epsilon_min_power']==-4 and handoff['epsilon_max_power']==1 and handoff['eta_center']==['0','256']
 assert handoff['normalization']=='native_raw' and handoff['error_quality']=='rigorous-bound'
 assert handoff['values']==native['original_Y_values'] and handoff['order']==native['order'] and handoff['seconds']==native['seconds']
 assert handoff['local_tail_certified'] is True and handoff['raw_total_width_gate_passed'] is True and handoff['raw_total_digits_target']==args['raw_total_digits']
 for doc in [contract,gate,handoff]:assert doc['physical_source_admission_required'] is True and doc['whole_PR11d_accuracy_claimed'] is False
 for role,want in [('native_input',out/'native.in'),('native_preparation',out/'native.json'),('native_output',out/'native-output.json'),('native_invocation_receipt',out/'native-invocation.json')]:assert Path(handoff[role+'_path'])==want and handoff[role+'_sha256']==sha(want)
 assert handoff['native_source_sha256']==inv['source_sha256'] and handoff['native_binary_sha256']==inv['binary_sha256'] and handoff['validator_sha256']==inv['wrapper_sha256']
 assert handoff['source_boundary_path']==args['boundary'] and handoff['source_boundary_sha256']==args['boundary_sha256']==sha(args['boundary'])
 assert handoff['source_constants_path']==args['constants'] and handoff['source_constants_sha256']==args['constants_sha256']==sha(args['constants'])
 boundary=load(args['boundary'],args['boundary_sha256']);constants=load(args['constants'],args['constants_sha256'])
 for field in ['source_receipts','recipe_receipt','matching_sha256','inventory_sha256']:assert handoff[field]==boundary[field]
 assert constants['boundary_input_sha256']==sha(args['boundary']) and meta['seed_binding']==sha(args['constants'])
 ordinary=load(handoff['ordinary_polynomial_connection_path'],handoff['ordinary_polynomial_connection_sha256'])
 assert handoff['source_equation_sha256']==handoff['original_source_equation_sha256']==ordinary['source_sha256']=='a9ec06c3a076f3460e84ec3492ae314b29f4cf470dddbe2a5442b502f7181184'
 pin(handoff['original_source_equation_path'],ordinary['source_sha256'])
 records.append({'profile':tag,'conditional_initial_sha256':expectedhash,'input_sha256':sha(out/'native.in'),'native_output_sha256':sha(out/'native-output.json'),'invocation_receipt_sha256':sha(out/'native-invocation.json'),'Pmax_bits':native['precision_max_bits'],'minimum_coefficient_bits':native['minimum_coefficient_precision_bits_used'],'actual_workers':8,'returncode':0,'accepted_order':17000,'local_tail_digits':args['local_tail_digits'],'strict_raw_total_absolute_digits':args['raw_total_digits'],'maximum_total_L1_radii':encoded,'all252_raw_output_strings_preserved_exactly':True,'all504_original_and_normalized_complex_boxes_finite':True,'conditional_flag_retained':True,'physical_initial_admitted':False})
pin(Path(__file__))
for p,h in PINS.items():assert sha(p)==h
report={'schema':'vakint.x8.completed-conditional-initial-output-independent-review.v2','accepted':True,'status':'passed_A_B_completed_invocations_prefix_seed_bindings_full_widths_and_conditional_output_contract','launcher_contract_review_sha256':sha(HERE/'review.json'),'actual_native_input_review_sha256':sha(prefixpath),'source_expression_matching_replay_sha256':prefix['source_replay_receipt_sha256'],'profiles':records,'scope':'Conditional numerical IVP handoffs only. Both exact actual inputs and all252seed boxes are independently audited;1587source rows/252matching replay is bound separately. A/B physical four-loop origin admission and independently blessed complete physical-initial envelopes remain mandatory.','no_point_estimate_or_radius_reset':True,'physical_initial_A_admitted':False,'physical_initial_B_admitted':False,'whole_PR11d_20000_accuracy_claimed':False,'main_PR11d_published_precision_cap':200,'native_preparer_HPL_invocations_by_reviewer':0,'production_files_modified':False,'artifact_sha256':PINS}
out=HERE/'completed-output-review-v2.json';assert not out.exists();out.write_text(json.dumps(report,indent=2)+'\n');print(out);print(sha(out));print(json.dumps(records,indent=2))
