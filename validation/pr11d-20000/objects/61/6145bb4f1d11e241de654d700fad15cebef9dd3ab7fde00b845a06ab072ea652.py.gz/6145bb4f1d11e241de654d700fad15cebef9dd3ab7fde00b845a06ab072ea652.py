"""Independently enumerate and compress each actual subsector's routings."""
from replay import *
from symmetries import determinant,sign,transform_expression

def matrix_sign(t):
    return tuple(tuple(-x for x in row) for row in t) if next(x for row in t for x in row if x)<0 else t
IDENTITY=tuple(tuple(Fraction(i==j) for j in range(4)) for i in range(4))

def multiply(a,b):
    return matrix_sign(tuple(tuple(sum(a[i][k]*b[k][j] for k in range(4)) for j in range(4)) for i in range(4)))

@functools.cache
def automorphisms(sector):
    active=[i for i in range(10) if sector>>i&1]
    first=[3] if 3 in active else []
    for extra in itertools.combinations([i for i in active if i not in first],4-len(first)):
        selected=first+list(extra)
        a=[V[i] for i in selected]
        if determinant(a):break
    else:return ()
    ai=frac_inverse(a)
    options=[([3] if i==3 else [j for j in active if j!=3]) for i in selected]
    lookup={sign(V[i]):i for i in active}
    out=set()
    for image in itertools.product(*options):
        if len(set(image))!=4:continue
        for signs in itertools.product((-1,1),repeat=4):
            b=[[s*x for x in V[j]] for j,s in zip(image,signs)]
            t=matrix_sign(tuple(tuple(sum(ai[i][k]*b[k][j] for k in range(4)) for j in range(4)) for i in range(4)))
            if t in out:continue
            if abs(determinant(t))!=1:continue
            mapping=[]
            for i in active:
                v=sign(tuple(sum(V[i][k]*t[k][j] for k in range(4)) for j in range(4)))
                p=lookup.get(v)
                if p is None or ((i==3)!=(p==3)):break
                mapping.append(p)
            if len(mapping)==len(active) and len(set(mapping))==len(active):out.add(t)
    return tuple(sorted(out))

@functools.cache
def generators(sector):
    group=automorphisms(sector)
    generated={IDENTITY};gens=[]
    for t in group:
        if t in generated:continue
        gens.append(t)
        frontier=list(generated)
        while frontier:
            a=frontier.pop()
            for b in gens:
                c=multiply(a,b)
                if c not in generated:generated.add(c);frontier.append(c)
        assert generated<=set(group)
    assert generated==set(group)
    return tuple(gens)

if __name__=='__main__':
    results=[]
    for sector in sorted({sum(1<<i for i,p in enumerate(n) if p>0) for n in BASIS}):
        g=automorphisms(sector);gens=generators(sector)
        print(sector,len(g),len(gens),flush=True)
        results.append({'sector':sector,'automorphism_count':len(g),'generators':[[[str(x) for x in row] for row in t] for t in gens]})
    (HERE/'sector-symmetries.json').write_text(json.dumps(results,indent=2)+'\n')
