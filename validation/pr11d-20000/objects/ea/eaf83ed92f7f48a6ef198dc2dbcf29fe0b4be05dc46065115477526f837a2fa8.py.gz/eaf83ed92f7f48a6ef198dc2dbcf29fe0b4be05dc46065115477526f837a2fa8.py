#!/usr/bin/env python3
"""P853 published exact jets, Cauchy truncation, native-point and20k arithmetic checks."""
import hashlib,json,math,sys,time
from decimal import Decimal,localcontext,ROUND_HALF_EVEN,ROUND_CEILING
from fractions import Fraction
from pathlib import Path
from flint import arb,ctx,fmpq
HERE=Path(__file__).resolve().parent
if not __debug__:
 raise RuntimeError('Acceptance validation must run with Python assertions enabled')

def evaluate(ast,constants):
 if 'integer' in ast:return arb(int(ast['integer']))
 if 'rational' in ast:return arb(fmpq(*map(int,ast['rational'])))
 if 'symbol' in ast:return constants[ast['symbol']]
 if 'sum' in ast:return sum((evaluate(a,constants) for a in ast['sum']),arb(0))
 if 'product' in ast:
  value=arb(1)
  for a in ast['product']:value*=evaluate(a,constants)
  return value
 if 'power' in ast:
  a,n=ast['power'];return evaluate(a,constants)**int(n['integer'])
 raise ValueError(ast)

def rounded_cell(v,digits):
 assert v.is_finite() and not v.contains(0)
 with localcontext() as c:
  c.prec=digits;c.rounding=ROUND_HALF_EVEN;out=+Decimal(v.mid().str(digits+70,radius=False));previous=out.next_minus(c);following=out.next_plus(c)
 with localcontext() as c:
  c.prec=digits+20;low=(out+previous)/2;high=(out+following)/2
 assert v.lower()>arb(str(low)).upper() and v.upper()<arb(str(high)).lower()
 return format(out,'f'),abs(v-arb(str(out))).upper()

def upper_decimal(v,digits=35):
 upper=v.upper();assert upper.is_finite() and upper>=0;ratio=upper.fmpq()
 with localcontext() as c:
  c.prec=digits;c.rounding=ROUND_CEILING;value=Decimal(int(ratio.numerator))/Decimal(int(ratio.denominator));text=str(value)
  if arb(text).lower()<upper:value=value.next_plus(c);text=str(value)
 assert arb(text).lower()>=upper
 return text


def poly_mul(a,b):
 out=[Fraction(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):out[i+j]+=x*y
 return out

def cauchy_bound_proof():
 r=Fraction(1,16)
 # n²b_n is decreasing fromn=2. Shift the exact difference polynomialn=m+2.
 left=poly_mul([0,0,1],poly_mul([2-4*r,1],[2-2*r,1]))
 right=poly_mul(poly_mul([r,1],[1+2*r,1]),[1,2,1])
 diff=[x-y for x,y in zip(left,right)];shifted=[sum(diff[j]*math.comb(j,i)*2**(j-i) for j in range(i,len(diff))) for i in range(len(diff))]
 assert all(x>=0 for x in shifted) and any(x>0 for x in shifted)
 b1=r*(1+2*r)/((2-4*r)*(2-2*r));b2=b1*(1+r)*(2+2*r)/((3-4*r)*(3-2*r));h=1+b1+4*b2;assert h<2
 # zeta(n)/n<=1 forintegern>=2; boundeachGamma-quotientlogbygeometricseries.
 cexp=7*r*r/(1-r)+(3*r)**2/(1-3*r)+(4*r)**2/(1-4*r)
 bexp=2*r*r/(1-r)+(4*r)**2/(1-4*r)+(2*r)**2/(1-2*r)
 assert cexp<Fraction(1,2) and bexp<Fraction(1,2)
 cm=1/(1-cexp);bm=1/(1-bexp);cot=Fraction(1,2)+8*r*r/(1-4*r*r)
 pref=2*(1+r)**3/(3*(1-2*r)**2*(1-3*r)*(1-4*r))
 bound=pref*cm*(r*((1+r)/(1-2*r)*h+1)+(1+4*r)*bm*cot)
 assert bound<4
 return {'radius':[1,16],'ratio_modulus_bound':4,'proved_rational_upper_bound':[bound.numerator,bound.denominator],'H_majorant':[h.numerator,h.denominator],'term_ratio_shifted_polynomial':[str(x) for x in shifted],'tail_formula':'4*(abs(epsilon)/(1/16))^6/(1-abs(epsilon)/(1/16))','proof':'UniformabsolutePochhammermajorantfor3F2, exactn²b_nmonotonicityforn>=2, zeta(n)<=2and1/n<=1/2, Gamma-logmajorantsande^x<=1/(1-x), exactcotangentseries; Cauchycoefficientbound.'}

def main():
 started=time.time();data=json.loads((HERE/'p853-exact-jet.json').read_text());proof=cauchy_bound_proof();ctx.dps=350
 constants={'z2':arb(2).zeta(),'z3':arb(3).zeta(),'z5':arb(5).zeta(),'gamma':arb.const_euler()}
 native=json.loads((HERE/'native-points.json').read_text());checks=[]
 assert {(p['profile'],p['index']) for p in native['points']}=={(0,0),(0,31),(1,0),(1,35)} and len(native['points'])==4
 assert set(data['symbols'])=={'z2','z3','z5','gamma'}
 for name,expected in [('native_raw',range(-3,3)),('FMFT_normalized',range(-3,3)),('K1_cubed_ratio',range(6))]:
  assert len(data[name])==6 and [x['epsilon_power'] for x in data[name]]==list(expected)
 for point in native['points']:
  source=Path(point['source']);assert hashlib.sha256(source.read_bytes()).hexdigest()==point['sha256']
  original=json.loads(source.read_bytes())['result']['p853_receipts'];assert len(original)==1
  receipt=original[0]['receipt'];assert receipt['epsilon']==point['epsilon'] and receipt['ratio']==point['ratio'] and receipt['raw_target']==point['raw_target']
  e=Fraction(point['epsilon']);ee=arb(fmpq(e.numerator,e.denominator));value=sum((evaluate(row['ast'],constants)*ee**row['epsilon_power'] for row in data['K1_cubed_ratio']),arb(0));center=arb(point['ratio'][0]);imaginary=arb(point['ratio'][1]);assert center.is_finite() and imaginary.is_finite();delta=((value-center)**2+imaginary**2).sqrt().upper();x=abs(ee)*16;tail=4*x**6/(1-x)
  assert delta<tail, (point['profile'],point['index'],delta,tail)
  checks.append({'profile':point['profile'],'index':point['index'],'difference':delta.str(30),'rigorous_jet_tail_bound':tail.str(30),'native_source_accuracy_claimed':False,'passed':True})
 ctx.dps=20150;constants={'z2':arb(2).zeta(),'z3':arb(3).zeta(),'z5':arb(5).zeta(),'gamma':arb.const_euler()};outputs={}
 for name in ['native_raw','FMFT_normalized','K1_cubed_ratio']:
  values=[]
  for row in data[name]:
   value=evaluate(row['ast'],constants);center,error=rounded_cell(value,20000);assert value.rel_accuracy_bits()>math.ceil(20100*math.log2(10))
   values.append({'epsilon_power':row['epsilon_power'],'value':center,'absolute_error_upper_bound':upper_decimal(error),'arithmetic_ball':value.str(20030),'validated_significant_digits':20000,'expression':row['expression']})
  outputs[name]=values
 out={'schema':'vakint.pr11d.p853-20k-jets.v1','source_exact_jet_sha256':hashlib.sha256((HERE/'p853-exact-jet.json').read_bytes()).hexdigest(),'digits':20000,'coefficient_arithmetic':'FLINT/Arbwithdirectederrorboundsandunambiguousround-to-nearestdecimalcells','coefficients':outputs}
 (HERE/'p853-20000-jets.json').write_text(json.dumps(out,indent=2)+'\n')
 mma_path=HERE/'mathematica-20000-coefficients.json';mma=json.loads(mma_path.read_text());independent=[]
 assert set(mma['coefficients'])=={'native_raw','FMFT_normalized','K1_cubed_ratio'}
 seed=json.loads((HERE/'mathematica-constants.json').read_text());assert seed['sha256']==mma['seed_sha256']
 assert hashlib.sha256(Path(seed['source']).read_bytes()).hexdigest()==seed['sha256']
 assert seed['working_decimal_digits']>=20100
 ctx.dps=20200
 for name,rows in mma['coefficients'].items():
  assert len(rows)==len(data[name])==6 and [x['epsilon_power'] for x in rows]==[x['epsilon_power'] for x in data[name]]
  assert all(x['precision']>=20090 for x in rows)
  for observed,row in zip(rows,data[name]):
   assert observed['epsilon_power']==row['epsilon_power']
   text=observed['value'];mantissa,sep,exponent=text.partition('*^');mantissa=mantissa.split('`')[0];point=arb(mantissa+('e'+exponent if sep else ''))
   value=evaluate(row['ast'],constants);relative=abs(value-point).upper()/abs(value).lower();assert relative<arb(10)**(-20080),(name,row['epsilon_power'],relative)
   agreed=int((-relative.log()/arb(10).log()).lower().floor().fmpz())
   independent.append({'normalization':name,'epsilon_power':row['epsilon_power'],'agreed_decimal_digits_lower_bound':agreed,'passed':True})
 assert len(independent)==18
 report={'schema':'vakint.pr11d.p853-jet-validation.v1','seconds':time.time()-started,'tail_proof':proof,'native_point_checks':checks,'coefficient_data_sha256':hashlib.sha256((HERE/'p853-20000-jets.json').read_bytes()).hexdigest(),'independent_Mathematica_coefficient_checks':independent,'minimum_independent_agreed_digits':min(x['agreed_decimal_digits_lower_bound'] for x in independent),'Mathematica_source_sha256':hashlib.sha256(mma_path.read_bytes()).hexdigest(),'validator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'wholePR11dAccuracyClaimed':False}
 (HERE/'validation-arb-native.json').write_text(json.dumps(report,indent=2)+'\n');print('P853 Arb20kcoefficientsandnativepointchecksPASS',report['seconds'])
if __name__=='__main__':main()
