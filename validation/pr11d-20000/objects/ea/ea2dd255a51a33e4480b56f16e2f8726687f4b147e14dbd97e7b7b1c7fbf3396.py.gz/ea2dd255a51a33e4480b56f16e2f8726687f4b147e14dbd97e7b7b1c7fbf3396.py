#!/usr/bin/env python3
"""Independent saved A endpoint convolution; no producer engine evaluation."""
import copy
import hashlib
import importlib.util
import itertools
import json
import sys
from fractions import Fraction as Q
from pathlib import Path
from flint import arb, acb, ctx

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BASE = HERE.parent
CHECKER = BASE / 'endpoint-replay/replay_snapshot.py'
CHECKER_SHA = '56be153128e0d62480489fcdd334d0061a5a149cf015050089304d54df5c429b'
COMPONENT = BASE / 'endpoint-replay/replay-snapshot.json'
COMPONENT_SHA = 'd0c195c1d051a352fb35c96ee3b77d4ba8a22bf33a69a85365f3db2a604a807a'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def main():
    assert sha(CHECKER) == CHECKER_SHA and sha(COMPONENT) == COMPONENT_SHA
    component = read(COMPONENT)
    pins = dict(component['source_pins'])
    pins.update({str(CHECKER): CHECKER_SHA, str(COMPONENT): COMPONENT_SHA})
    for p, h in pins.items():
        assert sha(p) == h, p
    # Separate Fraction implementation of the routing's quadratic identities.
    canonical = read(component['canonical_binding_proof_path'])
    witness = canonical['proof']['PR9d_witness']
    manifest = read(BASE / 'endpoint-replay/canonical-routing/immutable-inputs/4L-manifest-b40adfb8.json')
    family = next(f for f in manifest['families'] if f['sha256'] == '693719b1bc3d2f1d4d32c9312df66ced667a542591a2ada6f6498844fc5d0de1')
    U = witness['loop_matrix_k_equals_U_l']
    determinant = Q(0)
    for p in itertools.permutations(range(4)):
        inversions = sum(p[i] > p[j] for i in range(4) for j in range(i + 1, 4))
        product = Q((-1) ** inversions)
        for i in range(4): product *= U[i][p[i]]
        determinant += product
    assert abs(determinant) == 1
    quadratic = []
    for denominator in family['denominators']:
        matrix = [[Q(0) for _ in range(4)] for _ in range(4)]
        for coordinate, coefficient in zip(family['coordinates'], denominator['coefficients']):
            i, j = coordinate['left'], coordinate['right']
            matrix[i][j] = matrix[j][i] = Q(coefficient) / (1 if i == j else 2)
        quadratic.append(matrix)
    source, target = witness['source_powers'], witness['canonical_powers']
    edges = witness['active_slot_mapping']
    assert sorted(i for i, j, s in edges) == [i for i, p in enumerate(source) if p]
    assert sorted(j for i, j, s in edges) == [j for j, p in enumerate(target) if p]
    for i, j, sign in edges:
        transformed = [[sum(U[a][r] * quadratic[i][a][b] * U[b][s]
                            for a in range(4) for b in range(4))
                        for s in range(4)] for r in range(4)]
        assert transformed == quadratic[j]
        assert source[i] == target[j] and family['denominators'][i]['constant'] == family['denominators'][j]['constant'] == '-1'
    assert len(edges) == 7
    spec = importlib.util.spec_from_file_location('reviewed_A_endpoint_component', CHECKER)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    endpoint, boundary, raw, proof, mapping = [read(p) for p in
                                             (m.ENDPOINT, m.BOUNDARY, m.RAW, m.PROOF, m.MAPPING)]
    adjoints = {name: read(m.ANCESTOR / f'{name}-native-adjoint-20400.json') for name in m.TARGETS}
    ctx.dps = 20400
    y = [acb(arb(a), arb(b)) for a, b in boundary['values']]
    computed = []
    products = 0
    for name in m.TARGETS:
        w = [acb(arb(a), arb(b)) for a, b in adjoints[name]['complex_balls']]
        for p in range(6):
            z = acb(0)
            for j in range(p + 1):
                for i in range(22):
                    z += w[22*j+i] * y[22*(p-j)+i]
                    products += 1
            assert z.is_finite() and z.imag.contains(0)
            row = endpoint['coefficients']['native::' + name][p]
            assert row == {'epsilon_power': p-4, 'ball': z.real.str(20408, more=True),
                           'imaginary_ball': z.imag.str(20408, more=True),
                           'relative_accuracy_bits': int(z.real.rel_accuracy_bits()),
                           'absolute_radius': z.real.rad().str(35, more=True)}
            computed.append((z, row))
    ctx.dps = 20500
    maximum = arb(0)
    containments = 0
    for z, row in computed:
        for field, part in [('ball', z.real), ('imaginary_ball', z.imag)]:
            stored = arb(row[field])
            assert stored.contains(part)
            maximum = max(maximum, stored.rad())
            containments += 1
    assert maximum < arb(10) ** -20050
    current = m.validate()
    assert {k: v for k, v in current.items() if k != 'seconds'} == {k: v for k, v in component.items() if k != 'seconds'}
    cases = []

    def rejection(name, mutate):
        args = [copy.deepcopy(x) for x in (endpoint, boundary, raw, proof, adjoints, mapping)]
        mutate(args)
        try:
            m.replay_payload(*args)
        except (ValueError, KeyError) as error:
            cases.append({'case': name, 'rejected': True, 'diagnostic': str(error)})
        else:
            raise AssertionError('Corruption passed: ' + name)

    rejection('estimated_boundary', lambda a: a[1].update(error_quality='validated-digits-estimate'))
    rejection('wrong_basis', lambda a: a[1].update(basis='regular_U'))
    rejection('wrong_normalization', lambda a: a[0].update(normalization='FMFT'))
    rejection('wrong_final_center', lambda a: a[1].update(eta_center=['0', '1/8']))
    rejection('missing_master', lambda a: a[0]['coefficients'].pop('native::PR3'))
    rejection('false_adjoint_tail', lambda a: a[4]['PR3'].update(tail_bound_added=False))
    rejection('wrong_adjoint_center', lambda a: a[4]['PR3'].update(eta_center=['0', '1/8']))
    rejection('wrong_coefficient_order', lambda a: a[0]['coefficients']['native::PR3'][0].update(epsilon_power=-3))
    rejection('changed_real_box', lambda a: a[0]['coefficients']['native::PR3'][0].update(ball='0'))
    rejection('wrong_unit_mapping', lambda a: a[5]['old_from_selected_old'][11].__setitem__(2, '2'))
    for p, h in pins.items():
        assert sha(p) == h
    pins[str(Path(__file__).resolve())] = sha(Path(__file__).resolve())
    out = {'schema': 'vakint.production-A-endpoint-component-independent-review.v1',
           'accepted_for_frozen_scope': True,
           'scope': 'Frozen A endpoint checker source, 42 saved full interval convolutions, original outward strings/metadata, and independent exact canonical PR9d routing verification using an immutable manifest snapshot. Physical initial and 49-step chain remain separate.',
           'endpoint_checker_sha256': CHECKER_SHA, 'endpoint_replay_sha256': COMPONENT_SHA,
           'endpoint_sha256': component['endpoint_sha256'],
           'final_boundary_sha256': component['final_boundary_sha256'],
           'shared_canonical_witness_sha256': component['canonical_binding_proof_sha256'],
           'canonical_routing_determinant': str(determinant),
           'independent_exact_canonical_quadratic_identities': len(edges),
           'canonical_active_power_and_mass_bijection': True,
           'source_pins': pins, 'independent_products': products, 'complex_coefficients': 42,
           'full_component_containments': containments,
           'all_original_strings_and_precision_metadata_identical': True,
           'maximum_serialized_component_radius': maximum.str(45, more=True),
           'all_serialized_absolute_radii_below_1e_minus20050': True,
           'rejections': cases, 'rejection_count': len(cases),
           'whole_PR11d_20000_accuracy_claimed': False, 'PR11d_validated_decimal_cap': 200,
           'native_preparer_HPL_or_transport_calls': 0, 'producer_files_modified': False}
    target = HERE / 'endpoint-component-review.json'
    with target.open('x') as stream:
        stream.write(json.dumps(out, indent=2) + '\n')
    print(str(target))
    print(sha(target))


if __name__ == '__main__':
    main()
