#!/usr/bin/env python3
"""Exact convergent MZVs throughweight6 from shuffle, stuffle and duality."""
from collections import Counter
from functools import lru_cache
from itertools import product
from fractions import Fraction as Q
from flint import fmpq,fmpq_mat
@lru_cache(None)
def stuffle(a,b):
    if not a:return Counter({b:1})
    if not b:return Counter({a:1})
    out=Counter()
    for word,c in stuffle(a[1:],b).items():out[(a[0],)+word]+=c
    for word,c in stuffle(a,b[1:]).items():out[(b[0],)+word]+=c
    for word,c in stuffle(a[1:],b[1:]).items():out[(a[0]+b[0],)+word]+=c
    return out
@lru_cache(None)
def shuffle(a,b):
    if not a:return Counter({b:1})
    if not b:return Counter({a:1})
    out=Counter()
    for word,c in shuffle(a[1:],b).items():out[(a[0],)+word]+=c
    for word,c in shuffle(a,b[1:]).items():out[(b[0],)+word]+=c
    return out

def binary(a):return tuple(x for k in a for x in (0,)*(k-1)+(1,))
def indices(a):
    out=[];k=1
    for x in a:
        if x:k0=k;out.append(k0);k=1
        else:k+=1
    assert k==1
    return tuple(out)
def dual(a):return indices(tuple(1-x for x in reversed(binary(a))))
def compositions(n):
    if n==0:return [()]
    return [(k,)+rest for k in range(1,n+1) for rest in compositions(n-k)]
def admissible(n):return [w for w in compositions(n) if w[0]>=2]
def add(a,b,scale=Q(1)):
    out=a.copy()
    for m,c in b.items():out[m]=out.get(m,Q(0))+c*scale
    return {m:c for m,c in out.items() if c}
def mul(a,b):
    out={}
    for x,c in a.items():
        for y,d in b.items():
            z=tuple(u+v for u,v in zip(x,y));out[z]=out.get(z,Q(0))+c*d
    return {m:c for m,c in out.items() if c}
def relations():
    known={};evidence=[]
    for weight in range(2,7):
        words=admissible(weight);where={w:i for i,w in enumerate(words)}
        monomials=[m for m in product(range(4),range(3),range(2)) if 2*m[0]+3*m[1]+5*m[2]==weight]
        rows=[]
        def relation(left,right={}):
            assert all(w in where for w,c in left.items() if c)
            rows.append([fmpq(c.numerator,c.denominator) for c in [Q(left.get(w,0)) for w in words]+[-right.get(m,Q(0)) for m in monomials]])
        for w in words:relation(Counter({w:1})-Counter()) if False else None
        for w in words:
            c=Counter();c[w]+=1;c[dual(w)]-=1;relation(c)
        for split in range(2,weight-1):
            for a in admissible(split):
                for b in admissible(weight-split):
                    rhs=mul(known[a],known[b]);relation(stuffle(a,b),rhs)
                    c=Counter()
                    for word,n in shuffle(binary(a),binary(b)).items():c[indices(word)]+=n
                    relation(c,rhs)
        for b in admissible(weight-1):
            c=Counter(stuffle((1,),b))
            for word,n in shuffle((1,),binary(b)).items():c[indices(word)]-=n
            relation(c)
        generator={2:{(1,0,0):Q(1)},3:{(0,1,0):Q(1)},4:{(2,0,0):Q(2,5)},5:{(0,0,1):Q(1)},6:{(3,0,0):Q(8,35)}}[weight]
        relation(Counter({(weight,):1}),generator)
        reduced,rank=fmpq_mat(rows).rref();assert rank==len(words),(weight,rank,len(words))
        for i,w in enumerate(words):
            assert all(reduced[i,j]==int(i==j) for j in range(len(words)))
            known[w]={m:Q(-int(reduced[i,len(words)+k].numerator),int(reduced[i,len(words)+k].denominator)) for k,m in enumerate(monomials) if reduced[i,len(words)+k]}
        evidence.append({'weight':weight,'convergent_words':len(words),'shuffle_stuffle_duality_relations':len(rows),'rank':rank})
    assert known[(2,1)]==known[(3,)]
    assert known[(3,1)]=={(2,0,0):Q(1,10)}
    assert known[(2,2)]=={(2,0,0):Q(3,10)}
    assert known[(4,1)]=={(0,0,1):Q(2),(1,1,0):Q(-1)}
    return known,evidence
if __name__=='__main__':
    known,evidence=relations();print(evidence);print('zeta(3,2)=',known[(3,2)])
