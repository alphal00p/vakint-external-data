#!/usr/bin/env python3
"""Independent v4 metadata delta audit and saved-step replay only."""
import ast
import copy
import dataclasses
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
GENERIC = ROOT.parent / 'bessel/generic-rpf-admission'
V3 = GENERIC / 'exact_step_v3.py'
V4 = GENERIC / 'exact_step_v4.py'
V3_SHA = '8f4f305a48e18460f2fee22d1aa3646b254e8c16527d751a8388f6320eb0d75f'
V4_SHA = '5fe99cdc9ff6a232c337fcd485f9c2788ad2b5766f39036358bf47491096c879'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


class StripMetadata(ast.NodeTransformer):
    def visit_FunctionDef(self, node):
        if node.name == 'check_boundary_metadata':
            return None
        return self.generic_visit(node)

    def visit_AnnAssign(self, node):
        if isinstance(node.target, ast.Name) and node.target.id in ('boundary_metadata_policy', 'absent_flag_initial_sha256'):
            return None
        return self.generic_visit(node)

    def visit_Assign(self, node):
        if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id in ('prior_profile', 'following_profile'):
            assert isinstance(node.value, ast.Call) and node.value.func.id == 'check_boundary_metadata'
            return None
        return self.generic_visit(node)

    def visit_Expr(self, node):
        expected = "require(d.get('physical_accuracy_certified', True) is not False, 'Explicitly uncertified source')"
        if ast.unparse(node) == expected:
            return None
        return self.generic_visit(node)

    def visit_Dict(self, node):
        removed = {'boundary_metadata_policy', 'prior_boundary_profile', 'following_boundary_profile', 'physical_source_admission_required'}
        pairs = [(k, v) for k, v in zip(node.keys, node.values)
                 if not isinstance(k, ast.Constant) or k.value not in removed]
        node.keys, node.values = [k for k, v in pairs], [v for k, v in pairs]
        return self.generic_visit(node)

    def visit_Constant(self, node):
        if node.value in ('vakint.generic-exact-general-RPF-step-data-review.v3', 'vakint.generic-exact-general-RPF-step-data-review.v4'):
            return ast.copy_location(ast.Constant('REVIEWED_RECEIPT_SCHEMA'), node)
        return node


def main():
    assert sha(V3) == V3_SHA and sha(V4) == V4_SHA
    trees = [ast.parse(p.read_text()) for p in (V3, V4)]
    reduced = [StripMetadata().visit(copy.deepcopy(t)) for t in trees]
    assert ast.dump(reduced[0], include_attributes=False) == ast.dump(reduced[1], include_attributes=False)
    E = load_module('independently_reviewed_generic_v4', V4)
    sources = {str(V3): V3_SHA, str(V4): V4_SHA}
    cases, profiles, steps = [], {}, []
    cp = ROOT / 'jet-transport/polynomial-connection-regular-gauge.json'
    rp = ROOT / 'jet-transport/x8-ordinary-rational-pf.json'
    for letter in ('A', 'B'):
        directory = ROOT / f'hierarchy-transport/x8-production-{letter}-halfsteps-v11'
        initial_path = ROOT / f'helper/frobenius-transport/x8-production-{letter}-scheduled-v1/conditional-initial.json'
        binding_path = directory / 'run-binding.json'
        binding, initial = E.load(binding_path), E.load(initial_path)
        first_path = directory / 'step-000-boundary.json'
        following = E.load(first_path)
        meta = E.load(directory / 'step-000.json')
        k = E.StepContract(42, 6, -4, sha(cp), sha(rp), binding['source_equation_sha256'],
                           meta['working_bits'], binding['local_target_digits'],
                           binding['local_target_digits'] + binding['guard_digits'],
                           sha(binding_path), sha(initial_path), expected_worker_threads=8,
                           boundary_metadata_policy='conditional_v11',
                           absent_flag_initial_sha256=sha(initial_path))
        for path in [initial_path, first_path, binding_path]:
            sources[str(path)] = sha(path)
        prior_profile = E.check_boundary_metadata(initial, is_prior=True, actual_prior_sha256=sha(initial_path), contract=k)
        resume_profile = E.check_boundary_metadata(following, is_prior=True, actual_prior_sha256=sha(first_path), contract=k)
        assert prior_profile['physical_accuracy_certified_field_present'] is False
        assert prior_profile['physical_accuracy_certified'] is None
        assert prior_profile['absent_flag_initial_admitted'] is True
        assert resume_profile['physical_accuracy_certified_field_present'] is True
        assert resume_profile['physical_accuracy_certified'] is False
        assert resume_profile['absent_flag_initial_admitted'] is False
        profiles[letter] = {'prior': prior_profile, 'resume': resume_profile}
        if letter == 'A':
            def reject(name, data, role=True, actual=None, contract=None):
                try:
                    E.check_boundary_metadata(data, is_prior=role,
                                              actual_prior_sha256=actual or sha(initial_path),
                                              contract=contract or k)
                except (ValueError, KeyError, TypeError) as error:
                    cases.append({'case': name, 'rejected': True, 'diagnostic': str(error)})
                else:
                    raise AssertionError('Corruption accepted: ' + name)
            for field in ['schema', 'physical_source_admission_required', 'whole_PR11d_accuracy_claimed', 'raw_total_width_gate_passed']:
                d = dict(initial); del d[field]; reject('initial_missing_' + field, d)
            for marker in [False, True, None, 0, 1, 'false']:
                reject('initial_present_physical_' + repr(marker), {**initial, 'physical_accuracy_certified': marker})
            for marker in [False, None, 0, 1, 'pending']:
                reject('initial_bad_pending_' + repr(marker), {**initial, 'physical_source_admission_required': marker})
            reject('unblessed_absence', initial, contract=dataclasses.replace(k, absent_flag_initial_sha256=None))
            reject('wrong_absence_hash', initial, contract=dataclasses.replace(k, absent_flag_initial_sha256='0' * 64))
            reject('wrong_actual_prior', initial, actual='0' * 64)
            reject('initial_as_following', initial, role=False)
            for policy in ['unknown', None, True, 0]:
                reject('invalid_policy_' + repr(policy), initial, contract=dataclasses.replace(k, boundary_metadata_policy=policy))
            for role in [0, 1, None, 'prior']:
                reject('invalid_role_' + repr(role), initial, role=role)
            for role in [True, False]:
                actual = sha(first_path)
                for field in ['schema', 'physical_source_admission_required', 'physical_accuracy_certified',
                              'whole_PR11d_20000_accuracy_claimed', 'run_binding_sha256', 'initial_boundary_sha256']:
                    d = dict(following); del d[field]
                    reject(f'resume_{role}_missing_{field}', d, role, actual)
                for marker in [True, None, 0, 1, 'false']:
                    reject(f'resume_{role}_physical_{marker!r}', {**following, 'physical_accuracy_certified': marker}, role, actual)
                for field in ['run_binding_sha256', 'initial_boundary_sha256']:
                    reject(f'resume_{role}_rebound_{field}', {**following, field: '0' * 64}, role, actual)
                reject(f'resume_{role}_absence_exception', initial, role, actual)
            for d, actual in [(initial, sha(initial_path)), (following, sha(first_path))]:
                other = 'whole_PR11d_20000_accuracy_claimed' if d is initial else 'whole_PR11d_accuracy_claimed'
                for marker in [True, None, 0, 1]:
                    reject('conflicting_claim_' + other + repr(marker), {**d, other: marker}, True, actual)
            default = dataclasses.replace(k, boundary_metadata_policy='physical', absent_flag_initial_sha256=None)
            for d in [{}, {'physical_accuracy_certified': True}]:
                E.check_boundary_metadata(d, is_prior=True, actual_prior_sha256=sha(initial_path), contract=default)
            reject('default_explicitly_false_rejected', {'physical_accuracy_certified': False}, contract=default)
            reject('default_conditional_schema_rejected', initial, contract=default)
            reject('default_conditional_schema_cannot_reset_flags',
                   {'schema': initial['schema'], 'physical_accuracy_certified': True,
                    'physical_source_admission_required': False}, contract=default)
            for marker in [True, None, 0, 1, 'pending']:
                reject('default_pending_marker_' + repr(marker),
                       {'physical_source_admission_required': marker}, contract=default)
        for index in (0, 1):
            previous = initial_path if index == 0 else directory / f'step-{index-1:03}-boundary.json'
            paths = [directory / f'step-{index:03}.in', directory / f'step-{index:03}.json', previous,
                     cp, rp, directory / f'step-{index:03}-native.json', directory / f'step-{index:03}-boundary.json']
            checked = E.check_step(*paths, k)
            assert checked['physical_initial_origin_admitted'] is False
            assert checked['native_implementation_admitted'] is False
            assert checked['input_full_box_containments'] == checked['output_full_box_containments'] == 252
            sources.update(checked['artifact_sha256'])
            steps.append({'profile': letter, 'index': index, 'check': checked})
            print('PASS', letter, index, flush=True)
    for p, h in sources.items():
        assert sha(p) == h
    sources[str(Path(__file__).resolve())] = sha(Path(__file__).resolve())
    result = {'schema': 'vakint.generic-RPF-v4-independent-metadata-delta-review.v1',
              'accepted': True, 'status': 'passed_for_frozen_generic_RPF_v4_conditional_metadata_delta',
              'checker_sha256': V4_SHA, 'predecessor_sha256': V3_SHA,
              'numerical_AST_identical_after_only_reviewed_metadata_delta': True,
              'legacy_physical_accuracy_predicate_preserved': True,
              'physical_default_rejects_conditional_schema_and_pending_or_malformed_markers': True,
              'actual_absent_initial_field_reported_as_absent_not_false': True,
              'conditional_initial_exception_bound_to_actual_prior_hash_role_and_explicit_initial_pin': True,
              'explicit_pending_true_physical_false_required_on_produced_and_resumed_nodes': True,
              'no_physical_origin_admitted_by_generic_checker': True,
              'rejection_count': len(cases), 'negative_controls': cases,
              'actual_AB_initial_and_resume_profiles': profiles,
              'actual_saved_steps': steps, 'source_pins': sources,
              'scope': 'Only additive generic-checker metadata policy and four immutable saved v11 steps. Source-envelope and complete-chain admission remain separately required.',
              'native_preparer_HPL_or_transport_calls': 0,
              'producer_files_modified': False, 'whole_PR11d_20000_accuracy_claimed': False}
    out = HERE / 'v4-delta-review.json'
    with out.open('x') as stream:
        stream.write(json.dumps(result, indent=2) + '\n')
    print(sha(out))
    print('rejections', len(cases))


if __name__ == '__main__':
    main()
