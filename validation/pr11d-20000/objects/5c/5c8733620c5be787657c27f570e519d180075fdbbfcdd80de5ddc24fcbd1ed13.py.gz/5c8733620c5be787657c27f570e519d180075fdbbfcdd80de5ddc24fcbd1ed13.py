from replay import *

V=((1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1),
   (1,0,-1,0),(0,1,-1,0),(1,0,-1,-1),(0,1,-1,-1),
   (1,1,-1,-1),(0,0,1,1))
def sign(v):
    return tuple(-x for x in v) if next((x for x in v if x),1)<0 else tuple(v)
LOOKUP={sign(v):i for i,v in enumerate(V)}
def determinant(t):
    return sum((1 if sum(p[i]>p[j] for i in range(4) for j in range(i+1,4))%2==0 else -1)*
               t[0][p[0]]*t[1][p[1]]*t[2][p[2]]*t[3][p[3]] for p in itertools.permutations(range(4)))

@functools.cache
def automorphisms():
    images=[tuple(s*x for x in v) for s in (-1,1) for v in V]
    out=[]
    for a,b,c in itertools.product(images,repeat=3):
        for d in (V[3],tuple(-x for x in V[3])):
            t=(a,b,c,d)
            if abs(determinant(t))!=1:continue
            perm=[]
            for v in V:
                image=tuple(sum(v[i]*t[i][j] for i in range(4)) for j in range(4))
                p=LOOKUP.get(sign(image))
                if p is None:break
                perm.append(p)
            if len(perm)==10 and len(set(perm))==10 and perm[3]==3:
                out.append((tuple(perm),t))
    # T and -T induce identical squares; retain one authenticating witness.
    return tuple({p:(p,t) for p,t in out}.values())

def transform(seed,perm):
    p=[0]*10
    for i,j in enumerate(perm):p[j]=seed[i]
    return tuple(p)

def canonical(seed):
    return min(transform(seed,p) for p,t in automorphisms())

@functools.cache
def physical_automorphisms():
    active=tuple(range(1,9))
    # k2,k3,k4,k1-k3 form a unimodular basis. Their images are
    # independently enumerated among the eight actual graph propagators.
    images=[tuple(s*x for x in V[i]) for s in (-1,1) for i in active]
    out={}
    for a,b,c in itertools.product(images,repeat=3):
        for d in (V[3],tuple(-x for x in V[3])):
            t=(tuple(b[j]+c[j] for j in range(4)),a,b,d)
            if abs(determinant(t))!=1:continue
            perm=[]
            for i in active:
                image=tuple(sum(V[i][k]*t[k][j] for k in range(4)) for j in range(4))
                p=LOOKUP.get(sign(image))
                if p not in active:break
                perm.append(p)
            if len(perm)==8 and len(set(perm))==8 and perm[2]==3:
                out[tuple(perm)]=(tuple(perm),t)
    return tuple(out.values())

def transform_expression(seed,t):
    """Exact substitution of a loop routing, including ISP numerator polynomials."""
    transformed=[]
    for r,v in enumerate(V):
        w=tuple(sum(v[k]*t[k][j] for k in range(4)) for j in range(4))
        q=[w[a]*w[b]*(1 if a==b else 2) for a,b in COORDS]
        d=[sum(q[k]*QI[k][s] for k in range(10)) for s in range(10)]
        c=-MASSES[r]
        for m,a in zip(MASSES,d):c=c+rational(a)*m
        transformed.append((d,c))
    base=[0]*10
    for r,n in enumerate(seed):
        if n>0:
            d,c=transformed[r];positions=[i for i,v in enumerate(d) if v]
            if c.num or len(positions)!=1 or d[positions[0]]!=1:
                return None
            base[positions[0]]+=n
    out={tuple(base):ONE}
    for r,n in enumerate(seed):
        if n>=0:continue
        d,c=transformed[r]
        for _ in range(-n):
            new={}
            for p,value in out.items():
                add(new,p,value*c)
                for i,a in enumerate(d):
                    if a:
                        q=list(p);q[i]-=1;add(new,tuple(q),value*rational(a))
            out=new
    return remove_scaleless(out)

if __name__=='__main__':
    x=automorphisms()
    print('automorphisms',len(x),'physical',len(physical_automorphisms()))
    (HERE/'family-automorphisms.json').write_text(json.dumps([{'permutation':p,'matrix':t,'determinant':determinant(t)} for p,t in x],indent=2)+'\n')
    (HERE/'physical-automorphisms.json').write_text(json.dumps([{'permutation_of_slots_1_through_8':p,'matrix':t,'determinant':determinant(t)} for p,t in physical_automorphisms()],indent=2)+'\n')
