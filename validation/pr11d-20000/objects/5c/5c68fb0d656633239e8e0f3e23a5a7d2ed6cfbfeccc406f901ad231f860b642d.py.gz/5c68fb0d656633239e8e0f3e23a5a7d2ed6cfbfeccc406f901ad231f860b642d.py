#!/usr/bin/env python3
"""Read-only production-B endpoint arithmetic/pin replay; no native runs."""
import hashlib
import importlib.util
import json
import time
from fractions import Fraction as Q
from pathlib import Path

from flint import acb, arb, ctx

if not __debug__:
    raise RuntimeError("Assertions required")

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PINS = {}


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def bind(path, expected=None):
    path = Path(path).resolve()
    digest = sha(path)
    if expected is not None:
        assert digest == expected, ("hash mismatch", str(path))
    PINS[str(path)] = digest
    return path


def unique(pairs):
    result = {}
    for key, value in pairs:
        assert key not in result, ("duplicate JSON key", key)
        result[key] = value
    return result


def read(path, expected=None):
    return json.loads(bind(path, expected).read_text(), object_pairs_hook=unique)


def decode(values):
    assert len(values) == 132 and all(len(pair) == 2 for pair in values)
    result = [acb(arb(a), arb(b)) for a, b in values]
    assert all(value.is_finite() for value in result)
    return result


def convolve(W, Y, p):
    return sum((W[22*j+i] * Y[22*(p-j)+i]
                for j in range(p+1) for i in range(22)), acb(0))


started = time.monotonic()
ep_path = ROOT / "hierarchy-transport/pr9-production-B-endpoints.json"
ep = read(ep_path, "4f905a9a27d3b756cc551cff0ed893d1448e71dff9578d4143998578aebfbba2")
boundary_path = ROOT / "hierarchy-transport/pr9-production-API20600-substeps3-v9/step-035-boundary.json"
boundary = read(boundary_path, ep["boundary_sha256"])
raw_path = ROOT / "ancestor-flows/pr9-22.json"
raw = read(raw_path, "88290b3fe7015e350046044c3a93236700eb180e8141af5781fdfd5dfbfd9c88")
poly_path = bind(ROOT / "ancestor-flows/pr9-22-ordinary-polynomial.json", "701b6c7b09257c46924354433027ff19effb8426fb1fd731e3b161cc2daa0aac")
proof_path = ROOT / "ancestor-flows/pr9-22-endpoint-adjoints.json"
proof = read(proof_path, "512d1b3a79a782103540819a1fa37a8642f7c7bcddfa09dd9829ae13a34d2da0")
depth = read(ROOT / "ancestor-flows/endpoint-depth-proof.json")
assert ep["schema"] == "vakint.ancestor.certified-canonical-master-jets.v1"
assert ep["name"] == "pr9-22" and ep["normalization"] == "native_raw" and ep["error_quality"] == "rigorous-bound"
assert (ROOT / ep["boundary_source"]).resolve() == boundary_path.resolve()
assert ep["source_sha256"] == sha(raw_path) == proof["source_sha256"] == depth["source_sha256"]
assert ep["adjoint_proof_sha256"] == sha(proof_path)
assert ep["target_bindings"] == proof["target_bindings"] == depth["records"]
assert boundary["basis"] == "original_raw_epsilon_jets" and boundary["normalization"] == "native_raw"
assert boundary["error_quality"] == "rigorous-bound" and boundary["local_truncation_rigorously_enclosed"] is True
assert boundary["dimension"] == 22 and (boundary["epsilon_min_power"], boundary["epsilon_max_power"]) == (-4, 1)
assert boundary["source_equation_sha256"] == sha(raw_path)
assert list(map(Q, boundary["eta_center"])) == [Q(0), Q(1, 16)]

# Reuse the frozen independently reviewed exact rational AST/projector audit,
# not the exporter or the native recurrence. Its audit() writes no files.
generic_review = read(ROOT / "ancestor-flows/endpoint-review/review.json", "9afea657dbcf3c5a71570ddeb31be07e0f04a94b2f58f6f9ffeb363aabc076c8")
for path, digest in generic_review["source_sha256"].items():
    bind(path, digest)
algebra_path = bind(ROOT / "ancestor-flows/endpoint-review/independent_checks.py", "64468cfdd24ba001c55ef4879259ea0d81bedf2208bee31aa73df4e91cc9feea")
spec = importlib.util.spec_from_file_location("accepted_independent_endpoint_algebra", algebra_path)
algebra = importlib.util.module_from_spec(spec)
spec.loader.exec_module(algebra)
exact_projector_replay = algebra.audit("pr9-22")
bind(ROOT / "ancestor-flows/pr9-22-blocks.json")

sources = read(ROOT / "ancestor-flows/sources.json")
source_record = next(row for row in sources if row["name"] == "pr9-22")
native_mapping = read(source_record["source"], source_record["source_sha256"])
assert native_mapping["selected_old_basis"] == raw["basis"]
assert native_mapping["selected_old_differential_matrix"] == raw["differential_matrix"]
assert source_record["sha256"] == sha(raw_path)
manifest_path = Path("/shared/codex-1/vakint_rustred/vakint-external-data/4L/manifest.json")
manifest = read(manifest_path, "b40adfb858f4a10852d341aab0a8550de93e3c7526b953a6c4b21cbc7bb8f9b9")
mapping_checks = []
records = {row["symbol"]: row for row in proof["records"]}
for binding in ep["target_bindings"]:
    name, old, selected = binding["master"], binding["old_component"], binding["selected_component"]
    symbol = "native::" + name
    assert binding["powers"] == raw["basis"][selected]
    assert records[symbol]["component"] == selected
    assert records[symbol]["row_coefficients"][0] == binding["zero_sector_projector"]
    assert native_mapping["old_from_selected_old"][old] == [str(int(i == selected)) for i in range(22)]
    candidates = [row for row in manifest["masters"] if row["family_sha256"] == native_mapping["source_family_sha256"]
                  and row["exact_basis_expression"] == "vakint::{}::" + name]
    assert len(candidates) == 1
    canonical = candidates[0]
    literal = canonical["powers"] == native_mapping["old_basis"][old]
    assert literal or name == "PR9d"
    nonzero_projector = [i for i, text in enumerate(binding["zero_sector_projector"]) if text != "(0)/(1)"]
    if name == "PR9d":
        assert nonzero_projector == [6, 8, 9, 10, 13, 17, 18, 19, 20]
    mapping_checks.append({"symbol": symbol, "old_component": old, "selected_component": selected,
        "old_powers": native_mapping["old_basis"][old], "selected_powers": binding["powers"],
        "canonical_manifest_name": canonical["name"], "canonical_powers": canonical["powers"],
        "canonical_to_old_literal_identity": literal, "old_to_selected_literal_unit_row": True,
        "full_zero_sector_projector_replayed": True, "nonzero_projector_components": nonzero_projector})

admission_path = ROOT / "ancestor-flows/production-native-input-audit.json"
admission = read(admission_path)
assert admission["all_completed_production_inputs_valid"] is True and admission["pending_symbols"] == []
native_review = read(admission["implementation_review"], admission["implementation_review_sha256"])
for path, digest in native_review["source_sha256"].items():
    bind(path, digest)
assert admission["independent_auditor_source_sha256"] == sha(ROOT / "ancestor-flows/endpoint-review/native_checks.py")
accepted = {row["sha256"]: row for row in admission["checks"]}
wanted = {"native::" + name for name in ["PR3", "PR4", "PR4d", "PR5", "PR7", "PR9", "PR9d"]}
assert set(ep["coefficients"]) == wanted and len(ep["adjoint_inputs"]) == 7
seen = set()
results = []
all_radius_bounds = []
for entry in ep["adjoint_inputs"]:
    ap = Path(entry["path"])
    ap = ap if ap.is_absolute() else ROOT / ap
    adj = read(ap, entry["sha256"])
    accepted_record = accepted[entry["sha256"]]
    symbol = adj["symbol"]
    assert symbol in wanted and symbol not in seen and accepted_record["symbol"] == symbol
    seen.add(symbol)
    assert Path(accepted_record["path"]).resolve() == ap.resolve()
    assert accepted_record["all_required_residual_coefficients_retained"] is True
    assert accepted_record["all_input_output_source_hashes_match"] is True
    assert adj["name"] == "pr9-22" and adj["base_dimension"] == 22 and adj["dimension"] == 132 and adj["loop_count"] == 4
    assert adj["epsilon_range"] == [0, 5] and list(map(Q, adj["eta_center"])) == [Q(0), Q(1, 16)]
    assert adj["endpoint_projector_proof_sha256"] == sha(proof_path)
    assert adj["source_polynomial_sha256"] == entry["source_polynomial_sha256"] == sha(poly_path)
    assert adj["order"] == entry["order"] == accepted_record["order"] == 24000
    assert adj["working_bits"] == accepted_record["working_bits"] == 67771
    assert adj["tail_bound_added"] is True
    bind(ROOT / "ancestor-flows/endpoint_native.c", adj["native_source_sha256"])
    bind(ROOT / "ancestor-flows/endpoint-native", adj["native_binary_sha256"])
    bind(adj["native_input"], adj["native_input_metadata"]["input_sha256"])
    bind(adj["native_output"], adj["native_output_sha256"])
    assert adj["native_input_metadata"]["source_endpoint_proof_sha256"] == sha(proof_path)
    assert adj["native_input_metadata"]["source_polynomial_sha256"] == sha(poly_path)
    rows = ep["coefficients"][symbol]
    assert len(rows) == 6 and [row["epsilon_power"] for row in rows] == list(range(-4, 2))

    ctx.dps = 20800
    Y, W = decode(boundary["values"]), decode(adj["complex_balls"])
    threshold = (arb(10) ** -20000).lower()
    per_coefficient = []
    for p, row in enumerate(rows):
        value = convolve(W, Y, p)
        saved = acb(arb(row["ball"]), arb(row["imaginary_ball"]))
        assert saved.is_finite() and saved.contains(value), ("convolution containment", symbol, p)
        assert saved.imag.contains(0)
        rr, ir = saved.real.rad(), saved.imag.rad()
        total = (rr + ir).upper()
        assert total < threshold and (2*total).upper() < threshold, ("total width", symbol, p)
        all_radius_bounds.append(total)
        per_coefficient.append({"epsilon_power": p-4,
            "real_radius_upper": rr.upper().str(45, more=True),
            "imaginary_radius_upper": ir.upper().str(45, more=True),
            "complex_rectangle_l1_radius_upper": total.str(45, more=True),
            "l1_diameter_upper": (2*total).upper().str(45, more=True),
            "strict_l1_radius_below_1e_minus20000": True,
            "strict_l1_diameter_below_1e_minus20000": True,
            "full_complex_convolution_contained": True})

    # Reproduce original accumulation order, 20400-digit arithmetic and
    # 20408-significant-digit outward strings without invoking the projector.
    ctx.dps = 20400
    Y, W = decode(boundary["values"]), decode(adj["complex_balls"])
    assert ctx.prec == 67771
    for p, row in enumerate(rows):
        value = convolve(W, Y, p)
        assert row["ball"] == value.real.str(20408, more=True)
        assert row["imaginary_ball"] == value.imag.str(20408, more=True)
        assert row["relative_accuracy_bits"] == int(value.real.rel_accuracy_bits())
        assert row["absolute_radius"] == value.real.rad().str(35, more=True)
    results.append({"symbol": symbol, "adjoint_sha256": entry["sha256"],
        "admitted_native_operator": True, "order": 24000, "working_bits": 67771,
        "full_complex_containments": 6, "original20400digit_projection_and20408digit_strings_byte_identical": True,
        "precision_metadata_byte_identical": True, "coefficient_bounds": per_coefficient})
    print("PASS", symbol, flush=True)

assert seen == wanted
ctx.dps = 20800
maximum = max(all_radius_bounds)
for path, digest in PINS.items():
    assert sha(path) == digest, ("artifact changed during review", path)
report = {
    "schema": "vakint.pr9.production-B.endpoint-arithmetic-review.v1",
    "accepted_scope": "Seven previously admitted adjoints, exact selected-state/projector mapping, full-ball endpoint convolution, serialization and strict total-width checks, conditional on separately admitted terminal boundary.",
    "endpoint_arithmetic_accepted": True,
    "whole_physical_source_admission": False,
    "unresolved_physical_name_edge": "PR9d: canonical same-family P15 powers [0,2,1,0,1,1,1,1,1,0] versus native old89 powers [0,0,1,2,1,1,1,1,1,0]; separate exact routing witness is owned by ancestor endpoint reviewer.",
    "terminal_boundary": str(boundary_path), "terminal_boundary_sha256": sha(boundary_path),
    "source_and_implementation_pins": PINS,
    "checker_sha256": sha(__file__),
    "exact_projector_replay": exact_projector_replay,
    "canonical_mapping_checks": mapping_checks,
    "projection_formula": "[epsilon^(p-4)](W Y)=sum_(j=0)^p sum_(i=0)^21 W[j,i]*Y[p-j,i], p=0..5; W is epsilon-regular and no extra epsilon or normalization factor is applied.",
    "all_input_source_rounding_and_adjoint_tail_radii_retained": True,
    "independent_convolution_decimal_precision": 20800,
    "original_projection_decimal_precision": 20400,
    "original_serialization_digits": 20408,
    "coefficient_count": 42,
    "all42_strict_total_l1_radii_below_1e_minus20000": True,
    "all42_strict_total_l1_diameters_below_1e_minus20000": True,
    "maximum_total_complex_l1_radius_upper": maximum.str(50, more=True),
    "maximum_total_complex_l1_diameter_upper": (2*maximum).upper().str(50, more=True),
    "results": results,
    "interpretation": [
        "Bounds are computed from the stored final complex rectangles after serialization, not from the real-only pre-serialization absolute_radius metadata.",
        "The20400working precision and admitted adjoint precision do not imply20400finaldigits; the separately checked source-quality gate here is1e-20000.",
        "The accepted operator audit supplies prior recurrence/tail admission. This review rechecks actual operator/input/output/source hashes without rerunning those recurrences.",
        "Terminal-chain replay and physical initial-source/fresh-invocation admission are owned by separate reviewers and remain separate prerequisites.",
        "Main PR11d published precision cap remains200; no whole-PR11d accuracy or physical admission is asserted."
    ],
    "production_native_HPL_reruns": 0,
    "seconds": time.monotonic()-started,
}
out = HERE / "arithmetic-review.json"
with out.open("x") as stream:
    stream.write(json.dumps(report, indent=2) + "\n")
print(json.dumps({"receipt": str(out), "sha256": sha(out), "maximum_total_l1_radius_upper": report["maximum_total_complex_l1_radius_upper"], "seconds": report["seconds"]}))
