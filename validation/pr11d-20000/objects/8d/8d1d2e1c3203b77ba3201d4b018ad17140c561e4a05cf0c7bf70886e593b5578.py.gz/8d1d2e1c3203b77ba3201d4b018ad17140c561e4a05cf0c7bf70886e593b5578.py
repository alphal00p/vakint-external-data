#!/usr/bin/env python3
"""Substitute exact source recipes before requesting any finite master orders.

Different radial source factors can contain the same primitive with singular
prefactors. The full component/log coefficient is combined algebraically first,
so an apparent per-factor pole cannot force a spurious primitive request.
"""
from fractions import Fraction
import math
from gamma_ast import GammaExpression,Monomial
from gamma_jets import rat
from logjet_map import BoundaryLogJetMap,Rat,valuation

class ExpandedBoundary:
    def __init__(self,plan:BoundaryLogJetMap,factor_expressions,*,max_log_power):
        if type(max_log_power) is not int or max_log_power<0:raise ValueError('Explicit nonnegative logarithmic projection is required')
        self.plan=plan;self.max_log_power=max_log_power;merged={}
        for (component,alpha,beta,keys),prefactor in plan.terms:
            expr=GammaExpression([Monomial(prefactor)],identity='native region prefactor')
            for key in keys:
                if key not in factor_expressions:raise ValueError('Missing exact source recipe '+key)
                expr=expr.multiply(factor_expressions[key])
            for ell in range(max_log_power+1):
                if not beta and ell:continue
                weight=rat(beta**ell/Fraction(math.factorial(ell)))
                key=(component,alpha,ell)
                scaled=expr.scale(weight)
                merged[key]=merged[key].add(scaled) if key in merged else scaled
        self.expressions=merged

    def required_primitive_orders(self,primitives,*,last_epsilon_power=1,check=True):
        required={};details=[]
        for (component,alpha,ell),expression in self.expressions.items():
            own=expression.required_primitive_orders(last_epsilon_power-ell,primitives,check=check)
            for key,high in own.items():
                required[key]=max(required.get(key,high),high)
                details.append({'primitive':key,'highest_epsilon_power':high,'component':component,'integer_z_power':str(alpha),'log_power':ell})
        return required,details

    def evaluate(self,primitives,*,first_epsilon_power=-4,last_epsilon_power=1):
        from flint import arb
        self.required_primitive_orders(primitives,last_epsilon_power=last_epsilon_power)
        out={}
        for component,alpha in self.plan.selectors:
            for ell in range(self.max_log_power+1):
                for p in range(first_epsilon_power,last_epsilon_power+1):out[component,alpha,p,ell]=arb(0)
        for (component,alpha,ell),expression in self.expressions.items():
            through=last_epsilon_power-ell
            # An explicit Gamma expression can start above the projected range.
            # Such absence follows from its exact divisor/primitive support.
            starts=[]
            for r,slopes,keys in expression.terms:
                starts.append(valuation(r)+sum(primitives[k].first_power for k in keys))
            if not starts or min(starts)>through:continue
            jet=expression.factor_jet(through,primitives=primitives)
            for p in range(first_epsilon_power,last_epsilon_power+1):out[component,alpha,p,ell]=jet.coefficient(p-ell)
        return out
