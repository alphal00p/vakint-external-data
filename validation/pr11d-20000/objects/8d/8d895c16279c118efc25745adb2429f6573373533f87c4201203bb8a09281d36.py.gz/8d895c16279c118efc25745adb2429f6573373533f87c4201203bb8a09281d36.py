#!/usr/bin/env python3
"""Exact, bounded replay of normalized connection and generic Frobenius startup."""
import ast
import hashlib
import json
import resource
import time
from functools import lru_cache
from pathlib import Path
from flint import fmpq, fmpq_mat, fmpq_poly

if not __debug__:
    raise RuntimeError("Exact audit requires assertions")
HERE = Path(__file__).resolve().parent
BASE = HERE.parents[2]
MATCH = BASE / "infinity-matching"
SIZE = 252


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Rational:
    def __init__(self, n, d=None):
        self.n = n if isinstance(n, fmpq_poly) else fmpq_poly([n])
        self.d = fmpq_poly([1]) if d is None else d
        assert self.d
        if not self.n:
            self.d = fmpq_poly([1])
            return
        g = self.n.gcd(self.d)
        self.n, self.d = self.n // g, self.d // g
        c = self.d[self.d.degree()]
        self.n, self.d = self.n / c, self.d / c

    def __neg__(self):
        return Rational(-self.n, self.d)

    def __add__(self, other):
        return Rational(self.n * other.d + other.n * self.d, self.d * other.d)

    def __mul__(self, other):
        return Rational(self.n * other.n, self.d * other.d)

    def inverse(self):
        return Rational(self.d, self.n)

    def power(self, n):
        return self.inverse().power(-n) if n < 0 else Rational(self.n ** n, self.d ** n)


def literal_integer(node):
    if isinstance(node, ast.Constant) and type(node.value) is int:
        return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        return -literal_integer(node.operand)
    raise ValueError("Noninteger literal exponent")


def evaluate(node):
    if isinstance(node, ast.Constant) and type(node.value) is int:
        return Rational(node.value)
    if isinstance(node, ast.Name) and node.id == "z":
        return Rational(fmpq_poly([0, 1]))
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        return -evaluate(node.operand)
    if isinstance(node, ast.BinOp):
        a = evaluate(node.left)
        if isinstance(node.op, ast.Pow):
            return a.power(literal_integer(node.right))
        b = evaluate(node.right)
        if isinstance(node.op, ast.Add):
            return a + b
        if isinstance(node.op, ast.Sub):
            return a + -b
        if isinstance(node.op, ast.Mult):
            return a * b
        if isinstance(node.op, ast.Div):
            return a * b.inverse()
    raise ValueError(ast.dump(node))


@lru_cache(maxsize=None)
def parse(text):
    text = text.replace("pr11d_direct_helper::{}::z", "z").replace("^", "**")
    return evaluate(ast.parse(text, mode="eval").body)


def dense(values):
    assert len(values) == SIZE and all(len(row) == SIZE for row in values)
    return fmpq_mat([[fmpq(v) for v in row] for row in values])


def main():
    resource.setrlimit(resource.RLIMIT_AS, (3 * 2**30, 3 * 2**30))
    resource.setrlimit(resource.RLIMIT_CPU, (60, 65))
    started = time.monotonic()
    paths = {
        "normalized_source": BASE / "helper/augmented5.json.normalized.json",
        "polynomial_connection": MATCH / "polynomial-normalized-connection.json",
        "startup": MATCH / "exact-startup-coefficients.json",
        "matching": MATCH / "exact-boundary-matching.json",
        "exporter": MATCH / "export_connection.py",
        "startup_generator": MATCH / "exact_rows.py",
        "auditor": Path(__file__),
    }
    hashes = {name: sha(path) for name, path in paths.items()}
    source = json.loads(paths["normalized_source"].read_text())
    poly = json.loads(paths["polynomial_connection"].read_text())
    seed = json.loads(paths["startup"].read_text())
    matching = json.loads(paths["matching"].read_text())
    assert source["state_dimension"] == poly["dimension"] == seed["dimension"] == matching["dimension"] == SIZE
    assert poly["source_normalized_connection_sha256"] == matching["source_sha256"] == hashes["normalized_source"]
    assert poly["startup_data_sha256"] == hashes["startup"]
    assert poly["matching_data_sha256"] == seed["source_matching_sha256"] == hashes["matching"]
    assert poly["state_ordering"] == "state=42*(epsilon_power+4)+original_component"
    assert poly["epsilon_range"] == [-4, 1]
    assert seed["normalized_power_range"] == matching["normalized_power_range"] == [-8, 0]
    d = [fmpq(v) for v in poly["denominator_coefficients"]]
    D = fmpq_poly(d)
    assert D.degree() == poly["denominator_degree"] == 8 and d[0] == 0 and d[1] != 0
    assert D[8] == 1
    numerator = {}
    matrices = [fmpq_mat(SIZE, SIZE) for _ in range(poly["numerator_degree"] + 1)]
    terms = 0
    for row in poly["entries"]:
        i, j = row["row"], row["column"]
        assert type(i) is int and type(j) is int and 0 <= i < SIZE and 0 <= j < SIZE
        assert (i, j) not in numerator
        p, seen = fmpq_poly(), set()
        for term in row["terms"]:
            power = term["z_power"]
            assert type(power) is int and 0 <= power <= poly["numerator_degree"] and power not in seen
            seen.add(power)
            value = fmpq(int(term["numerator"]), int(term["denominator"]))
            assert value
            p[power] = value
            matrices[power][i, j] = value
            terms += 1
        assert p
        numerator[i, j] = p
    assert len(source["matrix"]) == SIZE
    fractions_checked = 0
    for i, row in enumerate(source["matrix"]):
        assert len(row) == SIZE
        for j, text in enumerate(row):
            value = parse(text)
            assert value.n * D == value.d * numerator.get((i, j), fmpq_poly()), (i, j, "normalized export")
            fractions_checked += 1
    residue = matrices[0] / d[1]
    for i, row in enumerate(source["residue"]):
        assert len(row) == SIZE
        for j, text in enumerate(row):
            value = parse(text)
            assert value.n == value.d * residue[i, j], (i, j, "residue")
    characteristic = residue.charpoly()
    factors = characteristic.factor()[1]
    eigenvalues = {}
    for factor, count in factors:
        assert factor.degree() == 1
        root = -factor[0] / factor[1]
        assert root.denominator == 1
        eigenvalues[int(root)] = int(count)
    assert set(eigenvalues) == set(range(-8, 0))
    assert eigenvalues == {r["root"]: r["width"] for r in matching["residue_blocks"]}
    assert sum(eigenvalues.values()) == SIZE
    # Independently extract the diagonal monomial change of variables.
    weights, scales = [], []
    for i, row in enumerate(source["transformation"]):
        assert len(row) == SIZE
        nonzero = [(j, parse(text)) for j, text in enumerate(row) if text != "0"]
        assert len(nonzero) == 1 and nonzero[0][0] == i
        value = nonzero[0][1]
        nn = [(k, value.n[k]) for k in range(value.n.degree()+1) if value.n[k]]
        dd = [(k, value.d[k]) for k in range(value.d.degree()+1) if value.d[k]]
        assert len(nn) == len(dd) == 1
        weights.append(nn[0][0] - dd[0][0])
        scales.append(nn[0][1] / dd[0][1])
    assert weights == matching["gauge_weights"]
    assert scales == [fmpq(x) for x in matching["gauge_scales"]]
    print("Normalized connection and full residue characteristic polynomial exact PASS", flush=True)
    coefficients, sparse_count = {}, 0
    for row in seed["coefficients"]:
        m, log = row["normalized_z_power"], row["log_power"]
        assert type(m) is int and type(log) is int and -8 <= m <= 0 and 0 <= log <= 8
        assert (m, log) not in coefficients
        C, seen = fmpq_mat(SIZE, SIZE), set()
        for i, j, text in row["entries"]:
            assert type(i) is int and type(j) is int and 0 <= i < SIZE and 0 <= j < SIZE
            assert (i, j) not in seen
            seen.add((i, j))
            value = fmpq(text)
            assert value
            C[i, j] = value
            sparse_count += 1
        assert C
        coefficients[m, log] = C
    zero = fmpq_mat(SIZE, SIZE)
    get = lambda m, log: coefficients.get((m, log), zero)
    residuals, products = 0, 0
    for m in range(-8, 1):
        for log in range(9):
            C = get(m, log)
            residual = (C * m + get(m, log+1) * (log+1)) * d[1]
            # Compare z^m log(z)^log in D(z) J'(z) - N(z) J(z).
            for r, N in enumerate(matrices):
                previous = get(m-r, log)
                if previous and N:
                    residual -= N * previous
                    products += 1
            for r in range(2, len(d)):
                previous_power = m+1-r
                residual += (get(previous_power, log) * previous_power +
                             get(previous_power, log+1) * (log+1)) * d[r]
            assert not residual, (m, log, "exact startup recurrence")
            residuals += 1
        print("Startup power", m, "all nine log equations exact PASS", flush=True)
    assert max(log for m, log in coefficients) == matching["max_exact_log_degree"] == 8
    assert any(log == 8 and C for (m, log), C in coefficients.items())
    # Reconstruct every boundary selector directly from sparse startup, then
    # prove 252-column independence over Q via its stored square inverse.
    def boundary_row(label):
        component = label["component"]
        epsilon = label["epsilon_power"]
        assert 0 <= component < 42 and -4 <= epsilon <= 1
        state = 42 * (epsilon+4) + component
        power = label["integer_z_power"] - weights[state]
        assert -8 <= power <= 0
        C = get(power, label["log_power"])
        return [C[state, j] * scales[state] for j in range(SIZE)]
    boundary_checks = 0
    for labels_key, values_key in [("selected_selectors", "boundary_matrix"),
                                   ("all_boundary_selectors", "all_boundary_matrix")]:
        labels, values = matching[labels_key], matching[values_key]
        assert len(labels) == len(values)
        for label, stored in zip(labels, values):
            assert boundary_row(label) == [fmpq(x) for x in stored]
            boundary_checks += 1
    B = dense(matching["boundary_matrix"])
    Binv = dense(matching["boundary_inverse"])
    identity = fmpq_mat([[int(i == j) for j in range(SIZE)] for i in range(SIZE)])
    assert B * Binv == identity
    determinant = B.det()
    assert determinant and determinant == fmpq(matching["boundary_determinant"])
    for name, path in paths.items():
        assert sha(path) == hashes[name], (name, "changed during audit")
    proof = [
        "D(z) has a simple zero at z=0, so z A(z)=N(z)/(D(z)/z) is analytic and the system is regular singular.",
        "Every coefficient equation for powers -8 through 0 and log degrees 0 through 8 was verified over Q directly in D J' = N J; omitted startup coefficients are zero.",
        "The 252 selected boundary coefficient rows extracted from startup have an exact inverse over Q. Thus the startup contains 252 independent solution columns, not merely a modular rank observation.",
        "The exact characteristic polynomial of R=N(0)/D'(0) has only roots -8 through -1. Therefore n I-R is invertible for every integer n>=1.",
        "For n>=1 the forcing only combines earlier coefficient polynomials in log(z), so its degree is at most 8. Solving (n I-R) C[n,l]=F[n,l]-(l+1) C[n,l+1] downward from l=8 introduces no log degree above 8.",
        "Induction extends all 252 independent columns with degree at most 8 at every subsequent power. Nonzero exact startup coefficients at log degree 8 show this generic bound is attained; no stronger physical-sector cancellation is claimed."
    ]
    report = {
        "schema": "vakint.pr11d.exact-frobenius-preparation-audit.v1",
        "accepted_for_scope": True,
        "method": "Separate restricted univariate rational AST parser, exact denominator-cleared matrix recurrences over Q, exact selector extraction, and exact inverse/characteristic identities; no producer module imported",
        "dimension": SIZE,
        "normalized_fraction_identities_checked": fractions_checked,
        "connection_nonzero_entries": len(numerator),
        "connection_numerator_terms": terms,
        "denominator_degree": D.degree(),
        "denominator_simple_zero_at_origin": True,
        "residue_eigenvalue_multiplicities": {str(k): v for k, v in sorted(eigenvalues.items())},
        "startup_power_range": [-8, 0],
        "startup_nonzero_power_log_blocks": len(coefficients),
        "startup_sparse_coefficients": sparse_count,
        "startup_exact_matrix_equations_checked": residuals,
        "startup_exact_scalar_equations_checked": residuals * SIZE * SIZE,
        "exact_matrix_products_for_recurrence": products,
        "boundary_rows_reconstructed_from_startup": boundary_checks,
        "selected_boundary_exact_inverse_verified": True,
        "selected_boundary_determinant": str(determinant),
        "independent_free_constants": SIZE,
        "generic_all_orders_log_degree_bound": 8,
        "generic_bound_attained_exactly": True,
        "generic_log_bound_proof": proof,
        "modular_observation_used_as_proof": False,
        "physical_boundary_values_verified": False,
        "numerical_transport_or_period_accuracy_claimed": False,
        "artifact_sha256": {name: {"path": str(path), "sha256": hashes[name]} for name, path in paths.items()},
        "seconds": time.monotonic() - started,
        "peak_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
    }
    (HERE / "startup-replay-receipt.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k not in ("artifact_sha256", "generic_log_bound_proof")}, indent=2))


if __name__ == "__main__":
    main()
