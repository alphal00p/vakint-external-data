#!/usr/bin/env python3
"""Run an immutable, explicitly conditional X8 startup with direct invocation pins.

This launcher certifies the numerical IVP enclosure and records its actual
execution. Independent physical source/matching/native-input admission remains
mandatory before the resulting ordinary-point vector is used as physical data.
"""
import argparse,datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
from flint import arb,acb,ctx
if not __debug__:raise RuntimeError('Assertions are required')
HERE=Path(__file__).resolve().parent
BASE=HERE.parents[2]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):return json.loads(Path(path).read_text())
def write(path,data):
    with Path(path).open('x') as stream:json.dump(data,stream,indent=2);stream.write('\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def check_pins(pins):
    for path,digest in pins.items():
        if sha(path)!=digest:raise ValueError('Changed pinned artifact: '+str(path))
def main():
    p=argparse.ArgumentParser()
    p.add_argument('--boundary',type=Path,required=True);p.add_argument('--boundary-sha256',required=True)
    p.add_argument('--constants',type=Path,required=True);p.add_argument('--constants-sha256',required=True)
    p.add_argument('--output-directory',type=Path,required=True)
    p.add_argument('--working-digits',type=int,required=True);p.add_argument('--local-tail-digits',type=int,required=True)
    p.add_argument('--raw-total-digits',type=int,required=True);p.add_argument('--max-order',type=int,default=18000)
    p.add_argument('--check-every',type=int,default=500);p.add_argument('--workers',type=int,default=8)
    a=p.parse_args()
    assert 0<a.raw_total_digits<a.working_digits and 0<a.local_tail_digits<a.working_digits
    assert a.workers in (1,2,4,8) and 0<a.check_every<=a.max_order
    boundary=a.boundary.resolve();constants=a.constants.resolve();out=a.output_directory.resolve()
    out.mkdir(parents=True,exist_ok=False)
    source=HERE/'contracted_v2_scheduled.c';binary=HERE/'contracted-native-v2-scheduled'
    preparer=HERE/'prepare_v2.py';review=HERE/'schedule-review/review.json'
    exact=BASE/'infinity-matching';ordinary=BASE/'jet-transport/polynomial-connection-regular-gauge.json'
    required={str(boundary):a.boundary_sha256,str(constants):a.constants_sha256,
        str(review):'165a577ec48751c78df18e2522ecc60cedcfb076e4d38cb697e6dc7a8496ead6'}
    check_pins(required)
    b,c=load(boundary),load(constants);r=load(review);o=load(ordinary)
    assert r['accepted'] is True and r['candidate_source_sha256']==sha(source) and r['candidate_binary_sha256']==sha(binary)
    assert c['boundary_input_sha256']==sha(boundary)
    assert b['error_quality']==c['error_quality']=='rigorous-bound'
    assert b['normalization']==c['normalization']=='native_raw'
    assert b['require_all_prepared_rows'] is True and c['all_prepared_coefficients_checked'] is True
    assert b['coefficient_count']==len(b['coefficients'])==1587 and len(c['free_constant_balls'])==252
    assert b['matching_sha256']==c['exact_matching_sha256']==sha(exact/'exact-boundary-matching.json')
    assert b['source_receipts']==c['source_receipts']
    for receipt in b['source_receipts']:
        assert receipt['error_quality']=='rigorous-bound' and receipt['normalization']=='native_raw'
        path=receipt.get('source',receipt.get('path'));assert path
        required[str(Path(path).resolve())]=receipt['sha256']
    for path,digest in b['recipe_receipt']['source_sha256'].items():required[str(Path(path).resolve())]=digest
    assert o['source_sha256']=='a9ec06c3a076f3460e84ec3492ae314b29f4cf470dddbe2a5442b502f7181184'
    required[str(Path(o['source']).resolve())]=o['source_sha256']
    for path in [source,binary,preparer,Path(__file__).resolve(),ordinary,
        exact/'polynomial-normalized-connection.json',exact/'exact-startup-coefficients.json',exact/'exact-boundary-matching.json']:
        required[str(path)]=sha(path)
    check_pins(required)
    ctx.dps=a.working_digits+100
    source_values=[arb(value) for value in c['free_constant_balls']]
    assert all(x.is_finite() for x in source_values)
    settings=vars(a).copy();settings={k:str(v) if isinstance(v,Path) else v for k,v in settings.items()}
    write(out/'run-contract.json',{'schema':'vakint.x8.conditional-native-initial-run.v1','settings':settings,
        'source_pins':required,'maximum_constant_radius':max(x.rad() for x in source_values).str(40),
        'physical_source_admission_required':True,'whole_PR11d_accuracy_claimed':False})
    native_input=out/'native.in';native_output=out/'native-output.json';preparation=out/'native.json'
    prepare_command=[sys.executable,str(preparer),'--connection',str(exact/'polynomial-normalized-connection.json'),
        '--startup',str(exact/'exact-startup-coefficients.json'),'--matching',str(exact/'exact-boundary-matching.json'),
        '--matched-constants',str(constants),'--digits',str(a.local_tail_digits),
        '--guard',str(a.working_digits-a.local_tail_digits),'--z-imag=-1/256',
        '--max-order',str(a.max_order),'--check-every',str(a.check_every),'--output',str(native_input)]
    with (out/'prepare.log').open('x') as stream:
        subprocess.run(prepare_command,stdout=stream,stderr=subprocess.STDOUT,check=True,
            env={**os.environ,'OPENBLAS_NUM_THREADS':'1'},cwd=HERE)
    m=load(preparation)
    assert m['dimension']==252 and m['constant_count']==252 and m['log_slots']==9
    assert m['z0']==['0','-1/256'] and m['seed_binding']==sha(constants) and m['input_sha256']==sha(native_input)
    assert m['requested_digits']==a.local_tail_digits and m['error_quality']=='rigorous-bound'
    required[str(native_input)]=sha(native_input);required[str(preparation)]=sha(preparation)
    check_pins(required)
    command=[str(binary),str(native_input),str(native_output)]
    bindings={role+'_path':str(path) for role,path in [('input',native_input),('output',native_output),('source',source),('binary',binary),('wrapper',Path(__file__).resolve())]}
    bindings.update({role+'_sha256':sha(path) for role,path in [('input',native_input),('source',source),('binary',binary),('wrapper',Path(__file__).resolve())]})
    env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':str(a.workers)}
    start=now();tick=time.monotonic()
    with (out/'native.log').open('x') as stream:
        child=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,env=env,cwd=out)
        write(out/'invocation-start.json',{'schema':'vakint.pr11d.direct-native-invocation-start.v1',
            **bindings,'command':command,'requested_workers':a.workers,'started_at':start,
            'pid':child.pid,'launcher_pid':os.getpid(),'controlled_environment':{'OMP_NUM_THREADS':str(a.workers),'OPENBLAS_NUM_THREADS':'1'},
            'source_pins':required})
        code=child.wait()
    check_pins(required)
    j=load(native_output) if native_output.exists() else {}
    invocation={'schema':'vakint.pr11d.direct-native-invocation.v1',**bindings,
        'output_sha256':sha(native_output) if native_output.exists() else None,
        'command':command,'returncode':code,'requested_workers':a.workers,
        'actual_workers':j.get('actual_workers'),'started_at':start,'finished_at':now(),
        'wall_seconds':time.monotonic()-tick,'start_receipt_sha256':sha(out/'invocation-start.json'),
        'input_source_binary_wrapper_unchanged_after_invocation':True,'source_pins':required}
    invocation_path=out/'native-invocation.json';write(invocation_path,invocation)
    if code!=0:raise RuntimeError('Native local-tail computation failed; frozen invocation receipt retained')
    assert j['dimension']==252 and j['local_tail_certified'] is True and j['working_bits']==m['bits']
    assert j['requested_workers']==j['configured_workers']==j['actual_workers']==a.workers
    assert j['full_precision_startup_total_certificate_and_output'] is True
    assert j['schedule_factorization_verified'] is True and j['coefficient_precision_slope_bits_per_order']==4
    assert j['schedule_radius_ratio_squared']=='65536/225'
    maxima={}
    for field in ['normalized_J_values','original_Y_values']:
        values=[acb(arb(re),arb(im)) for re,im in j[field]]
        assert len(values)==252 and all(x.is_finite() for x in values)
        maxima[field]=max(x.real.rad()+x.imag.rad() for x in values)
    threshold=arb(10)**(-a.raw_total_digits)
    width_passed=bool(maxima['original_Y_values']<threshold)
    write(out/'numerical-gate.json',{'schema':'vakint.x8.conditional-initial-numerical-gate.v1',
        'local_tail_certified':True,'raw_total_digits_target':a.raw_total_digits,'raw_total_width_gate_passed':width_passed,
        'maximum_total_radii':{k:v.str(40) for k,v in maxima.items()},'native_output_sha256':sha(native_output),
        'physical_source_admission_required':True,'whole_PR11d_accuracy_claimed':False})
    if not width_passed:raise RuntimeError('Actual total-radius gate failed; no initial handoff written')
    result={'schema':'vakint.x8.conditional-guarded-ordinary-boundary.v1','basis':'original_raw_epsilon_jets',
        'dimension':42,'jets':6,'epsilon_min_power':-4,'epsilon_max_power':1,'eta_center':['0','256'],
        'normalization':'native_raw','error_quality':'rigorous-bound','source_equation_sha256':o['source_sha256'],
        'original_source_equation_path':o['source'],'original_source_equation_sha256':o['source_sha256'],
        'ordinary_polynomial_connection_path':str(ordinary),'ordinary_polynomial_connection_sha256':sha(ordinary),
        'source_boundary_path':str(boundary),'source_boundary_sha256':sha(boundary),
        'source_constants_path':str(constants),'source_constants_sha256':sha(constants),
        'matching_sha256':b['matching_sha256'],'inventory_sha256':b['inventory_sha256'],
        'source_receipts':b['source_receipts'],'recipe_receipt':b['recipe_receipt'],
        'native_input_path':str(native_input),'native_input_sha256':sha(native_input),
        'native_preparation_path':str(preparation),'native_preparation_sha256':sha(preparation),
        'native_output_path':str(native_output),'native_output_sha256':sha(native_output),
        'native_source_sha256':sha(source),'native_binary_sha256':sha(binary),'validator_sha256':sha(__file__),
        'native_invocation_receipt_path':str(invocation_path),'native_invocation_receipt_sha256':sha(invocation_path),
        'local_tail_certified':True,'raw_total_digits_target':a.raw_total_digits,'raw_total_width_gate_passed':True,
        'maximum_total_radius':{k:v.str(40) for k,v in maxima.items()},'values':j['original_Y_values'],
        'order':j['order'],'seconds':j['seconds'],'physical_source_admission_required':True,
        'whole_PR11d_accuracy_claimed':False,
        'qualification':'Conditional numerical IVP enclosure. A separate independently blessed physical-initial admission must close primitive sources, matching and actual native-input assembly before physical use.'}
    initial=out/'conditional-initial.json';write(initial,result)
    print(json.dumps({'conditional_initial':str(initial),'sha256':sha(initial),
        'maximum_total_radius':result['maximum_total_radius'],'source_admission_required':True},indent=2),flush=True)
if __name__=='__main__':main()
