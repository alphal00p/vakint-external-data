#!/usr/bin/env python3
"""Exact application checks for the physical PR9 selected22 pole bound.

No producer imports or HPL, native, preparer, or transport evaluations.
The general scalar massive UV-forest theorem is inherited from its separately
accepted scientific review; the numerator exception is eliminated explicitly.
"""
from fractions import Fraction as Q
from itertools import combinations, permutations
from pathlib import Path
import hashlib
import json
from flint import fmpq_mat

HERE = Path(__file__).resolve().parent
PR11 = HERE.parents[4]
BESSEL = PR11.parent/'bessel'
EXT = Path('/shared/codex-2/vacuum_masters/MASTERS/4L/artifacts')
PINS = {}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path, digest):
    path = Path(path).resolve()
    assert sha(path) == digest, str(path)
    PINS[str(path)] = digest
    return json.loads(path.read_text())


def rows(matrix, height, width):
    return [[str(matrix[i,j]) for j in range(width)] for i in range(height)]


review = load(PR11/'helper/physical-poles-review/review.json',
              '22f69516f6f2e0a8278b9a4913dfd85a74b0e82b5c7e8507d0b8655c13d8ef31')
raw_certificate = load(BESSEL/'raw-pole-support/certificate.json',
                       'd5289b81989b14398ff3d8d65edbcbbd198f4bbab4811de9fd8b255f72b45dcd')
assert review['accepted'] is True
assert review['raw_pole_certificate_sha256'] == sha(BESSEL/'raw-pole-support/certificate.json')
raw42_path = EXT/'X8-Kira-derivative-closure-v1/prepared-system.json'
raw42 = load(raw42_path, 'a9ec06c3a076f3460e84ec3492ae314b29f4cf470dddbe2a5442b502f7181184')
raw22 = load(PR11/'ancestor-flows/pr9-22.json',
             '88290b3fe7015e350046044c3a93236700eb180e8141af5781fdfd5dfbfd9c88')
proof = load(EXT/'PR9-generic-epsilon-native-verification-v1/v2-proof.json',
             'bf46ece2c03d8df288ee2a63dc2be0e43fcacee01c37d509f1215439cc8f24cd')
original = load(EXT/'connected-PR9-PR9d-preparation-v3/closed-subsystems-v1/PR9-system.json',
                '8695f7847db0c3282d78ea2c5988c562b582d36ebaf798e45db8932fca13a140')
serialized = load(EXT/'PR9-generic-epsilon-native-verification-v1/exact-source-v3.json',
                  '1473c3c86eddd0037bf77034c12b713d45d7fefd3cde0e59e27a62fc9c98d2e2')
region = load(PR11/'ancestor-flows/pr9-22-region-source.json',
              'b7cedbc9a94359230fd3c04f5c0c76c260cc71a1619ababd0cef55eac65744f3')
source_review = load(PR11/'helper/pr9-api-boundary-review/pr9-source-review-receipt.json',
                     '2190357dd5232fe4d44b056ac555a711136f0f42af31ce3a30ce613e05b9282e')
box_review = load(PR11/'helper/pr9-proto1000-init-review/source-box-review.json',
                  '3a024807e6b37ee7b0aede682b31d8daa3f134da223c0cc90b7b8089c186066e')
assert raw22['basis'] == proof['selected_old_basis'] == region['basis']
assert raw22['differential_matrix'] == proof['selected_old_differential_matrix'] == region['differential_matrix']
assert original['basis'] == proof['old_basis']
assert [original['basis'][i] for i in proof['selected_old_indices']] == raw22['basis']
assert original['deformed_propagators'] == region['deformed_propagators'] == [2]
assert proof['deformed_slot_zero_based'] == 2
assert original['dimension'] == region['dimension'] == proof['dimension'] == '4-2*epsilon'
family = original['family']
assert family == raw42['family'] == region['family']
family_id = '693719b1bc3d2f1d4d32c9312df66ced667a542591a2ada6f6498844fc5d0de1'
assert family['sha256'] == original['source_family_sha256'] == proof['source_family_sha256'] == family_id
assert hashlib.sha256(family['fingerprint'].encode()).hexdigest() == family_id
assert family['external_momenta'] == [] and len(family['loop_momenta']) == 4
assert family['power_shifts'] == ['0']*10 and family['coordinate_index_base'] == 0
assert serialized['propagators_mathematica'][2] == '-1 - eta + k3^2'
assert serialized['propagators_mathematica'][9] == '-1 + k3^2 + 2*k3*k4 + k4^2'
assert original['normalization_conversion_from_rustflow'] == 'exp(4*EulerGamma*epsilon)'
vectors = []
for denominator in family['denominators']:
    assert Q(denominator['constant']) == -1
    gram = [[Q(0)]*4 for _ in range(4)]
    for coordinate, value in zip(family['coordinates'], denominator['coefficients']):
        assert coordinate['kind'] == 'loop_loop'
        i, j = coordinate['left'], coordinate['right']
        gram[i][j] = gram[j][i] = Q(value) if i == j else Q(value)/2
    assert fmpq_mat([[str(v) for v in row] for row in gram]).rank() == 1
    pivot = next(i for i in range(4) if gram[i][i])
    assert gram[pivot][pivot] == 1
    vector = gram[pivot]
    assert gram == [[a*b for b in vector] for a in vector]
    assert all(v.denominator == 1 for v in vector)
    vectors.append([int(v) for v in vector])
assert vectors == raw_certificate['graph_and_domain_checks']['quadratic_vectors']

# Actual denominator graph: slots 2..8. The numerator slot9 is excluded.
slots = list(range(2,9))
B = fmpq_mat([[0,1,-1,0,1,0,0], [0,-1,0,1,0,-1,0],
              [-1,0,0,-1,-1,0,1], [1,0,1,0,0,1,-1]])
V = fmpq_mat([vectors[i] for i in slots])
assert B*V == fmpq_mat(4,4) and B.rank() == 3 and V.rank() == 4
edges = []
for j in range(7):
    col = [int(B[i,j]) for i in range(4)]
    assert sorted(col) == [-1,0,0,1]
    edges.append([col.index(-1), col.index(1)])
bases = []
for chosen in combinations(range(7),4):
    det = fmpq_mat([vectors[slots[i]] for i in chosen]).det()
    if det:
        assert abs(det) == 1
        bases.append({'slots': [slots[i] for i in chosen], 'determinant': str(det)})
assert len(raw22['basis']) == 22
exceptions = []
graphs = []
for index, powers in enumerate(raw22['basis']):
    assert len(powers) == 10 and all(type(p) is int for p in powers)
    assert powers[0] == powers[1] == 0
    assert all(powers[i] >= 0 for i in slots)
    if powers[9]:
        exceptions.append(index)
        assert index == 7 and powers[9] == -1
    active = [i for i,s in enumerate(slots) if powers[s] > 0]
    absent = [i for i in range(7) if i not in active]
    assert fmpq_mat([vectors[slots[i]] for i in active]).rank() == 4
    if absent:
        assert fmpq_mat([[B[i,j] for j in absent] for i in range(4)]).rank() == len(absent)
    classes = [{i} for i in range(4)]
    for j in absent:
        u,v = edges[j]
        a = next(c for c in classes if u in c)
        b = next(c for c in classes if v in c)
        assert a is not b
        classes = [c for c in classes if c is not a and c is not b] + [a|b]
    owner = {v:i for i,c in enumerate(classes) for v in c}
    contracted = [[0]*len(active) for _ in classes]
    for k,j in enumerate(active):
        u,v = edges[j]
        contracted[owner[u]][k] -= 1
        contracted[owner[v]][k] += 1
    rank = fmpq_mat(contracted).rank()
    assert rank == len(classes)-1 and len(active)-rank == 4
    graphs.append({'component': index, 'powers': powers, 'active_denominator_slots': [slots[j] for j in active],
                   'absent_edges_form_forest': True, 'contracted_vertices': len(classes),
                   'contracted_incidence_rank': rank, 'independent_loops': 4,
                   'positive_scalar_powers': index != 7})
assert exceptions == [7]

# Numerator exception: x=(a,e,c,d)=(q3,-q4,q1-q3,q2-q3).
# Equal-mass r=(e,c,d,k5), k5=-(a+e+c+d). S4 fixes a exactly.
U = fmpq_mat([[0,0,1,0], [0,0,0,-1], [1,0,-1,0], [0,1,-1,0]])
assert abs(U.det()) == 1
a = [1,0,0,0]
r = [[0,1,0,0], [0,0,1,0], [0,0,0,1], [-1,-1,-1,-1]]
assert [sum(v[i] for v in r) for i in range(4)] == [-x for x in a]
maps = []
for permutation in permutations(range(4)):
    T = fmpq_mat([a] + [r[i] for i in permutation[:3]])
    assert abs(T.det()) == 1
    assert fmpq_mat([a])*T == fmpq_mat([a])
    assert fmpq_mat(r)*T == fmpq_mat([r[i] for i in permutation])
    original_map = U.inv()*T*U
    assert abs(original_map.det()) == 1
    assert all(Q(str(original_map[i,j])).denominator == 1 for i in range(4) for j in range(4))
    transformed = fmpq_mat([vectors[i] for i in [2,3,4,5,8]])*original_map
    assert rows(transformed,5,4)[0] == list(map(str,vectors[2]))
    equal_mass_squares = []
    for i in range(1,5):
        w = [Q(str(transformed[i,j])) for j in range(4)]
        equal_mass_squares.append(tuple(w[j]*w[k] for j in range(4) for k in range(4)))
    expected_squares = [tuple(vectors[s][j]*vectors[s][k] for j in range(4) for k in range(4)) for s in [3,4,5,8]]
    assert sorted(equal_mass_squares) == sorted(expected_squares)
    maps.append({'permutation': list(permutation), 'x_map': rows(T,4,4),
                 'q_map': rows(original_map,4,4), 'determinant': str(original_map.det())})
def outer(v):
    return [[Q(x)*Q(y) for y in v] for x in v]
lhs = [[Q(0)]*4 for _ in range(4)]
rhs = [[Q(3,2)*z for z in row] for row in outer(a)]
for v in r:
    difference = [x-y for x,y in zip(a,v)]
    for i in range(4):
        for j in range(4):
            lhs[i][j] += Q(1,4)*outer(difference)[i][j]
            rhs[i][j] += Q(1,4)*outer(v)[i][j]
assert lhs == rhs
pinches = []
for omitted in [2,3,8]:
    remaining = [i for i in [2,3,4,5,8] if i != omitted]
    det = fmpq_mat([vectors[i] for i in remaining]).det()
    assert abs(det) == 1
    pinches.append({'omitted_slot': omitted, 'remaining_slots': remaining,
                    'momentum_determinant': str(det),
                    'mass_squares': ['1+eta' if i == 2 else '1' for i in remaining],
                    'four_independent_tadpoles': True})
assert raw22['basis'][1] == [0,0,0,1,1,1,0,0,1,0]
assert raw22['basis'][8] == [0,0,1,1,1,1,0,0,1,0]
pinch8_powers = [0,0,1,1,1,1,0,0,0,0]
assert proof['retained_AMFlow_basis'][0] == pinch8_powers
row = proof['retained27_from_final22'][0]
assert row == ['0','0','0','-3/2','(1+symbolica_amflow::{}::eta)*-3/2','1'] + ['0']*16
# retained27_from_final22 uses Kira basis order, not selected-old order.
assert proof['generic_Kira_basis'][3] == raw22['basis'][1]
assert proof['generic_Kira_basis'][4] == raw22['basis'][8]
assert proof['generic_Kira_basis'][5] == raw22['basis'][7]

PINS[str(Path(__file__).resolve())] = sha(__file__)
for path,digest in PINS.items():
    assert sha(path) == digest, path
result = {
 'schema': 'vakint.PR9-selected22-independent-physical-pole-application.v1',
 'accepted': True,
 'raw_22_basis_pole_bound_verified': True,
 'raw_source_sha256': sha(PR11/'ancestor-flows/pr9-22.json'),
 'conclusion': 'Every physical selected22 raw PR9 integral is O(epsilon^-4) for D=4-2*epsilon on Re(eta)>-1, uniformly on compact mass-domain subsets.',
 'basis_size': 22, 'positive_scalar_rows': 21, 'numerator_exception_components': [7],
 'source_bindings': {'raw22_sha256': sha(PR11/'ancestor-flows/pr9-22.json'),
                     'generic_mapping_sha256': sha(EXT/'PR9-generic-epsilon-native-verification-v1/v2-proof.json'),
                     'original_family_source_sha256': sha(EXT/'connected-PR9-PR9d-preparation-v3/closed-subsystems-v1/PR9-system.json'),
                     'family_id': family_id, 'deformed_slot_zero_based': 2,
                     'mass_convention': 'Minkowski D2=q3^2-1-eta; all other denominator masses squared1. Numerator D9=(q3+q4)^2-1.'},
 'scalar_graph': {'active_family_slots': slots, 'momentum_vectors': [vectors[i] for i in slots],
                  'incidence': rows(B,4,7), 'edge_endpoints': edges, 'rank': 3,
                  'vertices': 4, 'edges': 7, 'loops': 4, 'unimodular_U_bases': bases},
 'basis_graph_checks': graphs,
 'numerator_reduction': {
  'component': 7, 'coordinate_change': rows(U,4,4), 'coordinate_determinant': str(U.det()),
  'S4_exact_unimodular_maps': maps,
  'integrated_identity': 'I7 = (3/2)*pinch(slot2) + pinch(slot3) + (3/2)*(1+eta)*I8',
  'equivalent_known_scalar_row': 'pinch(slot2)=I1; pinch(slot3)=pinch(slot8) by S4; the latter is retained_AMFlow_basis[0].',
  'averaging_proof': 'With a fixed and r=(e,c,d,k5), sum(r)=-a. S4 symmetry gives integral(a.e)=-integral(a^2)/4 and equal integrals of each r_i^2. Thus integral((a-e)^2-1)=integral((3/2)*a^2+e^2-1). Substitute a^2=D2+(1+eta), e^2=D3+1 and cancel denominator factors.',
  'native_mapping_corroboration': 'Pinned retained27_from_final22[0] independently agrees with the same identity in generic_Kira_basis order.',
  'pinched_products': pinches,
  'epsilon_singular_coefficients_introduced': False},
 'proof': [
  'The separately accepted physical-poles-review supplies the scalar fully massive four-loop UV-forest theorem. This application rechecks its graph, positive-power and mass-domain hypotheses for the actual selected22 denominator supports; it does not pretend that the old raw42 enumeration covered these22 rows.',
  'All21 scalar rows have only nonnegative integer powers, with positive active propagator powers. Every absent-edge set is a forest, every quotient is connected, and every active momentum matrix has rank4. The quotient cycle count is4 in every row. Dots are mass derivatives with constant factorial normalization and do not introduce inverse epsilon factors.',
  'On Re(eta)>-1, Re(sum alpha*m^2) is at least min(1,1+Re(eta))*sum alpha. Positive mass gap suppresses large Schwinger parameters, hence no soft/IR pole is added. The reviewed UV-forest theorem gives at most four simple dimensional scale poles, including the overall scale among the four.',
  'The only numerator row is reduced exactly using24 integer unimodular momentum permutations preserving the deformed momentum and permuting four equal unit-mass lines. The identity holds in a common convergence domain and then by meromorphic dimensional continuation. No tensor inverse or dimension-dependent denominator occurs.',
  'Each pinch is a product of four independent one-loop massive tadpoles, certified by a unit momentum determinant. Each tadpole is proportional to Gamma(epsilon-1) times a holomorphic nonzero mass power, so each product is O(epsilon^-4). The remaining scalar I8 already satisfies the scalar theorem. The polynomial coefficient1+eta preserves the bound.',
  'The authenticated native/FMFT conversion exp(4*EulerGamma*epsilon) is entire and nonzero near epsilon0, and therefore preserves this Laurent lower bound.'
 ],
 'existing_source_review_scope': 'Receipts2190357 and3a024807 admit source assembly/boxes and selected prefix data. They do not themselves enumerate this physical22 all-orders pole proof; the present explicit application supplies that bridge.',
 'conditions_and_limits': ['The trusted input is the already independently reviewed scalar massive UV-forest theorem and authenticated physical family/normalization. This is not a new proof of that general theorem.',
                           'The bound concerns complete physical integrals, not individual large-eta region factors, which may have deeper poles.',
                           'No numerical period values, source precision, transport enclosure, endpoint accuracy, or whole-PR11d precision is asserted.'],
 'exact_counts': {'rank_one_unit_mass_quadratics': 10, 'selected_basis_source_rows': 22,
                  'contracted_denominator_graphs': 22, 'positive_scalar_rows': 21,
                  'S4_unimodular_permutations': 24, 'pinched_tadpole_products': 3,
                  'source_and_checker_hashes': len(PINS)},
 'source_and_checker_sha256': PINS,
 'producer_files_modified': False, 'native_preparer_HPL_calls': 0,
 'whole_period_accuracy_claimed': False,
}
output = HERE/'review.json'
with output.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'accepted': True, 'counts': result['exact_counts'], 'review_sha256': sha(output)}))
