#!/usr/bin/env python3
"""Exercise actual A49 composition guards with cached saved-step audit results.

The exact per-step arithmetic is separately replayed on all saved steps. These
fixtures alter in-memory objects only and test the highlevel composition code;
they neither edit producer artifacts nor execute any numerical engine.
"""
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import sys
from pathlib import Path
from types import SimpleNamespace

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BASE = HERE.parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


def main():
    v = module('independent_A49_highlevel', BASE / 'replay.py')
    c = module('independent_A49_common', v.COMMON)
    saved_path = BASE / 'chain-data-review-v1.json'
    saved = c.load(saved_path)
    config_path = BASE / 'lineage-contract.json'
    config = c.load(config_path)
    source_snapshot = {str(p): sha(p) for p in [BASE / 'replay.py', config_path, v.COMMON]}
    for graph in ('source_pins', 'checker_implementation_sha256'):
        for p, h in config[graph].items():
            assert sha(p) == h, p
            source_snapshot[p] = h
    # All frozen numerical payloads remain actual files and are hashed once.
    numerical_snapshot = {}
    for p, h in saved['artifact_sha256'].items():
        assert sha(p) == h, p
        numerical_snapshot[p] = h
    hash_cache = {**source_snapshot, **numerical_snapshot}
    loaded = {}
    current = {'mutation': None, 'check_mutation': None}
    directories = [Path(s['directory']) for s in config['segments']]
    first = directories[0]
    last = directories[3]
    data_rows = {(r['segment_index'], r['index']): r for r in saved['steps']}

    def cached_sha(path):
        p = str(Path(path).resolve())
        if p not in hash_cache:
            hash_cache[p] = sha(p)
        return hash_cache[p]

    def cached_load(path):
        p = Path(path).resolve()
        if p not in loaded:
            data = c.load(p)
            if p.name.endswith('-native.json'):
                data = {k: value for k, value in data.items()
                        if k in ('order', 'seconds', 'tail_upper_enclosure',
                                 'openmp_requested_threads', 'openmp_actual_threads', 'openmp_thread_cap')}
            loaded[p] = data
        out = copy.deepcopy(loaded[p])
        if current['mutation']:
            current['mutation'](p, out)
        return out

    def pin(path, digest, pins):
        path = Path(path).resolve()
        c.require(type(digest) is str and len(digest) == 64 and cached_sha(path) == digest,
                  'Cached authenticated source digest differs ' + str(path))
        pins[str(path)] = digest
        return path

    reader = SimpleNamespace(load=cached_load, require=c.require, pin=pin, sha=cached_sha)

    def check_step(ip, mp, previous, poly, rpf, native, following, contract):
        segment = directories.index(Path(ip).parent)
        index = int(Path(ip).stem.split('-')[1])
        row = copy.deepcopy(data_rows[segment, index]['exact_step_audit'])
        if current['check_mutation']:
            current['check_mutation'](segment, index, row)
        return row

    checker = SimpleNamespace(StepContract=lambda **kw: SimpleNamespace(**kw),
                              check_raw_to_polynomial=lambda *a: saved['raw_to_regular_connection_check'],
                              check_step=check_step)
    original_module = v.module
    v.module = lambda name, path: reader if name == 'production_A_strict_reader' else checker
    v.sha = cached_sha
    cases = []

    def run(name, mutate=None, check_mutate=None, should_pass=False):
        current['mutation'], current['check_mutation'] = mutate, check_mutate
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                result = v.replay()
        except (ValueError, KeyError, TypeError, AssertionError) as e:
            if should_pass:
                raise
            cases.append({'case': name, 'rejected': True, 'diagnostic': str(e)})
        else:
            assert should_pass, 'Corruption passed: ' + name
            assert result['completed_step_count'] == 49
            assert result['actual_eight_worker_steps_with_requested_and_actual_metadata'] == 44
            cases.append({'case': name, 'accepted': True})
        current['mutation'], current['check_mutation'] = None, None

    def edit(target, key, value):
        target = Path(target).resolve()
        def change(p, data):
            if p == target:
                data[key] = value
        return change

    run('positive_cached_highlevel', should_pass=True)
    controls = [
        ('estimated_initial', config['initial_path'], 'error_quality', 'validated-digits-estimate'),
        ('wrong_initial_dimension', config['initial_path'], 'dimension', 21),
        ('wrong_first_input', first / 'run-binding.json', 'initial_sha256', '0' * 64),
        ('wrong_continuation_input', directories[1] / 'run-binding.json', 'initial_sha256', '0' * 64),
        ('wrong_driver', directories[2] / 'run-binding.json', 'driver_sha256', '0' * 64),
        ('wrong_preparer', first / 'run-binding.json', 'preparer_sha256', '0' * 64),
        ('wrong_target_digits', first / 'run-binding.json', 'local_target_digits', 1000),
        ('wrong_point', first / 'step-000.json', 'center', ['0', '255']),
        ('wrong_scale_source', first / 'step-000.json', 'scale_matching_sha256', '0' * 64),
        ('wrong_expected_steps', first / 'progress.json', 'expected_steps', 47),
        ('wrong_progress_tail', first / 'progress.json', 'last_boundary_sha256', '0' * 64),
        ('wrong_seam_boundary', first / 'optimization-continuation.json', 'last_boundary_sha256', '0' * 64),
        ('wrong_seam_directory', first / 'optimization-continuation.json', 'new_continuation_directory', str(first)),
        ('wrong_historical_actual_count', directories[2] / 'actual-worker-continuation.json', 'observed_actual_workers_previous_base_kernel', 8),
        ('wrong_final_hash', last / 'complete.json', 'final_boundary_sha256', '0' * 64),
        ('false_final_width_gate', last / 'complete.json', 'all_final_component_radii_meet_target', False),
        ('wrong_final_radius', last / 'complete.json', 'maximum_component_radius', '0'),
        ('wrong_native_time_total', last / 'complete.json', 'native_seconds', -1),
        ('wrong_actual_eight_workers', last / 'step-000-native.json', 'openmp_actual_threads', 4),
        ('wrong_requested_eight_workers', last / 'step-000-native.json', 'openmp_requested_threads', 4),
        ('wrong_worker_cap', last / 'step-000-native.json', 'openmp_thread_cap', 4),
    ]
    for name, target, key, value in controls:
        run(name, edit(target, key, value))
    for name, segment, key, value in [
        ('missing_full_input_containment', 0, 'input_full_box_containments', 131),
        ('missing_full_output_containment', 0, 'output_full_box_containments', 131),
        ('wrong_original_serialization', 0, 'original_outward_driver_serialization_byte_identical', False),
        ('wrong_mask_profile', 1, 'mask_metadata_checked', False),
        ('wrong_row_profile', 1, 'row_aggregation_checked', False),
        ('wrong_schedule_profile', 2, 'precision_schedule_metadata_checked', False),
    ]:
        def change(seg, index, row, wanted=segment, key=key, value=value):
            if seg == wanted and index == 0:
                row[key] = value
        run(name, check_mutate=change)

    for name, path in [('existing_output', BASE / 'replay.py'),
                       ('outside_output', BASE.parent / 'forbidden.json'),
                       ('missing_output_parent', HERE / 'missing' / 'receipt.json')]:
        try:
            v.fresh_output(path)
        except ValueError as e:
            cases.append({'case': name, 'rejected': True, 'diagnostic': str(e)})
        else:
            raise AssertionError(name)
    for p, h in {**source_snapshot, **numerical_snapshot}.items():
        assert sha(p) == h, 'Producer artifact changed during guard fixtures: ' + p
    report = {'schema': 'vakint.production-A-highlevel-guard-rejections.v1',
              'scope': 'Actual highlevel composition guards with cached previously successful exact-step subreceipts. Corruptions exist only in memory; no source bytes or saved intervals changed.',
              'implementation_sha256': source_snapshot,
              'numerical_artifact_hashes_verified_before_and_after': len(numerical_snapshot),
              'cases': cases, 'rejection_count': sum(r.get('rejected', False) for r in cases),
              'positive_cached_composition_passed': True,
              'native_preparer_HPL_or_matching_calls': 0,
              'producer_files_modified': False}
    out = HERE / (sys.argv[1] if len(sys.argv) > 1 else 'highlevel-guard-results.json')
    assert out.resolve().parent == HERE and not out.exists()
    with out.open('x') as stream:
        stream.write(json.dumps(report, indent=2) + '\n')
    print(str(out))
    print(sha(out))
    print('rejections', report['rejection_count'])


if __name__ == '__main__':
    main()
