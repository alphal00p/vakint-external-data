"""Independent, standard-library-only exact audit; never imports check_guards.

All output is confined to this review directory.  Unlike the producer's gcd
test, the root certificate below applies Sturm directly to |q(i*y)|**2.
"""
from pathlib import Path
from fractions import Fraction as Q
import ast
import collections
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
SOURCE = Path('/shared/codex-2/vacuum_masters/MASTERS/4L/artifacts/X8-Kira-derivative-closure-v1/prepared-system.json')
SOURCE_SHA = 'a9ec06c3a076f3460e84ec3492ae314b29f4cf470dddbe2a5442b502f7181184'


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def clean(p):
    return {m: c for m, c in p.items() if c}


def add(a, b):
    c = dict(a)
    for m, coefficient in b.items():
        c[m] = c.get(m, Q(0)) + coefficient
    return clean(c)


def multiply(a, b):
    c = {}
    for (j, k), ac in a.items():
        for (l, m), bc in b.items():
            pair = (j + l, k + m)
            c[pair] = c.get(pair, Q(0)) + ac * bc
    return clean(c)


def power(a, n):
    require(type(n) is int and 0 <= n <= 64, 'Not a bounded polynomial exponent')
    result = {(0, 0): Q(1)}
    for _ in range(n):
        result = multiply(result, a)
    return result


def parse_polynomial(text):
    text = text.replace('masters_4l::{}::epsilon', 'e').replace('symbolica_amflow::{}::eta', 'x').replace('^', '**')

    def visit(node):
        if isinstance(node, ast.Constant) and type(node.value) is int:
            return clean({(0, 0): Q(node.value)})
        if isinstance(node, ast.Name) and node.id in ('e', 'x'):
            return {(1, 0) if node.id == 'e' else (0, 1): Q(1)}
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
            return {m: -c for m, c in visit(node.operand).items()}
        if isinstance(node, ast.BinOp):
            if isinstance(node.op, ast.Pow):
                return power(visit(node.left), ast.literal_eval(node.right))
            a, b = visit(node.left), visit(node.right)
            if isinstance(node.op, ast.Add):
                return add(a, b)
            if isinstance(node.op, ast.Sub):
                return add(a, {m: -c for m, c in b.items()})
            if isinstance(node.op, ast.Mult):
                return multiply(a, b)
        raise RuntimeError('Current source guard is not a supported polynomial: ' + ast.dump(node))

    return visit(ast.parse(text, mode='eval').body)


def trim(p):
    p = list(p)
    while p and not p[-1]:
        p.pop()
    return p


def value(p, x):
    answer = Q(0)
    for c in reversed(p):
        answer = answer * x + c
    return answer


def plus(a, b):
    result = [Q(0)] * max(len(a), len(b))
    for i, c in enumerate(a):
        result[i] += c
    for i, c in enumerate(b):
        result[i] += c
    return trim(result)


def product(a, b):
    if not a or not b:
        return []
    result = [Q(0)] * (len(a) + len(b) - 1)
    for i, ac in enumerate(a):
        for j, bc in enumerate(b):
            result[i + j] += ac * bc
    return trim(result)


def remainder(a, b):
    require(bool(b), 'Polynomial division by zero')
    a = trim(a)
    while len(a) >= len(b):
        factor, offset = a[-1] / b[-1], len(a) - len(b)
        for i, coefficient in enumerate(b):
            a[offset + i] -= factor * coefficient
        a = trim(a)
    return a


def monic(p):
    return [c / p[-1] for c in p] if p else []


def gcd(a, b):
    while b:
        a, b = b, remainder(a, b)
    return monic(a)


def signs_at(chain, x):
    values = [value(p, x) for p in chain]
    return [1 if v > 0 else -1 for v in values if v]


def variations(signs):
    return sum(a != b for a, b in zip(signs, signs[1:]))


def root_count(p, left, right):
    require(bool(p) and value(p, left) != 0 and value(p, right) != 0, 'Zero polynomial or an endpoint zero')
    if len(p) == 1:
        return {'left_variations': 0, 'right_variations': 0, 'roots': 0, 'sturm_degrees': [0]}
    derivative = [i * p[i] for i in range(1, len(p))]
    chain = [p, derivative]
    while True:
        rem = [-c for c in remainder(chain[-2], chain[-1])]
        if not rem:
            break
        require(len(rem) < len(chain[-1]), 'Sturm degree did not decrease')
        chain.append(rem)
    vl = variations(signs_at(chain, left))
    vr = variations(signs_at(chain, right))
    return {'left_variations': vl, 'right_variations': vr, 'roots': vl - vr, 'sturm_degrees': [len(t) - 1 for t in chain]}


def tests():
    require(root_count([Q(-1), Q(0), Q(1)], Q(-2), Q(2))['roots'] == 2, 'Two-root self-test')
    require(root_count([Q(1), Q(-2), Q(1)], Q(0), Q(2))['roots'] == 1, 'Multiple-root self-test')
    require(root_count([Q(1), Q(0), Q(1)], Q(-2), Q(2))['roots'] == 0, 'Complex-root self-test')
    try:
        root_count([Q(-1), Q(1)], Q(1), Q(2))
    except RuntimeError:
        pass
    else:
        raise RuntimeError('Endpoint root was accepted')


tests()
source = json.loads(SOURCE.read_text())
input_data = json.loads((ROOT / 'input.json').read_text())
certificate = json.loads((ROOT / 'guard-validation.json').read_text())
connection_path = ROOT.parent / 'jet-transport/polynomial-connection.json'
connection = json.loads(connection_path.read_text())
producer_script = (ROOT / 'check_guards.py').read_text()
require("if not __debug__:raise RuntimeError('Acceptance guard validation requires assertions enabled')" in producer_script, 'Producer no longer rejects Python -O')
require("assert guards==source['nonzero_conditions'] and len(guards)==121" in producer_script, 'Producer source-list/count check disappeared')
require("assert hashlib.sha256(source_path.read_bytes()).hexdigest()==connection['source_sha256']==input['source_paths_sha256'][str(source_path)]" in producer_script, 'Producer source authentication disappeared')
require(connection['source'] == str(SOURCE) and connection['source_sha256'] == SOURCE_SHA, 'Connection source binding differs')
guards = source['nonzero_conditions']
require(sha(SOURCE) == SOURCE_SHA, 'Original source hash changed')
require(input_data['source_paths_sha256'][str(SOURCE)] == SOURCE_SHA, 'Input source hash binding differs')
require(len(guards) == len(set(guards)) == 121, 'Incorrect source guard count or duplicates')
require(guards == input_data['retained_native_nonzero_conditions'], 'Input guard strings differ from original source')
require(len(certificate['conditions']) == certificate['condition_count'] == 121, 'Incorrect certificate guard count')
require(certificate['input_sha256'] == sha(ROOT / 'input.json'), 'Certificate input binding differs')
require([c['source_condition_index'] for c in certificate['conditions']] == list(range(121)), 'Indices reordered or missing')
require([c['source_condition'] for c in certificate['conditions']] == guards, 'Certificate guards differ from source')
path = [Q(t) for t in input_data['path_imaginary']]
require(path[0] == Q(256) and path[-1] == Q(1, 16), 'Contour endpoints differ')
require(len(path) == 49 and all(Q(1, 16) <= b < a <= Q(256) for a, b in zip(path, path[1:])), 'Contour leaves reviewed interval')

rows = []
for index, (text, cert) in enumerate(zip(guards, certificate['conditions'])):
    poly = parse_polynomial(text)
    require(bool(poly), 'Identically zero source guard')
    lowest = min(k for k, _ in poly)
    degree = max(j for (k, j) in poly if k == lowest)
    leading = [poly.get((lowest, j), Q(0)) for j in range(degree + 1)]
    lead_cert = cert['numerator_leading_epsilon_coefficient']
    require(lead_cert['formal_epsilon_valuation'] == lowest, 'Leading epsilon valuation mismatch')
    require([Q(c) for c in lead_cert['leading_eta_coefficients']] == leading, 'Leading epsilon coefficient mismatch')
    denominator = cert['denominator_leading_epsilon_coefficient']
    require(denominator['formal_epsilon_valuation'] == 0 and denominator['leading_eta_coefficients'] == ['1'], 'Polynomial denominator certificate differs from unity')
    re = trim([c * (-1) ** (j // 2) if j % 2 == 0 else Q(0) for j, c in enumerate(leading)])
    im = trim([c * (-1) ** ((j - 1) // 2) if j % 2 else Q(0) for j, c in enumerate(leading)])
    independent_gcd = gcd(re, im)
    require([Q(c) for c in lead_cert['positive_imaginary_common_real_imag_polynomial']] == independent_gcd, 'Real/imaginary gcd certificate differs')
    norm_squared = plus(product(re, re), product(im, im))
    proof = root_count(norm_squared, Q(1, 16), Q(256))
    require(proof['roots'] == 0, 'Leading guard has a contour zero')
    require(value(norm_squared, Q(1, 16)) > 0 and value(norm_squared, Q(256)) > 0, 'Nonpositive norm at an endpoint')
    rows.append({'source_index': index, 'epsilon_valuation': lowest, 'eta_degree': degree,
                 'norm_squared_coefficients': [str(c) for c in norm_squared],
                 'norm_squared_sturm_certificate': proof})

result = {
    'schema': 'vakint.pr11d.independent-source-guard-review.v1',
    'status': 'PASS',
    'source_guard_count': len(rows),
    'source_guard_list_exact_equality': True,
    'source_guard_strings_unique': True,
    'contour': 'eta=i*y, 1/16 <= y <= 256; endpoints included',
    'independent_method': 'Python standard-library Fraction sparse polynomial parser; direct exact Sturm test of real(q(i*y))^2+imag(q(i*y))^2, plus independent Euclidean gcd verification of the producer certificate',
    'epsilon_valuation_histogram': dict(collections.Counter(str(r['epsilon_valuation']) for r in rows)),
    'current_source_denominators': 'All 121 guards are polynomials, hence every guard denominator is exactly 1.',
    'claim': 'Each original source condition is a nonzero formal epsilon germ along the entire closed contour. It is therefore an invertible Laurent-series divisor for every contour point. No finite-epsilon value, numerical epsilon radius, or source-accuracy increase is certified.',
    'initial_robustness_findings_resolved': [
        'Producer now authenticates original source bytes through connection/input SHA bindings, and requires exact guard-list equality and count 121.',
        'Producer now rejects Python -O before assertions could be bypassed.'
    ],
    'scope_observations': [
        'The source-string list presently contains no pure-epsilon-only factor: every leading numerator epsilon valuation is 0. General prose about retaining such divisors is not evidence of their occurrence in these 121 guards.',
        'The reviewed source set consists exclusively of polynomials, so rational-expression cancellation cannot erase a separate domain condition in this particular dataset. This is not a general proof for future rational or nested-divisor guard formats.'
    ],
    'source_bindings': {str(p): sha(p) for p in [SOURCE, connection_path, ROOT / 'input.json', ROOT / 'guard-validation.json', ROOT / 'check_guards.py', HERE / 'audit.py']},
    'conditions': rows,
}
(HERE / 'audit.json').write_text(json.dumps(result, indent=2) + '\n')
print('PASS: 121 original source guards; exact equality and independent full-contour polynomial nonvanishing')
