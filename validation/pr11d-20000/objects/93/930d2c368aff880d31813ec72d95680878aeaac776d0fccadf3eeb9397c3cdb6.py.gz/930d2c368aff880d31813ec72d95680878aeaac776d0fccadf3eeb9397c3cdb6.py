#!/usr/bin/env python3
"""Bounded independent review of one prepared native three-loop input.

Does not run native numerical transport or modify producer files. Negative
controls and preparer replays exist only in a temporary native-* directory.
"""
import copy
import hashlib
import json
import math
from fractions import Fraction as Q
from pathlib import Path
import subprocess
import sys
import tempfile

from flint import arb, ctx, fmpq

if not __debug__:
    raise RuntimeError("Assertions required")

HERE = Path(__file__).resolve().parent
PR11D = HERE.parents[1]
PERIODS = PR11D.parent
NATIVE = PR11D / "helper/frobenius-transport/native"
BOUNDARY = PERIODS / "bessel/ancestor-boundary/pr9-boundary-API20280-working20400.json"
CONNECTION = PR11D / "ancestor-flows/pr9-22-polynomial.json"
STARTUP = PR11D / "ancestor-flows/pr9-22-startup.json"
MATCHING = PR11D / "ancestor-flows/pr9-22-matching.json"
INPUT = NATIVE / "pr9-API20280-init-v1.in"
METADATA = INPUT.with_suffix(".json")
PREPARER = NATIVE / "prepare_v2.py"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def main():
    source_paths = [PREPARER, NATIVE / "contracted_v2.c", NATIVE / "FORMAT.typ",
                    BOUNDARY, CONNECTION, STARTUP, MATCHING, INPUT, METADATA]
    pins = {str(path): sha(path) for path in source_paths}
    p, s, m, b, meta = map(load, [CONNECTION, STARTUP, MATCHING, BOUNDARY, METADATA])
    assert p["matching_data_sha256"] == s["source_matching_sha256"] == b["matching_sha256"] == sha(MATCHING)
    assert p["startup_data_sha256"] == sha(STARTUP)
    assert b["inventory_sha256"] == m["inventory_sha256"]
    assert sha(m["inventory_path"]) == m["inventory_sha256"]
    assert b["normalization"] == "native_raw" and b["error_quality"] == "rigorous-bound"
    assert meta["seed_binding"] == sha(BOUNDARY) and meta["input_sha256"] == sha(INPUT)
    # Metadata source paths are relative to the actual invocation directory,
    # which was helper/frobenius-transport, not the location of the metadata.
    for relative, digest in meta["source_sha256"].items():
        resolved = (NATIVE.parent / relative).resolve()
        assert sha(resolved) == digest
        assert resolved in {CONNECTION, STARTUP, MATCHING}

    lines = iter(INPUT.read_text().splitlines())
    header = next(lines).split()
    assert header[0] == "FROB_V1"
    (dim, logs, block_count, count, nmin, nmax, dd, bd, poly_count,
     residue_count, startup_count, bits, digits, max_order, check_every) = map(int, header[1:])
    assert (dim, logs, count, nmin, nmax, digits) == (132, 9, 132, -4, -1, 20320)
    assert dim == p["dimension"] == s["dimension"] == m["dimension"]
    assert count == m["freeconstants"] and logs == p["generic_maximum_log_degree"] + 1
    assert [nmin, nmax] == s["normalized_power_range"] == m["normalized_power_range"]
    assert [nmin, nmax] == p["normalized_power_range"]
    zr, zi, zd = map(int, next(lines).split())
    assert (zr, zi, zd) == (0, -1, 256)
    z = (Q(zr, zd), Q(zi, zd))
    scale = int(next(lines))
    ctx.prec = bits
    denominator_bound = arb(next(lines))
    assert denominator_bound == arb(scale)
    owners = list(map(int, next(lines).split()))
    assert len(owners) == dim and set(owners) == set(range(block_count))
    assert max(owners.count(i) for i in range(block_count)) == 4
    assert meta["blocks"] == [[j for j in range(dim) if owners[j] == i] for i in range(block_count)]
    d = list(map(Q, p["denominator_coefficients"]))
    powers = [(Q(1), Q(0))]
    for unused in range(max(dd, bd)):
        a, c = powers[-1]
        powers.append((a*z[0] - c*z[1], a*z[1] + c*z[0]))
    def scaled_pair(q, k):
        return tuple(v*q/d[1]*scale for v in powers[k])
    for k in range(dd+1):
        pair = tuple(map(int, next(lines).split()))
        assert pair == scaled_pair(d[k+1], k)
    expected_residue = {}
    assert poly_count == len(p["entries"])
    for e in p["entries"]:
        r, c = map(int, next(lines).split())
        assert (r, c) == (e["row"], e["column"]) and owners[c] <= owners[r]
        terms = {t["z_power"]: Q(int(t["numerator"]), int(t["denominator"])) for t in e["terms"]}
        assert len(terms) == len(e["terms"])
        for k in range(bd+1):
            assert tuple(map(int, next(lines).split())) == scaled_pair(terms.get(k, Q(0)), k)
        if terms.get(0):
            expected_residue[r, c] = terms[0]/d[1]
    residue_scale = int(next(lines))
    residue = {}
    for unused in range(residue_count):
        r, c, value = map(int, next(lines).split())
        assert (r, c) not in residue
        residue[r, c] = Q(value, residue_scale)
    assert residue == expected_residue
    expected_startup = [(row["normalized_z_power"], row["log_power"], i, j, Q(q))
                        for row in s["coefficients"] for i, j, q in row["entries"]]
    actual_startup = []
    for unused in range(startup_count):
        n, ell, i, j, a, c = map(int, next(lines).split())
        assert c > 0 and nmin <= n <= nmax and 0 <= ell < logs and 0 <= i < dim and 0 <= j < count
        actual_startup.append((n, ell, i, j, Q(a, c)))
    assert actual_startup == expected_startup
    for weight, scale_value in zip(m["gauge_weights"], m["gauge_scales"], strict=True):
        w, a, c = map(int, next(lines).split())
        assert (w, Q(a, c)) == (weight, Q(scale_value)) and c > 0
    assert len(m["gauge_weights"]) == dim
    actual_constants = []
    for unused in range(count):
        real, imaginary = next(lines).split("|")
        assert arb(imaginary).is_zero() and arb(real).is_finite()
        actual_constants.append(arb(real))
    assert list(lines) == []

    fields = ("component", "integer_z_power", "epsilon_power", "log_power")
    key = lambda row: tuple(row[f] for f in fields)
    boundary = {key(row): arb(row["real_ball"]) for row in b["coefficients"]}
    assert len(boundary) == len(b["coefficients"]) == len(m["all_boundary_selectors"]) == 557
    assert set(boundary) == {key(row) for row in m["all_boundary_selectors"]}
    selected = [boundary[key(row)] for row in m["selected_selectors"]]
    fresh = [sum((selected[j]*arb(fmpq(q)) for j, q in enumerate(row) if q != "0"), arb(0))
             for row in m["boundary_inverse"]]
    assert len(fresh) == len(b["free_constant_balls"]) == count
    for x, original, native in zip(fresh, b["free_constant_balls"], actual_constants, strict=True):
        assert x.overlaps(arb(original))
        # Serialization is deliberately outward. Reproduce the exact stored
        # string before parsing, then require parsed ball equality, not overlap.
        serialized = arb(x.str(math.ceil(bits*math.log10(2))+10))
        assert serialized.mid() == native.mid() and serialized.rad() == native.rad()
    for selector, row in zip(m["all_boundary_selectors"], m["all_boundary_matrix"], strict=True):
        residual = sum((fresh[j]*arb(fmpq(q)) for j, q in enumerate(row) if q != "0"), arb(0)) - boundary[key(selector)]
        assert residual.contains(0)
    target = (arb(10) ** (-20240)).lower()
    assert all(x.rad() < target for x in actual_constants)
    max_rad = max(x.rad() for x in actual_constants)
    rel_bits = min(x.rel_accuracy_bits() for x in actual_constants if not x.contains(0))

    assert all(sha(path) == digest for path, digest in pins.items()), "Source changed during audit"
    receipt = {
      "schema":"vakint.pr9.native-input-independent-format-review.v1",
      "accepted":True,
      "method":"Independent exact Gaussian rational replay of polynomial/residue/startup/gauge serialization and exact Arb seed serialization replay; no native production rerun",
      "source_sha256":pins,
      "audit_implementation_sha256":sha(__file__),
      "dimension":dim,"log_slots":logs,"maximum_block_size":max(owners.count(i) for i in range(block_count)),
      "polynomial_entries_replayed":poly_count,"residue_entries_replayed":residue_count,
      "startup_entries_replayed":startup_count,"gauge_rows_replayed":dim,
      "boundary_rows_replayed":len(boundary),"constant_count":count,
      "all_serialized_seed_midpoints_and_radii_equal":True,
      "native_local_tail_target_digits":digits,"actual_absolute_seed_guard_digits":20240,
      "maximum_prepared_seed_radius":max_rad.str(30),"minimum_relative_bits_excluding_zero_containing":int(rel_bits),
      "all_prepared_seed_radii_below_10_to_minus20240":True,
      "input_sha256":sha(INPUT),"source_boundary_sha256":sha(BOUNDARY),
      "producer_files_modified":False,"native_transport_duplicated":False,
      "final_output_accuracy_claimed":False,
      "scope_limit":"20320 is the local tail target, not the precision of imported seeds. Final propagated widths must be checked separately at the intended20220 output target."
    }
    (HERE/"native-input-receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
    print(json.dumps({k:v for k,v in receipt.items() if k!="source_sha256"},indent=2))

if __name__=="__main__":main()
