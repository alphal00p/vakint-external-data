"""Exact post-replay of serialized local witnesses, without Gaussian solving."""
from replay import *
import time

@functools.cache
def rat(s):return parse(s,'e','x')

def main():
    start=time.monotonic()
    originals={hashlib.sha256(repr(normalize(row)).encode()).hexdigest():row for _,_,row in raw_system()}
    report=json.loads((HERE/'local-replay.json').read_text())
    for index,proof in enumerate(report['exact_matches']):
        original=originals[proof['row_sha256']]
        reconstructed={};seed=tuple(proof['seed'])
        for term in proof['witness']:
            muladd(reconstructed,ibp(seed,term['derivative_loop'],term['vector_loop']),rat(term['coefficient']))
        difference=original.copy();muladd(difference,reconstructed,-ONE)
        assert not difference,(index,proof)
        if index%1000==0:print('replayed',index,flush=True)
    receipt={'schema':'vakint.serialized-ibp-witness-replay.v1','passed':True,
             'exact_rows_replayed':len(report['exact_matches']),
             'witness_file_sha256':hashlib.sha256((HERE/'local-replay.json').read_bytes()).hexdigest(),
             'remaining_rows':len(report['unmatched']),
             'seconds':time.monotonic()-start}
    (HERE/'local-replay-validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt),flush=True)

if __name__=='__main__':main()
