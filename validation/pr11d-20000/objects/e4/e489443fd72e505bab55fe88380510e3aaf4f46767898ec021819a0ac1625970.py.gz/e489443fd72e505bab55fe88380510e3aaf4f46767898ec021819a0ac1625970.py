#!/usr/bin/env python3
"""Read-only exact RPF IVP audit, parameterized by an explicit frozen contract.

No producer, native executable or preparer is invoked. The caller separately
admits physical initial data, mathematical/native implementation and whole-chain
continuity. This module admits actual step data only.
"""
from dataclasses import dataclass
from fractions import Fraction as Q
from pathlib import Path
import hashlib, importlib.util, json, math, time
from flint import arb, acb, ctx, fmpq, fmpq_poly

HERE=Path(__file__).resolve().parent
REVIEWED=HERE.parent/'four-loop-control-admission/replay.py'
REVIEWED_SHA='ff24f65856778611e396e5fc08770029e69f38016eed4764af025941793ab71f'
COMMON=HERE.parents[1]/'pr11d/ancestor-flows/ordinary-chain-acceptance-v1/pf_input_review/check_step.py'
COMMON_SHA='7135e2f86d4c55629c7e15c01d49e19967e0f926ffd8056f6cc4e61cfb8a046b'
if hashlib.sha256(REVIEWED.read_bytes()).hexdigest()!=REVIEWED_SHA:raise RuntimeError('Frozen reviewed reader changed')
if hashlib.sha256(COMMON.read_bytes()).hexdigest()!=COMMON_SHA:raise RuntimeError('Frozen independent primitive reader changed')
spec=importlib.util.spec_from_file_location('frozen_PR9_audit_reader',REVIEWED)
F=importlib.util.module_from_spec(spec);spec.loader.exec_module(F)
C=F.C
require,sha,load,real,decode,aq=C.require,C.sha,C.load,C.real,C.decode,C.aq
compose,pair,mul,add=C.compose,C.pair,C.mul,C.add
if not __debug__:raise RuntimeError('Acceptance cannot run with Python optimization')

@dataclass(frozen=True)
class StepContract:
    dimension:int
    jets:int
    epsilon_min_power:int
    polynomial_sha256:str
    rational_pf_sha256:str
    source_equation_sha256:str
    working_bits:int
    target_digits:int
    serialization_decimal_digits:int
    run_binding_sha256:str
    initial_boundary_sha256:str
    component_scale_policy:str='identity'
    # matching-derived, minimum-subtracted exponent for each component;
    # the chain caller authenticates the matching proof supplying these.
    component_scale_weights:tuple=()
    expected_worker_threads:int|None=None

def fq(q):q=Q(q);return fmpq(q.numerator,q.denominator)
def poly(coeff):return fmpq_poly([fq(q) for q in coeff])
def _source(con,rpf,dim,jets,degree):
    require(con['dimension']==rpf['dimension']==dim and con['epsilon_jet_count']==rpf['epsilon_jet_count']==jets,'Connection dimensions')
    require(rpf['schema']in('vakint.ancestor.exact-rational-polynomial-partial-fractions.v1','vakint.pr11d.rational-PF-schema-conversion.v1'),'Unsupported general RPF schema')
    D=[Q(x)for x in con['denominator_coefficients']];require(len(D)<=degree+1 and con['numerator_degree']<=degree,'Header truncates connection')
    den=poly(D);original={};numerators=[]
    for e in con['entries']:
        key=e['row'],e['column'],e['epsilon_power'];require(key not in original and all(type(v)is int for v in key)and 0<=key[0]<dim and 0<=key[1]<dim and 0<=key[2]<jets,'Invalid or duplicate coupling')
        co=[Q(0)]*(degree+1);seen=set()
        for t in e['terms']:
            p=t['eta_power'];require(type(p)is int and 0<=p<=degree and p not in seen,'Invalid numerator power');seen.add(p);co[p]=Q(int(t['numerator']),int(t['denominator']))
        original[key]=poly(co);numerators.append((key,co))
    factors={f['index']:[Q(x)for x in f['coefficients']]for f in rpf['denominator_factors']};require(len(factors)==len(rpf['denominator_factors']),'Duplicate factor')
    keys=set()
    for e in rpf['entries']:
        key=e['row'],e['column'],e['epsilon_power'];require(key in original and key not in keys,'Unknown or duplicate RPF coupling');keys.add(key);value=poly([Q(x)for x in e['polynomial_part']])*den
        for t in e['terms']:
            require(t['factor_index']in factors and type(t['factor_power'])is int and 1<=t['factor_power']<=3,'Unsupported factor power')
            quotient,remainder=divmod(den,poly(factors[t['factor_index']])**t['factor_power']);require(not remainder,'Factor does not divide common denominator');value+=quotient*poly([Q(x)for x in t['numerator_coefficients']])
        require(value==original[key],'Exact general RPF identity failed '+str(key))
    require(keys==set(original),'Missing RPF coupling');return D,numerators,factors

def check_raw_to_polynomial(raw_path,polynomial_path):
    """Exact epsilon jets after the recorded 0/1 regular unit gauge.

    Optional once-per-chain companion. Source IBP derivation remains the caller's
    trust boundary; this checks the literal rational matrix to polynomial map.
    """
    pp=Path(polynomial_path);con=load(pp);raw=load(raw_path);require(sha(raw_path)==con['source_sha256'],'Raw source binding')
    ap=F.ROOT/'ancestor-flows/endpoint-review/independent_checks.py'
    require(sha(ap)=='64468cfdd24ba001c55ef4879259ea0d81bedf2208bee31aa73df4e91cc9feea','Independent AST reader changed')
    spec=importlib.util.spec_from_file_location('frozen_exact_AST',ap);M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
    dim=con['dimension'];jets=con['epsilon_jet_count'];weights=C.gauge_contract(con['regular_epsilon_gauge'],dim);E,X=M.C.gens();D=sum((M.C.constant(fq(q))*X**i for i,q in enumerate(con['denominator_coefficients'])),M.C.constant(0));N={}
    for e in con['entries']:
        key=e['row'],e['column'];p=N.get(key,M.C.constant(0))
        for t in e['terms']:p+=M.C.constant(fmpq(int(t['numerator']),int(t['denominator'])))*E**e['epsilon_power']*X**t['eta_power']
        N[key]=p
    require(len(raw['differential_matrix'])==dim and all(len(r)==dim for r in raw['differential_matrix']),'Raw matrix dimensions')
    for i,row in enumerate(raw['differential_matrix']):
        for j,text in enumerate(row):
            v=M.parsed(text.replace(raw['epsilon_symbol'],'e').replace(raw['variable'],'x'),{'constant':M.B,'e':M.B(E),'x':M.B(X)})
            v=v*M.B(M.C.constant(1)-2*E)**(weights[j]-weights[i])
            require(min(e for e,x in v.d.to_dict())==0,'Epsilon-singular transformed denominator')
            residual=v.n*D-v.d*N.get((i,j),M.C.constant(0));require(all(e>=jets for e,x in residual.to_dict()),'Raw-to-regular-polynomial identity '+str((i,j)))
    return {'raw_source_sha256':sha(raw_path),'polynomial_sha256':sha(pp),'exact_matrix_entries':dim*dim,'maximum_epsilon_power_kept':jets-1,'regular_unit_gauge_verified':True,'independent_AST_reader_sha256':sha(ap)}

def check_step(input_path,metadata_path,previous_boundary_path,polynomial_path,rational_pf_path,native_output_path,following_boundary_path,contract:StepContract):
    """Return a portable data receipt; modifies no file and restores Arb context."""
    saved=ctx.prec
    try:return _check(input_path,metadata_path,previous_boundary_path,polynomial_path,rational_pf_path,native_output_path,following_boundary_path,contract)
    finally:ctx.prec=saved

def _check(input_path,metadata_path,previous_boundary_path,polynomial_path,rational_pf_path,native_output_path,following_boundary_path,k):
    start=time.monotonic();paths=list(map(lambda p:Path(p).resolve(),[input_path,metadata_path,previous_boundary_path,polynomial_path,rational_pf_path,native_output_path,following_boundary_path]));ip,mp,pp,cp,fp,rp,np=paths;pins={str(p):sha(p)for p in paths};pins[str(REVIEWED.resolve())]=REVIEWED_SHA;pins[str(COMMON.resolve())]=COMMON_SHA
    require(sha(cp)==k.polynomial_sha256 and sha(fp)==k.rational_pf_sha256,'Explicit connection contract binding');con,rpf,meta,prior,result,following=map(load,[cp,fp,mp,pp,rp,np]);dim,jets=k.dimension,k.jets;states=dim*jets
    require(type(dim)is int and 1<=dim<=42 and type(jets)is int and 1<=jets<=6,'Unsupported dimensions');require(con['source_sha256']==k.source_equation_sha256 and rpf['source_polynomial_connection_sha256']==k.polynomial_sha256,'Source binding')
    require(meta['schema']=='vakint.constant-scaled-rational-pf-step.v1','Unknown step metadata schema');center=pair(meta['center'],'center');step=pair(meta['step'],'step');end=add(center,step);require(center[0]==step[0]==0 and center[1]>end[1]>0,'Unsupported contour')
    ctx.prec=max(k.working_bits+256,512)
    def boundary(d,point):
        require(d['basis']=='original_raw_epsilon_jets' and d['normalization']=='native_raw' and d['error_quality']=='rigorous-bound','Boundary conventions')
        require(d['dimension']==dim and d['epsilon_min_power']==k.epsilon_min_power and d['epsilon_max_power']==k.epsilon_min_power+jets-1,'Boundary Laurent range')
        require(d.get('source_equation_sha256',d.get('original_source_equation_sha256'))==k.source_equation_sha256 and pair(d['eta_center'],'eta')==point,'Boundary source/point')
        require(d.get('local_truncation_rigorously_enclosed')is True or d.get('local_tail_certified')is True,'Uncertified boundary');require(d.get('physical_accuracy_certified',True)is not False,'Explicitly uncertified source');return decode(d['values'],states)
    prior_values=boundary(prior,center);boundary(following,end)
    for key,want in [('input_sha256',sha(ip)),('initial_data_sha256',sha(pp)),('source_equation_sha256',k.source_equation_sha256),('polynomial_connection_sha256',k.polynomial_sha256),('rational_pf_source_sha256',k.rational_pf_sha256)]:require(meta[key]==want,'Metadata binding '+key)
    require(meta['normalization']=='native_raw'and meta['source_error_quality']=='rigorous-bound'and meta['physical_period_accuracy_claimed']is False,'Metadata source quality');require(meta['regular_epsilon_gauge']==con['regular_epsilon_gauge'],'Regular gauge binding');gauge=C.gauge_contract(con['regular_epsilon_gauge'],dim)
    if k.component_scale_policy=='identity':scales=[Q(1)]*dim
    elif k.component_scale_policy=='imaginary_center_power':
        require(len(k.component_scale_weights)==dim and all(type(w)is int and w>=0 for w in k.component_scale_weights),'Unbound scale weights');scales=[abs(center[1])**(-w)for w in k.component_scale_weights];require(meta['constant_scale_weights']==list(k.component_scale_weights),'Scale metadata weights')
    else:raise ValueError('Unknown component scale policy')
    require([Q(x)for x in meta['constant_component_scale']]==scales,'Component scale mismatch')
    for p,h in meta['implementation_dependency_sha256'].items():require(sha(p)==h,'Changed implementation dependency');pins[str(Path(p).resolve())]=h
    prefix=Path(meta['saved_polynomial_input_path']);require(sha(prefix)==meta['saved_polynomial_input_sha256'],'Prefix hash');prefixmeta=load(prefix.with_suffix('.json'));require(sha(prefix.with_suffix('.json'))==meta['saved_polynomial_metadata_sha256']and prefixmeta['input_sha256']==sha(prefix),'Prefix metadata');pins[str(prefix.resolve())]=sha(prefix);pins[str(prefix.with_suffix('.json').resolve())]=sha(prefix.with_suffix('.json'))
    rows=ip.read_text().splitlines();prefixrows=prefix.read_text().splitlines();require(rows[:len(prefixrows)]==prefixrows,'RPF append modified native prefix');lines=iter(rows)
    def ints(n):
        row=next(lines).split();require(len(row)==n,'Wrong integer row width');return [int(x)for x in row]
    header=ints(9);hd,hj,degree,count,nb,bits,digits,maxorder,every=header
    require((hd,hj,bits,digits)==(dim,jets,k.working_bits,k.target_digits)and degree>=0 and maxorder>=max(degree,8)and every>=1,'Native header contract');require(meta['degree']==degree and meta['dimension']==dim and meta['jets']==jets and meta['working_bits']==bits and meta['requested_digits']==digits,'Metadata/header mismatch')
    D,numerators,factors=_source(con,rpf,dim,jets,degree);require(count==len(numerators),'Entry count')
    lowertext=next(lines);ctx.prec=128;native_lower=real(lowertext);require(native_lower>0,'Nonpositive denominator bound');ctx.prec=max(bits+256,512);owners=ints(dim);blocks,wanted=C.block_owners(dim,con['entries']);require(owners==wanted and nb==len(blocks),'SCC block ordering')
    shifted_D=compose(D,center,step,degree);expected=[(key,[mul(step,z)for z in compose(co,center,step,degree)])for key,co in numerators]
    unscaled=math.lcm(*(q.denominator for co in [shifted_D]+[co for _,co in expected]for z in co for q in z));ratios=[scales[key[1]]/scales[key[0]]for key,co in expected];clear=math.lcm(*(q.denominator for q in ratios));scale=unscaled*clear
    require(str(unscaled)==meta['denominator_scale'],'Denominator scale');require(Q(meta.get('clear_denominator_factor','1'))==clear,'Scale clearing factor')
    for a,b in shifted_D:require(ints(2)==[int(a*scale),int(b*scale)],'Exact shifted denominator')
    pb={}
    for (key,co),ratio in zip(expected,ratios):
        require(ints(3)==list(key),'Polynomial key ordering')
        for a,b in co:require(ints(2)==[int(a*scale*ratio),int(b*scale*ratio)],'Exact shifted/scaled numerator')
        pb[key]=aq(sum(abs(a)+abs(b)for a,b in co)*scale*ratio)/native_lower
    lower,certs=C.segment_bound(D,center,step);require(meta['denominator_segment_certificates']==certs and native_lower.lower()<=(lower*scale).lower(),'Denominator segment bound');require(real(meta['denominator_lower_bound']).lower()<=(lower*unscaled).lower(),'Unscaled metadata bound')
    if clear==1:require(lowertext==meta['denominator_lower_bound'],'Unscaled literal bound mismatch')
    else:
        ctx.prec=128;v=real(meta['denominator_lower_bound'])*clear;require(lowertext==v.str(85,more=True),'Scaled literal bound serialization');ctx.prec=max(bits+256,512)
    seeds=[]
    for _ in range(states):
        f=next(lines).split('|');require(len(f)==2,'Seed pair');seeds.append(acb(real(f[0]),real(f[1])))
    converted=[]
    for j in range(jets):
        for i in range(dim):
            v=sum((prior_values[(j-a)*dim+i]*2**a for a in range(j+1)),acb(0))if gauge[i]else prior_values[j*dim+i];converted.append(v/fq(scales[i]))
    require(all(a.contains(b)for a,b in zip(seeds,converted)),'Full source→seed containment failed')
    bank=[];indices={};terms=[]
    for e in rpf['entries']:
        ratio=scales[e['column']]/scales[e['row']]
        if e['polynomial_part']:terms.append((e,-1,[Q(x)*ratio for x in e['polynomial_part']]))
        for t in e['terms']:
            key=t['factor_index'],t['factor_power']
            if key not in indices:indices[key]=len(bank);bank.append((factors[key[0]],key[1]))
            terms.append((e,indices[key],[Q(x)*ratio for x in t['numerator_coefficients']]))
    require(next(lines)==f'RPF_V1 {len(bank)} {len(terms)}'and ints(3)==C.scaled(center)and ints(3)==C.scaled(step),'RPF header/geometry');common=math.lcm(*(q.denominator for _,_,co in terms for q in co));require(ints(1)==[common]and str(common)==meta['rpf_shared_numerator_denominator'],'RPF shared denominator');require(meta['rpf_factor_bank_count']==len(bank)and meta['rpf_term_count']==len(terms),'RPF counts')
    mins=[];mcerts=[]
    for index,(co,power)in enumerate(bank):
        den=math.lcm(*(q.denominator for q in co));require(ints(3)==[len(co)-1,power,den]and ints(len(co))==[int(q*den)for q in co],'Factor serialization');t,sq,kind=F.factor_minimum(co,center,step);mins.append(aq(sq).sqrt());mcerts.append({'factor_index':index,'base_degree':len(co)-1,'power':power,'parameter_kind':kind,'minimizing_parameter':str(t),'minimum_factor_modulus_squared':str(sq)})
    rb={};mask=[set()for _ in bank];habs=aq(sum(x*x for x in step)).sqrt();rowdens=[1]*dim;active=0;olddiv=0
    for e,a,co in terms:
        key=e['row'],e['column'],e['epsilon_power'];require(ints(5)==list(key)+[a,len(co)-1]and ints(len(co))==[int(q*common)for q in co],'RPF term serialization');local=compose(co,center,step,len(co)-1);v=habs*aq(sum(abs(x)+abs(y)for x,y in local))
        if a>=0:v/=mins[a]**bank[a][1]
        rb[key]=rb.get(key,arb(0))+v
        if any(co):
            active+=1;olddiv+=jets-key[2];den=math.lcm(*(q.denominator for z in local for q in mul(step,z)));rowdens[key[0]]=math.lcm(rowdens[key[0]],den)
            if a>=0:
                for J in range(key[2],jets):mask[a].add((J-key[2])*dim+key[1])
    require(not list(lines),'Trailing native data')
    require(result['schema']=='vakint.pr11d.arb-local-transport-pilot.v1'and result['local_tail_certified']is True and result['no_PR11d_value_claimed']is True,'Native certificate/schema');order=result['order'];require(result['working_bits']==bits and result['target_absolute_digits']==digits and 8<=order<=maxorder and(order%every==0 or order==maxorder),'Native order/precision')
    tail=real(result['tail_upper_enclosure']);require(tail>=0 and tail.upper()<(arb(10)**-digits/16).lower(),'Native local tail gate');require(result['coefficient_method']=='exact rational-factor auxiliary cascades'and result['connection_bound_method']=='entrywise minimum of polynomial and exact rational-factor segment bounds','Unreviewed algorithm');require(result['rational_pf_identity_verified']is True and result['auxiliary_mask_verified']is True and result['factor_minimum_certificates']==mcerts,'Native source/factor proof');require(result['coefficient_ring_width']==max(degree,4)+1,'Coefficient ring history')
    pairs=sum(map(len,mask));levels=sum(len(s)*b[1]for s,b in zip(mask,bank));total=states*sum(b[1]for b in bank)
    require(result['auxiliary_active_states_by_factor']==[sorted(s)for s in mask],'Exact mask')
    for key,want in [('auxiliary_total_factor_state_pairs',len(bank)*states),('auxiliary_computed_factor_state_pairs',pairs),('auxiliary_skipped_factor_state_pairs',len(bank)*states-pairs),('auxiliary_total_cascade_state_levels',total),('auxiliary_computed_cascade_state_levels',levels),('auxiliary_skipped_cascade_state_levels',total-levels)]:require(result[key]==want,'Mask counter '+key)
    def mu(bounds):return max(sum((v for(i,j,jt),v in bounds.items()if i==r and jt==0 and owners[i]==owners[j]),arb(0)).upper()for r in range(dim))
    for key,bounds in [('polynomial_maximum_internal_row_bound',pb),('rpf_maximum_internal_row_bound',rb),('chosen_maximum_internal_row_bound',{key:arb.min(pb[key],rb[key])for key in pb})]:require(real(result[key]).upper()>=mu(bounds),'Native row bound '+key)
    if 'row_denominator_aggregation_verified'in result:
        require(result['row_denominator_aggregation_verified']is True and result['row_common_denominators']==list(map(str,rowdens))and result['row_numerator_identity_count']==10*active and result['baseline_term_divisions_per_order']==olddiv and result['row_divisions_per_order']==states,'Exact row aggregation counters/denominators')
    if 'coefficient_precision_schedule'in result:
        guard=all(len(co)==2 or len(co)==3 and co[1]**2-4*co[0]*co[2]>=0 for co,power in bank);ratio=center[1]**2/sum(x*x for x in step);slope=0;remaining=ratio
        if guard:
            while remaining>=4:slope+=1;remaining/=4
        floor=min(bits,1024);minimum=max(floor,bits-slope*(order-1));require(result['coefficient_precision_schedule']=='max(min(Pmax,1024),Pmax-slope*n), n starts at zero'and result['precision_max_bits']==bits and result['coefficient_precision_floor_bits']==floor and result['coefficient_precision_slope_bits_per_order']==slope and result['minimum_coefficient_precision_bits_used']==minimum and result['schedule_real_roots_guard']==guard and Q(result['schedule_radius_ratio_squared'])==ratio,'Precision schedule metadata');require(result['full_precision_total_and_certificate']is True and result['schedule_is_accuracy_guarantee']is False,'Schedule must preserve full final certificate')
    if k.expected_worker_threads is not None:require(result['openmp_requested_threads']==k.expected_worker_threads and result['openmp_actual_threads']==min(k.expected_worker_threads,result['openmp_thread_cap']),'Worker contract')
    for key,want in [('previous_boundary_sha256',sha(pp)),('transport_input_sha256',sha(ip)),('native_output_sha256',sha(rp)),('run_binding_sha256',k.run_binding_sha256),('initial_boundary_sha256',k.initial_boundary_sha256)]:require(following[key]==want,'Following binding '+key)
    require(following['whole_PR11d_20000_accuracy_claimed']is False,'Following precision promotion');Z=decode(result['values'],states);U=[v*fq(scales[i%dim])for i,v in enumerate(Z)];raw=[U[j*dim+i]-2*U[(j-1)*dim+i]if j and gauge[i]else U[j*dim+i]for j in range(jets)for i in range(dim)];out=decode(following['values'],states);require(all(a.contains(b)for a,b in zip(out,raw)),'Full native→raw box containment failed')
    ctx.dps=k.serialization_decimal_digits;Z=decode(result['values'],states);U=[v*aq(scales[i%dim])for i,v in enumerate(Z)];raw=[U[j*dim+i]-2*U[(j-1)*dim+i]if j and gauge[i]else U[j*dim+i]for j in range(jets)for i in range(dim)];encoded=[[v.real.str(k.serialization_decimal_digits+8,more=True),v.imag.str(k.serialization_decimal_digits+8,more=True)]for v in raw];require(encoded==following['values'],'Original outward driver serialization differs')
    for p,h in pins.items():require(sha(p)==h,'Data changed during audit '+p)
    return {'schema':'vakint.generic-exact-general-RPF-step-data-review.v1','accepted':True,'dimension':dim,'jets':jets,'epsilon_min_power':k.epsilon_min_power,'center':list(map(str,center)),'destination':list(map(str,end)),'polynomial_coupling_identities':len(numerators),'RPF_terms':len(terms),'factor_minima':len(bank),'input_full_box_containments':states,'output_full_box_containments':states,'original_outward_driver_serialization_byte_identical':True,'native_order':order,'local_target_digits':digits,'native_tail':result['tail_upper_enclosure'],'row_aggregation_checked':'row_denominator_aggregation_verified'in result,'precision_schedule_metadata_checked':'coefficient_precision_schedule'in result,'artifact_sha256':pins,'checker_sha256':sha(__file__),'reviewed_predecessor_sha256':REVIEWED_SHA,'seconds':time.monotonic()-start,'physical_initial_origin_admitted':False,'native_implementation_admitted':False,'native_or_preparer_invoked':False,'whole_period_accuracy_claimed':False}
