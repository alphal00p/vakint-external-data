#!/usr/bin/env python3
"""Independent bounded comparison of API/HPL and native Taylor sunset jets."""
import json,hashlib,sys
from pathlib import Path
from flint import arb,fmpq,ctx
if not __debug__:raise RuntimeError('Acceptance checks require assertions enabled')
sys.set_int_max_str_digits(200000)
HERE=Path(__file__).resolve().parent
BASE=HERE.parent.parent
def ball(x):
    q=x['exact_binary_value']
    return arb(fmpq(int(q['numerator']),int(q['denominator'])))
def main():
    ctx.dps=20400
    a=BASE/'lower-ancestors/2L-P2.json';b=BASE/'pr11d/ancestor-flows/sunset-ratio-20300-normalized.json'
    aa=json.loads(a.read_text());bb=json.loads(b.read_text());tests=[]
    for row in bb['coefficients']['FMFTandMATAD']:
        p=row['epsilon_power'];r=next(r for r in aa['coefficients'] if r['epsilon_power']==p)
        x=ball(r['numerical_value'])+arb(0,ball(r['precision']['real']['absolute_error']).upper());y=arb(row['ball'])
        assert x.is_finite() and y.is_finite() and x.overlaps(y),(p,x.str(20),y.str(20))
        relative=abs(x-y).upper()/min(abs(x).lower(),abs(y).lower())
        digits=int((-relative.log()/arb(10).log()).lower().floor().fmpz())
        assert relative.upper()<(arb(10)**-20200).lower()
        tests.append({'epsilon_power':p,'agreement_digits_lower_bound':digits,'bounded_balls_overlap':True})
    result={'schema':'vakint.sunset.independent-native-API-HPL-versus-Taylor.v1','accepted':True,'checks':tests,'API_source_sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'Taylor_source_sha256':hashlib.sha256(b.read_bytes()).hexdigest(),'normalization':'FMFTandMATAD','minimum_agreement_digits':min(t['agreement_digits_lower_bound'] for t in tests),'working_decimal_digits':20400,'validator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (HERE/'sunset-API-independent-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
    print('PASS six bounded API/HPL versus Taylor coefficient balls; minimum agreement digits',result['minimum_agreement_digits'])
if __name__=='__main__':main()
