"""Explicit offline guard production through the public tracked numerical API."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

import symbolica
from symbolica import E
from symbolica.community.hepkit.vakint import Vakint

sys.set_int_max_str_digits(0)
OUT = Path(__file__).parent
ROOT = Path('/shared/codex-1/vakint_rustred/gammaloop_vakint_rustred')
DATA = ROOT / 'crates/vakint/data'
REQUESTED = 20600
POWERS = list(range(-3, 3))
TARGETS = ['P13', 'P14']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, obj):
    temporary = path.with_suffix(path.suffix + '.next')
    temporary.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')
    temporary.replace(path)


def number(value):
    numerator, denominator = value.as_integer_ratio()
    return {'decimal': str(value), 'precision_bits': value.precision,
            'exact_binary_value': {'numerator': str(numerator), 'denominator': str(denominator)}}


def precision(value):
    return {'significant_digits': value.significant_digits,
            'significant_bits': value.significant_bits, 'exact_zero': value.exact_zero,
            'quality': value.quality.name, 'absolute_error': number(value.absolute_error)}


host_path = OUT.parent / 'optimized/host-build-provenance.json'
host = json.loads(host_path.read_text())
assert sha(Path(symbolica.__file__)) == host['sha256']
assert host['compiler_artifact']['profile']['opt_level'] == '3'
shutil.copyfile(host_path, OUT / 'host-provenance.json')
manifest_path = DATA / '3L/manifest.json'
manifest = json.loads(manifest_path.read_text())
release = json.loads((DATA / 'manifest.json').read_text())
assert next(p for p in release['loop_packs'] if p['loop_count'] == 3)['manifest_sha256'] == sha(manifest_path)
shutil.copyfile(manifest_path, OUT / '3L-manifest.json')
shutil.copyfile(DATA / 'manifest.json', OUT / 'release-manifest.json')
receipt = {'schema': 'vakint-lower-ancestor-guard-production-v1',
           'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'requested_decimal_precision': REQUESTED,
           'minimum_required_achieved_digits': REQUESTED,
           'source_selection': 'P13/P14 epsilon -3..2 only; exact authenticated formulas',
           'native_api': 'Vakint.numerical_evaluation(E(exact_formula), {})',
           'passes_per_coefficient': 1, 'automatic_retry': False,
           'purpose': 'Explicit offline guard production for measured PR9/X8 propagation loss; does not change runtime precision policy.',
           'normalization': 'FMFTandMATAD', 'normalization_transform_applied': False,
           'mass_squared': '1', 'extension_path': symbolica.__file__,
           'extension_sha256': host['sha256'], 'build_profile': host['compiler_artifact']['profile'],
           'dependency_revision': 'c5fc2209c46a678d69726f61a4e16abf668a55c2',
           'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
           'release_manifest_sha256': sha(DATA / 'manifest.json'),
           'loop_manifest_sha256': sha(manifest_path), 'script_sha256': sha(Path(__file__)),
           'completed_coefficients': [], 'completed_masters': []}
save(OUT / 'receipt.json', receipt)
engine = Vakint(evaluation_order=[], run_time_decimal_precision=REQUESTED)
for name in TARGETS:
    key = '3L-' + name
    metadata = next(m for m in manifest['masters'] if m['name'] == name)
    source = OUT / 'source' / key
    source.mkdir(parents=True, exist_ok=True)
    save(source / 'master-metadata.json', metadata)
    formula_path = DATA / '3L' / metadata['files']['symbolic.json']['path']
    assert sha(formula_path) == metadata['files']['symbolic.json']['sha256']
    shutil.copyfile(formula_path, source / 'symbolic.json')
    formulas = dict(json.loads(formula_path.read_text()))
    accepted = json.loads((OUT.parent / (key + '.json')).read_text())
    accepted_by_order = {c['epsilon_power']: c for c in accepted['coefficients']}
    assert accepted['master_id'] == metadata['master_id']
    coefficients = []
    record = {'master': key, 'master_id': metadata['master_id'],
              'family_sha256': metadata['family_sha256'], 'powers': metadata['powers'],
              'loop_count': 3, 'exact_basis_expression': metadata['exact_basis_expression'],
              'normalization': 'FMFTandMATAD',
              'normalization_formula': metadata['graph_definition']['normalization'],
              'mass_squared': '1', 'source_formula_sha256': sha(formula_path),
              'master_metadata_sha256': hashlib.sha256(json.dumps(metadata, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest(),
              'prior_AP_inspection_sha256': sha(OUT.parent / (key + '.json')),
              'provenance': {'version': manifest['version'], 'master_id': metadata['master_id']},
              'requested_decimal_precision': REQUESTED, 'complete': False, 'coefficients': coefficients}
    for power in POWERS:
        formula = formulas[power]
        formula_sha = hashlib.sha256(formula.encode()).hexdigest()
        assert accepted_by_order[power]['formula_sha256'] == formula_sha
        assert accepted_by_order[power]['available_precision'] == 'ArbitraryPrecision'
        print(json.dumps({'event': 'starting', 'master': key, 'epsilon_power': power, 'requested': REQUESTED}), flush=True)
        start = time.monotonic()
        result, statistical_error = engine.numerical_evaluation(E(formula, default_namespace='vakint'), {})
        elapsed = time.monotonic() - start
        assert statistical_error is None and list(result.coefficients) == [0]
        assert not result.warnings
        coefficient = result.coefficients[0]
        assert coefficient.precision.imaginary.exact_zero
        components = {'real': precision(coefficient.precision.real),
                      'imaginary': precision(coefficient.precision.imaginary)}
        assert all(c['quality'] == 'Bounded' and (c['exact_zero'] or c['significant_digits'] >= REQUESTED) for c in components.values())
        item = {'epsilon_power': power, 'available_precision': 'ArbitraryPrecision',
                'requested_decimal_precision': REQUESTED,
                'formula_sha256': formula_sha,
                'numerical_value': number(coefficient.numerical_value.real),
                'precision': components, 'warnings': [], 'elapsed_seconds': elapsed}
        coefficients.append(item)
        save(OUT / (key + '.json'), record)
        receipt['completed_coefficients'].append({'master': key, 'epsilon_power': power,
                                                  'elapsed_seconds': elapsed,
                                                  'achieved_digits': components['real']['significant_digits']})
        save(OUT / 'receipt.json', receipt)
        print(json.dumps({'event': 'completed', **receipt['completed_coefficients'][-1]}), flush=True)
    record['complete'] = True
    save(OUT / (key + '.json'), record)
    receipt['completed_masters'].append({'master': key, 'path': str(OUT / (key + '.json')),
                                         'sha256': sha(OUT / (key + '.json')),
                                         'orders': POWERS})
    save(OUT / 'receipt.json', receipt)
    print(json.dumps({'event': 'master_completed', **receipt['completed_masters'][-1]}), flush=True)
receipt['success'] = True
receipt['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
save(OUT / 'receipt.json', receipt)
