#!/usr/bin/env python3
"""Exact AST/delta and metadata-only review; no FLINT or numerical jobs."""
import ast, copy, hashlib, json, sys
from pathlib import Path
from types import SimpleNamespace
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OLD = ROOT / 'hierarchy-transport/run_x8_rpf_v10.py'
NEW = ROOT / 'hierarchy-transport/run_x8_rpf_v11.py'
PINS = {}
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p, expected=None):
    p = Path(p).resolve(); h = sha(p)
    assert expected is None or h == expected, (p, h, expected)
    assert str(p) not in PINS or PINS[str(p)] == h
    PINS[str(p)] = h
    return p
def read(p, expected=None): return json.loads(pin(p, expected).read_text())
def dump(node): return ast.dump(node, include_attributes=False)
def stmt(text): return ast.parse(text).body[0]
def module(nodes): return compile(ast.fix_missing_locations(ast.Module(body=copy.deepcopy(nodes), type_ignores=[])), '<extracted-review-gate>', 'exec')

pin(OLD)
pin(NEW, '826c6fc378c0526f42adeb4026436d4bc9ae30479136e1845e36f5af92f98667')
oldtree = ast.parse(OLD.read_text()); newtree = ast.parse(NEW.read_text())
oldguard = dump(stmt("assert initial.get('physical_accuracy_certified', True) is not False"))
resumeguard = dump(stmt("assert following['physical_source_admission_required'] is conditional"))
metadata_targets = {
    "run_binding['physical_source_admission_required']", "run_binding['conditional_initial_explicitly_authorized']",
    "following['physical_source_admission_required']", "following['physical_accuracy_certified']",
    "report['physical_source_admission_required']", "report['physical_accuracy_certified']"}
class StripReviewedMetadata(ast.NodeTransformer):
    def __init__(self): self.removed = []
    def visit_Expr(self, node):
        if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            self.removed.append('docstring'); return None
        if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute) and node.value.func.attr == 'add_argument' and node.value.args and isinstance(node.value.args[0], ast.Constant) and node.value.args[0].value == '--allow-conditional-initial':
            assert ast.unparse(node.value) == "ap.add_argument('--allow-conditional-initial', action='store_true')"
            self.removed.append('opt-in CLI'); return None
        return self.generic_visit(node)
    def visit_Assign(self, node):
        if len(node.targets) == 1 and (ast.unparse(node.targets[0]) in metadata_targets or ast.unparse(node.targets[0]) == 'conditional'):
            self.removed.append(ast.unparse(node)); return None
        return self.generic_visit(node)
    def visit_If(self, node):
        if isinstance(node.test, ast.Name) and node.test.id == 'conditional':
            self.removed.append('conditional initial classification/gate'); return None
        return self.generic_visit(node)
    def visit_Assert(self, node):
        if dump(node) in {oldguard, resumeguard}:
            self.removed.append(ast.unparse(node)); return None
        return self.generic_visit(node)
    def visit_Constant(self, node):
        if node.value in ('vakint.certified-X8-rpf-ordinary-transport.v10', 'vakint.certified-X8-rpf-ordinary-transport.v11'):
            return ast.copy_location(ast.Constant(value='REVIEWED-METADATA-SCHEMA'), node)
        return node
normalizers = [StripReviewedMetadata(), StripReviewedMetadata()]
normalized = [n.visit(copy.deepcopy(t)) for n, t in zip(normalizers, [oldtree, newtree])]
assert dump(normalized[0]) == dump(normalized[1]), 'A non-metadata AST difference exists'
assert len(normalizers[0].removed) == 2 and len(normalizers[1].removed) == 11
main = next(n for n in newtree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
start = next(i for i,n in enumerate(main.body) if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'conditional')
policy = module(main.body[start:start+2])
resume = module([next(n for n in ast.walk(main) if isinstance(n, ast.Assert) and dump(n) == resumeguard)])
def classify(initial, optin):
    ns = {'initial': copy.deepcopy(initial), 'args': SimpleNamespace(allow_conditional_initial=optin)}
    try: exec(policy, ns); return {'accepted': True, 'conditional': ns['conditional']}
    except (AssertionError, KeyError) as e: return {'accepted': False, 'error': type(e).__name__ + ': ' + str(e)}
cases = []
actual = []
for profile, ih, rh in [
    ('A', 'e68d82518214ffae10879beb129001c7233552d69e2b544c0a17fe2dc9a6d447', 'a793849fe790107e25a368d026baa7e2a07414f8df83e18b24f9a3d5814b6190'),
    ('B', 'c789f3587d02ecd3d9ca9ee0eb699120aa209c5bee88901c32d5c22068dc37b9', 'dfe211748be090484753f73eea5be1c4abecd853d14599903f178609d03d96a1')]:
    ip = ROOT / f'helper/frobenius-transport/x8-production-{profile}-scheduled-v1/conditional-initial.json'
    rp = ROOT / f'hierarchy-transport/x8-production-{profile}-halfsteps-v11/run-binding.json'
    full = read(ip, ih); run = read(rp, rh)
    initial = {k: full[k] for k in ('schema','physical_source_admission_required','whole_PR11d_accuracy_claimed','raw_total_width_gate_passed')}
    assert 'physical_accuracy_certified' not in full
    assert initial == {'schema':'vakint.x8.conditional-guarded-ordinary-boundary.v1','physical_source_admission_required':True,'whole_PR11d_accuracy_claimed':False,'raw_total_width_gate_passed':True}
    assert run['initial_sha256'] == ih and run['driver_sha256'] == sha(NEW)
    assert run['physical_source_admission_required'] is True and run['conditional_initial_explicitly_authorized'] is True
    assert classify(initial, True) == {'accepted':True,'conditional':True}
    assert classify(initial, False)['accepted'] is False
    actual.append({'profile':profile,'initial_path':str(ip),'initial_sha256':ih,'run_binding_path':str(rp),'run_binding_sha256':rh,'initial_flags':initial,'physical_accuracy_certified_field_present':False,'explicit_opt_in_bound':True})
baseline = actual[0]['initial_flags']
for name, changes, optin, expected in [
    ('proper conditional explicit opt-in', {}, True, True),
    ('proper conditional without opt-in', {}, False, False),
    ('conditional wrong schema', {'schema':'unexpected'}, True, False),
    ('conditional whole-period claim', {'whole_PR11d_accuracy_claimed':True}, True, False),
    ('conditional failed total width', {'raw_total_width_gate_passed':False}, True, False),
    ('conditional-schema flags reset bypass', {'physical_source_admission_required':False,'physical_accuracy_certified':True}, False, True),
    ('nonboolean pending flag accepted', {'physical_source_admission_required':'pending'}, True, True)]:
    data = dict(baseline); data.update(changes); result = classify(data, optin)
    assert result['accepted'] is expected
    cases.append({'case':name,'observed':result})
data = dict(baseline); del data['physical_source_admission_required']; data.pop('physical_accuracy_certified',None)
result = classify(data, False); assert result == {'accepted':True,'conditional':False}
cases.append({'case':'conditional-schema both flags missing bypass','observed':result})
resume_cases = []
for physical in [False, True, 'missing']:
    following = {'physical_source_admission_required':True}
    if physical != 'missing': following['physical_accuracy_certified'] = physical
    exec(resume, {'following':following,'conditional':True})
    resume_cases.append({'physical_accuracy_certified':physical,'new_resume_metadata_gate_accepted':True})
# A missing/false pending flag does reject in the added resume gate.
for following in [{}, {'physical_source_admission_required':False}]:
    try: exec(resume, {'following':following,'conditional':True})
    except (KeyError, AssertionError): pass
    else: raise AssertionError('Expected pending-flag rejection')
validator = ROOT/'ancestor-flows/rpf-chain-acceptance-v1/validate.py'
admission = ROOT/'ancestor-flows/rpf-chain-acceptance-v1/initial_admission.py'
pin(validator); pin(admission)
assert "complete['schema'] == 'vakint.certified-X8-rpf-ordinary-transport.v10'" in validator.read_text()
assert "initial.get('physical_accuracy_certified', True) is not False" in admission.read_text()
pin(Path(__file__))
for p,h in PINS.items(): assert sha(p) == h
report = {
    'schema':'vakint.X8-v11-conditional-metadata-delta-independent-review.v1',
    'status':'numerical_AST_identical_actual_AB_conditional_profile_checked_generic_metadata_hardening_required',
    'accepted_for_numeric_delta_and_actual_AB_conditional_computation':True,
    'accepted_for_generic_fail_closed_conditional_source_policy':False,
    'accepted_for_physical_source_or_final_precision':False,
    'driver_sha256':sha(NEW),'predecessor_sha256':sha(OLD),
    'nonmetadata_AST_byte_identical':True,
    'numerical_recurrence_gauge_precision_serialization_and_error_gate_unchanged':True,
    'actual_AB_conditional_initials_and_explicit_opt_in_bound':actual,
    'removed_AST_metadata_nodes':{'v10':normalizers[0].removed,'v11':normalizers[1].removed},
    'initial_policy_cases':cases,'resume_policy_cases':resume_cases,
    'findings':[
        {'id':'conditional_schema_flag_consistency','line':18,'severity':'metadata admission hardening',
         'finding':'Classification trusts optional flag values before recognizing the conditional schema. Removing both flags or resetting them false/true admits a conditional-schema artifact through the ordinary branch without opt-in and would emit physical_accuracy_certified=true. Nonboolean truthy pending flags also pass.',
         'required_hardening':'A conditional-schema initial must require pending is True, physical_accuracy_certified is False, the exact schema, and explicit opt-in. Reject inconsistent/missing/malformed conditional markers.'},
        {'id':'resume_physical_accuracy_flag','line':70,'severity':'metadata admission hardening',
         'finding':'The added resume assertion checks pending identity only. A saved following boundary with physical_accuracy_certified=true or absent passes this metadata assertion. Fresh actual conditional outputs write false correctly.',
         'required_hardening':'Require pending is True and physical_accuracy_certified is False on every actual conditional boundary and complete output, including resumed nodes.'}],
    'actual_initial_flag_qualification':'Both frozen initial artifacts have exact conditional schema and pending=true, but physical_accuracy_certified is absent. Their pending flag correctly selects the conditional branch; freshly generated boundaries and complete outputs explicitly set physical_accuracy_certified=false. No false field is inferred to exist in either initial file.',
    'final_admission_obligation':'Frozen active v11 is computation only. A separate independently reviewed source-admission/chain validator must authenticate the actual conditional initial schema and pending=true, explicitly qualify the known absent physical flag on these two frozen initials using a bound additive contract, require pending=true and explicit physical_accuracy_certified=false on produced boundary/complete nodes, require separate admitted physical initial provenance, and verify the saved numerical chain. Existing frozen RPF-v1 initial admission requires a separately accepted source graph; its physical flag assertion alone does not reject these absent-flag initials. Its complete-schema gate accepts v10 only, not v11.',
    'actual_numerical_results_or_live_progress_not_reviewed':True,
    'source_pins':PINS,'native_preparer_HPL_or_transport_invoked':False,'producer_files_modified':False,
    'published_precision_cap_unchanged':200}
out = HERE/'review.json'; tmp = out.with_suffix('.json.tmp');tmp.write_text(json.dumps(report,indent=2)+'\n');tmp.replace(out)
print(sha(out))
