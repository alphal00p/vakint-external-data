#!/usr/bin/env python3
"""Strict, source-scoped region-to-epsilon/log boundary adapter.

This optional development helper evaluates no master on its own. Factor jets
must carry certified lower pole bounds and explicit contiguous known orders.
Missing data are errors, never zero. Regional slopes are combined before the
logarithmic epsilon lift; rational cancellations happen before data requests.
"""
from dataclasses import dataclass
from fractions import Fraction
import importlib.util
import hashlib,json,math
from pathlib import Path
from typing import Mapping
from flint import arb,fmpq

OWNER=Path('/shared/codex-1/vakint_rustred/workspace/precision-periods/pr11d/helper/exact_system.py')
spec=importlib.util.spec_from_file_location('pr11d_exact_owner',OWNER)
exact=importlib.util.module_from_spec(spec);spec.loader.exec_module(exact)
Rat,parse=exact.Rat,exact.parse
EPS='masters_4l::{}::epsilon'

class MissingCoefficient(ValueError):pass
class UncertifiedPoleBound(ValueError):pass

@dataclass(frozen=True)
class FactorJet:
    first_power:int
    coefficients:tuple
    pole_bound_proof:str
    source_identity:str

    def __post_init__(self):
        if type(self.first_power) is not int or not isinstance(self.coefficients,tuple) or not self.coefficients:
            raise ValueError('Factor jets need an integer lower power and explicit known coefficients')
        if not isinstance(self.pole_bound_proof,str) or not self.pole_bound_proof or not isinstance(self.source_identity,str) or not self.source_identity:
            raise UncertifiedPoleBound(self.source_identity)
        if any(not isinstance(x,arb) or not x.is_finite() for x in self.coefficients):
            raise ValueError('Every known coefficient must be an explicit finite Arb value')

    @property
    def last_power(self):return self.first_power+len(self.coefficients)-1

    def coefficient(self,power):
        if power<self.first_power:return arb(0) # certified absence, not extrapolation
        if power>self.last_power:
            raise MissingCoefficient(f'{self.source_identity}: requested epsilon^{power}; known through epsilon^{self.last_power}')
        return self.coefficients[power-self.first_power]


def valuation(r):
    if not r.num:return None
    return int(min(k[0] for k in r.num.to_dict())-min(k[0] for k in r.den.to_dict()))

def fraction(c):return Fraction(int(c.numerator),int(c.denominator))
def as_arb(c):return arb(fmpq(c.numerator,c.denominator))

def affine(text):
    r=parse(text,EPS,'x')
    if any(k[1] for p in [r.num,r.den] for k in p.to_dict()):raise ValueError('Unexpected second variable')
    d=r.den.to_dict()
    if set(d)!={(0,0)}:raise ValueError('Exponent denominator must be constant')
    dd=fraction(d[(0,0)]);n=r.num.to_dict()
    if any(k[0]>1 for k in n):raise ValueError('Exponent is not affine in epsilon')
    return fraction(n.get((0,0),fmpq(0)))/dd,fraction(n.get((1,0),fmpq(0)))/dd


def rational_coefficients(r,last):
    lo=valuation(r)
    if lo is None:return {}
    if lo>last:return {}
    if any(k[1] for p in [r.num,r.den] for k in p.to_dict()):raise ValueError('Prefactor depends on an unexpected variable')
    nd=r.num.to_dict();dd=r.den.to_dict();nv=min(k[0] for k in nd);dv=min(k[0] for k in dd)
    n={int(k[0]-nv):fraction(c) for k,c in nd.items()};d={int(k[0]-dv):fraction(c) for k,c in dd.items()}
    out=[]
    for i in range(last-lo+1):
        out.append((n.get(i,Fraction(0))-sum(d.get(j,Fraction(0))*out[i-j] for j in range(1,i+1)))/d[0])
    return {lo+i:c for i,c in enumerate(out)}


def validate_scope(data):
    if data.get('all_selected_slopes_combined_after_epsilon_expansion') is not True:
        raise ValueError('An inventory covering all slopes at the selected integer powers is required')
    if data.get('source_scoped_complete_outcomes') is not True:
        raise ValueError('Native per-request outcomes are required; coverage requests alone do not certify emitted rows')
    selectors={(int(r['component']),Fraction(r['integer_power'])) for r in data['selected_integer_power_scope']}
    if len(selectors)!=len(data['selected_integer_power_scope']):raise ValueError('Duplicate selectors')
    expected={(i,a,j) for i,a in selectors for j in range(len(data['regions']))}
    actual=set();witnesses={}
    for r in data['coverage']:
        i,a,j=int(r['component']),Fraction(r['integer_power']),int(r['region']);key=(i,a,j)
        if key in actual or key not in expected:raise ValueError('Duplicate or extraneous region witness')
        actual.add(key);witnesses[key]=r;lo=Fraction(r['leading_alpha']);beta=Fraction(r['leading_beta'])
        order=2*(a-lo)
        if order.denominator!=1 or r['required_half_order']!=order:raise ValueError('Wrong required half-order')
        reason='below_leading_intercept' if order<0 else 'native_expansion_requested'
        if r['exclusion']!=reason:raise ValueError('Wrong exclusion reason')
        if order>=0 and order>data['expansion_half_order']:raise ValueError('Incomplete native expansion depth')
        outcomes={'excluded_below_leading_intercept'} if order<0 else {'native_exact_zero_integrand','native_factorization_scaleless_zero','emitted_product_terms'}
        if r.get('outcome') not in outcomes:raise ValueError('Missing or invalid native request outcome')
    if actual!=expected:raise ValueError('Incomplete region coverage')
    emitted=set()
    for row in data['boundary_coefficients']:
        if Fraction(row['jacobian_determinant']) not in (Fraction(-1),Fraction(1)):
            raise ValueError('Nonunit Jacobians need an explicit dimensional Jacobian factor')
        alpha,beta=affine(row['inverse_eta_exponent']);i=int(row['component']);j=int(row['region'])
        if (i,alpha,j) not in actual:raise ValueError('Contribution lies outside the authenticated scope')
        key=(i,alpha,j)
        if key in emitted:raise ValueError('Duplicate emitted region/order row')
        emitted.add(key);witness=witnesses[key]
        if witness['outcome']!='emitted_product_terms':raise ValueError('Row contradicts recorded zero or excluded outcome')
        if row['half_order']!=witness['required_half_order'] or beta!=Fraction(witness['leading_beta']):
            raise ValueError('Contribution half-order or slope disagrees with witness')
    expected_emitted={key for key,w in witnesses.items() if w['outcome']=='emitted_product_terms'}
    if emitted!=expected_emitted:raise ValueError('Missing emitted region/order row')
    return selectors


class BoundaryLogJetMap:
    @classmethod
    def from_file(cls,path,expected_sha256):
        raw=Path(path).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=expected_sha256:raise ValueError('Boundary inventory checksum mismatch')
        return cls(json.loads(raw))

    def __init__(self,data,*,validate=True):
        self.selectors=validate_scope(data) if validate else {(int(r['component']),Fraction(r['integer_power'])) for r in data['selected_integer_power_scope']}
        self.dimension=len(data['basis'])
        groups={}
        for row in data['boundary_coefficients']:
            alpha,beta=affine(row['inverse_eta_exponent'])
            for product in row['products']:
                # Sorting preserves multiplicities while identifying commuting products.
                key=(int(row['component']),alpha,beta,tuple(sorted(product['factor_keys'])))
                groups[key]=groups.get(key,Rat(0))+parse(product['coefficient'],EPS,'x')
        self.terms=tuple((key,r) for key,r in groups.items() if r.num)

    def _log_terms(self,factors,upper_power,max_log_power=None):
        if max_log_power is not None and (type(max_log_power) is not int or max_log_power<0):
            raise ValueError('The optional maximum logarithmic power must be a nonnegative integer')
        merged={}
        for (i,alpha,beta,keys),r in self.terms:
            for key in keys:
                if key not in factors:raise MissingCoefficient('Missing factor capability: '+key)
            lo=valuation(r)+sum(factors[k].first_power for k in keys)
            stop=max(0,upper_power-lo+1)
            if max_log_power is not None:stop=min(stop,max_log_power+1)
            for ell in range(stop):
                if beta==0 and ell:continue
                w=beta**ell/Fraction(math.factorial(ell))
                scale=Rat(exact.CTX.constant(fmpq(w.numerator,w.denominator)))
                key=(i,alpha,ell,keys)
                merged[key]=merged.get(key,Rat(0))+r*scale
        return tuple((key,r) for key,r in merged.items() if r.num)

    def required_orders(self,factors:Mapping[str,FactorJet],upper_power:int,*,max_log_power=None):
        required={}
        for (component,alpha,ell,keys),r in self._log_terms(factors,upper_power,max_log_power):
            lows=[factors[k].first_power for k in keys];vr=valuation(r)
            if vr+sum(lows)>upper_power-ell:continue
            for key,lo in zip(keys,lows):
                high=upper_power-ell-vr-sum(lows)+lo
                required[key]=max(required.get(key,high),high)
        for key,high in required.items():factors[key].coefficient(high)
        return required

    def _term_coefficient(self,r,keys,factors,power):
        jets=[factors[k] for k in keys];vr=valuation(r);v=vr+sum(j.first_power for j in jets)
        if power<v:return arb(0)
        rc=rational_coefficients(r,power-sum(j.first_power for j in jets))
        result={p:as_arb(c) for p,c in rc.items() if c}
        for pos,jet in enumerate(jets):
            following=sum(j.first_power for j in jets[pos+1:]);next_result={}
            for a,c in result.items():
                high=power-following-a
                for b in range(jet.first_power,high+1):
                    if a+b>power-following:break
                    q=jet.coefficient(b)
                    next_result[a+b]=next_result.get(a+b,arb(0))+c*q
            result=next_result
        return result.get(power,arb(0))

    def evaluate(self,factors:Mapping[str,FactorJet],*,first_power=-4,last_power=1,max_log_power=None):
        if type(first_power) is not int or type(last_power) is not int or first_power>last_power:
            raise ValueError('Invalid requested Laurent range')
        self.required_orders(factors,last_power,max_log_power=max_log_power)
        # Keys are (component, integer z-power, raw epsilon-power, log-power).
        # No fixed log-width is assumed: deeper sector poles retain all logs.
        out={}
        for i,alpha in self.selectors:
            for p in range(first_power,last_power+1):
                for ell in range(1 if max_log_power is None else max_log_power+1):out[i,alpha,p,ell]=arb(0)
        for (i,alpha,ell,keys),r in self._log_terms(factors,last_power,max_log_power):
            lo=valuation(r)+sum(factors[k].first_power for k in keys)
            for p in range(first_power,last_power+1):
                if p-ell<lo:continue
                c=self._term_coefficient(r,keys,factors,p-ell)
                k=(i,alpha,p,ell);out[k]=out.get(k,arb(0))+c
        return out
