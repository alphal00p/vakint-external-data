"""Seal the independently reviewed, refined original-MMA development oracle."""
from pathlib import Path
import json,hashlib,re
ROOT=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Acceptance sealing requires assertions enabled')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
comparison=json.loads((ROOT/'baseline170-comparison.json').read_text());refined=json.loads((ROOT/'refined200-comparison.json').read_text())
assert comparison['practical_70_digit_solver_crosscheck_passed']
assert min(comparison['archived_reference_observed_real_agreed_digits_lower_bound'],comparison['imaginary_suppression_digits_lower_bound'],comparison['refinement_observed_agreed_digits_lower_bound'])>=100
assert comparison['native_prototype_observed_agreed_digits_lower_bound']>=70
independent=json.loads((ROOT/'independent-review/output-review.json').read_text());static=json.loads((ROOT/'independent-review/exact-review.json').read_text())
assert independent['practical_70_digit_solver_crosscheck_passed'] and not independent['physical_accuracy_certified'] and not independent['whole_PR11d_20000_accuracy_claimed']
assert static['status']=='PASS_exact_input_algorithm_and_central_parser_only'
assert independent['refinement_observed_scaled_complex_agreement_digits']>=100
independent_refined=next(row for row in independent['results'] if row['label']=='refined200')
assert min(independent_refined['archived_reference_observed_scaled_real_agreement_digits'],independent_refined['observed_scaled_imaginary_suppression_digits'])>=100
processes=[]
for label in ['baseline170','refined200']:
 process=json.loads((ROOT/f'{label}-process.json').read_text());result=json.loads((ROOT/f'{label}-result.json').read_text());assert process['exit_code']==0 and result['segments']==48
 assert process['peak_child_rss_kib']<8*1024**2
 assert result['solver_sha256']==sha(ROOT/'upstream/diffeq_solver/DESolver.m')=='0dfa7f91bd8b8d160412dbc3a8c076413e488745bcefe58bc434999d03f76a46'
 for filename,digest in process['source_sha256'].items():
  path=Path(filename)
  if label=='baseline170' and path==ROOT/'run.py':path=ROOT/'run-baseline170.py'
  assert sha(path)==digest,(label,path)
 log=(ROOT/(label+'.log')).read_text();assert not re.findall(r'\w+::\w+:',log),'Rejected Mathematica warning in accepted run '+label
 pole=json.loads((ROOT/f'{label}-pole-check.json').read_text());assert len(pole['coefficients'])==5 and pole['source_result_sha256']==sha(ROOT/f'{label}-result.json')
 processes.append({'label':label,'working_decimal_digits':result['working_digits'],'Taylor_order':result['taylor_order'],'solve_seconds':result['solve_seconds'],'wall_seconds':process['elapsed_seconds'],'peak_resident_memory_mib':process['peak_child_rss_kib']/1024,'process_sha256':sha(ROOT/f'{label}-process.json'),'result_sha256':sha(ROOT/f'{label}-result.json')})
input=json.loads((ROOT/'input.json').read_text());guard=json.loads((ROOT/'guard-validation.json').read_text());lift=json.loads((ROOT/'lift-validation.json').read_text())
assert guard['condition_count']==121 and lift['exact_epsilon_coefficient_checks']==10584 and lift['target_ordered_powers']==input['ordered_target_powers']
finiteness=json.loads((ROOT/'finiteness-validation.json').read_text());assert finiteness['target_powers']==input['ordered_target_powers'] and finiteness['maximum_UV_degree_at_d4']==-2 and finiteness['global_Wick_sign']==-1
summary={'schema':'vakint.pr11d.refined-original-AMFlow-oracle-acceptance.v1','status':'PASS_practical_100_digit_independent_ordinary_solver_crosscheck','master_id':input['master_id'],'epsilon_coefficient':0,'finite_real_central_value':refined['finite_real_central_value'],'finite_imaginary_central_value':refined['finite_imaginary_central_value'],'baseline_reference_observed_real_agreement_digits':comparison['archived_reference_observed_real_agreed_digits_lower_bound'],'refined_reference_observed_real_agreement_digits':refined['archived_reference_observed_real_agreed_digits_lower_bound'],'baseline_refinement_observed_complex_agreement_digits':comparison['refinement_observed_agreed_digits_lower_bound'],'refined_imaginary_suppression_digits':refined['imaginary_suppression_digits_lower_bound'],'native_prototype_observed_agreement_digits':comparison['native_prototype_observed_agreed_digits_lower_bound'],'source_error_quality':'validated-digits-estimate','physical_accuracy_certified':False,'whole_PR11d_20000_accuracy_claimed':False,'source_cap_changed':False,'independence_scope':input['scope'],'normalization':input['normalization'],'exact_P17_convergence_conditions':42,'retained_domain_guards':121,'exact_original_DE_coefficient_checks':10584,'actual_emitted_lift_entry_checks':63504,'resources':processes,'reference_is_postsolve_only':True,'optional_Mathematica_development_oracle_only':True,'source_hashes':{name:sha(ROOT/name) for name in ['input.json','finiteness-validation.json','guard-validation.json','lift-validation.json','path-convergence.json','reference-provenance.json','runner-provenance.json','baseline170-comparison.json','refined200-comparison.json','independent-review/exact-review.json','independent-review/output-review.json']}}
(ROOT/'acceptance.json').write_text(json.dumps(summary,indent=2)+'\n')
excluded={'wolfram-license','wolfram-userbase','tmp','__pycache__'}
files=[p for p in ROOT.rglob('*') if p.is_file() and p!=ROOT/'files.json' and not any(part in excluded for part in p.relative_to(ROOT).parts)]
manifest={'schema':'vakint.pr11d.original-AMFlow-oracle-files.v1','status':'sealed','acceptance_sha256':sha(ROOT/'acceptance.json'),'upstream_license_retained':True,'private_license_configuration_excluded':True,'files':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(files)]}
(ROOT/'files.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(summary,indent=2));print('SEALED',len(files),'development oracle files')
