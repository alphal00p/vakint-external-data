#!/usr/bin/env python3
"""Strict authenticated front end to the reviewed PR9 source assembler."""
import argparse,json,sys
from pathlib import Path
from flint import arb,ctx
from endpoint_sources import load_native_endpoints,sha
HERE=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--working-digits',type=int,default=20400)
    ap.add_argument('--three-loop-input',required=True);ap.add_argument('--three-loop-sha256',required=True)
    ap.add_argument('--maximum-constant-error-power',type=int,default=20240)
    ap.add_argument('--output-prefix',required=True);args=ap.parse_args()
    if args.working_digits<args.maximum_constant_error_power+40 or args.maximum_constant_error_power<1:
        raise ValueError('The guarded matching contract requires a fixed working-precision allowance')
    prefix=Path(args.output_prefix)
    if any(prefix.with_suffix(s).exists() for s in ['.json','.unmatched.json','.guard-validation.json']):
        raise ValueError('Preserve earlier source/matching evidence; choose a new output prefix')
    ctx.dps=args.working_digits;ctx.threads=1
    _,source=load_native_endpoints(args.three_loop_input,args.three_loop_sha256,{'native::L3_P13':(-3,2),'native::L3_P14':(-3,2)})
    original_argv=sys.argv
    try:
        sys.argv=[str(HERE/'pr9_boundary.py'),'--working-digits',str(args.working_digits),'--three-loop-input',str(Path(args.three_loop_input).resolve()),'--output-prefix',str(prefix.resolve())]
        from pr9_boundary import main as assemble
        assemble()
    finally:sys.argv=original_argv
    # Bind the exact accepted input again after assembly; any concurrent source
    # replacement invalidates this run rather than switching snapshots midway.
    if sha(args.three_loop_input)!=args.three_loop_sha256:raise ValueError('Accepted source changed during PR9 assembly')
    output=prefix.with_suffix('.json');data=json.loads(output.read_bytes())
    if data.get('error_quality')!='rigorous-bound' or not data.get('all_overdetermined_residuals_contain_zero'):
        raise ValueError('Complete bounded PR9 matching acceptance is required')
    values=[arb(s) for s in data['free_constant_balls']]
    if len(values)!=132 or any(not v.is_finite() for v in values):raise ValueError('132 finite matched constants required')
    threshold=(arb(10)**-args.maximum_constant_error_power).lower()
    maximum=max(v.rad() for v in values)
    if not maximum.upper()<threshold:
        raise ValueError('Measured PR9 source/matching error lacks the required guard; maximum='+maximum.str(35))
    receipt={'schema':'vakint.pr9.guarded-source-and-matching-acceptance.v1','accepted':True,'source':source,
      'boundary_sha256':sha(output),'matched_constants':132,'all557rows_consistent':True,
      'absolute_error_contract':'Every matched constant radius is below10^(-'+str(args.maximum_constant_error_power)+')',
      'maximum_constant_radius':maximum.upper().str(45,more=True),'working_decimal_digits':args.working_digits,
      'wrapper_sha256':sha(Path(__file__)),'assembler_sha256':sha(HERE/'pr9_boundary.py'),
      'whole_PR11d_accuracy_claimed':False}
    prefix.with_suffix('.guard-validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('ACCEPTED guarded PR9source: all132constant errors<10^-'+str(args.maximum_constant_error_power),flush=True)
if __name__=='__main__':main()
