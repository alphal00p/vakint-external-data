"""Independent rational-RREF and Schwinger-matroid finiteness check."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import hashlib, json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if not __debug__: raise RuntimeError("Exact audit requires assertions")
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
connection_path = ROOT.parent/"jet-transport/polynomial-connection.json"
connection = json.loads(connection_path.read_text())
source_path = Path(connection["source"])
source = json.loads(source_path.read_text())
assert sha(source_path) == connection["source_sha256"] == "a9ec06c3a076f3460e84ec3492ae314b29f4cf470dddbe2a5442b502f7181184"
input_path = ROOT/"input.json"
input_data = json.loads(input_path.read_text())
assert input_data["source_paths_sha256"][str(source_path)] == sha(source_path)
assert input_data["ordered_target_powers"] == [0,2,1,1,1,1,1,1,1,0]
assert source["family"]["external_momenta"] == []
proof_path = ROOT/"finiteness-validation.json"
proof = json.loads(proof_path.read_text())
assert proof["source_sha256"] == sha(source_path)

def rref(rows):
    rows = [list(map(F, row)) for row in rows]
    pivots, row = [], 0
    for col in range(4):
        candidate = next((j for j in range(row, len(rows)) if rows[j][col]), None)
        if candidate is None: continue
        rows[row], rows[candidate] = rows[candidate], rows[row]
        scale = rows[row][col]
        rows[row] = [v/scale for v in rows[row]]
        for j in range(len(rows)):
            if j != row and rows[j][col]:
                scale = rows[j][col]
                rows[j] = [v-scale*w for v, w in zip(rows[j], rows[row])]
        pivots.append(col)
        row += 1
    return rows[:row], pivots

def kernel(rows):
    rows, pivots = rref(rows)
    result = []
    for col in range(4):
        if col in pivots: continue
        v = [F(0)]*4
        v[col] = 1
        for row, pivot in zip(rows, pivots): v[pivot] = -row[col]
        result.append(v)
    return result

def determinant(rows):
    rows = [list(map(F, row)) for row in rows]
    d = F(1)
    for col in range(4):
        candidate = next((j for j in range(col, 4) if rows[j][col]), None)
        if candidate is None: return F(0)
        if candidate != col:
            rows[col], rows[candidate] = rows[candidate], rows[col]
            d = -d
        pivot = rows[col][col]
        d *= pivot
        for j in range(col+1, 4):
            scale = rows[j][col]/pivot
            rows[j] = [a-scale*b for a, b in zip(rows[j], rows[col])]
    return d

# Independently pin the eight physical forms. Verify all ten quadratic-form
# coefficients against the source, so a favorable but different graph cannot
# enter this finiteness argument.
momenta = [[0,1,0,0],[0,0,1,0],[0,0,0,1],[1,0,-1,0],
           [0,1,-1,0],[1,0,-1,-1],[0,1,-1,-1],[1,1,-1,-1]]
slots = list(range(1,9))
powers = [2,1,1,1,1,1,1,1]
coords = [(i,j) for i in range(4) for j in range(i,4)]
for slot, vector in zip(slots, momenta):
    denominator = source["family"]["denominators"][slot]
    assert F(denominator["constant"]) == -1
    expected = [vector[i]*vector[j]*(1 if i == j else 2) for i,j in coords]
    assert list(map(F, denominator["coefficients"])) == expected
    assert proof["active_momenta"][slot-1] == {"slot":slot,"momentum":vector,"power":powers[slot-1]}
assert sum(powers) == 9 and len(rref(momenta)[1]) == 4

flats, checks = {}, 0
for soft_mask in range(256):
    soft = [v for i,v in enumerate(momenta) if soft_mask >> i & 1]
    K = kernel(soft)
    assert all(sum(a*b for a,b in zip(q,w)) == 0 for q in soft for w in K)
    if not K: continue
    hard = [i for i,v in enumerate(momenta) if any(sum(a*b for a,b in zip(v,w)) for w in K)]
    degree = 4*len(K)-2*sum(powers[i] for i in hard)
    assert degree <= -2
    record = {"hard_line_slots":[slots[i] for i in hard],"hard_loop_subspace_dimension":len(K),"hard_denominator_power_sum":sum(powers[i] for i in hard),"UV_degree_at_d4":degree}
    key = tuple(record["hard_line_slots"])
    assert key not in flats or flats[key] == record
    flats[key] = record
    checks += 1
conditions = sorted(flats.values(), key=lambda r:(r["hard_loop_subspace_dimension"],r["hard_line_slots"]))
assert checks == proof["nonzero_hard_subspace_checks"] == 122
assert len(flats) == proof["distinct_hard_flat_conditions"] == 42
assert conditions == proof["conditions"]
assert max(r["UV_degree_at_d4"] for r in conditions) == proof["maximum_UV_degree_at_d4"] == -2
assert proof["enumerated_soft_line_subsets"] == 256

# A second route works directly with Schwinger parameters. By Cauchy-Binet,
# U = det(sum alpha_i q_i q_i^T) = sum_B det(Q_B)^2 product_{i in B} alpha_i.
# Each face T -> 0 has U-order4-rank(complement T), verified against every
# actual basis monomial rather than assumed from a kernel implementation.
bases = []
for subset in combinations(range(8),4):
    det = determinant([momenta[i] for i in subset])
    if det:
        assert abs(det) == 1
        bases.append(subset)
assert len(bases) == 45
face_checks, margins = [], []
for small_mask in range(1,256):
    small = {i for i in range(8) if small_mask >> i & 1}
    complement = [v for i,v in enumerate(momenta) if i not in small]
    rank = len(rref(complement)[1])
    order = min(len(set(B)&small) for B in bases)
    assert order == 4-rank
    margin = sum(powers[i] for i in small)-2*order
    assert margin >= 1
    face_checks.append({"small_line_slots":[slots[i] for i in sorted(small)],"schwinger_U_vanishing_order":order,"measure_minus_U_power_margin_at_d4":margin})
    margins.append(margin)
assert proof["global_Wick_sign"] == (-1)**sum(powers) == -1

result = {
    "schema":"vakint.pr11d.independent-exact-finiteness-review.v1",
    "status":"PASS_exact_massive_Euclidean_convergence",
    "loop_rank":4,"active_lines":8,"total_denominator_power":9,
    "unit_mass_squared":1,"all_original_quadratic_forms_verified":True,
    "soft_line_subsets":256,"nonzero_kernel_checks":checks,
    "distinct_flat_conditions":len(flats),"maximum_UV_degree":-2,
    "independent_Schwinger_basis_monomials":len(bases),
    "independent_Schwinger_scaling_face_checks":len(face_checks),
    "minimum_Schwinger_measure_margin":min(margins),
    "global_Wick_sign":-1,
    "analyticity_reason":"All positive unit masses exclude IR singularities. Cauchy-Binet gives a positive45monomial U; every proper Schwinger face has strictly positive measure margin at epsilon0. Sector decomposition into ordered alpha coordinates uses these strict subset inequalities for every nested prefix, giving an integrable majorant in an epsilon neighborhood. Overall Gamma(A-Ld/2)=Gamma(1+4epsilon) is analytic there.",
    "arbitrary_subspace_exhaustion":"For any nonzero hard-loop subspace S, all propagator forms annihilating S define a kernel Sstar containing S. Every other form remains nonzero on Sstar; its denominator-power sum is unchanged and its loop dimension can only increase. Thus its flat kernel is at least as UV-dangerous and is included among the256subsets.",
    "normalization_consequence":"P17 has no negative epsilon powers; multiplying native raw by exp(4 EulerGamma epsilon) preserves its finite coefficient exactly. This proof uses no numerically small pole.",
    "whole_PR11d_numerical_accuracy_claimed":False,
    "source_sha256":{str(p):sha(p) for p in [HERE/"audit_finiteness.py",ROOT/"check_finiteness.py",proof_path,connection_path,source_path,input_path]},
    "Schwinger_face_checks":face_checks,
}
(HERE/"finiteness-review.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({k:v for k,v in result.items() if k not in ["source_sha256","Schwinger_face_checks"]},indent=2))
