#!/usr/bin/env python3
"""Checked exact-expression trees for optional boundary-source producers."""
from dataclasses import dataclass
import ast
from fractions import Fraction
import re
from flint import arb,fmpq,fmpq_mpoly_ctx
from gamma_jets import GammaRecipe,GammaArgument,Rat,rat,E
from logjet_map import exact

def integer(x):
    if type(x) is int:return x
    if isinstance(x,str) and re.fullmatch(r'-?[0-9]+',x):return int(x)
    raise ValueError('An explicit integer is required')

@dataclass(frozen=True)
class Monomial:
    rational:object
    gammas:tuple=()
    primitives:tuple=()

    def multiply(self,other):
        return Monomial(self.rational*other.rational,self.gammas+other.gammas,self.primitives+other.primitives)
    def power(self,n):
        if self.primitives and n<0:raise ValueError('Inverse finite primitives are not supported by this source provider')
        if n<0:
            gs=tuple(GammaArgument(g.intercept,g.slope,g.exponent*n) for g in self.gammas)
            return Monomial(self.rational**n,gs)
        return Monomial(self.rational**n,tuple(GammaArgument(g.intercept,g.slope,g.exponent*n) for g in self.gammas),self.primitives*n)

def parse_tree(node):
    if not isinstance(node,dict) or len(node)!=1:raise ValueError('Each source expression node must have one checked operation')
    op,value=next(iter(node.items()))
    if op=='integer':return [Monomial(rat(integer(value)))]
    if op=='rational':
        if not isinstance(value,list) or len(value)!=2:raise ValueError('A rational requires numerator and denominator')
        return [Monomial(rat(Fraction(integer(value[0]),integer(value[1]))))]
    if op=='epsilon_rational':
        if set(value)!={'numerator','denominator'}:raise ValueError('Invalid epsilon-rational node')
        def poly(xs):
            if not isinstance(xs,list) or not xs:raise ValueError('Explicit ascending polynomial coefficients are required')
            qq=[Fraction(x) for x in xs]
            return exact.CTX.from_dict({(i,0):fmpq(x.numerator,x.denominator) for i,x in enumerate(qq) if x})
        return [Monomial(Rat(poly(value['numerator']),poly(value['denominator'])))]
    if op=='gamma':
        if set(value)!={'constant','epsilon'}:raise ValueError('Invalid affine-Gamma node')
        a,b=Fraction(value['constant']),Fraction(value['epsilon'])
        if a.denominator!=1:raise ValueError('Noninteger Gamma intercept requires a separate checked kernel')
        return [Monomial(Rat(1),(GammaArgument(a.numerator,b,1),))]
    if op=='primitive':
        if not isinstance(value,str) or not value:raise ValueError('A qualified primitive source identity is required')
        return [Monomial(Rat(1),(),(value,))]
    if op=='sum':
        if not isinstance(value,list) or not value:raise ValueError('An explicit nonempty sum is required')
        return [term for child in value for term in parse_tree(child)]
    if op=='product':
        if not isinstance(value,list) or not value:raise ValueError('An explicit nonempty product is required')
        out=[Monomial(Rat(1))]
        for child in value:
            terms=parse_tree(child);out=[a.multiply(b) for a in out for b in terms]
        return out
    if op=='power':
        if set(value)!={'base','exponent'}:raise ValueError('Invalid integer-power node')
        terms=parse_tree(value['base']);n=integer(value['exponent'])
        if n==0:return [Monomial(Rat(1))]
        if len(terms)==1:return [terms[0].power(n)]
        if n<0:raise ValueError('A sum cannot be inverted without an authenticated algebraic reduction')
        out=[Monomial(Rat(1))]
        for _ in range(n):out=[a.multiply(b) for a in out for b in terms]
        return out
    raise ValueError('Unsupported source expression operation: '+op)

class GammaExpression:
    def __init__(self,terms,*,identity):
        merged={}
        for term in terms:
            recipe=GammaRecipe(term.rational,term.gammas,identity=identity)
            key=(tuple(sorted(recipe.slopes.items())),tuple(sorted(term.primitives)))
            merged[key]=merged.get(key,Rat(0))+recipe.rational
        self.terms=tuple((r,slopes,primitives) for (slopes,primitives),r in merged.items() if r.num)
        self.identity=identity

    @classmethod
    def from_tree(cls,node,*,identity):return cls(parse_tree(node),identity=identity)

    def monomials(self):
        return [Monomial(r,tuple(GammaArgument(1,b,n) for b,n in slopes),primitives) for r,slopes,primitives in self.terms]

    def multiply(self,other):
        return GammaExpression([a.multiply(b) for a in self.monomials() for b in other.monomials()],identity=self.identity+' * '+other.identity)

    def scale(self,value):
        return GammaExpression([Monomial(m.rational*value,m.gammas,m.primitives) for m in self.monomials()],identity=self.identity)

    def add(self,other):
        return GammaExpression(self.monomials()+other.monomials(),identity=self.identity+' + '+other.identity)

    def multiply_recipe(self,recipe):
        terms=[]
        for r,slopes,primitives in self.terms:
            gs=tuple(GammaArgument(1,b,n) for b,n in slopes)
            terms.append(Monomial(r*recipe.prefactor,gs+recipe.gammas,primitives))
        return GammaExpression(terms,identity=self.identity+'; '+recipe.identity)

    def gamma_only_recipe_terms(self):
        out=[]
        for r,slopes,primitives in self.terms:
            if primitives:raise ValueError('A finite primitive callback is required: '+','.join(primitives))
            out.append(GammaRecipe(r,[GammaArgument(1,b,n) for b,n in slopes],identity=self.identity))
        return out

    def formal_gamma_coefficients(self,through):
        recipes=self.gamma_only_recipe_terms()
        if not recipes:return {}
        first=min(r.first_power for r in recipes)
        if through<first:return {}
        depth=through-first;names=('EulerGamma',)+tuple('zeta'+str(k) for k in range(2,max(2,depth+1)))
        context=fmpq_mpoly_ctx.get(names);zero=context.constant(0)
        formal={p:zero for p in range(first,through+1)}
        for recipe in recipes:
            for p,c in recipe.exact_polynomial_coefficients(through,context).items():formal[p]+=c
        return formal

    def grouped_primitive_coefficients(self):
        groups={}
        for r,slopes,keys in self.terms:
            groups.setdefault(keys,[]).append(Monomial(r,tuple(GammaArgument(1,b,n) for b,n in slopes)))
        return {keys:GammaExpression(terms,identity=self.identity+'; exact primitive multiplier') for keys,terms in groups.items()}

    def required_primitive_orders(self,through,primitives,*,check=True):
        required={}
        for keys,multiplier in self.grouped_primitive_coefficients().items():
            for key in keys:
                if key not in primitives:raise ValueError('Missing primitive source capability: '+key)
            lows=[primitives[k].first_power for k in keys]
            # Different Gamma monomials can cancel at several leading epsilon
            # orders. Certify those zeros symbolically before requesting finite
            # primitive coefficients; numerical near-zero is never sufficient.
            formal=multiplier.formal_gamma_coefficients(through-sum(lows))
            nonzero=[p for p,c in formal.items() if c]
            if not nonzero:continue
            first=min(nonzero)
            for key,lo in zip(keys,lows):
                high=through-first-sum(lows)+lo
                required[key]=max(required.get(key,high),high)
        if check:
            for key,high in required.items():primitives[key].coefficient(high)
        return required

    def factor_jet(self,through,*,primitives=None):
        from logjet_map import FactorJet
        primitives={} if primitives is None else primitives
        self.required_primitive_orders(through,primitives)
        if not self.terms:
            return FactorJet(0,tuple(arb(0) for _ in range(max(0,through)+1)),
              'Exact algebraic cancellation of the complete authenticated expression tree',self.identity)
        if any(keys for _,_,keys in self.terms):
            combined={};first=None
            for keys,multiplier in self.grouped_primitive_coefficients().items():
                jets=[primitives[k] for k in keys]
                gamma_through=through-sum(j.first_power for j in jets)
                formal=multiplier.formal_gamma_coefficients(gamma_through)
                nonzero=[p for p,c in formal.items() if c]
                if not nonzero:continue
                gamma_jet=multiplier.factor_jet(gamma_through)
                terms={p:gamma_jet.coefficient(p) for p in range(min(nonzero),gamma_through+1)}
                group_first=min(nonzero)+sum(j.first_power for j in jets)
                first=group_first if first is None else min(first,group_first)
                for pos,jet in enumerate(jets):
                    following=sum(j.first_power for j in jets[pos+1:]);next_terms={}
                    for a,c in terms.items():
                        for b in range(jet.first_power,through-following-a+1):
                            p=a+b;next_terms[p]=next_terms.get(p,arb(0))+c*jet.coefficient(b)
                    terms=next_terms
                for p,c in terms.items():combined[p]=combined.get(p,arb(0))+c
            if first is None:
                lower=min((r.first_power+sum(primitives[k].first_power for k in keys)
                  for keys,multiplier in self.grouped_primitive_coefficients().items()
                  for r in multiplier.gamma_only_recipe_terms()),default=through)
                lower=min(lower,through)
                return FactorJet(lower,tuple(arb(0) for _ in range(through-lower+1)),
                  'Exact formal Gamma multiplier cancellations prove every requested coefficient vanishes',self.identity)
            return FactorJet(first,tuple(combined.get(p,arb(0)) for p in range(first,through+1)),
              'Exact formal Gamma multiplier pole bounds and explicitly certified primitive support',self.identity)
        term_data=[(r,[]) for r in self.gamma_only_recipe_terms()]
        first=min(r.first_power+sum(j.first_power for j in jets) for r,jets in term_data)
        if through<first:raise ValueError('Requested range lies below the certified Gamma-expression support')
        coeff={p:arb(0) for p in range(first,through+1)}
        for recipe,jets in term_data:
            terms=recipe.coefficients(through-sum(j.first_power for j in jets))
            for pos,jet in enumerate(jets):
                following=sum(j.first_power for j in jets[pos+1:]);next_terms={}
                for a,c in terms.items():
                    high=through-following-a
                    for b in range(jet.first_power,high+1):
                        p=a+b
                        next_terms[p]=next_terms.get(p,arb(0))+c*jet.coefficient(b)
                terms=next_terms
            for p,c in terms.items():coeff[p]+=c
        if all(not jets for _,jets in term_data):
            formal=self.formal_gamma_coefficients(through)
            for p,c in formal.items():
                if not c:coeff[p]=arb(0)
            nonzero=[p for p in range(first,through+1) if formal[p]]
            if nonzero:first=min(nonzero)
        return FactorJet(first,tuple(coeff[p] for p in range(first,through+1)),
          'Finite exact sum of affine-Gamma recurrences and explicitly certified primitive jets; each lower pole follows from exact epsilon divisors and the primitive source certificate',self.identity)

def from_basis_expression(text,*,epsilon_symbol='ep',primitive_prefix='native::'):
    """Read only rational arithmetic and explicitly named primitive symbols."""
    tree=ast.parse(text.replace('vakint::{}::','').replace('^','**'),mode='eval')
    def convert(n):
        if isinstance(n,ast.Constant) and type(n.value) is int:return [Monomial(rat(n.value))]
        if isinstance(n,ast.Name):
            if n.id==epsilon_symbol:return [Monomial(E)]
            return [Monomial(Rat(1),(),(primitive_prefix+n.id,))]
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):
            return [Monomial(-m.rational,m.gammas,m.primitives) for m in convert(n.operand)]
        if not isinstance(n,ast.BinOp):raise ValueError('Unsupported catalog expression node '+ast.dump(n))
        a=GammaExpression(convert(n.left),identity='catalog subexpression').monomials()
        if isinstance(n.op,ast.Pow):
            sign=-1 if isinstance(n.right,ast.UnaryOp) and isinstance(n.right.op,ast.USub) else 1
            v=n.right.operand if sign==-1 else n.right
            if not isinstance(v,ast.Constant) or type(v.value) is not int or len(a)!=1:raise ValueError('Explicit monomial integer power required')
            return [a[0].power(sign*v.value)]
        b=GammaExpression(convert(n.right),identity='catalog subexpression').monomials()
        if isinstance(n.op,ast.Add):return a+b
        if isinstance(n.op,ast.Sub):return a+[Monomial(-m.rational,m.gammas,m.primitives) for m in b]
        if isinstance(n.op,ast.Mult):return [x.multiply(y) for x in a for y in b]
        if isinstance(n.op,ast.Div):
            if len(b)!=1:raise ValueError('Denominator must be one exact monomial')
            return [x.multiply(b[0].power(-1)) for x in a]
        raise ValueError('Unsupported catalog arithmetic '+ast.dump(n))
    return GammaExpression(convert(tree.body),identity=text)
