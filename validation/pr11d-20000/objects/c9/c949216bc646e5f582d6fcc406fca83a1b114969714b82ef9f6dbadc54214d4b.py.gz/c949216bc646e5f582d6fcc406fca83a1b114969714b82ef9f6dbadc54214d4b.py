#!/usr/bin/env python3
"""Bounded contracted Fuchsian/log-series pilot; no physical boundary claim."""
from collections import defaultdict
from fractions import Fraction as Q
import argparse,hashlib,json,math,resource,time
from pathlib import Path
from flint import arb,acb,ctx,fmpq,fmpq_mat
if not __debug__:raise RuntimeError('Assertions are required')
HERE=Path(__file__).resolve().parent
INPUT=HERE.parents[1]/'infinity-matching'
RAW=Path('/shared/codex-2/vacuum_masters/MASTERS/4L/artifacts/X8-Kira-derivative-closure-v1/prepared-system.json')

def aq(x):
    x=Q(x);return arb(fmpq(x.numerator,x.denominator))
def cq(x):return acb(aq(x[0]),aq(x[1]))
def cmul(a,b):return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def cscale(a,b):return (a[0]*b,a[1]*b)
def upper(x):return x.upper()
def absupper(x):return abs(x).upper()
def zeros(logs,dim):return [[acb(0) for _ in range(dim)] for _ in range(logs)]

class System:
    def __init__(self,z0):
        self.z0=z0;self.files={name:INPUT/name for name in ['polynomial-normalized-connection.json','exact-startup-coefficients.json','exact-boundary-matching.json']}
        self.poly=json.loads(self.files['polynomial-normalized-connection.json'].read_text());self.startup=json.loads(self.files['exact-startup-coefficients.json'].read_text());self.match=json.loads(self.files['exact-boundary-matching.json'].read_text())
        assert self.poly['matching_data_sha256']==hashlib.sha256(self.files['exact-boundary-matching.json'].read_bytes()).hexdigest()
        assert self.poly['startup_data_sha256']==hashlib.sha256(self.files['exact-startup-coefficients.json'].read_bytes()).hexdigest()
        assert self.startup['source_matching_sha256']==self.poly['matching_data_sha256']
        assert self.poly['dimension']==252 and self.poly['generic_maximum_log_degree']==8
        self.dim=252;self.logs=9;self.degree=12
        # z0 purely imaginary: all finite denominator poles are real, so the
        # normalized d(z0*t)=D(z0*t)/(z0*t*D1) has modulus at least one.
        assert z0[0]==0 and z0[1]!=0
        original=[Q(x) for x in self.poly['denominator_coefficients']]
        from flint import fmpq_poly
        fac=fmpq_poly([fmpq(x.numerator,x.denominator) for x in original[1:]]).factor()[1]
        assert all(p.degree()==1 and p[0] for p,_ in fac)
        self.powers=[(Q(1),Q(0))]
        for _ in range(12):self.powers.append(cmul(self.powers[-1],z0))
        self.dq=[cscale(self.powers[k],value/original[1]) for k,value in enumerate(original[1:])]
        self.d=[cq(x) for x in self.dq]
        self.B=[[] for _ in range(13)];self.Bq=[{} for _ in range(13)]
        for entry in self.poly['entries']:
            row,col=entry['row'],entry['column']
            for term in entry['terms']:
                k=term['z_power'];q=Q(int(term['numerator']),int(term['denominator']))/original[1]
                value=cscale(self.powers[k],q)
                self.B[k].append((row,col,cq(value)));self.Bq[k][row,col]=value
        self.R={key:q[0] for key,q in self.Bq[0].items()};assert all(q[1]==0 for q in self.Bq[0].values())
        original_blocks=json.loads(RAW.read_text())['differential_blocks']
        self.blocks=[[42*jet+i for i in block] for block in original_blocks for jet in range(6)]
        self.block_of={i:b for b,indices in enumerate(self.blocks) for i in indices};assert len(self.block_of)==252
        assert max(map(len,self.blocks))<=3
        assert all(self.block_of[c]<=self.block_of[r] for matrix in self.B for r,c,_ in matrix)
        self.same=[];self.off=[]
        for block in self.blocks:
            self.same.append(tuple(tuple(self.R.get((r,c),Q(0)) for c in block) for r in block))
            self.off.append([(r,c,aq(v)) for (r,c),v in self.R.items() if r in block and self.block_of[c]<self.block_of[r]])
        # H=(B-R*d)/(t*d). Exact coefficient cancellation precedes bounds.
        hsum=defaultdict(lambda:arb(0))
        for k in range(1,13):
            keys=set(self.Bq[k]) | (set(self.R) if k<len(self.dq) else set())
            for key in keys:
                b=self.Bq[k].get(key,(Q(0),Q(0)))
                rd=cscale(self.dq[k],self.R.get(key,Q(0))) if k<len(self.dq) else (Q(0),Q(0))
                q=(b[0]-rd[0],b[1]-rd[1])
                hsum[key]+=absupper(cq(q))
        self.M=defaultdict(lambda:arb(0))
        for key,value in hsum.items():self.M[key]=upper(value)
        for key,value in self.R.items():self.M[key]=upper(self.M[key]+abs(aq(value)))
        self.Mrows=[[] for _ in range(252)]
        for (r,c),v in self.M.items():self.Mrows[r].append((c,v))
        self.mu=[]
        for b,block in enumerate(self.blocks):
            self.mu.append(max((upper(sum((v for c,v in self.Mrows[r] if self.block_of[c]==b),arb(0))) for r in block)))
        self.logbounds=[arb(1)]+[upper((arb(k)/arb(1).exp())**k) for k in range(1,9)]

    def initialize(self,constants):
        assert len(constants)==252 and all(x.is_finite() for x in constants)
        hist=[zeros(self.logs,self.dim) for _ in range(13)]
        for row in self.startup['coefficients']:
            n,ell=row['normalized_z_power'],row['log_power'];assert -8<=n<=0 and 0<=ell<=8
            for i,j,q in row['entries']:hist[n%13][ell][i]+=aq(q)*constants[j]
        logz=cq(self.z0).log();logpowers=[acb(1)]
        for _ in range(8):logpowers.append(logpowers[-1]*logz)
        total=[acb(0) for _ in range(252)]
        for n in range(-8,1):
            old=hist[n%13];new=zeros(9,252);factor=cq(self.z0)**n
            for k in range(9):
                for ell in range(k,9):
                    scale=math.comb(ell,k)*logpowers[ell-k]*factor
                    for i,value in enumerate(old[ell]):
                        if not value.is_zero():new[k][i]+=scale*value
            hist[n%13]=new
            total=[a+b for a,b in zip(total,new[0])]
        return hist,total

    def next(self,n,hist):
        force=zeros(9,252)
        for k in range(1,13):
            index=n-k
            if index < -8:continue
            prior=hist[index%13]
            for row,col,value in self.B[k]:
                for ell in range(9):
                    if not prior[ell][col].is_zero():force[ell][row]+=value*prior[ell][col]
        for k in range(1,len(self.d)):
            index=n-k
            if index < -8:continue
            prior=hist[index%13]
            for ell in range(9):
                for i in range(252):
                    v=index*prior[ell][i]
                    if ell<8:v+=(ell+1)*prior[ell+1][i]
                    if not v.is_zero():force[ell][i]-=self.d[k]*v
        inverse={}
        for matrix in self.same:
            if matrix in inverse:continue
            a=fmpq_mat([[fmpq((Q(n if i==j else 0)-v).numerator,(Q(n if i==j else 0)-v).denominator) for j,v in enumerate(row)] for i,row in enumerate(matrix)])
            inv=a.inv();inverse[matrix]=[[arb(inv[i,j]) for j in range(inv.ncols())] for i in range(inv.nrows())]
        result=zeros(9,252)
        for ell in range(8,-1,-1):
            rhs=force[ell]
            if ell<8:rhs=[a-(ell+1)*b for a,b in zip(rhs,result[ell+1])]
            for b,block in enumerate(self.blocks):
                for row,col,value in self.off[b]:rhs[row]+=value*result[ell][col]
                inv=inverse[self.same[b]]
                for i,row in enumerate(block):result[ell][row]=sum((inv[i][j]*rhs[col] for j,col in enumerate(block)),acb(0))
        return result

    def certify(self,m,hist):
        forcing=[arb(0) for _ in range(252)]
        for power in range(m+1,m+13):
            residual=zeros(9,252)
            for k,d in enumerate(self.d):
                n=power-k
                if not -8<=n<=m:continue
                prior=hist[n%13]
                for ell in range(9):
                    for i in range(252):
                        v=n*prior[ell][i]
                        if ell<8:v+=(ell+1)*prior[ell+1][i]
                        if not v.is_zero():residual[ell][i]+=d*v
            for k,matrix in enumerate(self.B):
                n=power-k
                if not -8<=n<=m:continue
                prior=hist[n%13]
                for row,col,value in matrix:
                    for ell in range(9):
                        if not prior[ell][col].is_zero():residual[ell][row]-=value*prior[ell][col]
            for ell,row in enumerate(residual):
                for i,value in enumerate(row):forcing[i]+=absupper(value)*self.logbounds[ell]
        budgets=[arb(0) for _ in self.blocks]
        for b,block in enumerate(self.blocks):
            denominator=arb(m)-self.mu[b]
            if not denominator>0:return None
            need=arb(0)
            for row in block:
                value=forcing[row]
                for col,bound in self.Mrows[row]:
                    if self.block_of[col]<b:value+=bound*budgets[self.block_of[col]]
                need=max(need,upper(value))
            budgets[b]=upper(need/denominator)
        return budgets

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--digits',type=int,default=100);ap.add_argument('--guard',type=int,default=100);ap.add_argument('--eta-imag',type=int,default=256);ap.add_argument('--max-order',type=int,default=300);ap.add_argument('--check-every',type=int,default=20);ap.add_argument('--output',required=True);a=ap.parse_args()
    resource.setrlimit(resource.RLIMIT_AS,(2<<30,2<<30));ctx.dps=a.digits+a.guard;ctx.threads=1
    started=time.time();system=System((Q(0),-Q(1,a.eta_imag)));constants=[acb(1) for _ in range(252)]
    hist,total=system.initialize(constants);setup=time.time()-started;print('setup_seconds',setup,flush=True)
    target=arb(10)**(-a.digits)/100;accepted=False;certificate_seconds=0
    for m in range(1,a.max_order+1):
        value=system.next(m,hist);hist[m%13]=value;total=[x+y for x,y in zip(total,value[0])]
        if m%a.check_every==0:
            tick=time.time();budget=system.certify(m,hist);certificate_seconds+=time.time()-tick
            maximum=max(budget) if budget else None
            print('order',m,'seconds',time.time()-started,'tail',maximum.str(8) if maximum is not None else 'unavailable',flush=True)
            if maximum is not None and maximum<target:accepted=True;break
    if accepted:
        total=[z+acb(arb(0,budget[system.block_of[i]]),arb(0,budget[system.block_of[i]])) for i,z in enumerate(total)]
    original=[z*aq(scale)*cq(system.z0)**weight for z,scale,weight in zip(total,system.match['gauge_scales'],system.match['gauge_weights'])]
    out={'schema':'vakint.pr11d.contracted-frobenius-synthetic-pilot.v1','local_tail_certified':accepted,'synthetic_constants':'all252equalone','physical_PR11d_claimed':False,'digits':a.digits,'working_digits':ctx.dps,'eta_center':['0',str(a.eta_imag)],'z_center':['0',str(-Q(1,a.eta_imag))],'maximum_log_degree':8,'order':m,'seconds':time.time()-started,'setup_seconds':setup,'certificate_seconds':certificate_seconds,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'normalized_J_values':[[z.real.str(a.digits+40),z.imag.str(a.digits+40)] for z in total],'original_Y_values':[[z.real.str(a.digits+40),z.imag.str(a.digits+40)] for z in original],'source_sha256':{name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in system.files.items()},'implementation_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    Path(a.output).write_text(json.dumps(out,indent=2)+'\n')
    if not accepted:raise SystemExit(1)
if __name__=='__main__':main()
