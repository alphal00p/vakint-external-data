"""Exact unit-mass Euclidean UV power counting for the P17 target."""
from pathlib import Path
from itertools import combinations
from fractions import Fraction as F
import json,hashlib
from flint import fmpq_mat,fmpz_mat
ROOT=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Exact convergence validation requires assertions')
input=json.loads((ROOT/'input.json').read_text());connection=json.loads((ROOT.parent/'jet-transport/polynomial-connection.json').read_text());source_path=Path(connection['source']);source=json.loads(source_path.read_text());family=source['family'];powers=input['ordered_target_powers'];coords=[(i,j) for i in range(4) for j in range(i,4)]
assert source['source_family_sha256']=='693719b1bc3d2f1d4d32c9312df66ced667a542591a2ada6f6498844fc5d0de1' and family['external_momenta']==[]
lines=[]
for slot,(p,a) in enumerate(zip(family['denominators'],powers,strict=True)):
 if not a:continue
 assert a>0 and p['constant']=='-1';coeff=list(map(F,p['coefficients']));pivot=next(i for i in range(4) if coeff[coords.index((i,i))]);assert coeff[coords.index((pivot,pivot))]==1
 q=[coeff[coords.index(tuple(sorted((i,pivot))))]/(1 if i==pivot else 2) for i in range(4)];assert all(x.denominator==1 for x in q);q=list(map(int,q))
 assert [F(q[i]*q[j]*(1 if i==j else 2)) for i,j in coords]==coeff
 lines.append({'slot':slot,'momentum':q,'power':a})
assert len(lines)==8 and sum(powers)==9
seen={};checks=0
for mask in range(1<<len(lines)):
 soft=[line['momentum'] for i,line in enumerate(lines) if mask>>i&1]
 if soft:
  kernel,nullity=fmpz_mat(soft).nullspace();directions=[[int(kernel[i,j]) for i in range(4)] for j in range(nullity)]
 else:nullity=4;directions=[[int(i==j) for i in range(4)] for j in range(4)]
 if not nullity:continue
 hard=[line for line in lines if any(sum(x*y for x,y in zip(line['momentum'],w)) for w in directions)]
 assert hard
 ultraviolet_degree=4*nullity-2*sum(line['power'] for line in hard)
 assert ultraviolet_degree<0
 identity=tuple(line['slot'] for line in hard)
 record={'hard_line_slots':list(identity),'hard_loop_subspace_dimension':nullity,'hard_denominator_power_sum':sum(line['power'] for line in hard),'UV_degree_at_d4':ultraviolet_degree}
 if identity in seen:assert seen[identity]==record
 seen[identity]=record;checks+=1
result={'schema':'vakint.pr11d.target-exact-Euclidean-convergence.v1','status':'all_UV_subspaces_strictly_convergent_all_masses_positive','target_powers':powers,'active_mass_squared':'1','active_momenta':lines,'enumerated_soft_line_subsets':256,'nonzero_hard_subspace_checks':checks,'distinct_hard_flat_conditions':len(seen),'maximum_UV_degree_at_d4':max(r['UV_degree_at_d4'] for r in seen.values()),'conditions':sorted(seen.values(),key=lambda r:(r['hard_loop_subspace_dimension'],r['hard_line_slots'])),'method':'For each subset of soft linear propagator forms, compute its exact integer kernel S. The hard directions in S scale all forms not annihilating S. Require4 dim(S)-2 sum_{q|S !=0}a_q<0 for every resulting matroid flat. These finite conditions are the Euclidean Weinberg power-counting conditions for this massive vacuum graph. Positive unit masses exclude infrared singularities.','normalization_consequence':'The integral is analytic at epsilon0; multiplying raw by exp(4 EulerGamma epsilon) leaves its finite coefficient unchanged. No zero is inferred from small numerical pole coefficients.','global_Wick_sign':(-1)**sum(powers),'source_sha256':hashlib.sha256(source_path.read_bytes()).hexdigest(),'whole_PR11d_numerical_accuracy_claimed':False}
(ROOT/'finiteness-validation.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',checks,'UV subspace checks;',len(seen),'distinctflats;maxUVdegree',result['maximum_UV_degree_at_d4'],'globalWicksign',result['global_Wick_sign'])
