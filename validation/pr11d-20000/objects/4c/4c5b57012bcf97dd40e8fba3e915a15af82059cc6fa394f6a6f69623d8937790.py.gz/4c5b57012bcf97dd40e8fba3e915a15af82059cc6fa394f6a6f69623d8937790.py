#!/usr/bin/env python3
"""Exact frozen A/B X8 source assembly; no native/HPL/preparer execution."""
import hashlib
import importlib.util
import json
import resource
import sys
import time
from pathlib import Path
from flint import arb, ctx

if not __debug__:
    raise RuntimeError('Assertions required')
sys.dont_write_bytecode = True
sys.set_int_max_str_digits(300000)
HERE = Path(__file__).resolve().parent
PR11 = HERE.parents[1]
BESSEL = PR11.parent / 'bessel'
ASSEMBLER = BESSEL / 'ancestor-boundary'
RUNS = ASSEMBLER / 'production-runs-v1'
PINS = {}
EXPECTED = {
    'A': (20800, '37b62d59e28eaff4b8e533399be12272a247d0ce4546b9e6533df54678186f95',
          '77f47b270d66f53ebc64d46089cab300bdff8a35a73753cb05e1644d769348ad'),
    'B': (21200, 'b387e100fdba452cba39b2bc9df3f1aaefe91c421792911dabd7493075a46dd7',
          '2bc55b7d4b6e8ff10533b91e39a2a80f40cbad671f927aff1ea84b429c81e18a'),
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pin(path, expected=None):
    path = Path(path).resolve()
    digest = sha(path)
    require(expected is None or digest == expected, f'hash mismatch: {path}')
    require(str(path) not in PINS or PINS[str(path)] == digest, f'changed source: {path}')
    PINS[str(path)] = digest
    return digest


def unique(items):
    result = {}
    for key, value in items:
        require(key not in result, f'duplicate JSON key: {key}')
        result[key] = value
    return result


def read(path, expected=None):
    pin(path, expected)
    return json.loads(Path(path).read_text(), object_pairs_hook=unique)


def module(name, path):
    pin(path)
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def profile_sources(name, profile, argv, saved, x8):
    expected_support = [
        {'native::L3_P13': (-3, 2), 'native::L3_P14': (-3, 2)},
        {'native::' + s: (-4, 1) for s in ['PR3', 'PR4', 'PR4d', 'PR5', 'PR7', 'PR9', 'PR9d']},
    ]
    if name == 'A':
        primitives, sources = x8.fixed_bounded_sources()
    else:
        primitives, sources = {}, []
    for stem, support in zip(['three-loop', 'four-loop'], expected_support, strict=True):
        path, digest = argv['--' + stem + '-input'], argv['--' + stem + '-sha256']
        pin(path, digest)
        values, provenance = x8.load_native_endpoints(path, digest, support)
        primitives.update(values)
        sources.append(provenance)
    if name == 'B':
        # Reproduce guard20600/x8_assemble.py inline operations in their original
        # order and context. The diagnostic arithmetic_ball field is never read.
        sunset = Path(argv['--sunset-input'])
        sdigest = argv['--sunset-sha256']
        source = read(sunset, sdigest)
        rows = source['coefficients']['native_raw']
        require(source['error_quality'] == 'rigorous-bound'
                and source['validated_analytic_truncation_and_rounding'] is True
                and [r['epsilon_power'] for r in rows] == list(range(-2, 4)), 'sunset support')
        balls = tuple(arb(r['ball']) for r in rows)
        require(all(b.is_finite() for b in balls), 'sunset finite balls')
        primitives['native::L2_P2'] = x8.FactorJet(-2, balls,
            'Accepted exact sunset recurrence with rigorous complex-epsilon Cauchy tail',
            'native::L2_P2; ' + sdigest)
        sources.append({'source': str(sunset.resolve()), 'sha256': sdigest,
                        'error_quality': 'rigorous-bound', 'normalization': 'native_raw'})
        p853 = Path(argv['--p853-input'])
        pdigest = argv['--p853-sha256']
        checked = read(argv['--p853-validation'], profile['p853_acceptance']['sha256'])
        data = read(p853, pdigest)
        require(checked['coefficient_data_sha256'] == pdigest
                and checked['source_exact_jet_sha256'] == data['source_exact_jet_sha256'], 'P853 source binding')
        rows = data['coefficients']['native_raw']
        require([r['epsilon_power'] for r in rows] == list(range(-3, 5)), 'P853 support')
        balls = []
        for r in rows:
            center, error = arb(r['value']), arb(r['absolute_error_upper_bound'])
            require(center.is_finite() and error.is_finite() and error.lower() >= 0, 'P853 finite bound')
            balls.append(center + arb(0, error.upper()))
        primitives[x8.P853] = x8.FactorJet(-3, tuple(balls),
            'Accepted exact hypergeometric Laurent coefficients with independent highprecision validation',
            x8.P853 + '; ' + pdigest)
        sources.append({'source': str(p853.resolve()), 'sha256': pdigest,
                        'acceptance_sha256': sha(argv['--p853-validation']),
                        'error_quality': 'rigorous-bound', 'normalization': 'native_raw'})
    require(sources == saved['source_receipts'], 'primitive provenance differs')
    return primitives


def replay(name, manifest, x8, matcher):
    started = time.monotonic()
    digits, boundary_hash, constants_hash = EXPECTED[name]
    saved_path = RUNS / name / 'x8-source.boundary.json'
    constants_path = RUNS / name / 'x8-source.constants.json'
    saved, constants = read(saved_path, boundary_hash), read(constants_path, constants_hash)
    invocation = read(RUNS / name / 'assemble-invocation.json')
    require(invocation['success'] is True and invocation['exit_code'] == 0
            and invocation['profile'] == name and invocation['action'] == 'assemble', 'invocation fields')
    require(invocation['output_sha256'] == boundary_hash
            and Path(invocation['output_path']).resolve() == saved_path.resolve(), 'invocation output binding')
    require(saved['working_decimal_digits'] == constants['working_decimal_digits']
            == invocation['working_decimal_digits'] == digits, 'original working precision')
    args = invocation['argv']
    require(len(args[2:]) % 2 == 0, 'invocation argv shape')
    argv = dict(zip(args[2::2], args[3::2], strict=True))
    require(len(argv) == len(args[2:]) // 2, 'duplicate invocation flags')
    require(int(argv['--working-digits']) == digits, 'invocation argv precision')
    profile = manifest['profiles'][name]
    require(args[1] == profile['assembler']['path'], 'profile assembler')
    for entry in profile.values():
        if isinstance(entry, dict) and 'path' in entry:
            pin(entry['path'], entry['sha256'])
    for path, digest in invocation['artifact_sha256'].items():
        pin(path, digest)
    pin(RUNS / name / 'assemble.log', invocation['log_sha256'])
    pin(RUNS / 'run_profile.py', invocation['runner_sha256'])
    if name == 'A':
        for relative, digest in saved['implementation_sha256'].items():
            path = BESSEL / relative if relative.startswith('pr11-boundary/') else ASSEMBLER / relative
            pin(path, digest)
    else:
        pin(profile['assembler']['path'], saved['producer_sha256'])
    for entry in saved['source_receipts']:
        pin(entry['source'], entry['sha256'])
        if 'acceptance_receipt' in entry:
            pin(entry['acceptance_receipt'], entry['acceptance_receipt_sha256'])
    for path, digest in saved['recipe_receipt']['source_sha256'].items():
        pin(path, digest)
    require(constants['boundary_input_sha256'] == boundary_hash
            and constants['source_receipts'] == saved['source_receipts'], 'constants source linkage')
    ctx.dps = digits
    ctx.threads = 1
    require(ctx.prec == constants['working_bits'], 'actual original working bits')
    primitives = profile_sources(name, profile, argv, saved, x8)
    factors, recipe = x8.build_factor_expressions()
    require(recipe == saved['recipe_receipt'] and len(factors) == 324, 'source recipe replay')
    inventory = BESSEL / 'pr11-boundary/inventory-full-v2.json'
    pin(inventory, saved['inventory_sha256'])
    plan = x8.BoundaryLogJetMap.from_file(inventory, saved['inventory_sha256'])
    matching = matcher.Matching()
    require(matching.binding == saved['matching_sha256'] == constants['exact_matching_sha256'], 'matching binding')
    compiled = x8.ExpandedBoundary(plan, factors, max_log_power=matching.data['max_exact_log_degree'])
    required, _ = compiled.required_primitive_orders(primitives)
    require(required == saved['required_raw_primitive_through'], 'primitive order requirements')
    raw = compiled.evaluate(primitives)
    boundary = {}
    for (i, alpha, p, ell), value in raw.items():
        require(alpha.denominator == 1, 'noninteger source exponent')
        key = (i, alpha.numerator, p, ell)
        require(key not in boundary, 'duplicate source selector')
        boundary[key] = value
    for key, value in boundary.items():
        require(key in matching.positions or value.contains(0), f'forbidden source support: {key}')
    selected = {key: boundary[key] for key in matching.all_keys}
    result = matching.solve(selected, inventory_sha256=sha(inventory),
                            normalization='native_raw', error_quality='rigorous-bound')
    for key, value in result.report.items():
        if key != 'seconds':
            require(constants[key] == value, f'matching report field {key}')
    require(len(saved['coefficients']) == len(selected) == 1587, 'complete boundary count')
    require(len(result.constants) == len(constants['free_constant_balls']) == 252, 'constant count')
    rowchecks = []
    for original, (key, value) in zip(saved['coefficients'], selected.items(), strict=True):
        require(matcher.key(original) == key, 'boundary selector ordering')
        require(value.str(digits + 12, more=True) == original['real_ball'], f'boundary string replay: {key}')
        rowchecks.append({'key': list(key), 'identical_serialized_ball': True})
    constantchecks = []
    for index, (value, original) in enumerate(zip(result.constants, constants['free_constant_balls'], strict=True)):
        require(value.str(digits + 12, more=True) == original, f'constant string replay: {index}')
        constantchecks.append({'index': index, 'identical_serialized_ball': True})
    for path, digest in PINS.items():
        require(sha(path) == digest, f'artifact changed during replay: {path}')
    report = {
        'schema': 'vakint.X8.production-source-exact-reassembly.v1', 'profile': name,
        'accepted_for_frozen_source_assembly_and_matching_replay': True,
        'all_1587_rows_and_252_constants_identical_serialization': True,
        'source_boundary_sha256': boundary_hash, 'source_constants_sha256': constants_hash,
        'working_decimal_digits': digits, 'working_bits': ctx.prec, 'formatter_digits': digits + 12,
        'factor_count': len(factors), 'required_primitive_orders': required,
        'boundary_coefficients': rowchecks, 'constants': constantchecks,
        'all_prepared_source_equations_checked': True,
        'all_matching_report_fields_except_timing_identical': True,
        'primitive_provenance_recipe_and_original_argument_bindings_equal': True,
        'p853_fields_used': ['value', 'absolute_error_upper_bound'],
        'p853_arithmetic_ball_used': False,
        'overlap_used_as_acceptance': False,
        'source_profiles_mixed': False,
        'source_origin_admission': 'CONDITIONAL: external A/B four-loop physical chain and alias-origin reviews must close separately. This replay proves the frozen input balls were assembled and matched exactly; it does not prove their physical origins.',
        'physical_source_admission_claimed': False,
        'source_pins': dict(PINS), 'validator_sha256': sha(__file__),
        'no_HPL_native_prefix_preparer_or_transport_rerun': True,
        'no_existing_artifacts_modified': True, 'whole_PR11d_accuracy_claimed': False,
        'seconds': time.monotonic() - started,
        'peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
    }
    target = HERE / (name + '-numeric-reassembly.json')
    require(not target.exists(), f'preserve existing review: {target}')
    target.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'profile': name, 'accepted': True, 'path': str(target),
                      'sha256': sha(target), 'seconds': report['seconds']}), flush=True)


def main():
    resource.setrlimit(resource.RLIMIT_AS, (2 * 2**30, 2 * 2**30))
    resource.setrlimit(resource.RLIMIT_CPU, (150, 155))
    manifest = read(ASSEMBLER / 'production-source-profiles-v1.json',
                    'd1132ed3218ad71b28053956b61217e83b18fb44d0e198b6d0661165421b8987')
    pin(__file__)
    for filename in ['endpoint_sources.py', 'x8_guarded_boundary.py', 'guard20600/x8_assemble.py']:
        pin(ASSEMBLER / filename)
    for filename in ['gamma_jets.py', 'gamma_ast.py', 'expanded_boundary.py', 'source_recipes.py', 'logjet_map.py']:
        pin(BESSEL / 'pr11-boundary' / filename)
    pin(PR11 / 'infinity-matching/match.py', '53096d6ac7e61f285fb32b7f5a3c97ef6baa7a08cbdab7b2eb446db1b42d2840')
    pin(PR11 / 'infinity-matching/exact-boundary-matching.json', '649d059e55ac920aad980eaf444ae45c0f86e7302db0eb1a5096cece33686504')
    pin(PR11 / 'infinity-matching/verification.json')
    sys.path.insert(0, str(BESSEL / 'pr11-boundary'))
    sys.path.insert(0, str(ASSEMBLER))
    x8 = module('review_frozen_x8_source_assembler', ASSEMBLER / 'x8_guarded_boundary.py')
    matcher = module('review_frozen_physical_source_matching', PR11 / 'infinity-matching/match.py')
    for profile in ['A', 'B']:
        replay(profile, manifest, x8, matcher)


if __name__ == '__main__':
    main()
