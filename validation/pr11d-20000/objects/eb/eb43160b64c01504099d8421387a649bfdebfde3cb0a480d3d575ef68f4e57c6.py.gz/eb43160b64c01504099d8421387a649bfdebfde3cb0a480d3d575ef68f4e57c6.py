#!/usr/bin/env python3
"""Record one fresh saved-input/saved-binary production-A INIT replay."""
import hashlib,json,os,resource,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
NATIVE=HERE.parents[2]/'helper/frobenius-transport/native'
PINS={
 'pr9-API20280-init-v1.in':'826de190c795c5fd8a5b6b36bf63715a8b98a997e4825d8ec6aa222f3ee72ce8',
 'contracted_v2.c':'5f9c381280172f1d388a3661fb13a3a799848391c29b334e5c1ebc150879ff60',
 'contracted-native-v2':'ff3d297816b301c010fb8ee4645207ecdec0f74cf8e7a8678b678d5bfb3175c3',
 'pr9-API20280-init-v1-output.json':'91186644e6a7c04862dab7c53127caaeea2cca71d6ff50b0839511cf18372b6b'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def checked():
 d={str(NATIVE/name):sha(NATIVE/name) for name in PINS}
 for name,digest in PINS.items():
  if d[str(NATIVE/name)]!=digest:raise ValueError('pin mismatch: '+name)
 return d
def dump(p,obj):
 with p.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
def restrict():
 resource.setrlimit(resource.RLIMIT_AS,(2<<30,2<<30))
 os.sched_setaffinity(0,set(sorted(os.sched_getaffinity(0))[:4]))
def main():
 before=checked();output=HERE/'replayed-native-output.json';log=HERE/'native.stderr';stdout=HERE/'native.stdout';receipt=HERE/'invocation.json'
 for p in [output,log,stdout,receipt]:
  if p.exists():raise ValueError('refusing overwrite: '+str(p))
 command=[str(NATIVE/'contracted-native-v2'),str(NATIVE/'pr9-API20280-init-v1.in'),str(output)]
 env=dict(os.environ,OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_DYNAMIC='FALSE')
 start=time.monotonic();stamp=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
 result={'schema':'vakint.pr9.production-A.fresh-native-invocation.v1','command':command,'cwd':str(HERE),'environment_overrides':{k:env[k] for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_DYNAMIC']},'cpu_affinity':sorted(os.sched_getaffinity(0))[:4],'address_space_limit_bytes':2<<30,'timeout_seconds':2700,'started_utc':stamp,'source_sha256_before':before,'runner_sha256':sha(__file__),'preparation_or_HPL_or_transport_rerun':False}
 try:
  with log.open('xb') as err,stdout.open('xb') as out:
   completed=subprocess.run(command,cwd=HERE,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=2700,preexec_fn=restrict,check=False)
  result['returncode']=completed.returncode
 except subprocess.TimeoutExpired:
  result['returncode']=None;result['timed_out']=True
 result['wall_seconds']=time.monotonic()-start;result['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());result['source_sha256_after']=checked()
 result['source_files_unchanged']=result['source_sha256_before']==result['source_sha256_after'];result['stderr_sha256']=sha(log);result['stdout_sha256']=sha(stdout)
 result['accepted_same_input_same_binary_replay']=False
 if output.exists():result['output_sha256']=sha(output)
 if result.get('returncode')==0:
  original=json.loads((NATIVE/'pr9-API20280-init-v1-output.json').read_text());replayed=json.loads(output.read_text())
  excluded=['seconds','setup_seconds','initialization_seconds','certificate_seconds','peak_rss_bytes']
  a={k:v for k,v in original.items() if k not in excluded};b={k:v for k,v in replayed.items() if k not in excluded}
  result['excluded_timing_and_resource_fields_only']=excluded;result['compared_fields']=sorted(a);result['all_numerical_history_and_contract_fields_equal']=a==b
  result['unequal_fields']=sorted(k for k in set(a)|set(b) if a.get(k)!=b.get(k))
  for field in ['normalized_J_values','original_Y_values']:
   result[field+'_count']=len(replayed[field]);result[field+'_byte_identical_strings']=original[field]==replayed[field]
  result['accepted_same_input_same_binary_replay']=a==b and result['source_files_unchanged'] and all(result[k+'_count']==132 and result[k+'_byte_identical_strings'] for k in ['normalized_J_values','original_Y_values'])
 dump(receipt,result);print(json.dumps({'receipt':str(receipt),'sha256':sha(receipt),'accepted':result['accepted_same_input_same_binary_replay'],'wall_seconds':result['wall_seconds'],'unequal_fields':result.get('unequal_fields')},indent=2),flush=True)
 if not result['accepted_same_input_same_binary_replay']:sys.exit(1)
if __name__=='__main__':main()
