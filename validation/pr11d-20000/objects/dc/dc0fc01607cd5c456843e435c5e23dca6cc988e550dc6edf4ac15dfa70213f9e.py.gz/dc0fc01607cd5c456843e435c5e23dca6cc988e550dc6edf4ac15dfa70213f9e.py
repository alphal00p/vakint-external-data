#!/usr/bin/env python3
from pathlib import Path
import dataclasses,hashlib,importlib.util,json,sys
sys.dont_write_bytecode=True;sys.set_int_max_str_digits(0)
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];BESSEL=ROOT.parent/'bessel';V2=BESSEL/'generic-rpf-admission/exact_step_v2.py';V3=BESSEL/'generic-rpf-admission/exact_step_v3.py'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
assert sha(V3)=='8f4f305a48e18460f2fee22d1aa3646b254e8c16527d751a8388f6320eb0d75f'
a=V2.read_text();b=V3.read_text();expected=a.replace("if clear==1:require(lowertext==meta['denominator_lower_bound'],'Unscaled literal bound mismatch')","if k.component_scale_policy=='identity':require(clear==1 and lowertext==meta['denominator_lower_bound'],'Unscaled literal bound mismatch')").replace("vakint.generic-exact-general-RPF-step-data-review.v2","vakint.generic-exact-general-RPF-step-data-review.v3")
assert b==expected,'Unreviewed additional v3 change'
spec=importlib.util.spec_from_file_location('independent_v3_branch_review',V3);E=importlib.util.module_from_spec(spec);sys.modules[spec.name]=E;spec.loader.exec_module(E)
chain=ROOT/'hierarchy-transport/pr9-production-API20600-substeps3-v9';con=ROOT/'ancestor-flows/pr9-22-ordinary-polynomial.json';pf=ROOT/'ancestor-flows/pr9-22-ordinary-rational-pf.json';run=load(chain/'run-binding.json');w=load(ROOT/'ancestor-flows/pr9-22-matching.json')['gauge_weights'][:22];w=tuple(x-min(w) for x in w)
k=E.StepContract(22,6,-4,sha(con),sha(pf),run['source_equation_sha256'],69429,20600,20900,sha(chain/'run-binding.json'),run['initial_sha256'],'imaginary_center_power',w,8)
args=[chain/'step-024.in',chain/'step-024.json',chain/'step-023-boundary.json',con,pf,chain/'step-024-native.json',chain/'step-024-boundary.json']
meta=load(args[1]);assert meta['center']==['0','1'] and meta['clear_denominator_factor']=='1'
original_lines=args[0].read_text().splitlines();assert original_lines[1]!=meta['denominator_lower_bound']
before=E.ctx.prec;positive=E.check_step(*args,k);assert positive['accepted'] and E.ctx.prec==before
xchain=ROOT/'hierarchy-transport/x8-prototype-RPF-halfsteps-v10';xr=load(xchain/'run-binding.json');xc=ROOT/'jet-transport/polynomial-connection-regular-gauge.json';xp=ROOT/'jet-transport/x8-ordinary-rational-pf.json'
xk=E.StepContract(42,6,-4,sha(xc),sha(xp),xr['source_equation_sha256'],4319,850,1300,sha(xchain/'run-binding.json'),xr['initial_sha256'],'identity',(),4)
xa=[xchain/'step-000.in',xchain/'step-000.json',ROOT/'helper/frobenius-transport/x8-bounded-hierarchy-prototype-guard780-eta256-v1.json',xc,xp,xchain/'step-000-native.json',xchain/'step-000-boundary.json']
identity=E.check_step(*xa,xk);assert identity['accepted'] and E.ctx.prec==before
rejects=[]
def reject(label,arguments,contract,reason):
 try:E.check_step(*arguments,contract)
 except (ValueError,AssertionError) as error:
  assert reason in str(error),(label,str(error));assert E.ctx.prec==before
  rejects.append({'case':label,'rejected':True,'reason':str(error)});return
 raise AssertionError(label+' accepted')
reject('wrong_identity_profile_on_reserialized_PR9_clear_one',args,dataclasses.replace(k,component_scale_policy='identity',component_scale_weights=()),'Unscaled literal bound mismatch')
folder=HERE/'wrong_literal_fixture';folder.mkdir(exist_ok=True)
lines=original_lines[:];lines[1]=meta['denominator_lower_bound'];ip=folder/'native.in';ip.write_text('\n'.join(lines)+'\n')
oldprefix=Path(meta['saved_polynomial_input_path']);prefix=folder/'prefix.in';prefixlines=oldprefix.read_text().splitlines();prefixlines[1]=meta['denominator_lower_bound'];prefix.write_text('\n'.join(prefixlines)+'\n')
pm=load(oldprefix.with_suffix('.json'));pm['input_sha256']=sha(prefix);prefix.with_suffix('.json').write_text(json.dumps(pm,indent=2)+'\n')
m=meta.copy();m.update(input_sha256=sha(ip),saved_polynomial_input_path=str(prefix),saved_polynomial_input_sha256=sha(prefix),saved_polynomial_metadata_sha256=sha(prefix.with_suffix('.json')));mp=folder/'native.json';mp.write_text(json.dumps(m,indent=2)+'\n')
f=load(args[-1]);f['transport_input_sha256']=sha(ip);fp=folder/'following.json';fp.write_text(json.dumps(f,indent=2)+'\n')
changed=args[:];changed[0]=ip;changed[1]=mp;changed[-1]=fp
reject('rebound_unscaled_literal_in_scaled_PR9_input',changed,k,'Scaled literal bound serialization')
pins={str(p):sha(p) for p in [V2,V3,Path(__file__),ROOT/'hierarchy-transport/prepare_scaled_segment.py',BESSEL/'generic-rpf-admission/exact_step.py']}
for record in [positive,identity]:
 for p,h in record['artifact_sha256'].items():assert sha(p)==h;pins[p]=h
report={'schema':'vakint.generic-RPF-v3-literal-bound-policy-delta-review.v1','accepted':True,'status':'passed_explicit_scaling_policy_bound_serialization_delta','predecessor_v2_sha256':sha(V2),'checker_v3_sha256':sha(V3),'exact_diff_is_only_branch_policy_and_receipt_schema':True,'all_exact_source_bounds_and_enclosure_inequalities_unchanged':True,'proof':'The scaled PR9 adapter always rounds and re-encodes its bound at128bits, including multiplierone. The identity adapter retains its literal string. An explicit verified scale policy selects the actual generating procedure; equal numerical multipliers do not select serialization semantics. Prior accepted policies are exhaustively checked before this branch.','positive_controls':[{'case':'actual_B_step024_center_i_clear_one','accepted':True,'checker_receipt':positive},{'case':'actual_identity_X8_step000','accepted':True,'checker_receipt':identity}],'rejections':rejects,'upstream_mask_profile_and_core_review_required':True,'physical_source_admitted':False,'native_or_preparer_rerun':False,'producer_files_modified':False,'artifact_sha256':pins}
out=HERE/'review.json';assert not out.exists();out.write_text(json.dumps(report,indent=2)+'\n');print(out);print(sha(out))
