#!/usr/bin/env python3
"""Bless the reviewed X8 admission author and exact completed A/B source receipts."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
AUTHOR = HERE.parent / "seal.py"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    if not __debug__:
        raise RuntimeError("Assertions required")
    checks_path = HERE / "complete-checks.json"
    origins_path = HERE / "origin-binding-controls-final.json"
    checks = json.loads(checks_path.read_text())
    origins = json.loads(origins_path.read_text())
    assert checks["all_actual_check_only_and_consumer_checks_passed"] is True
    assert origins["all_negative_controls_rejected"] is True
    assert checks["author_sha256"] == origins["author_sha256"] == sha(AUTHOR)
    assert checks["negative_control_count"] == 27 and origins["negative_control_count"] == 80
    assert set(checks["profiles"]) == set(checks["four_loop_admissions"]) == {"A", "B"}
    assert not checks["accepted_initial_or_author_review_written"]
    assert sha(HERE / "check_complete.py") == checks["review_script_sha256"]
    assert sha(HERE / "check_gates_final.py") == origins["review_script_sha256"]
    pins = {str(path): sha(path) for path in [AUTHOR, checks_path, origins_path,
            HERE / "check_complete.py", HERE / "check_gates_final.py", Path(__file__)]}
    for profile in ["A", "B"]:
        result = checks["profiles"][profile]
        assert result["actual_author_check_only_passed"] is True
        assert result["frozen_consumer_verified_returned_envelope"] is True
        assert result["all_252_initial_balls_checked"] is True
        assert result["primitive_data_count"] == 4
        for row in [checks["four_loop_admissions"][profile], result["four_loop_admission"]]:
            assert sha(row["path"]) == row["sha256"]
            pins[row["path"]] = row["sha256"]
    report = {
        "schema": "vakint.X8-physical-initial-envelope-author-independent-review.v1",
        "accepted": True,
        "status": "passed_frozen_X8_physical_initial_envelope_author",
        "author_sha256": sha(AUTHOR),
        "four_loop_admissions": checks["four_loop_admissions"],
        "profiles": checks["profiles"],
        "actual_author_check_only_passed_for_both_profiles": True,
        "frozen_initial_admission_consumer_verified_both_returned_envelopes": True,
        "negative_controls_rejected": 107,
        "actual_transitive_artifact_pins_rechecked_in_complete_review": len(checks["artifact_sha256"]),
        "fixed_gap": "The draft accepted a caller-checksummed four-loop success label without an independent receipt binding. The reviewed author now requires the exact A/B receipt path+SHA map in this independently blessed review before reading the selected receipt, and requires a nonempty proof graph. Unblessed substitutions and missing/extra/swapped bindings reject.",
        "reviewed_contract": [
            "Exactly four primitive data artifacts per profile, bound to complete independent non-four-loop and four-loop physical admission receipts; exact eleven-primitive Laurent-depth map, canonical names/ranges and native raw normalization.",
            "No overlap or error-quality label is used as the physical admission argument. P853 uses its explicit authenticated identity and bounded-value source convention; no additional downstream Euler conversion is admitted.",
            "Exact source replay, all 252 full seed boxes, raw 42-state pole bound, six-jet lift and infinity gauge, normalized Frobenius preparation/full rank/log degree eight, and scheduled kernel review are all frozen and hash-bound.",
            "Completed actual native invocation must have typed returncode zero, eight requested/actual workers, unchanged input/source/binary/wrapper snapshots and exact command/data/source bindings.",
            "Both immutable initial targets e68d8251... and c789f358... pass the frozen consumer. Each has 252 finite full balls and the actual absolute radius-sum gate A1e-20060 or B1e-20340.",
            "All source and artifact graph paths are absolute and hashes are rechecked before authoring; missing source origins and false/incomplete proof fields fail closed.",
        ],
        "component_receipts": [
            {"path": str(checks_path), "sha256": sha(checks_path)},
            {"path": str(origins_path), "sha256": sha(origins_path)},
        ],
        "artifact_sha256": pins,
        "review_method": "Read-only author review and exact binding/interval checks. The preliminary reviewer object and returned envelope paths were virtual in-memory test objects; all scientific source receipts and actual initial/native artifacts were real. Neither virtual accepted object was emitted.",
        "accepted_initial_envelopes_written_by_reviewer": False,
        "new_native_HPL_source_assembly_or_transport_computation": False,
        "producer_and_original_artifacts_modified": False,
        "whole_PR11d_or_public_precision_claimed": False,
        "scope": "Blesses this exact author implementation and the exact completed A/B four-loop receipt bindings for physical ordinary-point initialization only. Subsequent transport, endpoint projection, final precision certification and release remain separate. Existing external IBP/source trust boundaries are retained.",
    }
    output = HERE / "review.json"
    assert not output.exists(), "Preserve accepted independent review"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"path": str(output), "sha256": sha(output), "author_sha256": report["author_sha256"],
                      "accepted": True}, indent=2))


if __name__ == "__main__":
    main()
