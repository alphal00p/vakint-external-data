#!/usr/bin/env python3
"""Independent endpoint algebra/majorant checks; imports no producer modules."""
import ast, hashlib, json, time
from pathlib import Path
from fractions import Fraction as F
from flint import fmpq, fmpq_poly, fmpq_mat, fmpq_mpoly_ctx

BASE=Path(__file__).resolve().parents[1]
C=fmpq_mpoly_ctx.get(('e','x'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

class U:
    def __init__(self,n=0,d=1):
        self.n=n if isinstance(n,fmpq_poly) else fmpq_poly([n])
        self.d=d if isinstance(d,fmpq_poly) else fmpq_poly([d])
        assert self.d
        if not self.n: self.d=fmpq_poly([1]);return
        g=self.n.gcd(self.d);self.n=self.n//g;self.d=self.d//g
        scale=self.d.leading_coefficient();self.n/=scale;self.d/=scale
    def __bool__(self): return bool(self.n)
    def __add__(a,b):
        if not isinstance(b,U):b=U(b)
        return U(a.n*b.d+b.n*a.d,a.d*b.d)
    __radd__=__add__
    def __neg__(a):return U(-a.n,a.d)
    def __sub__(a,b):return a+-b if isinstance(b,U) else a+U(-b)
    def __mul__(a,b):
        if not isinstance(b,U):b=U(b)
        return U(a.n*b.n,a.d*b.d)
    __rmul__=__mul__
    def __truediv__(a,b):
        if not isinstance(b,U):b=U(b)
        return U(a.n*b.d,a.d*b.n)
    def __pow__(a,k):return U(a.n**k,a.d**k) if k>=0 else U(a.d**(-k),a.n**(-k))
    def jet(a):
        assert a.d[0]
        q=[]
        for k in range(6):q.append((a.n[k]-sum((a.d[j]*q[k-j] for j in range(1,k+1)),fmpq(0)))/a.d[0])
        return q

def parsed(text,variable_values):
    node=ast.parse(text.replace('^','**'),mode='eval').body
    def visit(n):
        if isinstance(n,ast.Constant):return variable_values['constant'](n.value)
        if isinstance(n,ast.Name):return variable_values[n.id]
        if isinstance(n,ast.UnaryOp):return -visit(n.operand)
        if isinstance(n,ast.BinOp):
            a=visit(n.left)
            if isinstance(n.op,ast.Pow):return a**int(ast.literal_eval(n.right))
            b=visit(n.right)
            if isinstance(n.op,ast.Add):return a+b
            if isinstance(n.op,ast.Sub):return a-b
            if isinstance(n.op,ast.Mult):return a*b
            if isinstance(n.op,ast.Div):return a/b
        raise ValueError(ast.dump(n))
    return visit(node)

class B:
    def __init__(self,n=0,d=None):
        self.n=C.constant(n) if isinstance(n,int) else n
        self.d=C.constant(1) if d is None else d
        assert self.d
        g=self.n.gcd(self.d);self.n//=g;self.d//=g
    def __add__(a,b):return B(a.n*b.d+b.n*a.d,a.d*b.d)
    def __neg__(a):return B(-a.n,a.d)
    def __sub__(a,b):return a+-b
    def __mul__(a,b):return B(a.n*b.n,a.d*b.d)
    def __truediv__(a,b):return B(a.n*b.d,a.d*b.n)
    def __pow__(a,k):return B(a.n**k,a.d**k) if k>=0 else B(a.d**(-k),a.n**(-k))

def rowmul(row,A):
    out=[U() for _ in row]
    for i,v in enumerate(row):
        if v:
            for j,q in enumerate(A[i]):
                if q:out[j]=out[j]+v*q
    return out

def inv(A):
    return fmpq_mat(A).inv().tolist()

def audit(name):
    rawp=BASE/f'{name}.json';raw=json.loads(rawp.read_text())
    pp=BASE/f'{name}-endpoint-adjoints.json';proof=json.loads(pp.read_text())
    cp=BASE/f'{name}-ordinary-polynomial.json';con=json.loads(cp.read_text())
    bp=BASE/f'{name}-blocks.json';bd=json.loads(bp.read_text())
    assert sha(rawp)==proof['source_sha256']==con['source_sha256']==bd['source_sha256']
    d=con['dimension'];dim=6*d
    assert con['regular_epsilon_gauge']['weights']==[0]*d
    assert proof['no_extra_epsilon_factor_required'] and proof['epsilon_jet_count']==6
    roots=[parsed(s,{'constant':U,'e':U(fmpq_poly([0,1]))}) for s in proof['formal_roots']]
    residue=[];source_entries=0;unit_entries=0
    for row in raw['differential_matrix']:
        rr=[]
        for text in row:
            text=text.replace(raw['epsilon_symbol'],'e').replace(raw['variable'],'x')
            v=parsed(text,{'constant':B,'e':B(C.gen(0)),'x':B(C.gen(1))})
            if not v.n:rr.append(U());continue
            source_entries+=1;ns=v.n.to_dict();ds=v.d.to_dict();nv=min(x for e,x in ns);dv=min(x for e,x in ds)
            assert nv-dv>=-1
            def coeff(poly,k):
                out=fmpq_poly()
                for (e,x),c in poly.items():
                    if x==k:out[e]=c
                return out
            den=coeff(ds,dv);assert den[0];unit_entries+=1
            rr.append(U(coeff(ns,nv),den) if nv-dv==-1 else U())
        residue.append(rr)
    # Generic-epsilon annihilator, with no evaluation or epsilon truncation.
    for i in range(d):
        row=[U(int(i==j)) for j in range(d)]
        for root in roots:row=[a-root*b for a,b in zip(rowmul(row,residue),row)]
        assert not any(row)
    prefix_checks=0;initial_checks=0
    D=[fmpq(x) for x in con['denominator_coefficients']];nd=con['numerator_degree']
    assert D[0]==0 and D[1] and nd>=len(D)-2
    N={}
    for en in con['entries']:
        for k in range(en['epsilon_power'],6):
            i=d*k+en['column'];j=d*(k-en['epsilon_power'])+en['row'];p=N.setdefault((i,j),[fmpq(0)]*(nd+1))
            for t in en['terms']:p[t['eta_power']]-=fmpq(int(t['numerator']),int(t['denominator']))
    for record in proof['records']:
        initial=[U(int(record['component']==j)) for j in range(d)]
        for root in roots[1:]:initial=[(a-root*b)/(-root) for a,b in zip(rowmul(initial,residue),initial)]
        expected=[parsed(s,{'constant':U,'e':U(fmpq_poly([0,1]))}) for s in record['row_coefficients'][0]]
        assert not any(a-b for a,b in zip(initial,expected));assert not any(rowmul(initial,residue));initial_checks+=2*d
        # Every saved rational row is epsilon regular; exact six-jet recurrence.
        values=[]
        for row in record['row_coefficients']:
            q=[parsed(s,{'constant':U,'e':U(fmpq_poly([0,1]))}).jet() for s in row]
            values.append([q[i][k] for k in range(6) for i in range(d)])
        for n in range(len(values)):
            residual=[fmpq(0)]*dim
            for k in range(1,min(len(D)-1,n+1)+1):
                j=n-k+1
                for i in range(dim):residual[i]+=D[k]*j*values[j][i]
            for (i,j),co in N.items():
                for k in range(min(nd,n)+1):residual[i]-=co[k]*values[n-k][j]
            assert not any(residual),(name,record['symbol'],n)
            prefix_checks+=dim
    blocks=[tuple(d*k+i for i in block) for k in range(6) for block in reversed(bd['ordered_blocks'])]
    bi={i:b for b,block in enumerate(blocks) for i in block};assert len(bi)==dim
    assert all(bi[j]<=bi[i] for i,j in N)
    r=fmpq(1,16);lower=abs(D[1])-sum((abs(D[k+1])*r**k for k in range(1,len(D)-1)),fmpq(0));assert lower>0
    M={}
    for (i,j),co in N.items():
        R=co[0]/D[1];h=[co[k]-R*(D[k+1] if k+1<len(D) else 0) for k in range(nd+1)];assert not h[0]
        M[i,j]=abs(R)+sum((abs(h[k])*r**k for k in range(1,len(h))),fmpq(0))/lower
    maximum=fmpq(0)
    for block in blocks:
        inverse=inv([[251*int(i==j)-M.get((i,j),fmpq(0)) for j in block] for i in block])
        assert all(v>=0 for row in inverse for v in row)
        maximum=max(maximum,max(sum((M.get((i,j),fmpq(0)) for j in block),fmpq(0)) for i in block))
    return {'name':name,'source_hash':sha(rawp),'proof_hash':sha(pp),'polynomial_hash':sha(cp),
            'base_dimension':d,'lifted_dimension':dim,'generic_annihilator_exact_rows':d,
            'source_nonzero_entries_eta_denominator_epsilon_units':unit_entries,
            'initial_projector_and_residue_kernel_exact_scalar_identities':initial_checks,
            'saved_six_jet_prefix_recurrence_exact_scalar_identities':prefix_checks,
            'projectors':len(proof['records']),'blocks':len(blocks),'maximum_block_size':max(map(len,blocks)),
            'all_degree_topology_checked':True,'positive_diagonal_block_resolvents_at_m250':True,
            'disc_denominator_lower_at_r1over16':str(lower),'largest_diagonal_block_M_row_sum':str(maximum),
            'regular_epsilon_gauge':'identity; no transformation in either audited source'}

if __name__=='__main__':
    start=time.monotonic();rows=[]
    for name in ['three-loop-seven','pr9-22']:
        rows.append(audit(name));print('PASS',name,flush=True)
    out={'schema':'vakint.ancestor.endpoint.independent-exact-checks.v1','seconds':time.monotonic()-start,
         'implementation':'Independent AST evaluation and rational polynomial arithmetic; no producer imports', 'checks':rows}
    (BASE/'endpoint-review/independent-checks.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
