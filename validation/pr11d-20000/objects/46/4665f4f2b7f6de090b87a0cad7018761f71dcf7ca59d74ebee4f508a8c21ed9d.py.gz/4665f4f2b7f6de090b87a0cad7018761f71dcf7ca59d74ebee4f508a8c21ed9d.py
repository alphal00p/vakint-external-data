"""Read-only endpoint convolution and normalization replay; no producer imports."""
import hashlib
import json
import math
from fractions import Fraction as F
from pathlib import Path

from flint import acb, arb, ctx

HERE = Path(__file__).resolve().parents[2]
ROOT = HERE.parents[3]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def iv(text):
    text = text.strip()
    if text.startswith("["):
        center, radius = text[1:-1].split("+/-")
        center, radius = F(center.strip() or "0"), F(radius)
        return center - radius, center + radius
    center = F(text)
    return center, center


def add(a, b):
    return a[0] + b[0], a[1] + b[1]


def neg(a):
    return -a[1], -a[0]


def mul(a, b):
    products = [x * y for x in a for y in b]
    return min(products), max(products)


def cmul(a, b):
    return (add(mul(a[0], b[0]), neg(mul(a[1], b[1]))),
            add(mul(a[0], b[1]), mul(a[1], b[0])))


def cadd(a, b):
    return add(a[0], b[0]), add(a[1], b[1])


def contains(a, b):
    return a[0] <= b[0] and b[1] <= a[1]


def replay():
    endpoint_path = HERE / "three-loop-prototype-endpoints.json"
    comparison_path = HERE / "three-loop-prototype-comparison.json"
    proof_path = HERE / "three-loop-seven-endpoint-adjoints.json"
    source_path = HERE / "three-loop-seven.json"
    endpoint = json.loads(endpoint_path.read_text())
    comparison = json.loads(comparison_path.read_text())
    proof = json.loads(proof_path.read_text())
    boundary = json.loads(Path(endpoint["boundary_source"]).read_text())
    assert sha(endpoint_path) == comparison["source_sha256"]
    assert sha(proof_path) == endpoint["adjoint_proof_sha256"]
    assert sha(source_path) == endpoint["source_sha256"] == proof["source_sha256"]
    assert sha(endpoint["boundary_source"]) == endpoint["boundary_sha256"]
    assert endpoint["target_bindings"] == proof["target_bindings"]
    assert proof["loop_count"] == 3 and proof["raw_epsilon_range"] == [-3, 2]
    assert boundary["epsilon_min_power"] == -3 and boundary["epsilon_max_power"] == 2
    assert boundary["dimension"] == 7 and boundary["normalization"] == "native_raw"
    assert boundary["source_equation_sha256"] == sha(source_path)
    expected = {(s, p) for s in ["native::L3_P13", "native::L3_P14"] for p in range(-3, 3)}
    assert {(s, r["epsilon_power"]) for s, rows in endpoint["coefficients"].items() for r in rows} == expected
    assert len(comparison["checks"]) == 12
    assert {(r["symbol"], r["epsilon_power"]) for r in comparison["checks"]} == expected
    hashes = {str(p): sha(p) for p in [endpoint_path, comparison_path, proof_path, source_path, Path(endpoint["boundary_source"])]}
    Y = [(iv(a), iv(b)) for a, b in boundary["values"]]
    ctx.dps = 260
    AY = [acb(arb(a), arb(b)) for a, b in boundary["values"]]
    raw_bits = []
    for record in endpoint["adjoint_inputs"]:
        path = Path(record["path"])
        assert sha(path) == record["sha256"]
        hashes[str(path)] = sha(path)
        adjoint = json.loads(path.read_text())
        assert adjoint["epsilon_range"] == [0, 5] and adjoint["loop_count"] == 3
        assert adjoint["endpoint_projector_proof_sha256"] == sha(proof_path)
        assert [F(x) for x in adjoint["eta_center"]] == [F(x) for x in boundary["eta_center"]]
        W = [(iv(a), iv(b)) for a, b in adjoint["complex_balls"]]
        AW = [acb(arb(a), arb(b)) for a, b in adjoint["complex_balls"]]
        assert len(W) == len(Y) == 42
        for p, row in enumerate(endpoint["coefficients"][adjoint["symbol"]]):
            assert row["epsilon_power"] == p - 3
            value = ((F(0), F(0)), (F(0), F(0)))
            avalue = acb(0)
            for j in range(p + 1):
                for i in range(7):
                    value = cadd(value, cmul(W[7*j+i], Y[7*(p-j)+i]))
                    avalue += AW[7*j+i] * AY[7*(p-j)+i]
            saved = iv(row["ball"]), iv(row["imaginary_ball"])
            assert contains(saved[0], value[0]) and contains(saved[1], value[1])
            assert value[1][0] <= 0 <= value[1][1]
            assert acb(arb(row["ball"]), arb(row["imaginary_ball"])).contains(avalue)
            assert avalue.imag.contains(0)
            assert arb(row["absolute_radius"]).contains(avalue.real.rad())
            raw_bits.append(int(avalue.real.rel_accuracy_bits()))
            assert raw_bits[-1] == row["relative_accuracy_bits"]
    ctx.dps = 300
    fmft_bits, agreement_digits = [], []
    for symbol, rows in endpoint["coefficients"].items():
        values = [arb(r["ball"]) for r in rows]
        gamma = 3 * arb.const_euler()
        exponential = [gamma**n / math.factorial(n) for n in range(6)]
        reference_path = ROOT / "vakint-external-data/3L/masters" / symbol.split("_")[-1] / "numerical.json"
        references = dict(json.loads(reference_path.read_text()))
        hashes[str(reference_path)] = sha(reference_path)
        for n in range(6):
            value = sum((values[k] * exponential[n-k] for k in range(n+1)), arb(0))
            row = next(r for r in comparison["checks"] if r["symbol"] == symbol and r["epsilon_power"] == n-3)
            assert row["reference_sha256"] == sha(reference_path)
            reference = arb(references[n-3])
            assert value.overlaps(reference)
            assert arb(row["computed_ball"]).contains(value)
            fmft_bits.append(int(value.rel_accuracy_bits()))
            assert fmft_bits[-1] == row["achieved_relative_accuracy_bits"]
            difference = abs(value.mid() - reference.mid())
            scale = max(arb(1), abs(reference).upper())
            agreement = int(max(0, float((-((difference + arb(10)**(-300))/scale).log()/arb(10).log()).lower())))
            assert agreement == row["midpoint_agreement_decimal_digits"]
            agreement_digits.append(agreement)
    return {"passed_coefficients": 12, "minimum_raw_relative_accuracy_bits": min(raw_bits),
            "minimum_fmft_relative_accuracy_bits": min(fmft_bits),
            "minimum_midpoint_agreement_decimal_digits": min(agreement_digits), "hashes": hashes}


if __name__ == "__main__":
    print(json.dumps(replay(), indent=2))
