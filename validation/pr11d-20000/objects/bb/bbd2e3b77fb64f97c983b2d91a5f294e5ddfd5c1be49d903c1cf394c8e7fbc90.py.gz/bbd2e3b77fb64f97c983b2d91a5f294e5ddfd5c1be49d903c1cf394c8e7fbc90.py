#!/usr/bin/env python3
"""190-digit development boundary; never a 20k PR11d acceptance receipt.

Gamma/P853 formulas are exact or bounded. The external-200/DREAM-250 ancestor
inputs use explicitly labelled validated-digit estimates for this prototype.
"""
import argparse,hashlib,importlib.util,json,math,sys,time
from decimal import Decimal,localcontext
from fractions import Fraction
from pathlib import Path
from flint import arb,ctx,fmpq
from source_recipes import build_factor_expressions,HERE,HELPER,sha
from logjet_map import BoundaryLogJetMap,FactorJet
from expanded_boundary import ExpandedBoundary

ROOT=HERE.parents[3]
PR11=HERE.parent.parent/'pr11d'

def wolfram_text(s):
    m,sep,e=s.partition('*^');return m.split('`')[0]+('e'+e if sep else '')

def estimated_decimal(s,digits):
    central=arb(s)
    with localcontext() as c:
        c.prec=digits+30;d=Decimal(s)
        # One full unit in the final validated significant decimal place.
        error=Decimal(10)**((d.adjusted() if d else 0)-digits+1)
    return central+arb(0,arb(str(error)).upper())

def native_from_fmft(values,loops):
    if not values or sorted(values)!=list(range(min(values),max(values)+1)):
        raise ValueError('Every imported Laurent coefficient must be explicit and contiguous')
    first,last=min(values),max(values);g=-loops*arb.const_euler()
    expo=[arb(1)]
    for n in range(1,last-first+1):expo.append(expo[-1]*g/n)
    return {p:sum((values[q]*expo[p-q] for q in range(first,p+1)),arb(0)) for p in range(first,last+1)}

def load_prototype_primitives():
    values={};sources=[]
    dream_path=PR11/'dream/ancestor-250-jets.json';dream=json.loads(dream_path.read_text())
    for name,normalizations in dream['coefficients'].items():
        rows=normalizations['native_raw'];first=min(r['epsilon_power'] for r in rows);last=max(r['epsilon_power'] for r in rows)
        assert first==-4 and last==1 and len(rows)==6
        coeff={r['epsilon_power']:estimated_decimal(wolfram_text(r['value']),190) for r in rows}
        values['native::'+name]=FactorJet(first,tuple(coeff[p] for p in range(first,last+1)),
          'Authenticated physical four-loop Laurent support through the complete recorded expansion; ancestor DRA source',name+'; prototype190digit estimate')
    sources.append({'path':str(dream_path),'sha256':sha(dream_path),'validated_decimal_digits_used':190,'error_quality':'validated-digits-estimate','normalization':'native_raw'})
    external=ROOT/'vakint-external-data'
    for loops,name in [(2,'P2'),(3,'P13'),(3,'P14')]:
        path=external/f'{loops}L/masters/{name}/numerical.json';rows=json.loads(path.read_text())
        raw=native_from_fmft({p:estimated_decimal(s,200) for p,s in rows},loops)
        first,last=min(raw),max(raw);assert first==-loops
        symbol=f'native::L{loops}_{name}'
        values[symbol]=FactorJet(first,tuple(raw[p] for p in range(first,last+1)),
          'Authenticated all-massive catalog Laurent support; no source coefficient below the declared pole is present',symbol+'; external200digit estimate')
        sources.append({'path':str(path),'sha256':sha(path),'validated_decimal_digits_used':200,'error_quality':'validated-digits-estimate','normalization':'FMFTandMATAD','native_conversion':'exp(-L EulerGamma epsilon), exactly once'})
    path=PR11/'p853/higher-order/p853-20200-jets-through-order7.json';data=json.loads(path.read_text())
    rows=data['coefficients']['native_raw'];assert [r['epsilon_power'] for r in rows]==list(range(-3,5))
    coeff=[arb(r['value'])+arb(0,arb(r['absolute_error_upper_bound']).upper()) for r in rows]
    name='pr11d::massless::8535684c37e21dfd38135b151cca892f3552977fef43ab9d0f2deb22f3762f64::raw_native'
    values[name]=FactorJet(-3,tuple(coeff),'Exact Grozin Gamma/hypergeometric Laurent derivation through rawepsilon4, independently validated20200digits',name)
    sources.append({'path':str(path),'sha256':sha(path),'validated_decimal_digits_used':20200,'error_quality':'rigorous-bound','normalization':'native_raw'})
    return values,sources

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--working-digits',type=int,default=260);ap.add_argument('--output-prefix',required=True);args=ap.parse_args()
    ctx.dps=args.working_digits;ctx.threads=1;start=time.time()
    factors,recipe_receipt=build_factor_expressions();primitives,source_receipts=load_prototype_primitives()
    plan=BoundaryLogJetMap.from_file(HERE/'inventory-full-v2.json','db5290bc8520499001d9998098d95474270ba2f5ffed1213dfa5ce2062eac7e9')
    spec=importlib.util.spec_from_file_location('pr11d_matching',PR11/'infinity-matching/match.py');module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    matching=module.Matching();maxlog=matching.data['max_exact_log_degree']
    compiled=ExpandedBoundary(plan,factors,max_log_power=maxlog)
    required,details=compiled.required_primitive_orders(primitives)
    print('All finite-source requirements validated:',required,flush=True)
    boundary=compiled.evaluate(primitives)
    converted={}
    for (component,alpha,power,log),value in boundary.items():
        assert alpha.denominator==1
        converted[component,alpha.numerator,power,log]=value
    excluded={k:v for k,v in converted.items() if k not in matching.positions}
    failures=[(k,v.str(30)) for k,v in excluded.items() if not v.contains(0)]
    if failures:raise ValueError('Source has forbidden prepared support: '+str(failures[:10]))
    selected={k:converted[k] for k in matching.all_keys}
    print('Complete explicit boundary assembled:',len(selected),'rows; excluded certified-zero enclosures:',len(excluded),'seconds',time.time()-start,flush=True)
    prefix=Path(args.output_prefix)
    rows=[{**module.label(k),'real_ball':v.str(args.working_digits+8,more=True)} for k,v in selected.items()]
    payload={'schema':'vakint.pr11d.complete-development-boundary.v1','inventory_sha256':sha(HERE/'inventory-full-v2.json'),'normalization':'native_raw','error_quality':'validated-digits-estimate','require_all_prepared_rows':True,'coefficients':rows,'source_receipts':source_receipts,'recipe_receipt':recipe_receipt,'required_raw_primitive_through':required,'requested_source_accuracy_digits':190,'matching_accuracy_claimed':False,'whole_PR11d_accuracy_claimed':False}
    prefix.with_suffix('.boundary.json').write_text(json.dumps(payload,indent=2)+'\n')
    result=matching.solve(selected,inventory_sha256=sha(HERE/'inventory-full-v2.json'),normalization='native_raw',error_quality='validated-digits-estimate')
    constants={**result.report,'free_constant_balls':[v.str(args.working_digits+8,more=True) for v in result.constants],'boundary_input_sha256':sha(prefix.with_suffix('.boundary.json')),'wall_seconds':time.time()-start}
    prefix.with_suffix('.constants.json').write_text(json.dumps(constants,indent=2)+'\n')
    print('PASS: complete1587row physical boundary matched252constants; seconds',time.time()-start,flush=True)

if __name__=='__main__':main()
