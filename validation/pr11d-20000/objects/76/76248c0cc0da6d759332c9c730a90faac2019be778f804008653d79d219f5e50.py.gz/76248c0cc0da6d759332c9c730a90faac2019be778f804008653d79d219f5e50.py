"""Find and exactly replay unimodular routings for positive-power integrals."""
from replay import *
from symmetries import determinant,sign

@functools.cache
def witness(source,target):
    if min(source)<0 or min(target)<0:return None
    active=[i for i,p in enumerate(source) if p>0]
    target_active=[i for i,p in enumerate(target) if p>0]
    if len(active)!=len(target_active):return None
    if sorted(source)!=sorted(target):return None
    candidates=[]
    # Fix the mass-deformed line in the independent basis whenever present.
    first=[3] if 3 in active else []
    for extra in itertools.combinations([i for i in active if i not in first],4-len(first)):
        selected=first+list(extra)
        a=[V[i] for i in selected]
        if determinant(a):break
    else:return None
    ai=frac_inverse(a)
    ai=[[int(x) if x.denominator==1 else x for x in row] for row in ai]
    options=[([3] if i==3 else [j for j in target_active if j!=3 and target[j]==source[i]]) for i in selected]
    for image in itertools.product(*options):
        if len(set(image))!=4:continue
        for signs in itertools.product((-1,1),repeat=4):
            b=[[s*x for x in V[j]] for j,s in zip(image,signs)]
            t=tuple(tuple(sum(ai[i][k]*b[k][j] for k in range(4)) for j in range(4)) for i in range(4))
            det=determinant(t)
            if abs(det)!=1:continue
            mapping={};good=True
            for i in active:
                v=sign(tuple(sum(V[i][k]*t[k][j] for k in range(4)) for j in range(4)))
                match=[j for j in target_active if sign(V[j])==v and source[i]==target[j] and ((i==3)==(j==3))]
                if len(match)!=1:good=False;break
                mapping[i]=match[0]
            if good and len(set(mapping.values()))==len(target_active):
                return {'matrix':[[str(x) for x in row] for row in t],
                        'determinant':str(det),'slot_map':mapping}
    return None

def main():
    from target import rowspace,reduce
    seed=BASIS[37]
    pivots=rowspace([((seed,i,j),ibp(seed,i,j)) for i,j in itertools.product(range(4),repeat=2)])
    proofs=[]
    for target in DATA['target_reductions']:
        row={tuple(target['powers']):ONE}
        for term in target['terms']:add(row,tuple(term['powers']),-parse(term['coefficient'],DATA['epsilon_symbol'],DATA['variable']))
        remainder,ibp_witness=reduce(row,pivots)
        transports=[]
        for source in sorted(list(remainder)):
            if source not in remainder:continue
            for dest in sorted(remainder):
                if dest>=source:break
                w=witness(source,dest)
                if w:
                    value=remainder.pop(source);add(remainder,dest,value)
                    transports.append({'source':source,'target':dest,'coefficient':str(value),'witness':w})
                    break
        print('target',target['powers'],'remaining',len(remainder),serialize(remainder),flush=True)
        proofs.append({'target':target['powers'],'ibp_witness':[{'seed':n,'derivative_loop':i,'vector_loop':j,'coefficient':str(v)} for (n,i,j),v in ibp_witness.items()],
                       'routing_witnesses':transports,'remainder':serialize(remainder)})
    (HERE/'target-replay.json').write_text(json.dumps(proofs,indent=2)+'\n')

if __name__=='__main__':main()
