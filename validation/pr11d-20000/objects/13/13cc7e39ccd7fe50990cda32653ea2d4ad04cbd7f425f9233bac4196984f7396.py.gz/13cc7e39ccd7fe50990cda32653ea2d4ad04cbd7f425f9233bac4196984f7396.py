#!/usr/bin/env python3
"""Read-only physical X8 RPFv11 chain acceptance; no numerical engine calls.

The frozen computation retained conditional metadata. Physical origin is admitted
only through a separately blessed exact initial-source envelope. Historical
flags are checked, preserved and never reclassified by absence alone.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import sys
import time
from fractions import Fraction as Q
from pathlib import Path
from flint import arb, acb, ctx

sys.dont_write_bytecode = True
if not __debug__:
    raise RuntimeError('Assertions are required')
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OLD = HERE.parent / 'ordinary-chain-acceptance-v1'
PREDECESSOR = HERE.parent / 'rpf-chain-acceptance-v1'
COMMON = OLD / 'common.py'
COMMON_SHA = 'fa246be34bb42c21d6112a666c5840f36a0ced54f5667cd7b9487a4acc22e3ef'
INITIAL_MODULE = PREDECESSOR / 'initial_admission.py'
INITIAL_MODULE_SHA = '97efa1736729f039bcf0201e893afcfd02be9191a578d7ca0e42e6e91aaaf308'
WRAPPER_REVIEW = ROOT / 'helper/x8-rpf-v10-review/review.json'
WRAPPER_REVIEW_SHA = '23fb2a05433b29619caba1262d75340bc907776cda7c921de28e479043ac30e4'
METADATA_REVIEW = ROOT / 'helper/x8-rpf-v11-review/review.json'
METADATA_REVIEW_SHA = '13d18f9903fee8c16c7d977bf0d02438da25b35b7372e2df89241021080da84d'
INITIAL_AUTHOR_REVIEW_SHA = '740306cd63b8398fde05df8723742c0265140f5c107cb89d034ad7ee45f1964e'
RAW_PROOF = ROOT.parent / 'bessel/raw-pole-support/certificate.json'
RAW_PROOF_SHA = 'd5289b81989b14398ff3d8d65edbcbbd198f4bbab4811de9fd8b255f72b45dcd'
FINITE_PROOF = ROOT / 'parametric-finiteness/certificate.json'
FINITE_PROOF_SHA = '3aa4fe32825867a6ddeb6a5af35bc9e5d550bdd031db2f71834753a176a9da6a'
CONNECTION = ROOT / 'jet-transport/polynomial-connection-regular-gauge.json'
RPF = ROOT / 'jet-transport/x8-ordinary-rational-pf.json'
DRIVER = ROOT / 'hierarchy-transport/run_x8_rpf_v11.py'
PREPARER = ROOT / 'hierarchy-transport/prepare_x8_rpf_v1.py'
NATIVE = ROOT / 'helper/jet-transport/transport-rpf-scheduled-threads'
PROFILES = {
    'A': {'initial_sha256': 'e68d82518214ffae10879beb129001c7233552d69e2b544c0a17fe2dc9a6d447',
          'binding_sha256': 'a793849fe790107e25a368d026baa7e2a07414f8df83e18b24f9a3d5814b6190',
          'admission_sha256': '257375fba2d1dc7994d638faaaa4d684433ee64501bde988e3bb4f8809086895',
          'digits': 20300, 'guard': 300, 'required_final_digits': 20010},
    'B': {'initial_sha256': 'c789f3587d02ecd3d9ca9ee0eb699120aa209c5bee88901c32d5c22068dc37b9',
          'binding_sha256': 'dfe211748be090484753f73eea5be1c4abecd853d14599903f178609d03d96a1',
          'admission_sha256': 'cc49014f84a66cfa68ae921ac71bf07010a8dacf76844f49de03029c4809a547',
          'digits': 20500, 'guard': 300, 'required_final_digits': 20300},
}


def pending_only(args):
    return args.check_only or args.prefix_steps is not None


def initial_metadata(c, data):
    c.require(data['schema'] == 'vakint.x8.conditional-guarded-ordinary-boundary.v1'
              and data['physical_source_admission_required'] is True
              and 'physical_accuracy_certified' not in data
              and data['whole_PR11d_accuracy_claimed'] is False
              and data['raw_total_width_gate_passed'] is True,
              'Frozen conditional initial classification or known-absence contract differs')
    c.require('whole_PR11d_20000_accuracy_claimed' not in data
              or data['whole_PR11d_20000_accuracy_claimed'] is False,
              'Conditional initial has a contradictory alternate whole-period claim')
    for key, wanted in [('basis', 'original_raw_epsilon_jets'), ('dimension', 42), ('jets', 6),
                        ('epsilon_min_power', -4), ('epsilon_max_power', 1),
                        ('normalization', 'native_raw'), ('error_quality', 'rigorous-bound'),
                        ('eta_center', ['0', '256'])]:
        c.require(type(data[key]) is type(wanted) and data[key] == wanted,
                  'Conditional initial convention differs: ' + key)
    c.require(data['local_tail_certified'] is True, 'Conditional initial numerical tail is not certified')


def produced_metadata(c, data, label):
    c.require(data['physical_source_admission_required'] is True
              and data['physical_accuracy_certified'] is False
              and data['whole_PR11d_20000_accuracy_claimed'] is False,
              'Conditional produced ' + label + ' classification was reset, omitted or malformed')
    c.require('whole_PR11d_accuracy_claimed' not in data
              or data['whole_PR11d_accuracy_claimed'] is False,
              'Conditional produced ' + label + ' has a contradictory legacy whole-period claim')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def explicit(name, path):
    path = Path(path).resolve()
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    if Path(module.__file__).resolve() != path:
        raise ValueError('Unexpected imported helper origin')
    return module


def unique_pairs(items):
    out = {}
    for key, value in items:
        if key in out:
            raise ValueError('Duplicate JSON key ' + str(key))
        out[key] = value
    return out


def finite_number(text):
    value = float(text)
    if not math.isfinite(value):
        raise ValueError('Nonfinite JSON number')
    return value


def load(path):
    return json.loads(Path(path).read_bytes(), object_pairs_hook=unique_pairs,
                      parse_float=finite_number,
                      parse_constant=lambda s: (_ for _ in ()).throw(ValueError('Nonfinite JSON scalar')))


def fresh_output(path):
    original = Path(path)
    resolved = original.resolve()
    if original.is_symlink() or resolved.exists() or not resolved.is_relative_to(HERE):
        raise ValueError('Output must be fresh and nonsymlink under the dedicated validator directory')
    if not resolved.parent.is_dir():
        raise ValueError('Output parent directory must already exist')
    return resolved


def pin_graph(c, data, field, pins):
    graph = data[field]
    c.require(type(graph) is dict and graph, 'Missing pinned graph ' + field)
    for path, digest in graph.items():
        c.require(Path(path).is_absolute(), 'Pins must use absolute paths')
        c.pin(path, digest, pins)


def physical_proof(c, args, pins):
    for path, digest in [(RAW_PROOF, RAW_PROOF_SHA), (FINITE_PROOF, FINITE_PROOF_SHA)]:
        c.pin(path, digest, pins)
    raw, finite = c.load(RAW_PROOF), c.load(FINITE_PROOF)
    c.require(raw['accepted'] is True and raw['raw_basis_pole_bound'] == -4
              and raw['raw_basis_size'] == 42, 'Physical raw pole support differs')
    c.require(finite['status'] == 'passed_all_254_proper_faces_and_overall_scaling'
              and finite['all_negative_Laurent_coefficients_exactly_zero'] is True
              and finite['FMFT_equals_native_finite_coefficient'] is True,
              'Physical finite target proof differs')
    for path, digest in raw['input_sha256'].items():
        c.pin(path, digest, pins)
    c.pin(RAW_PROOF.parent / 'verify.py', raw['verifier_sha256'], pins)
    c.pin(FINITE_PROOF.parent / 'verify.py', finite['validator_sha256'], pins)
    c.pin(finite['canonical_reference_input_path'], finite['canonical_reference_input_sha256'], pins)
    if args.physical_proof_review is None:
        c.require(pending_only(args), 'Final acceptance needs a blessed physical proof review')
        return False
    c.require(args.physical_proof_review_sha256, 'Physical proof review checksum required')
    c.pin(args.physical_proof_review, args.physical_proof_review_sha256, pins)
    review = c.load(args.physical_proof_review)
    c.require(review['accepted'] is True
              and review['status'] == 'passed_raw42_physical_pole_bound_and_P17_exact_finiteness'
              and review['raw_pole_certificate_sha256'] == RAW_PROOF_SHA
              and review['finiteness_certificate_sha256'] == FINITE_PROOF_SHA,
              'Scientific review does not accept the frozen physical proofs')
    for field in ['implementation_sha256', 'transitive_source_sha256']:
        pin_graph(c, review, field, pins)
    return True


def reviewed_implementation(args, implementations):
    if args.independent_review is None:
        if not pending_only(args):
            raise ValueError('Final acceptance needs an explicit independent validator review')
        return None
    if not args.independent_review_sha256 or sha(args.independent_review) != args.independent_review_sha256:
        raise ValueError('Independent validator review checksum differs')
    review = load(args.independent_review)
    if review['status'] != 'passed_for_frozen_physical_X8_chain_validator' or review['accepted'] is not True:
        raise ValueError('Independent validator review is not accepted')
    if review['validator_sha256'] != implementations[str(HERE / 'validate.py')]:
        raise ValueError('Independent review addresses another validator')
    if review['implementation_sha256'] != implementations:
        raise ValueError('Independent review implementation set differs')
    return review


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--profile', choices=tuple(PROFILES), required=True)
    parser.add_argument('--input-directory', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--initial-admission', type=Path)
    parser.add_argument('--initial-admission-sha256')
    parser.add_argument('--prefix-steps', type=int)
    parser.add_argument('--independent-review', type=Path)
    parser.add_argument('--independent-review-sha256')
    parser.add_argument('--physical-proof-review', type=Path)
    parser.add_argument('--physical-proof-review-sha256')
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    profile = PROFILES[args.profile]
    args.initial = ROOT / f'helper/frobenius-transport/x8-production-{args.profile}-scheduled-v1/conditional-initial.json'
    args.input_directory = args.input_directory or ROOT / f'hierarchy-transport/x8-production-{args.profile}-halfsteps-v11'
    if args.prefix_steps is not None and not 1 <= args.prefix_steps <= 12:
        raise ValueError('A pending prefix must select between one and twelve completed steps')
    if (args.initial_admission is None) != (args.initial_admission_sha256 is None):
        raise ValueError('Initial source admission needs both an explicit path and blessed checksum')
    if args.initial_admission is None and not pending_only(args):
        raise ValueError('Final physical chain acceptance needs a separately blessed initial-source admission')
    started = time.monotonic()
    output = fresh_output(args.output)
    if sha(COMMON) != COMMON_SHA or sha(INITIAL_MODULE) != INITIAL_MODULE_SHA:
        raise ValueError('Frozen common or initial-envelope helper changed')
    c = explicit('physical_X8_RPF_readonly_common', COMMON)
    checker_pins_path = HERE / 'checker-pins.json'
    checker_pins = c.load(checker_pins_path)
    c.require(checker_pins['schema'] == 'vakint.physical-X8-RPF-checker-pins.v1', 'Unknown checker pin schema')
    checker_path = Path(checker_pins['checker_path']).resolve()
    for path, digest in checker_pins['implementation_sha256'].items():
        c.require(Path(path).is_absolute() and c.sha(path) == digest, 'Generic checker implementation changed')
    c.require(checker_pins['implementation_sha256'].get(str(checker_path)) == c.sha(checker_path), 'Checker is absent from its pinned implementation graph')
    implementations = {str(path): sha(path) for path in [HERE / 'validate.py', INITIAL_MODULE, COMMON, checker_pins_path]}
    implementations.update(checker_pins['implementation_sha256'])
    accepted_review = reviewed_implementation(args, implementations)
    sources, artifacts = dict(implementations), {}
    initial_module = explicit('physical_X8_RPF_initial_admission', INITIAL_MODULE)
    checker_review_accepted = False
    if checker_pins['independent_review_path'] is not None:
        c.pin(checker_pins['independent_review_path'], checker_pins['independent_review_sha256'], sources)
        checker_review = c.load(checker_pins['independent_review_path'])
        c.require(checker_review['accepted'] is True
                  and checker_review['status'] == 'passed_for_frozen_generic_RPF_step_checker'
                  and checker_review['implementation_sha256'] == checker_pins['implementation_sha256'],
                  'Generic RPF checker is not independently accepted for these exact implementations')
        pin_graph(c, checker_review, 'source_pins', sources)
        checker_review_accepted = True
    else:
        c.require(pending_only(args), 'Final acceptance needs the generic checker independent review')
    checker = explicit('physical_X8_reviewed_generic_RPF_checker', checker_path)
    if accepted_review:
        c.pin(args.independent_review, args.independent_review_sha256, sources)
        pin_graph(c, accepted_review, 'source_pins', sources)
    c.pin(WRAPPER_REVIEW, WRAPPER_REVIEW_SHA, sources)
    wrapper_review = c.load(WRAPPER_REVIEW)
    c.require(wrapper_review['accepted'] is True
              and wrapper_review['status'] == 'passed_for_frozen_X8_RPF_v10_export_preparation_driver_and_saved_12_halfstep_chain',
              'Frozen RPFv10 wrapper review differs')
    pin_graph(c, wrapper_review, 'implementation_and_source_sha256', sources)
    pin_graph(c, wrapper_review, 'review_receipts', sources)
    c.pin(METADATA_REVIEW, METADATA_REVIEW_SHA, sources)
    metadata_review = c.load(METADATA_REVIEW)
    c.require(metadata_review['accepted_for_numeric_delta_and_actual_AB_conditional_computation'] is True
              and metadata_review['accepted_for_generic_fail_closed_conditional_source_policy'] is False
              and metadata_review['accepted_for_physical_source_or_final_precision'] is False
              and metadata_review['nonmetadata_AST_byte_identical'] is True
              and metadata_review['numerical_recurrence_gauge_precision_serialization_and_error_gate_unchanged'] is True
              and metadata_review['driver_sha256'] == sha(DRIVER),
              'V11 numerical-only metadata delta or its explicit scope differs')
    pin_graph(c, metadata_review, 'source_pins', sources)
    scientific_review_accepted = physical_proof(c, args, sources)
    c.pin(args.initial, profile['initial_sha256'], artifacts)
    initial = c.load(args.initial)
    initial_metadata(c, initial)
    initial_origin_accepted = False
    initial_proof = {'physical_provenance_verified': False,
                     'conditional_initial_schema_verified': True,
                     'actual_physical_accuracy_certified_field_present': False,
                     'absence_is_not_physical_admission': True,
                     'known_absence_authority_path': str(METADATA_REVIEW),
                     'known_absence_authority_sha256': METADATA_REVIEW_SHA}
    if args.initial_admission is not None:
        c.require(args.initial_admission_sha256 == profile['admission_sha256'],
                  'Initial admission is not the explicitly blessed artifact for this A/B profile')
        initial, admission_checks = initial_module.verify(c, ROOT, args.initial, args.initial_admission,
                                                         args.initial_admission_sha256, sources, artifacts)
        envelope = c.load(args.initial_admission)
        c.require(envelope['profile'] == args.profile
                  and envelope['conditional_generation_scope_closed_by_this_separate_admission'] is True
                  and envelope['independent_author_review_sha256'] == INITIAL_AUTHOR_REVIEW_SHA,
                  'Physical source envelope profile, classification closure or author review differs')
        c.pin(envelope['independent_author_review_path'], INITIAL_AUTHOR_REVIEW_SHA, sources)
        initial_proof.update(admission_checks)
        initial_origin_accepted = True
    connection, rpf = c.load(CONNECTION), c.load(RPF)
    source_sha = connection['source_sha256']
    c.require(initial['source_equation_sha256'] == source_sha, 'Initial and ordinary connection sources differ')
    c.pin(connection['source'], source_sha, sources)
    raw_connection_check = checker.check_raw_to_polynomial(connection['source'], CONNECTION)
    c.require(raw_connection_check['exact_matrix_entries'] == 1764
              and raw_connection_check['regular_unit_gauge_verified'] is True,
              'Raw-to-regular X8 matrix is not completely checked')
    chain = args.input_directory.resolve()
    c.require(chain.is_dir(), 'Missing completed chain directory')
    binding_path, complete_path, progress_path = [chain / name for name in ['run-binding.json', 'complete.json', 'progress.json']]
    c.pin(binding_path, profile['binding_sha256'], artifacts)
    binding = c.load(binding_path)
    complete = progress = None
    if args.prefix_steps is None:
        complete, progress = c.load(complete_path), c.load(progress_path)
        for path in [complete_path, progress_path]:
            artifacts[str(path)] = c.sha(path)
    expected_binding = {'initial_sha256': c.sha(args.initial), 'driver_sha256': c.sha(DRIVER),
                        'preparer_sha256': c.sha(PREPARER), 'connection_sha256': c.sha(CONNECTION),
                        'native_sha256': c.sha(NATIVE), 'source_equation_sha256': source_sha,
                        'normalization': 'native_raw', 'error_quality': 'rigorous-bound',
                        'dimension': 42, 'epsilon_jet_count': 6, 'end_eta_imag': '1/16',
                        'initial_contract_sha256': None, 'partial_fraction_sha256': None,
                        'physical_source_admission_required': True,
                        'conditional_initial_explicitly_authorized': True,
                        'local_target_digits': profile['digits'], 'guard_digits': profile['guard'],
                        'required_final_absolute_digits': profile['required_final_digits'],
                        'native_worker_threads': 8, 'substeps_per_halving': 1}
    for key, wanted in expected_binding.items():
        c.require(type(binding[key]) is type(wanted) and binding[key] == wanted, 'RPF run binding differs: ' + key)
    for key, path in [('native_path', NATIVE), ('preparer_path', PREPARER)]:
        c.require(Path(binding[key]).resolve() == path.resolve(), 'Unreviewed executable/helper path')
    dependencies = binding['implementation_and_source_dependency_sha256']
    expected_dependencies = {DRIVER, PREPARER, ROOT / 'helper/jet-transport/append_rpf_scaled.py',
                             ROOT / 'helper/jet-transport/prepare_generic_segment.py',
                             ROOT / 'helper/frobenius-transport/native/prepare_v2.py', CONNECTION,
                             Path(connection['source']), RPF, ROOT / 'jet-transport/partial-fractions-regular-gauge.json',
                             ROOT / 'jet-transport/export_x8_rpf.py'}
    c.require(set(map(Path, dependencies)) == expected_dependencies, 'RPF run dependency graph is incomplete or unexpected')
    for path, digest in dependencies.items():
        c.pin(path, digest, sources)
    digits, guard, workers, substeps = [binding[key] for key in ['local_target_digits', 'guard_digits', 'native_worker_threads', 'substeps_per_halving']]
    c.require(type(digits) is int and digits >= 32 and type(guard) is int and guard >= 32, 'Invalid precision policy')
    c.require(type(workers) is int and workers in (1, 2, 4, 8), 'Unreviewed native worker count')
    c.require(type(substeps) is int and 1 <= substeps <= 64, 'Invalid halving subdivision')
    ctx.dps = digits + guard
    center, end = Q(initial['eta_center'][1]), Q(1, 16)
    destinations, top = [], center
    while top > end:
        bottom = max(end, top / 2)
        step = (top - bottom) / substeps
        destinations.extend(top - step * k for k in range(1, substeps + 1))
        top = bottom
    c.require(destinations and destinations[-1] == end, 'Incomplete physical contour')
    expected_count = len(destinations)
    c.require(expected_count == 12, 'The frozen A/B production contour must have twelve halfsteps')
    count = expected_count if args.prefix_steps is None else args.prefix_steps
    if args.prefix_steps is None:
        for pattern in ['step-*.in', 'step-*-native.json', 'step-*-boundary.json']:
            if pattern == 'step-*.in':
                wanted = {chain / f'step-{i:03}{suffix}.in' for i in range(count) for suffix in ['', '.polynomial']}
            else:
                wanted = {chain / pattern.replace('*', f'{i:03}', 1) for i in range(count)}
            c.require(set(chain.glob(pattern)) == wanted, 'Missing or orphan completed artifact ' + pattern)
    previous, steps, budget = args.initial.resolve(), [], None
    for i, destination in enumerate(destinations[:count]):
        ip, mp, op, bp = [chain / f'step-{i:03}{suffix}' for suffix in ['.in', '.json', '-native.json', '-boundary.json']]
        meta, native, following = [c.load(path) for path in [mp, op, bp]]
        c.require(following['schema'] == 'vakint.certified-ancestor-ordinary-boundary.v1',
                  'Produced boundary schema differs')
        produced_metadata(c, following, 'boundary')
        c.require(meta['center'] == ['0', str(center)] and meta['step'] == ['0', str(destination - center)]
                  and following['eta_center'] == ['0', str(destination)], 'Exact center/step ordering differs')
        for key, wanted in [('initial_boundary_sha256', c.sha(args.initial)), ('run_binding_sha256', c.sha(binding_path)),
                            ('source_equation_sha256', source_sha)]:
            c.require(following[key] == wanted, 'Following boundary binding differs: ' + key)
        header = list(map(int, ip.read_text().splitlines()[0].split()))
        c.require(len(header) == 9 and header[:3] == [42, 6, 8], 'Native polynomial header differs')
        c.require(header[5] == math.ceil((digits + guard) * math.log2(10))
                  and header[6] == digits and header[7] >= 8 and header[8] >= 1,
                  'Native header differs from the frozen precision/operational policy')
        contract = checker.StepContract(
            dimension=42, jets=6, epsilon_min_power=-4,
            polynomial_sha256=c.sha(CONNECTION), rational_pf_sha256=c.sha(RPF),
            source_equation_sha256=source_sha, working_bits=header[5],
            target_digits=digits, serialization_decimal_digits=digits + guard,
            run_binding_sha256=c.sha(binding_path), initial_boundary_sha256=c.sha(args.initial),
            component_scale_policy='identity', expected_worker_threads=workers,
            boundary_metadata_policy='conditional_v11', absent_flag_initial_sha256=profile['initial_sha256'])
        checked = checker.check_step(ip, mp, previous, CONNECTION, RPF, op, bp, contract)
        c.require(checked['accepted'] is True and checked['dimension'] == 42 and checked['jets'] == 6
                  and checked['input_full_box_containments'] == 252 and checked['output_full_box_containments'] == 252
                  and checked['original_outward_driver_serialization_byte_identical'] is True
                  and checked['row_aggregation_checked'] is True and checked['precision_schedule_metadata_checked'] is True
                  and checked['mask_metadata_checked'] is True
                  and checked['boundary_metadata_policy'] == 'conditional_v11',
                  'Generic checker did not validate all required X8 paths')
        prior_profile, following_profile = checked['prior_boundary_profile'], checked['following_boundary_profile']
        c.require(prior_profile['absent_flag_initial_admitted'] is (i == 0)
                  and prior_profile['physical_accuracy_certified_field_present'] is (i != 0)
                  and prior_profile['physical_accuracy_certified'] is (None if i == 0 else False)
                  and following_profile['physical_accuracy_certified_field_present'] is True
                  and following_profile['physical_accuracy_certified'] is False,
                  'Generic boundary diagnostics do not preserve actual absent/false metadata')
        for path, digest in checked['artifact_sha256'].items():
            c.require(path not in artifacts or artifacts[path] == digest, 'Conflicting artifact pin')
            artifacts[path] = digest
        current_budget = tuple(header[5:])
        c.require(budget is None or budget == current_budget, 'Operational native policy changed within the chain')
        budget = current_budget
        for key in ['local_tail_certified', 'rational_pf_identity_verified', 'auxiliary_mask_verified',
                    'row_denominator_aggregation_verified', 'full_precision_total_and_certificate']:
            c.require(native[key] is True, 'Native local certificate is incomplete: ' + key)
        c.require(type(native['openmp_requested_threads']) is int and native['openmp_requested_threads'] == workers
                  and type(native['openmp_actual_threads']) is int and native['openmp_actual_threads'] == workers
                  and type(native['openmp_thread_cap']) is int and native['openmp_thread_cap'] == 16,
                  'Actual native workers differ from the frozen request')
        c.require(native['working_bits'] == header[5] and native['target_absolute_digits'] == digits
                  and type(native['order']) is int and 8 <= native['order'] <= header[7]
                  and (native['order'] % header[8] == 0 or native['order'] == header[7]), 'Native precision/order differs')
        tail = arb(native['tail_upper_enclosure'])
        c.require(tail.is_finite() and tail >= 0 and tail.upper() < (arb(10) ** (-digits) / 16).lower(), 'Local certified tail exceeds its gate')
        c.require(type(native['seconds']) in (int, float) and native['seconds'] >= 0,
                  'Invalid native elapsed time')
        steps.append({'index': i, 'center': str(center), 'destination': str(destination),
                      'boundary_sha256': c.sha(bp), 'native_order': native['order'],
                      'native_seconds': native['seconds'], 'local_tail': native['tail_upper_enclosure'],
                      'exact_step_audit': checked})
        previous, center = bp, destination
    ctx.dps = digits + guard
    final = c.load(previous)
    values = [acb(arb(x), arb(y)) for x, y in final['values']]
    c.require(len(values) == 252 and all(z.is_finite() for z in values), 'Incomplete/nonfinite final vector')
    width = max(max(z.real.rad(), z.imag.rad()) for z in values)
    required = binding['required_final_absolute_digits']
    if args.prefix_steps is None:
        c.require(complete['schema'] == 'vakint.certified-X8-rpf-ordinary-transport.v11'
                  and complete['complete'] is True and complete['error_quality'] == 'rigorous-bound',
                  'RPFv11 chain is not complete')
        produced_metadata(c, complete, 'complete receipt')
        c.require(progress['schema'] == 'vakint.certified-ancestor-transport-progress.v1'
                  and progress['completed_steps'] == progress['expected_steps'] == count,
                  'Progress ledger is incomplete')
        c.require('physical_accuracy_certified' not in progress
                  and 'physical_source_admission_required' not in progress,
                  'Progress ledger unexpectedly makes a physical classification')
        def absolute(path):
            value = Path(path)
            return (value if value.is_absolute() else ROOT / value).resolve()
        c.require(absolute(complete['final_boundary']) == absolute(progress['last_boundary']) == previous.resolve(),
                  'Final boundary path differs')
        c.require(complete['final_boundary_sha256'] == progress['last_boundary_sha256'] == c.sha(previous),
                  'Final boundary checksum differs')
        c.require(complete['run_binding_sha256'] == progress['run_binding_sha256'] == c.sha(binding_path),
                  'Final run binding differs')
        for summary in [complete['steps'], progress['steps']]:
            c.require(type(summary) is list and len(summary) == count, 'Step summary is incomplete')
            for recorded, checked in zip(summary, steps):
                for key in ['index', 'center', 'destination', 'boundary_sha256', 'native_seconds', 'order', 'local_tail']:
                    wanted = checked['native_order'] if key == 'order' else checked[key]
                    c.require(recorded[key] == wanted, 'Step summary differs from checked data: ' + key)
        c.require(width.str(35, more=True) == complete['maximum_component_radius'],
                  'Final radius serialization differs')
        c.require(type(required) is int and complete['required_final_absolute_digits'] == required
                  and complete['all_final_component_radii_meet_target'] is True and width < arb(10) ** (-required),
                  'Final absolute-error gate failed')
        c.require(complete['native_seconds'] == sum(row['native_seconds'] for row in steps),
                  'Native timing sum differs')
        for data in [complete, progress, final]:
            c.require(data['whole_PR11d_20000_accuracy_claimed'] is False,
                      'Ordinary chain promotes whole-period accuracy')
    for path, digest in {**sources, **artifacts}.items():
        c.require(c.sha(path) == digest, 'Immutable source/artifact changed during validation: ' + path)
    accepted = bool(accepted_review and checker_review_accepted and scientific_review_accepted
                    and initial_origin_accepted and not pending_only(args))
    status = ('passed_for_frozen_completed_physical_chain' if accepted else
              'checks_passed_prefix_only_no_physical_chain_acceptance' if args.prefix_steps is not None else
              'checks_passed_independent_review_pending')
    report = {'schema': 'vakint.pr11d.physical-X8-chain-acceptance.v1',
              'status': status, 'transport_family': 'rational-PF-v11', 'production_profile': args.profile,
              'validator_sha256': sha(Path(__file__)),
              'check_only': args.check_only, 'independent_validator_review_path': str(args.independent_review.resolve()) if accepted_review else None,
              'independent_validator_review_sha256': args.independent_review_sha256 if accepted_review else None,
              'prefix_steps': args.prefix_steps, 'expected_complete_steps': expected_count,
              'completed_execution_verified': args.prefix_steps is None,
              'physical_proof_review_path': str(args.physical_proof_review.resolve()) if scientific_review_accepted else None,
              'physical_proof_review_sha256': args.physical_proof_review_sha256 if scientific_review_accepted else None,
              'source_pins': sources, 'artifact_sha256': artifacts, 'source_equation_sha256': source_sha,
              'basis': 'original_raw_epsilon_jets', 'dimension': 42, 'jets': 6, 'epsilon_range': [-4, 1],
              'epsilon_min_power': -4, 'epsilon_max_power': 1, 'normalization': 'native_raw', 'error_quality': 'rigorous-bound',
              'eta_center': ['0', str(center)], 'chain_directory': str(chain),
              'initial_physical_boundary_sha256': c.sha(args.initial), 'initial_physical_proof_pins': initial_proof,
              'initial_source_admission_path': str(args.initial_admission.resolve()) if initial_origin_accepted else None,
              'initial_source_admission_sha256': args.initial_admission_sha256 if initial_origin_accepted else None,
              'actual_initial_physical_accuracy_certified_field_present': False,
              'initial_known_absence_metadata_review_sha256': METADATA_REVIEW_SHA,
              'conditional_generation_markers_preserved': True,
              'physical_origin_established_by_separate_admission': initial_origin_accepted,
              'raw_pole_certificate_sha256': RAW_PROOF_SHA, 'finiteness_certificate_sha256': FINITE_PROOF_SHA,
              'initial_physical_provenance_verified': initial_origin_accepted, 'all_step_source_hashes_and_centers_verified': True,
              'all_local_tails_certified': True, 'all_interval_gauge_and_serialization_checks_passed': True,
              'all_RPF_and_polynomial_inputs_exactly_reconstructed': True, 'steps_verified': count,
              'raw_to_regular_polynomial_check': raw_connection_check,
              'final_boundary': str(previous.resolve()), 'final_boundary_sha256': c.sha(previous),
              'final_maximum_component_radius': width.str(35, more=True),
              'complete_receipt_path': str(complete_path) if args.prefix_steps is None else None,
              'complete_receipt_sha256': c.sha(complete_path) if args.prefix_steps is None else None,
              'required_final_absolute_digits': required, 'steps': steps,
              'native_or_prefix_recurrence_rerun': False, 'immutable_sources_or_payloads_modified': False,
              'final_PR11d_precision_cap_unchanged': 200, 'whole_PR11d_20000_accuracy_claimed': False,
              'independent_IBP_validation_claimed': False,
              'inherited_IBP_scope_qualification': 'Uses the authenticated prepared X8 differential-system snapshot; chain validation does not enlarge the independently established IBP scope.',
              'seconds': time.monotonic() - started}
    with output.open('x') as stream:
        stream.write(json.dumps(report, indent=2) + '\n')
    print('PASS physical X8 RPF chain', count, 'steps;', report['status'], report['seconds'], 'seconds')


if __name__ == '__main__':
    main()
