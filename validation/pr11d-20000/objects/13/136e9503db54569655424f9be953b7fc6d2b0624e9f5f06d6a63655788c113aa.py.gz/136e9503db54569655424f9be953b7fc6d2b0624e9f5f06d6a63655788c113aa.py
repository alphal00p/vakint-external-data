"""Retain and certify every source exclusion on the formal epsilon contour."""
from pathlib import Path
from fractions import Fraction as F
import ast,json,hashlib
from flint import fmpq_mpoly_ctx,fmpq,fmpq_poly
ROOT=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Acceptance guard validation requires assertions enabled')
input=json.loads((ROOT/'input.json').read_text());guards=input['retained_native_nonzero_conditions']
connection_path=ROOT.parent/'jet-transport/polynomial-connection.json';connection=json.loads(connection_path.read_text());source_path=Path(connection['source']);source=json.loads(source_path.read_text())
assert hashlib.sha256(source_path.read_bytes()).hexdigest()==connection['source_sha256']==input['source_paths_sha256'][str(source_path)]
assert guards==source['nonzero_conditions'] and len(guards)==121
C=fmpq_mpoly_ctx.get(['e','x']);e,x=C.gens()
class RF:
 def __init__(self,n,d=None):
  self.n=n if hasattr(n,'to_dict') else C.constant(n);self.d=C.constant(1) if d is None else d
  assert self.d
  common=self.n.gcd(self.d);self.n=self.n/common;self.d=self.d/common
 def __add__(self,b):return RF(self.n*b.d+b.n*self.d,self.d*b.d)
 def __neg__(self):return RF(-self.n,self.d)
 def __sub__(self,b):return self+-b
 def __mul__(self,b):return RF(self.n*b.n,self.d*b.d)
 def __truediv__(self,b):return RF(self.n*b.d,self.d*b.n)
 def __pow__(self,n):return RF(self.n**n,self.d**n) if n>=0 else RF(self.d**(-n),self.n**(-n))
def parse(s):
 s=s.replace('masters_4l::{}::epsilon','e').replace('symbolica_amflow::{}::eta','x').replace('^','**')
 def walk(t):
  if isinstance(t,ast.Constant) and type(t.value) is int:return RF(t.value)
  if isinstance(t,ast.Name) and t.id in ['e','x']:return RF(e if t.id=='e' else x)
  if isinstance(t,ast.UnaryOp) and isinstance(t.op,ast.USub):return -walk(t.operand)
  if isinstance(t,ast.BinOp):
   if isinstance(t.op,ast.Pow):
    n=ast.literal_eval(t.right);assert type(n) is int;return walk(t.left)**n
   a,b=walk(t.left),walk(t.right)
   if isinstance(t.op,ast.Add):return a+b
   if isinstance(t.op,ast.Sub):return a-b
   if isinstance(t.op,ast.Mult):return a*b
   if isinstance(t.op,ast.Div):return a/b
  raise ValueError(ast.dump(t))
 return walk(ast.parse(s,mode='eval').body)
def sign(q):return 1 if q>0 else -1 if q<0 else 0
def evaluate(poly,value):
 answer=F(0)
 for c in reversed(poly.coeffs()):answer=answer*value+F(str(c))
 return answer
def variations(chain,point):
 ss=[sign(evaluate(p,point)) for p in chain];ss=[v for v in ss if v]
 return sum(a!=b for a,b in zip(ss,ss[1:]))
def no_roots_on_interval(p,a=F(1,16),b=F(256)):
 assert p and evaluate(p,a)!=0 and evaluate(p,b)!=0
 if p.degree()==0:return {'sturm_variations_left':0,'sturm_variations_right':0,'roots_on_closed_interval':0}
 chain=[p,p.derivative()]
 while chain[-1]:
  rem=-(chain[-2]%chain[-1])
  if not rem:break
  chain.append(rem)
 left,right=variations(chain,a),variations(chain,b);assert left==right
 return {'sturm_variations_left':left,'sturm_variations_right':right,'roots_on_closed_interval':left-right}
def leading(poly):
 assert poly
 power=min(int(p[0]) for p in poly.to_dict());coeff={int(p[1]):F(str(c)) for p,c in poly.to_dict().items() if int(p[0])==power};degree=max(coeff)
 eta=fmpq_poly([fmpq(coeff.get(i,F(0)).numerator,coeff.get(i,F(0)).denominator) for i in range(degree+1)])
 re=fmpq_poly([eta[i]*((-1)**(i//2)) if i%2==0 else 0 for i in range(degree+1)])
 im=fmpq_poly([eta[i]*((-1)**((i-1)//2)) if i%2 else 0 for i in range(degree+1)])
 common=re.gcd(im);assert common
 certificate=no_roots_on_interval(common)
 return {'formal_epsilon_valuation':power,'leading_eta_coefficients':[str(c) for c in eta.coeffs()],'positive_imaginary_common_real_imag_polynomial':[str(c) for c in common.coeffs()],'proof':certificate}
output=[]
for index,text in enumerate(guards):
 q=parse(text);assert q.n and q.d
 output.append({'source_condition_index':index,'source_condition':text,'numerator_leading_epsilon_coefficient':leading(q.n),'denominator_leading_epsilon_coefficient':leading(q.d)})
result={'schema':'vakint.pr11d.AMFlow-formal-contour-domain-certification.v1','status':'all121_source_conditions_preserved_and_formally_nonzero_on_path','condition_count':len(output),'epsilon_interpretation':'Formal punctured epsilon germ: every condition numerator and denominator has a nonzero leading epsilon coefficient at every eta=i*y,1/16<=y<=256. Pure epsilon factors remain explicit formal Laurent divisors. No finite-epsilon exclusion is silently dropped.','method':'Exact rational polynomial parsing; exact gcd of real/imaginary leading coefficient at eta=i*y; exact Sturm root count on closed rational interval.','conditions':output,'input_sha256':hashlib.sha256((ROOT/'input.json').read_bytes()).hexdigest()}
(ROOT/'guard-validation.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',len(output),'full native source guards on physical contour')
