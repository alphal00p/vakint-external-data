#!/usr/bin/env python3
"""Exact applicability and source-prefix checks for physical X8 raw pole order.

The all-massive physical graph bound is distinct from the individual expanded
region factors, whose deeper UV/IR poles are retained and cancelled explicitly.
No numerical values or sampled epsilon points enter this certificate.
"""
import ast,hashlib,itertools,json,sys
from pathlib import Path
from fractions import Fraction
from flint import fmpq,fmpq_mat,fmpq_mpoly_ctx
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'pr11-boundary'))
from source_recipes import build_factor_expressions,read,sha
from logjet_map import BoundaryLogJetMap,valuation
from expanded_boundary import ExpandedBoundary

SOURCE=Path('/shared/codex-2/vacuum_masters/MASTERS/4L/artifacts/X8-Kira-derivative-closure-v1/prepared-system.json')
INVENTORY=HERE.parent/'pr11-boundary/inventory-full-v2.json'
P853FILE=HERE.parent.parent/'pr11d/p853/higher-order/p853-exact-jet-through-order7.json'
P853='pr11d::massless::8535684c37e21dfd38135b151cca892f3552977fef43ab9d0f2deb22f3762f64::raw_native'
CTX=fmpq_mpoly_ctx.get(('EulerGamma','zeta2','zeta3','zeta4','zeta5','zeta6','zeta7','zeta8'))
ZERO=CTX.constant(0)

def q(x):
    x=Fraction(x);return fmpq(x.numerator,x.denominator)

def lift(poly):
    return CTX.from_dict({tuple(powers)+(0,)*(8-len(powers)):coefficient for powers,coefficient in poly.to_dict().items()})

def exact_ast(node):
    if len(node)!=1:raise ValueError('A checked exact P853 expression node is required')
    kind,value=next(iter(node.items()))
    if kind=='integer':return CTX.constant(int(value))
    if kind=='rational':return CTX.constant(fmpq(int(value[0]),int(value[1])))
    if kind=='symbol':
        names={'gamma':0,'z2':1,'z3':2,'z5':4,'z7':6}
        return CTX.gen(names[value])
    if kind=='sum':return sum((exact_ast(v) for v in value),ZERO)
    if kind=='product':
        out=CTX.constant(1)
        for v in value:out*=exact_ast(v)
        return out
    if kind=='power':
        base,exponent=value
        if set(exponent)!={'integer'} or int(exponent['integer'])<0:raise ValueError('Nonnegative exact polynomial power required')
        return exact_ast(base)**int(exponent['integer'])
    raise ValueError('Unsupported exact P853 operation '+kind)

def graph_certificate(data):
    family=data['family'];basis=data['basis'];pairs=[(i,j) for i in range(4) for j in range(i,4)]
    assert data['source_family_sha256']=='693719b1bc3d2f1d4d32c9312df66ced667a542591a2ada6f6498844fc5d0de1'
    assert family['external_momenta']==[] and len(family['loop_momenta'])==4 and data['deformed_propagators']==[3]
    assert len(basis)==42 and all(len(row)==10 and all(type(n) is int and n>=0 for n in row) for row in basis)
    vectors=[]
    for prop in family['denominators']:
        assert prop['constant']=='-1'
        cs=[Fraction(c) for c in prop['coefficients']]
        pivot=next(i for i in range(4) if cs[pairs.index((i,i))])
        assert cs[pairs.index((pivot,pivot))]==1
        v=[cs[pairs.index(tuple(sorted((i,pivot))))]/(1 if i==pivot else 2) for i in range(4)]
        assert all(c.denominator==1 for c in v)
        assert [v[i]*v[j]*(1 if i==j else 2) for i,j in pairs]==cs
        vectors.append([c.numerator for c in v])
    slots=sorted({i for row in basis for i,n in enumerate(row) if n})
    assert slots==list(range(1,9));V=[vectors[i] for i in slots]
    # Five vertex conservation rows for the eight actual physical branches.
    B=[[-1,0,0,0,0,-1,0,1],[0,0,-1,0,1,0,-1,0],[0,0,1,-1,0,1,0,0],
       [0,1,0,1,0,0,1,-1],[1,-1,0,0,-1,0,0,0]]
    assert fmpq_mat(B).rank()==4 and fmpq_mat(V).rank()==4
    assert fmpq_mat(B)*fmpq_mat(V)==fmpq_mat(5,4)
    edges=[]
    for j in range(8):
        negative=[i for i in range(5) if B[i][j]==-1];positive=[i for i in range(5) if B[i][j]==1]
        assert len(negative)==len(positive)==1 and sum(B[i][j]!=0 for i in range(5))==2
        edges.append([negative[0],positive[0]])
    minors=[]
    for chosen in itertools.combinations(range(8),4):
        det=fmpq_mat([V[i] for i in chosen]).det()
        if det:
            assert abs(det)==1
            minors.append({'family_slots':[slots[i] for i in chosen],'determinant':str(det),'U_coefficient':'1'})
    assert minors
    rows=[]
    for component,powers in enumerate(basis):
        parent=list(range(5))
        def find(i):
            while parent[i]!=i:i=parent[i]
            return i
        for j,(u,v) in enumerate(edges):
            if not powers[slots[j]]:parent[find(u)]=find(v)
        vertices=sorted({find(i) for i in range(5)});index={v:i for i,v in enumerate(vertices)}
        active=[j for j,slot in enumerate(slots) if powers[slot]]
        incidence=[[0]*len(active) for _ in vertices]
        for column,j in enumerate(active):
            u,v=edges[j];incidence[index[find(u)]][column]-=1;incidence[index[find(v)]][column]+=1
        rank=fmpq_mat(incidence).rank();loops=len(active)-rank
        restricted=[V[j] for j in active]
        assert loops==4 and fmpq_mat(restricted).rank()==4
        assert fmpq_mat(incidence)*fmpq_mat(restricted)==fmpq_mat(len(vertices),4)
        rows.append({'component':component,'powers':powers,'active_slots':[slots[j] for j in active],
          'contracted_vertex_count':len(vertices),'active_edge_count':len(active),'incidence_rank':rank,'independent_loops':loops,
          'positive_mass_denominators':True,'no_negative_index_numerators':True,'mass_derivative_orders':[max(0,n-1) for n in powers]})
    return {'physical_loop_count':4,'active_family_slots':slots,'quadratic_vectors':vectors,'vertex_incidence_matrix':B,'edge_endpoints':edges,
      'graph_cycle_dimension':4,'unimodular_cycle_basis':True,'positive_Cauchy_Binet_U_terms':minors,'basis_checks':rows,
      'mass_domain':'Re(eta)>-1: every active Euclidean mass squared is1, except family slot3 with1+eta, all with positive real part',
      'contour_included':'Entire imaginary eta axis and an open neighborhood of eta=0',
      'infrared_bound':'Re(sum(alpha_e*m_e^2)) >= min(1,1+Re(eta))*sum(alpha_e), for every alpha_e>=0; strict positive gap on compact subsets'}

def source_zero_certificate():
    factors,recipes=build_factor_expressions();plan=BoundaryLogJetMap.from_file(INVENTORY,'db5290bc8520499001d9998098d95474270ba2f5ffed1213dfa5ce2062eac7e9')
    inventory=read(INVENTORY);assert len(inventory['boundary_coefficients'])==132 and len(inventory['coverage'])==1591
    lower=lambda k:-2 if k=='native::L2_P2' else -3 if k.startswith('native::L3_') or k.startswith('pr11d::') else-4
    # Conservative exact Gamma divisor bounds, before any sector cancellation.
    minimum=0;term_count=0
    for row in inventory['boundary_coefficients']:
        for product in row['products']:
            from gamma_ast import GammaExpression,Monomial
            from logjet_map import parse,EPS
            expression=GammaExpression([Monomial(parse(product['coefficient'],EPS,'unused'))],identity='native regional coefficient')
            for key in product['factor_keys']:expression=expression.multiply(factors[key])
            for r,_,keys in expression.terms:
                minimum=min(minimum,valuation(r)+sum(lower(k) for k in keys));term_count+=1
    assert minimum==-6
    compiled=ExpandedBoundary(plan,factors,max_log_power=8)
    exact_source=read(P853FILE);prefix={r['epsilon_power']:exact_ast(r['ast']) for r in exact_source['native_raw'] if r['epsilon_power']<=-2}
    assert prefix[-3]==CTX.constant(fmpq(1,3)) and prefix[-2]==CTX.constant(fmpq(7,3))-CTX.gen(0)
    zero_rows=[];primitive_requirements=set()
    for component,alpha in sorted(plan.selectors):
        for p in range(minimum,-4):
            for ell in range(9):
                expression=compiled.expressions.get((component,alpha,ell));total=ZERO
                if expression:
                    for keys,multiplier in expression.grouped_primitive_coefficients().items():
                        through=p-ell-sum(lower(k) for k in keys);formal=multiplier.formal_gamma_coefficients(through)
                        if not keys:
                            total+=lift(formal.get(p-ell,CTX.constant(0)))
                        elif keys==(P853,):
                            for exponent,coefficient in formal.items():
                                needed=p-ell-exponent
                                if needed < -3:continue
                                if not coefficient:continue
                                if needed not in prefix:raise ValueError('A further exact P853 coefficient is needed for negative support')
                                total+=lift(coefficient)*prefix[needed];primitive_requirements.add(needed)
                        elif any(coefficient for coefficient in formal.values()):
                            raise ValueError('An unprovided exact primitive identity enters below physical pole bound: '+str(keys))
                assert not total,(component,str(alpha),p,ell,str(total))
                zero_rows.append({'component':component,'integer_z_power':str(alpha),'epsilon_power':p,'log_power':ell,'exact_coefficient':'0'})
    assert len(zero_rows)==666 and primitive_requirements=={-3,-2}
    return {'source_scope':'All37selected integer-power groups from the full132regionalrows, including every recorded epsilon slope and1591 native request outcomes',
      'regional_expanded_monomial_count':term_count,'conservative_lowest_sector_power':minimum,
      'forbidden_orders_checked':[-6,-5],'log_powers_checked':list(range(9)),'exact_zero_rows':zero_rows,
      'needed_exact_P853_orders':sorted(primitive_requirements),'exact_P853_prefix':{'-3':'1/3','-2':'7/3-EulerGamma'},
      'all_lower_orders_absent_by_exact_Gamma_divisors_and_primitive_support':True,'source_recipe_receipt':recipes,
      'scope_limitation':'This finite-source-prefix check alone is not a global ordinary-family pole theorem; that conclusion uses the independent all-massive graph argument.'}

def main():
    if not __debug__:raise RuntimeError('Assertions must remain enabled')
    data=read(SOURCE);graph=graph_certificate(data);zeros=source_zero_certificate()
    # Exact epsilon regularity of the ordinary connection is an algebraic
    # transport property, not the physical proof of the initial pole bound.
    from logjet_map import parse
    matrix=[[parse(s,data['epsilon_symbol'],data['variable']) for s in row] for row in data['differential_matrix']]
    negative=[(i,j,valuation(v)) for i,row in enumerate(matrix) for j,v in enumerate(row) if v.num and valuation(v)<0]
    assert not negative
    inputs=[SOURCE,INVENTORY,P853FILE,HERE.parent/'pr11-boundary/source_recipes.py',HERE.parent/'pr11-boundary/gamma_ast.py',HERE.parent/'pr11-boundary/gamma_jets.py',HERE.parent/'pr11-boundary/expanded_boundary.py']
    result={'schema':'vakint.X8-physical-raw-pole-support.v1','accepted':True,'raw_basis_pole_bound':-4,'raw_basis_size':42,
      'conclusion':'Every original physical raw basis integral is meromorphic in epsilon with no power below-4 throughout Re(eta)>-1; the complete selected source prefix has all666forbidden coefficients exactly zero.',
      'proof_authority':'Published UV-forest/maximum-pole theorem, applied after exact graph/mass/power checks; independent exact finite-prefix cancellations below-4',
      'references':[{'title':'Smirnov and Smirnov, Hepp and Speer sectors within modern strategies of sector decomposition','url':'https://arxiv.org/abs/0812.4700','location':'Section2, equations1 and6-8; maximalUVforests haveh nontrivial elements'},
        {'title':'Anselmi, Renormalization of a class of non-renormalizable theories','url':'https://arxiv.org/abs/hep-th/0502237','location':'AppendixA,publishedPDFpage36; maximalUVpoleorder<=loopcount; infrared safety established separately here'}],
      'graph_and_domain_checks':graph,'exact_source_prefix':zeros,'ordinary_connection_epsilon_regular':True,
      'transport_consequence':'An epsilon-regular raw ordinary ODE cannot create coefficients below the certified initial lower support. The physical graph theorem independently holds at every point of the contour and near the final endpoint.',
      'not_claimed':['No individual mixed massive/massless regional factor is assigned the physical four-loop bound','No rectangular campaign coverage is strengthened','No finite-prefix check is promoted into a global asymptotic completeness theorem','No numerical agreement or output precision is asserted'],
      'input_sha256':{str(p):sha(p) for p in inputs},'verifier_sha256':sha(Path(__file__))}
    output=HERE/'certificate.json'
    if output.exists():raise ValueError('Preserve prior support certificates')
    output.write_text(json.dumps(result,indent=2)+'\n');print('PASS:42physicalgraphs;666exactforbiddensourcecoefficients;rawpolebound-4')
if __name__=='__main__':main()
