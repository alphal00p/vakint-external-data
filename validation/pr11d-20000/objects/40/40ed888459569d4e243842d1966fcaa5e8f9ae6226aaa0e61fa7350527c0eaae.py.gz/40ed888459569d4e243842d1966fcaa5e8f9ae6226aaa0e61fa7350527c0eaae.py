"""Convolve certified adjoints with native raw jets; retain every coefficient ball."""
import argparse,hashlib,json,math
from fractions import Fraction
from pathlib import Path
from flint import arb,acb,ctx
HERE=Path(__file__).parent
if not __debug__:raise RuntimeError('Assertions required')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def project(name,boundary_path,adjoint_paths,digits,output):
 ctx.dps=digits;boundary=json.load(open(boundary_path));raw=HERE/f'{name}.json';data=json.load(open(raw));proof=HERE/f'{name}-endpoint-adjoints.json';pd=json.load(open(proof));dim=pd['dimension'];loops=pd['loop_count']
 assert boundary['basis']=='original_raw_epsilon_jets' and boundary['normalization']=='native_raw' and boundary['error_quality']=='rigorous-bound'
 assert boundary['source_equation_sha256']==sha(raw) and boundary['dimension']==dim and boundary['epsilon_min_power']==-loops and boundary['epsilon_max_power']==5-loops
 Y=[acb(arb(a),arb(b)) for a,b in boundary['values']];assert len(Y)==6*dim and all(z.is_finite() for z in Y)
 result={};receipts=[]
 for adjoint_path in adjoint_paths:
  adj=json.load(open(adjoint_path));assert adj['name']==name and adj['base_dimension']==dim and adj['endpoint_projector_proof_sha256']==sha(proof)
  assert all(Fraction(a)==Fraction(b) for a,b in zip(adj['eta_center'],boundary['eta_center']))
  W=[acb(arb(a),arb(b)) for a,b in adj['complex_balls']];assert len(W)==6*dim and all(z.is_finite() for z in W)
  rows=[]
  for p in range(6):
   value=sum((W[dim*j+i]*Y[dim*(p-j)+i] for j in range(p+1) for i in range(dim)),acb(0));assert value.imag.contains(0),'Physical vacuum coefficient has an unresolved imaginary component'
   rows.append({'epsilon_power':p-loops,'ball':value.real.str(digits+8,more=True),'imaginary_ball':value.imag.str(digits+8,more=True),'relative_accuracy_bits':int(value.real.rel_accuracy_bits()),'absolute_radius':value.real.rad().str(35,more=True)})
  result[adj['symbol']]=rows;receipts.append({'path':str(adjoint_path),'sha256':sha(adjoint_path),'order':adj['order'],'source_polynomial_sha256':adj['source_polynomial_sha256']})
 payload={'schema':'vakint.ancestor.certified-canonical-master-jets.v1','name':name,'normalization':'native_raw','error_quality':'rigorous-bound','coefficients':result,'target_bindings':pd['target_bindings'],'boundary_source':str(boundary_path),'boundary_sha256':sha(boundary_path),'source_sha256':sha(raw),'adjoint_proof_sha256':sha(proof),'adjoint_inputs':receipts,'precision_source':'Arb coefficient balls retain all input, recurrence, truncation and final convolution errors','whole_PR11d_accuracy_claimed':False};Path(output).write_text(json.dumps(payload,indent=2)+'\n');print('PROJECTION PASS',name,[(s,min(r['relative_accuracy_bits'] for r in v)) for s,v in result.items()]);return payload
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('--boundary',type=Path,required=True);p.add_argument('--adjoints',type=Path,nargs='+',required=True);p.add_argument('--digits',type=int,default=260);p.add_argument('--output',type=Path,required=True);a=p.parse_args();project(a.name,a.boundary,a.adjoints,a.digits,a.output)
