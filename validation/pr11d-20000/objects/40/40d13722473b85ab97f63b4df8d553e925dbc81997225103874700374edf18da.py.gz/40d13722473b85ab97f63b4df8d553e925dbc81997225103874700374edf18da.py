#!/usr/bin/env python3
"""Seal separately reviewed physical source, chain and endpoint admissions.

No source assembly, matching, recurrence, transport or projection is recomputed.
The caller supplies an explicit independently blessed whole-checker review.
"""
import argparse
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from flint import arb, acb, ctx

sys.dont_write_bytecode = True
if not __debug__:
    raise RuntimeError('Assertions required')
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
COMMON = HERE.parent / 'ordinary-chain-acceptance-v1/common.py'
COMMON_SHA = 'fa246be34bb42c21d6112a666c5840f36a0ced54f5667cd7b9487a4acc22e3ef'
ENDPOINT_SHA = '2b33f543f27e42ba6963fd6abc488b225a1f30d54c92fa1b2770bb42f6f839c1'
INITIAL_SHA = 'e82c3c649f9e48df240d4be2b058e78148a75bde273197ca7299f6a26c13ed7f'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--chain-data', type=Path, required=True)
    parser.add_argument('--endpoint-replay', type=Path, required=True)
    parser.add_argument('--initial-admission', type=Path, required=True)
    parser.add_argument('--initial-admission-sha256', required=True)
    parser.add_argument('--independent-review', type=Path, required=True)
    parser.add_argument('--independent-review-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    original, output = args.output, args.output.resolve()
    if original.is_symlink() or output.exists() or not output.is_relative_to(HERE) or not output.parent.is_dir():
        raise ValueError('Output must be a fresh nonsymlink path under this admission directory')
    if sha(COMMON) != COMMON_SHA:
        raise ValueError('Frozen common helper changed')
    spec = importlib.util.spec_from_file_location('production_A_seal_reader', COMMON)
    c = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = c
    spec.loader.exec_module(c)
    c.require(Path(c.__file__).resolve() == COMMON, 'Unexpected reader origin')
    sources = {str(COMMON): COMMON_SHA, str(Path(__file__)): sha(__file__)}
    artifacts = {}
    c.pin(args.independent_review, args.independent_review_sha256, sources)
    review = c.load(args.independent_review)
    c.require(review['accepted'] is True
              and review['status'] == 'passed_for_frozen_production_A_physical_source_checker',
              'Independent whole-checker review is not accepted')
    c.require(review['checker_sha256'] == sha(HERE / 'replay.py')
              and review['seal_sha256'] == sha(__file__), 'Independent review addresses another checker')
    for field in ['source_pins', 'implementation_sha256']:
        c.require(type(review[field]) is dict and review[field], 'Missing independent review source graph')
        for path, digest in review[field].items():
            c.require(Path(path).is_absolute(), 'Review graph paths must be absolute')
            c.pin(path, digest, sources)

    receipts = {}
    for name, path, expected in [('chain', args.chain_data, review['chain_data_review_sha256']),
                                 ('endpoint', args.endpoint_replay, review['endpoint_replay_sha256']),
                                 ('initial', args.initial_admission, args.initial_admission_sha256)]:
        c.pin(path, expected, artifacts)
        receipts[name] = c.load(path)
    chain, endpoint, initial = [receipts[name] for name in ['chain', 'endpoint', 'initial']]
    c.require(review['initial_admission_sha256'] == args.initial_admission_sha256
              and review['endpoint_sha256'] == ENDPOINT_SHA, 'Independent review addresses other physical data')
    c.require(chain['schema'] == 'vakint.PR9-production-A-chain-data-review.v1'
              and chain['status'] == 'passed_actual_data_and_reviewed_native_certificate_chain'
              and chain['checker_sha256'] == sha(HERE / 'replay.py'), 'Unaccepted or stale chain data')
    c.require(chain['completed_step_count'] == 49 and len(chain['steps']) == 49
              and [s['global_index'] for s in chain['steps']] == list(range(49))
              and [s['steps'] for s in chain['segments']] == [2, 2, 1, 44]
              and chain['initial_sha256'] == INITIAL_SHA, 'Incomplete physical transport lineage')
    c.require(chain['new_native_or_preparer_calls'] == 0
              and chain['all_checks_use_exact_identity_full_containment_or_original_outward_replay'] is True,
              'Wrong physical chain admission method')
    c.require(review['raw_22_basis_pole_bound_verified'] is True
              and review['raw_source_sha256'] == chain['raw_source_sha256'],
              'The physical six-jet closure lacks its independently verified lower pole bound')
    pole_certificate_path = c.pin(review['raw_22_pole_bound_certificate_path'],
                                  review['raw_22_pole_bound_certificate_sha256'], sources)
    pole_certificate = c.load(pole_certificate_path)
    c.require(pole_certificate['accepted'] is True
              and pole_certificate['schema'] == 'vakint.PR9-selected22-independent-physical-pole-application.v1'
              and pole_certificate['raw_22_basis_pole_bound_verified'] is True
              and type(pole_certificate['basis_size']) is int and pole_certificate['basis_size'] == 22
              and pole_certificate['raw_source_sha256'] == chain['raw_source_sha256'],
              'The exact positive-basis/numerator pole-bound certificate addresses another source or scope')
    pole_sources = pole_certificate['source_and_checker_sha256']
    c.require(type(pole_sources) is dict and pole_sources, 'The pole-bound authority lacks its source/checker graph')
    for path, digest in pole_sources.items():
        c.require(Path(path).is_absolute(), 'Pole-bound source pins must be absolute')
        c.pin(path, digest, sources)
    c.require(initial['schema'] == 'vakint.pr9.production-A.physical-initial-admission.v1'
              and initial['accepted'] is True and initial['status'] == 'passed_for_frozen_production_A_physical_initial'
              and initial['source_only'] is False and initial['initial_artifact_sha256'] == INITIAL_SHA,
              'Physical initial source and execution are not fully accepted')
    for field in ['initial_physical_source_admitted', 'all_132_seed_full_source_boxes_contained',
                  'all_132_actual_native_seed_strings_reproduced_exactly',
                  'all_numerical_history_fields_identical', 'both_132_normalized_and_raw_vectors_byte_identical',
                  'physical_primitive_API_and_sunset_proofs_revalidated']:
        c.require(initial[field] is True, 'Initial admission leaves an open source edge: ' + field)
    c.require(initial['source_boundary_rows_exactly_replayed_by_blessed_proof'] == 557
              and initial['matched_constants_exactly_replayed_by_blessed_proof'] == 132
              and initial['overlap_used_as_physical_acceptance'] is False,
              'Initial physical source rows were not exactly admitted')
    c.pin(initial['independent_review_path'], initial['independent_review_sha256'], sources)
    initial_review = c.load(initial['independent_review_path'])
    c.require(initial_review['accepted'] is True
              and initial_review['status'] == 'passed_for_frozen_production_A_initial_admission_checker_and_data'
              and initial_review['initial_artifact_sha256'] == INITIAL_SHA,
              'Initial source checker/data lack independent acceptance')
    c.pin(initial['fresh_native_invocation_path'], initial['fresh_native_invocation_sha256'], artifacts)
    invocation = c.load(initial['fresh_native_invocation_path'])
    c.require(invocation['schema'] == 'vakint.pr9.production-A.fresh-native-invocation.v1'
              and invocation['accepted_same_input_same_binary_replay'] is True
              and type(invocation['returncode']) is int and invocation['returncode'] == 0
              and invocation['all_numerical_history_and_contract_fields_equal'] is True,
              'Exact-input native initialization was not successfully reproduced')
    c.require(initial_review['native_invocation_sha256'] == initial['fresh_native_invocation_sha256'],
              'Independent initial review addresses another native invocation')
    c.require(endpoint['schema'] == 'vakint.pr11d.physical-4L-production-A-endpoint-replay.v1'
              and endpoint['accepted'] is True and endpoint['status'] == 'passed_for_frozen_42_endpoint_coefficients'
              and endpoint['endpoint_sha256'] == ENDPOINT_SHA, 'Endpoint coefficient replay is not accepted')
    c.require(endpoint['final_boundary_sha256'] == chain['final_boundary_sha256']
              and Path(endpoint['final_boundary_path']).resolve() == Path(chain['final_boundary_path']).resolve(),
              'Endpoint projection uses another transported boundary')
    checks = endpoint['endpoint_replay']
    for key, expected in [('working_decimal_digits', 20400), ('serialization_decimal_digits', 20408),
                          ('master_count', 7), ('complex_coefficient_count', 42),
                          ('component_full_box_containments', 84), ('byte_identical_component_strings', 84)]:
        c.require(type(checks[key]) is int and checks[key] == expected, 'Incomplete endpoint replay: ' + key)
    for field in ['all_source_and_adjoint_review_hashes_verified',
                  'all_canonical_family_power_and_order_bindings_verified',
                  'all_serialized_complex_boxes_fully_enclose_original_convolutions',
                  'all_original_coefficient_and_metadata_strings_byte_identical']:
        c.require(endpoint[field] is True, 'Endpoint admission is incomplete: ' + field)
    c.require(endpoint['canonical_binding_count'] == 7
              and endpoint['canonical_binding_proof_sha256'] == review['canonical_binding_proof_sha256'],
              'Exact canonical master aliases are not independently bound')
    c.pin(endpoint['canonical_binding_proof_path'], endpoint['canonical_binding_proof_sha256'], sources)
    aliases = c.load(endpoint['canonical_binding_proof_path'])
    c.require(aliases['accepted'] is True
              and aliases['status'] == 'passed_exact_canonical_bindings_and_PR9d_unimodular_routing',
              'Canonical aliases are not exactly admitted')
    for data in [chain, endpoint, initial, initial_review]:
        for field, target in [('source_pins', sources), ('implementation_sha256', sources), ('artifact_sha256', artifacts)]:
            if field not in data:
                continue
            c.require(type(data[field]) is dict, 'Malformed source/artifact graph')
            for key, value in data[field].items():
                if type(value) is str:
                    path, digest = key, value
                else:
                    c.require(type(value) is dict and set(value) == {'path', 'sha256'}, 'Malformed named artifact binding')
                    path, digest = value['path'], value['sha256']
                c.require(Path(path).is_absolute(), 'Admitted graph paths must be absolute')
                c.pin(path, digest, target)
    endpoint_path = c.pin(endpoint['endpoint_path'], ENDPOINT_SHA, artifacts)
    payload = c.load(endpoint_path)
    c.require(payload['normalization'] == 'native_raw' and payload['error_quality'] == 'rigorous-bound',
              'Admitted source normalization or error quality differs')
    expected_symbols = {'native::' + name for name in ['PR3', 'PR4', 'PR4d', 'PR5', 'PR7', 'PR9', 'PR9d']}
    c.require(set(payload['coefficients']) == expected_symbols, 'Canonical source inventory differs')
    ctx.dps = 20500
    maximum = arb(0)
    for symbol, rows in payload['coefficients'].items():
        c.require(len(rows) == 6 and [r['epsilon_power'] for r in rows] == list(range(-4, 2)),
                  'Missing source Laurent order: ' + symbol)
        for row in rows:
            value = acb(arb(row['ball']), arb(row['imaginary_ball']))
            c.require(value.is_finite() and value.imag.contains(0), 'Nonfinite or nonreal physical source')
            maximum = max(maximum, value.real.rad(), value.imag.rad())
    c.require(maximum.upper() < (arb(10) ** -20050).lower(), 'Admitted 4L source guard is insufficient')
    for path, digest in {**sources, **artifacts}.items():
        c.require(sha(path) == digest, 'Immutable admitted file changed during sealing: ' + path)
    result = {'schema': 'vakint.PR9-production-A-complete-physical-source-admission.v1',
              'accepted': True, 'whole_chain_physical_source_admitted': True,
              'scope': 'Seven canonical4L native-raw master jets epsilon−4..1, from API20280 physical primitives and an independently admitted/freshly reproduced initial, through49 source-bound RPF steps and seven certified endpoint operators.',
              'endpoint_path': str(endpoint_path), 'endpoint_sha256': ENDPOINT_SHA,
              'initial_admission_path': str(args.initial_admission.resolve()), 'initial_admission_sha256': args.initial_admission_sha256,
              'chain_data_review_path': str(args.chain_data.resolve()), 'chain_data_review_sha256': sha(args.chain_data),
              'endpoint_replay_path': str(args.endpoint_replay.resolve()), 'endpoint_replay_sha256': sha(args.endpoint_replay),
              'independent_chain_review_path': str(args.independent_review.resolve()),
              'independent_chain_review_sha256': args.independent_review_sha256,
              'canonical_binding_proof_sha256': endpoint['canonical_binding_proof_sha256'],
              'raw_22_basis_pole_bound': -4,
              'raw_22_pole_bound_certificate_path': str(pole_certificate_path),
              'raw_22_pole_bound_certificate_sha256': review['raw_22_pole_bound_certificate_sha256'],
              'fresh_INIT_invocation_receipt_sha256': initial['fresh_native_invocation_sha256'],
              'normalization': 'native_raw', 'error_quality': 'rigorous-bound',
              'canonical_masters': sorted(expected_symbols), 'epsilon_powers': list(range(-4, 2)), 'coefficient_count': 42,
              'all_component_absolute_radii_below': '1e-20050', 'maximum_component_radius': maximum.str(45, more=True),
              'source_pins': sources, 'artifact_sha256': artifacts,
              'source_aliases_graph_and_normalization_verified': True,
              'all_initial_and_transport_full_interval_errors_preserved': True,
              'historical_scheduled_segment_workers': chain['historical_scheduled_segment_workers'],
              'native_solver_contract': 'Admits retained outputs through independently reviewed frozen numerical kernels and exact saved-IVP/certificate bindings. INIT has a new recorded same-input/same-binary reproduction; laterRPF steps and endpoint kernels retain the frozen-artifact workflow contract.',
              'IBP_trust_scope': 'Inherits the authenticated source IBP system and exact recorded basis transports; this audit does not independently regenerate those relations.',
              'exact_zeros_not_inferred_from_small_values': True, 'new_native_invocations': 1,
              'source_HPL_or_preparer_reevaluation': False, 'data_precision_caps_modified': False,
              'whole_PR11d_20000_accuracy_claimed': False, 'PR11d_validated_decimal_cap': 200}
    with output.open('x') as stream:
        stream.write(json.dumps(result, indent=2) + '\n')
    print('ACCEPTED productionA physical4Lsources', sha(output), 'maximumradius', result['maximum_component_radius'])


if __name__ == '__main__':
    main()
