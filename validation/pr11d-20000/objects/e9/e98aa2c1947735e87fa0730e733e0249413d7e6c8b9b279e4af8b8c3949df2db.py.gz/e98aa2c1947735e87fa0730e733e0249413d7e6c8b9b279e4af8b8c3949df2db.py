#!/usr/bin/env python3
"""Read-only audit of frozen launcher and live invocation-start contracts."""
from pathlib import Path
import hashlib,json,os,math,datetime
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];N=ROOT/'helper/frobenius-transport/native'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
launcher=N/'run_x8_guarded_initial_v1.py';kernel=N/'contracted_v2_scheduled.c';binary=N/'contracted-native-v2-scheduled';review=N/'schedule-review/review.json'
assert sha(launcher)=='a0a12ffdd1f9f531863c6427aa49b54150084de8bab769ccf60a34cf96b7e30a'
assert sha(review)=='165a577ec48751c78df18e2522ecc60cedcfb076e4d38cb697e6dc7a8496ead6'
proof=load(review);assert proof['accepted'] is True and proof['candidate_source_sha256']==sha(kernel) and proof['candidate_binary_sha256']==sha(binary)
pins={str(p):sha(p) for p in [launcher,kernel,binary,review,N/'prepare_v2.py',Path(__file__)]};records=[]
for tag in ['A','B']:
 out=N.parent/f'x8-production-{tag}-scheduled-v1';contract=load(out/'run-contract.json');start=load(out/'invocation-start.json');meta=load(out/'native.json');args=contract['settings']
 assert contract['physical_source_admission_required'] is True and contract['whole_PR11d_accuracy_claimed'] is False
 for doc in [contract,start]:
  for path,digest in doc['source_pins'].items():
   assert sha(path)==digest,(tag,path)
   if path in pins:assert pins[path]==digest
   pins[path]=digest
 for p in [out/'run-contract.json',out/'invocation-start.json',out/'native.json']:pins[str(p)]=sha(p)
 assert start['command']==[str(binary),str(out/'native.in'),str(out/'native-output.json')]
 assert start['requested_workers']==args['workers']==8 and start['controlled_environment']=={'OMP_NUM_THREADS':'8','OPENBLAS_NUM_THREADS':'1'}
 assert start['wrapper_sha256']==sha(launcher) and start['binary_sha256']==sha(binary) and start['source_sha256']==sha(kernel) and start['input_sha256']==sha(out/'native.in')
 assert args['boundary_sha256']==sha(args['boundary']) and args['constants_sha256']==sha(args['constants'])
 assert meta['input_sha256']==start['input_sha256'] and meta['seed_binding']==args['constants_sha256']
 assert meta['dimension']==252 and meta['constant_count']==252 and meta['log_slots']==9 and meta['z0']==['0','-1/256']
 assert meta['requested_digits']==args['local_tail_digits'] and meta['bits']==math.ceil(args['working_digits']*math.log2(10))
 with (out/'native.in').open() as stream:header=stream.readline().split()
 assert header[0]=='FROB_V1' and int(header[1])==252 and int(header[2])==9 and int(header[12])==meta['bits'] and int(header[13])==args['local_tail_digits']
 proc=Path('/proc')/str(start['pid']);observation={'pid':start['pid'],'snapshot_time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'process_still_present':proc.exists()}
 if proc.exists():
  command=[v.decode() for v in (proc/'cmdline').read_bytes().split(b'\0') if v];assert command==start['command']
  exe=os.readlink(proc/'exe');assert Path(exe)==binary and sha(proc/'exe')==sha(binary)
  env={v.split(b'=',1)[0].decode():v.split(b'=',1)[1].decode() for v in (proc/'environ').read_bytes().split(b'\0') if v.startswith((b'OMP_NUM_THREADS=',b'OPENBLAS_NUM_THREADS='))}
  assert env==start['controlled_environment']
  fields=dict(line.split(':',1) for line in (proc/'status').read_text().splitlines() if ':' in line)
  observation.update({'proc_command_matches_recorded_three_argument_command':True,'proc_executable_sha256':sha(proc/'exe'),'controlled_environment_matches':True,'OS_threads_observed':int(fields['Threads'])})
 records.append({'run':tag,'working_digits':args['working_digits'],'Pmax_bits':meta['bits'],'local_tail_digits':args['local_tail_digits'],'raw_total_digits':args['raw_total_digits'],'boundary_sha256':args['boundary_sha256'],'constants_sha256':args['constants_sha256'],'native_input_sha256':start['input_sha256'],'run_contract_sha256':sha(out/'run-contract.json'),'invocation_start_sha256':sha(out/'invocation-start.json'),'live_observation':observation,'independent_prefix_seed_and_physical_source_admission_pending':True})
report={'schema':'vakint.x8.conditional-initial-launcher-independent-review.v1','accepted':True,'status':'passed_for_frozen_conditional_launcher_contract_only','launcher_sha256':sha(launcher),'findings':[],'static_contract_checks':{'source_boundary_constant_hashes_verified_before_preparation':True,'frozen_independently_reviewed_kernel_pin_checked':True,'source_receipts_and_exact_startup_matching_snapshots_checked':True,'native_command_exactly_binary_input_output':True,'direct_Popen_records_child_PID_and_command':True,'all_input_source_binary_wrapper_pins_rechecked_after_child':True,'nonzero_native_exit_prevents_handoff':True,'requested_configured_actual_workers_must_match':True,'native_Pmax_must_match_preparation_bits':True,'finite_252_normalized_and_original_output_balls_required':True,'raw_sum_of_real_and_imag_radii_strict_target_gate_required':True,'failed_width_gate_prevents_handoff':True,'fresh_output_directory_and_exclusive_receipt_writes':True,'source_and_invocation_flags_explicitly_conditional':True,'full_original_native_balls_copied_without_midpoint_or_radius_edit':True},'actual_started_runs':records,'scope_limits':['This accepts the launcher code contract and frozen start artifacts. Native jobs were active during this audit, so their exit status, post-run receipts, final local-tail and total-width gates have not yet been observed here.','The launcher checks source snapshot structure and hashes, not the exact 1587-row expression assembly, 252-constant matching or native seed construction. Those need a separate independently blessed initial-admission receipt.','error_quality=rigorous-bound describes the conditional numerical IVP enclosure. physical_source_admission_required=True must be honored by downstream physical admission; this receipt does not bless either physical initial value.','Observed /proc command/executable/environment and OS thread counts supplement the start receipt, without changing or controlling the running processes. Final worker acceptance still uses the reviewed native kernel actual_workers field.'],'physical_initial_A_admitted':False,'physical_initial_B_admitted':False,'native_or_preparer_invocations_by_reviewer':0,'active_source_or_output_files_modified':False,'whole_PR11d_20000_accuracy_claimed':False,'artifact_sha256':pins}
out=HERE/'review.json';assert not out.exists();out.write_text(json.dumps(report,indent=2)+'\n');print(out);print(sha(out));print(json.dumps(records,indent=2))
