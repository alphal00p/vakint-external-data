"""Strict read-only artifact loading and fresh scoped receipt creation."""
import hashlib,importlib.util,json,math,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
def require(ok,message):
 if not ok:raise ValueError(message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pairs(items):
 result={}
 for k,v in items:require(k not in result,'Duplicate JSON key '+str(k));result[k]=v
 return result
def number(s):
 value=float(s);require(math.isfinite(value),'Nonfinite JSON numeric literal');return value
def load(path):return json.loads(Path(path).read_bytes(),object_pairs_hook=pairs,parse_float=number,parse_constant=lambda s:(_ for _ in ()).throw(ValueError('Nonfinite JSON scalar '+s)))
def pin(path,digest,pins):
 path=Path(path).resolve();require(type(digest) is str and len(digest)==64,'Invalid checksum');require(sha(path)==digest,'Source/artifact checksum mismatch '+str(path));pins[str(path)]=digest;return path
def integer(v,wanted,label):require(type(v) is int and v==wanted,'Wrong '+label)
def fresh_output(path):
 raw=Path(path);out=raw.resolve();require(out.is_relative_to(HERE),'Output must remain under dedicated validator directory');require(not raw.is_symlink() and not out.exists(),'Output must be fresh and nonsymlink');require(out.parent.is_dir(),'Output directory must already exist');return out
def module(name,path):
 path=Path(path).resolve();spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);require(Path(m.__file__).resolve()==path,'Unexpected imported helper origin');return m
