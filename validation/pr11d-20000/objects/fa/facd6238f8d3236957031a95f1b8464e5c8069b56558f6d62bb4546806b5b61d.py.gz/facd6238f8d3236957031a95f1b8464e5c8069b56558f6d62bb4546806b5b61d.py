"""Bounded, exact IBP-row membership for physical X8 target relations."""
from replay import *

def rowspace(rows):
    pivots={}
    for ident,original in rows:
        row=original.copy();witness={ident:ONE}
        while row:
            k=max(row)
            if k not in pivots:
                scale=ONE/row[k]
                row={k:v*scale for k,v in row.items()}
                witness={k:v*scale for k,v in witness.items()}
                pivots[k]=(row,witness)
                break
            old,proof=pivots[k]
            factor=-row[k]
            muladd(row,old,factor);muladd(witness,proof,factor)
    return pivots

def reduce(row,pivots):
    row=row.copy();witness={}
    for k,(old,proof) in sorted(pivots.items(),reverse=True):
        if k in row:
            factor=row[k]
            muladd(row,old,-factor);muladd(witness,proof,factor)
    return row,witness

def main():
    seed=BASIS[37]
    rows=[((seed,i,j),ibp(seed,i,j)) for i,j in itertools.product(range(4),repeat=2)]
    pivots=rowspace(rows)
    for target in DATA['target_reductions']:
        row={tuple(target['powers']):ONE}
        for t in target['terms']:
            add(row,tuple(t['powers']),-parse(t['coefficient'],DATA['epsilon_symbol'],DATA['variable']))
        remainder,witness=reduce(row,pivots)
        print('target',target['powers'],'remaining',len(remainder),'witness',len(witness),flush=True)
        print(serialize(remainder),flush=True)

if __name__=='__main__':main()
