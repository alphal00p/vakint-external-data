#!/usr/bin/env python3
"""Exact generic native Frobenius preparation; physical provenance stays explicit."""
import argparse,hashlib,heapq,json,math
from fractions import Fraction as Q
from pathlib import Path
from flint import arb,acb,ctx,fmpq,fmpq_poly
if not __debug__:raise RuntimeError('Assertions required')
HERE=Path(__file__).resolve().parent
DEFAULT=HERE.parents[2]/'infinity-matching'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def aq(q):q=Q(q);return arb(fmpq(q.numerator,q.denominator))
def mul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def scaled(a,q):return a[0]*q,a[1]*q
def blocks(dim,entries):
    graph=[set() for _ in range(dim)]
    for e in entries:graph[e['column']].add(e['row'])
    indexes=[None]*dim;low=[0]*dim;stack=[];active=set();components=[]
    def visit(v):
        indexes[v]=low[v]=visit.next;visit.next+=1;stack.append(v);active.add(v)
        for w in graph[v]:
            if indexes[w] is None:visit(w);low[v]=min(low[v],low[w])
            elif w in active:low[v]=min(low[v],indexes[w])
        if low[v]==indexes[v]:
            component=[]
            while True:
                w=stack.pop();active.remove(w);component.append(w)
                if w==v:break
            components.append(sorted(component))
    visit.next=0
    for v in range(dim):
        if indexes[v] is None:visit(v)
    owner={v:b for b,c in enumerate(components) for v in c};arcs=[set() for _ in components];indegree=[0]*len(components)
    for v,row in enumerate(graph):
        for w in row:
            a,b=owner[v],owner[w]
            if a!=b and b not in arcs[a]:arcs[a].add(b);indegree[b]+=1
    ready=[(min(c),b) for b,c in enumerate(components) if not indegree[b]];heapq.heapify(ready);ordered=[]
    while ready:
        _,b=heapq.heappop(ready);ordered.append(components[b])
        for other in arcs[b]:
            indegree[other]-=1
            if not indegree[other]:heapq.heappush(ready,(min(components[other]),other))
    assert len(ordered)==len(components) and max(map(len,ordered))<=4
    owners={v:b for b,c in enumerate(ordered) for v in c}
    assert all(owners[e['column']]<=owners[e['row']] for e in entries)
    return ordered,owners

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--connection',type=Path,default=DEFAULT/'polynomial-normalized-connection.json');ap.add_argument('--startup',type=Path,default=DEFAULT/'exact-startup-coefficients.json');ap.add_argument('--matching',type=Path,default=DEFAULT/'exact-boundary-matching.json');ap.add_argument('--matched-constants',type=Path);ap.add_argument('--digits',type=int,default=100);ap.add_argument('--guard',type=int,default=100);ap.add_argument('--z-real',default='0');ap.add_argument('--z-imag',default='-1/256');ap.add_argument('--max-order',type=int,default=300);ap.add_argument('--check-every',type=int,default=20);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    p=json.loads(args.connection.read_text());s=json.loads(args.startup.read_text());m=json.loads(args.matching.read_text())
    assert p['matching_data_sha256']==sha(args.matching)==s['source_matching_sha256']
    assert p['startup_data_sha256']==sha(args.startup)
    dim=p['dimension'];logs=p['generic_maximum_log_degree']+1;constant_count=m['freeconstants']
    assert s['dimension']==m['dimension']==dim and 1<=dim<=252 and 1<=logs<=16 and 1<=constant_count<=dim
    nmin,nmax=s['normalized_power_range'];assert -32<=nmin<=nmax<=32 and nmin<=0
    z=(Q(args.z_real),Q(args.z_imag));assert z!=(0,0)
    d_original=[Q(x) for x in p['denominator_coefficients']];assert d_original[0]==0 and d_original[1]
    dd=len(d_original)-2;bd=p['numerator_degree'];assert dd<=16 and bd<=16
    powers=[(Q(1),Q(0))]
    for _ in range(max(dd,bd)):powers.append(mul(powers[-1],z))
    d=[scaled(powers[k],x/d_original[1]) for k,x in enumerate(d_original[1:])]
    entries=[];R={}
    for e in p['entries']:
        coeff=[(Q(0),Q(0)) for _ in range(bd+1)]
        for t in e['terms']:
            k=t['z_power'];q=Q(int(t['numerator']),int(t['denominator']))/d_original[1];coeff[k]=scaled(powers[k],q)
            if k==0 and q:R[e['row'],e['column']]=q
        entries.append((e['row'],e['column'],coeff))
    L=1
    for row in [d]+[v for _,_,v in entries]:
        for pair in row:
            for q in pair:L=math.lcm(L,q.denominator)
    LR=math.lcm(*(q.denominator for q in R.values()))
    bs,owner=blocks(dim,p['entries'])
    # Every current denominator factor has real nonzero roots, proved exactly
    # for linear factors and quadratics by their rational discriminants.
    ctx.dps=100;factorization=fmpq_poly([fmpq(q.numerator,q.denominator) for q in d_original[1:]]).factor()[1]
    roots=[]
    for factor,multiplicity in factorization:
        if factor.degree()==1:values=[-arb(factor[0])/arb(factor[1])]
        elif factor.degree()==2:
            discr=factor[1]**2-4*factor[2]*factor[0];assert discr>0
            values=[(-arb(factor[1])+sign*arb(discr).sqrt())/(2*arb(factor[2])) for sign in [-1,1]]
        else:raise ValueError('This preparer requires independently isolated real denominator roots')
        roots.extend((v,multiplicity) for v in values)
    if z[0]==0:
        lower=arb(L);denominator_proof='All roots real and nonzero; imaginary ray gives |d(t)|>=1 exactly'
    else:
        radius=abs(acb(aq(z[0]),aq(z[1])));lower=arb(L)
        for root,multiplicity in roots:
            gap=1-radius/abs(root);assert gap>0,'The conservative disk denominator bound is unavailable'
            lower*=gap**multiplicity
        lower=lower.lower();denominator_proof='Product of positive 1-|z0|/|root| bounds, outward rounded'
    bits=math.ceil((args.digits+args.guard)*math.log2(10));ctx.prec=bits
    if args.matched_constants:
        record=json.loads(args.matched_constants.read_text());assert record.get('exact_matching_sha256',record.get('matching_sha256'))==sha(args.matching)
        assert record['normalization']=='native_raw'
        assert record.get('all_prepared_coefficients_checked',record.get('all_prepared_rows_checked')) is True
        constants=record['free_constant_balls'];assert len(constants)==constant_count
        assert all(arb(x).is_finite() for x in constants)
        quality=record['error_quality'];assert quality in ('rigorous-bound','validated-digits-estimate')
        if 'coefficients' in record:
            fields=('component','integer_z_power','epsilon_power','log_power')
            key=lambda row:tuple(row[f] for f in fields)
            boundary={}
            for row in record['coefficients']:
                label=key(row);assert label not in boundary;boundary[label]=arb(row['real_ball'])
            assert set(boundary)=={key(row) for row in m['all_boundary_selectors']}
            selected=[boundary[key(row)] for row in m['selected_selectors']]
            fresh=[sum((selected[j]*arb(fmpq(q)) for j,q in enumerate(row) if q!='0'),arb(0)) for row in m['boundary_inverse']]
            assert all(a.overlaps(arb(b)) for a,b in zip(fresh,constants))
            for label,row in zip(m['all_boundary_selectors'],m['all_boundary_matrix']):
                residual=sum((fresh[j]*arb(fmpq(q)) for j,q in enumerate(row) if q!='0'),arb(0))-boundary[key(label)]
                assert residual.contains(0),'Inconsistent complete matched boundary'
            constants=[x.str(math.ceil(bits*math.log10(2))+10) for x in fresh]
        seeds=[x+'|0' for x in constants];seed_binding=sha(args.matched_constants)
    else:seeds=['1|0']*constant_count;quality='synthetic';seed_binding='all free constants equal one'
    startup=[(row['normalized_z_power'],row['log_power'],i,j,Q(q)) for row in s['coefficients'] for i,j,q in row['entries']]
    assert all(nmin<=n<=nmax and 0<=ell<logs and 0<=i<dim and 0<=j<constant_count for n,ell,i,j,q in startup)
    zden=math.lcm(z[0].denominator,z[1].denominator)
    rows=[f'FROB_V1 {dim} {logs} {len(bs)} {constant_count} {nmin} {nmax} {dd} {bd} {len(entries)} {len(R)} {len(startup)} {bits} {args.digits} {args.max_order} {args.check_every}',f'{int(z[0]*zden)} {int(z[1]*zden)} {zden}',str(L),lower.str(85),' '.join(str(owner[i]) for i in range(dim))]
    rows += [f'{int(re*L)} {int(im*L)}' for re,im in d]
    for r,c,coeff in entries:rows += [f'{r} {c}']+[f'{int(re*L)} {int(im*L)}' for re,im in coeff]
    rows.append(str(LR));rows += [f'{r} {c} {int(q*LR)}' for (r,c),q in sorted(R.items())]
    rows += [f'{n} {ell} {i} {j} {q.numerator} {q.denominator}' for n,ell,i,j,q in startup]
    for weight,scale in zip(m['gauge_weights'],m['gauge_scales']):
        q=Q(scale);rows.append(f'{weight} {q.numerator} {q.denominator}')
    rows += seeds;args.output.write_text('\n'.join(rows)+'\n')
    metadata={'schema':'vakint.generic.native-contracted-frobenius-input.v1','dimension':dim,'log_slots':logs,'blocks':bs,'maximum_block_size':max(map(len,bs)),'minimum_native_version':2 if max(map(len,bs))>3 else 1,'constant_count':constant_count,'startup_range':[nmin,nmax],'z0':[str(x) for x in z],'poly_scale':str(L),'residue_scale':str(LR),'denominator_bound':lower.str(85),'denominator_proof':denominator_proof,'bits':bits,'requested_digits':args.digits,'startup_family':'source-certified prepared family; no unspecified modes may be discarded','error_quality':quality,'seed_binding':seed_binding,'source_sha256':{str(args.connection):sha(args.connection),str(args.startup):sha(args.startup),str(args.matching):sha(args.matching)},'input_sha256':sha(args.output),'physical_period_accuracy_claimed':False}
    args.output.with_suffix('.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps({k:v for k,v in metadata.items() if k!='blocks'},indent=2))
if __name__=='__main__':main()
