"""Bounded exact replay of the actual 42-row differential connection."""
from replay import *
from target import rowspace,reduce
from symmetries import physical_automorphisms,transform_expression
from routing import witness as positive_routing
import time
import argparse

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--rows',default=','.join(str(i) for i in range(42)))
    parser.add_argument('--redistribute-dots',action='store_true')
    parser.add_argument('--output',default='derivative-expanded-replay.json')
    args=parser.parse_args()
    selected={int(i) for i in args.rows.split(',')}
    start=time.monotonic();proofs=[]
    all_routings={r['sector']:[tuple(tuple(Fraction(x) for x in row) for row in t) for t in r['generators']]
                  for r in json.loads((HERE/'sector-symmetries.json').read_text())}
    for index,(seed,matrixrow) in enumerate(zip(BASIS,DATA['differential_matrix'])):
        if index not in selected:continue
        original={}
        if seed[3]:
            n=list(seed);n[3]+=1;add(original,tuple(n),Rat(seed[3]))
        for basis,c in zip(BASIS,matrixrow):
            add(original,basis,-parse(c,DATA['epsilon_symbol'],DATA['variable']))
        seeds={seed}|{n for n in BASIS if n in original}
        if args.redistribute_dots:
            active=[i for i,p in enumerate(seed) if p>0]
            for composition in compositions(sum(seed)-len(active),len(active)):
                n=[0]*10
                for i,p in zip(active,composition):n[i]=1+p
                seeds.add(tuple(n))
        rows=[(('ibp',n,i,j),ibp(n,i,j)) for n in sorted(seeds) for i,j in itertools.product(range(4),repeat=2)]
        support=set(original)|{p for _,row in rows for p in row}
        sector=sum(1<<i for i,p in enumerate(seed) if p>0)
        routing_matrices=list(dict.fromkeys(t for n in seeds for t in all_routings[sum(1<<i for i,p in enumerate(n) if p>0)]))
        for p in sorted(support):
            for transform_index,t in enumerate(routing_matrices):
                image=transform_expression(p,t)
                if image is None:continue
                row={p:ONE};muladd(row,image,-ONE)
                if row:rows.append((('routing',p,transform_index),row))
        positive_routings=[]
        for p in sorted(support):
            if min(p)<0:continue
            for b in BASIS:
                if b>=p or sorted(p)!=sorted(b) or p[3]!=b[3]:continue
                routing=positive_routing(p,b)
                if routing:
                    rows.append((('positive-routing',p,b),{p:ONE,b:-ONE}))
                    positive_routings.append({'source':p,'target':b,'witness':routing})
        pivots=rowspace(rows)
        remainder,witness=reduce(original,pivots)
        proof={'row':index,'basis':seed,'proved':not remainder,
               'routing_matrices':[[[str(x) for x in row] for row in t] for t in routing_matrices],
               'positive_routings':positive_routings,
               'witness':[{'row':ident,'coefficient':str(v)} for ident,v in witness.items()],
               'remainder':serialize(remainder)}
        if not remainder:
            reconstructed={}
            original_rows=dict(rows)
            for ident,v in witness.items():muladd(reconstructed,original_rows[ident],v)
            difference=original.copy();muladd(difference,reconstructed,-ONE);assert not difference
        proofs.append(proof)
        print(index,'proved',not remainder,'witness',len(witness),'remainder',len(remainder),flush=True)
        (HERE/args.output).write_text(json.dumps({'schema':'vakint.independent-x8-derivative-witnesses.v1','selected_rows':sorted(selected),
            'complete':False,'proofs':proofs,'source_sha256':hashlib.sha256((HERE/'source/prepared-system.json').read_bytes()).hexdigest(),
            'seconds':time.monotonic()-start},indent=2)+'\n')
    report={'schema':'vakint.independent-x8-derivative-witnesses.v1','complete':len(proofs)==42 and all(p['proved'] for p in proofs),
            'selected_rows':sorted(selected),
            'proved_rows':[p['row'] for p in proofs if p['proved']],
            'unproved_rows':[p['row'] for p in proofs if not p['proved']],
            'source_sha256':hashlib.sha256((HERE/'source/prepared-system.json').read_bytes()).hexdigest(),
            'proofs':proofs,'seconds':time.monotonic()-start}
    (HERE/args.output).write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()
