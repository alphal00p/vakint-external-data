"""Bounded-memory native adjoint recurrence plus independently structured tail enclosure."""
import argparse,hashlib,json,math,subprocess,time,sys
from pathlib import Path
from flint import arb,acb,ctx,fmpq,fmpq_mat
from evaluate_endpoint import System,dot
HERE=Path(__file__).parent
if not __debug__:raise RuntimeError('Assertions required')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def prepare(system,order,digits,rlog,path):
 scale=math.lcm(*(int(q.q) for q in system.D),*(int(q.q) for A in system.N for row in A for q in row if q));entries=[(k,i,j,q*scale) for k,A in enumerate(system.N) for i,row in enumerate(A) for j,q in enumerate(row) if q];assert all(v.q==1 for k,i,j,v in entries)
 rows=[f'{system.dimension} {len(system.blocks)} {system.deg} {system.ndeg} {len(entries)} {order} {ctx.prec} {digits+20} {rlog}',' '.join(str(system.blockof[i]) for i in range(system.dimension))]
 rows += [str(int(q*scale)) for q in system.D]
 rows += [f'{k} {i} {j} {v}' for k,i,j,v in entries]
 rows += [str(q) for q in system.initial];path.write_text('\n'.join(rows)+'\n')
 return {'exact_rational_integer_scale':str(scale),'source_polynomial_sha256':system.source_hash,'source_endpoint_proof_sha256':system.projector_hash,'input_sha256':sha(path),'order':order,'radius_power_of_two':rlog,'working_bits':ctx.prec}
def enclose(system,data,r):
 dim=system.dimension;order=data['order'];M,lower=system.bound_matrix(r);values={int(row['eta_power']):[arb(v) for v in row['values']] for row in data['last_coefficients']};assert len(values)==len(set(values))
 forcing=[arb(0) for _ in range(dim)]
 for n in range(order+1,order+max(system.ndeg,system.deg-1)+1):
  defect=[arb(0) for _ in range(dim)]
  for power in range(1,system.deg+1):
   index=n-power+1
   if 1<=index<=order:
    previous=values[index];weight=index*system.D[power]
    for i in range(dim):defect[i]+=previous[i]*weight
  for power in range(system.ndeg+1):
   index=n-power
   if 0<=index<=order:
    previous=values[index]
    for i,row in enumerate(system.sp[power]):defect[i]-=dot(row,previous)
  for i in range(dim):forcing[i]+=abs(defect[i]).upper()*r**(n-order-1)/lower
 budgets=[arb(0) for _ in range(dim)]
 for b,block in enumerate(system.blocks):
  A=fmpq_mat([[int(i==j)*(order+1)-M[i][j] for j in block] for i in block]);inverse=A.inv();assert all(q>=0 for row in inverse.tolist() for q in row),'Tailblocknotpositive; increaseorder'
  local=[forcing[i]+sum((budgets[j]*M[i][j] for j in range(dim) if system.blockof[j]<b and M[i][j]),arb(0)) for i in block]
  for k,i in enumerate(block):budgets[i]=sum((local[q]*inverse[k,q] for q in range(len(block))),arb(0))
 result=[];tail=[]
 for i,(real,imag) in enumerate(data['polynomial_values']):
  radius=(budgets[i]*r**(order+1)).upper();tail.append(radius);result.append(acb(arb(real)+arb(0,radius),arb(imag)+arb(0,radius)))
 return result,{'maximum_tail_radius':max(tail).str(40,more=True),'tail_bound_added':True,'tail_method':'Same exact polynomial defect and block positive resolvent as reviewedPythonreference; prefixcoefficientroundingretainedbyArbnativeintervalrecurrence','disc_denominator_lower_bound':str(lower)}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('name');ap.add_argument('--symbol',required=True);ap.add_argument('--digits',type=int,default=260);ap.add_argument('--order',type=int,default=250);ap.add_argument('--radius-power-of-two',type=int,default=4);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--compare-python',action='store_true');a=ap.parse_args();ctx.dps=a.digits;system=System(a.name,a.symbol);prefix=a.output.with_suffix('');inputpath=prefix.with_suffix('.in');nativepath=prefix.with_suffix('.native.json');start=time.monotonic();metadata=prepare(system,a.order,a.digits,a.radius_power_of_two,inputpath)
 r=subprocess.run([str(HERE/'endpoint-native'),str(inputpath),str(nativepath)],capture_output=True,text=True);assert r.returncode==0,r.stderr;data=json.load(open(nativepath));assert data['dimension']==system.dimension and data['order']==a.order and data['working_bits']==ctx.prec and data['radius_power_of_two']==a.radius_power_of_two
 values,report=enclose(system,data,fmpq(1,2**a.radius_power_of_two));comparisons=[]
 if a.compare_python:
  old,oldreport=system.evaluate(a.order,fmpq(1,2**a.radius_power_of_two));assert all(x.overlaps(y) for x,y in zip(values,old));comparisons.append({'independent_python_prefix_and_tail_overlap':True,'checked_components':len(values)})
 payload={'schema':'vakint.ancestor.analytic-endpoint-adjoint.v1','name':a.name,'symbol':a.symbol,'dimension':system.dimension,'base_dimension':system.base,'loop_count':system.proof['loop_count'],'eta_center':['0',str(fmpq(1,2**a.radius_power_of_two))],'epsilon_range':[0,5],'order':a.order,'working_bits':ctx.prec,'source_polynomial_sha256':system.source_hash,'endpoint_projector_proof_sha256':system.projector_hash,'definition':'Wprime=-WA; targetendpoint=W dot originalrawY; no extra epsilon factor','native_source_sha256':sha(HERE/'endpoint_native.c'),'native_binary_sha256':sha(HERE/'endpoint-native'),'native_input':str(inputpath),'native_input_metadata':metadata,'native_output':str(nativepath),'native_output_sha256':sha(nativepath),'seconds':time.monotonic()-start,'native_seconds':data['native_seconds'],'peak_rss_bytes':data['peak_rss_bytes'],'validation':comparisons,**report,'complex_balls':[[v.real.str(a.digits+8,more=True),v.imag.str(a.digits+8,more=True)] for v in values],'whole_PR11d_accuracy_claimed':False};a.output.write_text(json.dumps(payload,indent=2)+'\n');print('NATIVEADJOINT PASS',a.symbol,payload['native_seconds'],'secnative',payload['seconds'],'sectotal','max_tail',report['maximum_tail_radius'])
if __name__=='__main__':main()
