#!/usr/bin/env python3
"""Strict saved-output gates for the separately frozen Frobenius schedule."""
import hashlib,json
from pathlib import Path
from flint import arb,acb,ctx
if not __debug__:raise RuntimeError('Assertions required')
HERE=Path(__file__).resolve().parent
OUT=HERE/'scheduled-performance-v1'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):return json.loads(path.read_text())
ctx.dps=21000
reports=[]
bindings=[Path(__file__),HERE/'contracted_v2_scheduled.c',HERE/'contracted-native-v2-scheduled',
    HERE/'build-v2-scheduled.sh',HERE/'contracted_v2_threads.c',HERE/'contracted-native-v2-threads']
for scope,baseline,new,input_path,complete in [
    ('partial20k',HERE/'threads-review/x8-20000-first1000-workers8.json',OUT/'x8-first1000-scheduled-workers8.json',HERE/'threads-review/x8-20000-first1000.in',False),
    ('full1000',OUT/'x8-full1000-baseline-workers8.json',OUT/'x8-full1000-scheduled-workers8.json',HERE/'x8-1000.in',True),
]:
    a,b=load(baseline),load(new)
    assert a['local_tail_certified']==b['local_tail_certified']==complete
    assert a['dimension']==b['dimension']==252 and a['order']==b['order']
    assert a['working_bits']==b['working_bits']==b['precision_max_bits']
    assert a['actual_workers']==b['actual_workers']==8
    assert b['schedule_factorization_verified'] and b['coefficient_precision_slope_bits_per_order']==4
    assert b['schedule_radius_ratio_squared']=='65536/225'
    assert b['full_precision_startup_total_certificate_and_output'] and not b['schedule_is_accuracy_guarantee']
    maxima={}
    for field in ['normalized_J_values','original_Y_values']:
        left=[acb(arb(re),arb(im)) for re,im in a[field]]
        right=[acb(arb(re),arb(im)) for re,im in b[field]]
        assert len(left)==len(right)==252
        assert all(x.is_finite() and y.is_finite() and x.overlaps(y) for x,y in zip(left,right))
        maxima[field]=max(x.real.rad()+x.imag.rad() for x in right)
        if complete:
            assert all(x.real.rad()+x.imag.rad()<arb('1e-1000') for x in left+right)
    if complete:assert b['minimum_coefficient_precision_bits_used']==1024
    else:assert b['minimum_coefficient_precision_bits_used']==63436 and b['order']==1000
    reports.append({'scope':scope,'local_tail_certified':complete,'all_504_intervals_overlap':True,
        'full_solution_1000_digit_total_width_gate_passed':complete,
        'maximum_total_radii':{k:v.str(40) for k,v in maxima.items()},
        'baseline_seconds':a['seconds'],'scheduled_seconds':b['seconds'],
        'order':b['order'],'Pmax':b['precision_max_bits'],'minimum_coefficient_precision_bits':b['minimum_coefficient_precision_bits_used']})
    bindings += [baseline,new,input_path]
report={'schema':'vakint.frobenius.scheduled-precision-output-review.v1','accepted_for_scope':True,
    'scope':'Full1000-digit synthetic X8 acceptance plus bounded first1000-order20k arithmetic probe. No completed20k solution or physical period claim.',
    'strict_total_width_gate_is_separate_from_native_local_tail_gate':True,
    'runs':reports,'source_and_output_sha256':{str(p):sha(p) for p in bindings}}
path=OUT/'receipt-v2.json'
with path.open('x') as stream:json.dump(report,stream,indent=2);stream.write('\n')
print(json.dumps({'receipt':str(path),'runs':reports},indent=2))
