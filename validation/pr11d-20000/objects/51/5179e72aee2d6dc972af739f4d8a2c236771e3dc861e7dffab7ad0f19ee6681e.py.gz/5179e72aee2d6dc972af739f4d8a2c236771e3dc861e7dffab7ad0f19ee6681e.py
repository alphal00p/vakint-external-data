#!/usr/bin/env python3
"""Actual unmasked-baseline admission and strict-mask regression controls."""
import json,dataclasses
from pathlib import Path
import exact_step_v2 as E
HERE=Path(__file__).resolve().parent
def main():
    root=E.F.ROOT;con=root/'ancestor-flows/pr9-22-ordinary-polynomial.json';pf=root/'ancestor-flows/pr9-22-ordinary-rational-pf.json';m=E.load(root/'ancestor-flows/pr9-22-matching.json');w=m['gauge_weights'][:22];w=tuple(x-min(w)for x in w)
    directory=root/'hierarchy-transport/pr9-production-API20280-v5';run=E.load(directory/'run-binding.json');initial=root/'helper/frobenius-transport/pr9-API20280-eta256-guard20220-v1.json'
    contract=E.StepContract(22,6,-4,E.sha(con),E.sha(pf),run['source_equation_sha256'],int((directory/'step-000.in').read_text().splitlines()[0].split()[5]),run['local_target_digits'],run['local_target_digits']+run['guard_digits'],E.sha(directory/'run-binding.json'),run['initial_sha256'],'imaginary_center_power',w,mask_metadata_required=False)
    checks=[];receipts=[]
    for i in [0,1]:
        prior=initial if i==0 else directory/f'step-{i-1:03}-boundary.json';args=[directory/f'step-{i:03}.in',directory/f'step-{i:03}.json',prior,con,pf,directory/f'step-{i:03}-native.json',directory/f'step-{i:03}-boundary.json']
        r=E.check_step(*args,contract);E.require(r['mask_metadata_checked']is False and r['unmasked_baseline_implementation_admission_required']is True,'Baseline profile mislabeled');receipts.append(r);checks.append({'case':'actual-unmasked-baseline-'+str(i),'passed':True});print('PASS baseline',i,flush=True)
    args=[directory/'step-000.in',directory/'step-000.json',initial,con,pf,directory/'step-000-native.json',directory/'step-000-boundary.json'];rejects=[]
    def reject(label,args,policy):
        before=E.ctx.prec
        try:E.check_step(*args,policy)
        except (ValueError,KeyError,AssertionError):E.require(E.ctx.prec==before,'Failure leaked Arb precision');rejects.append({'case':label,'rejected':True});return
        raise RuntimeError('Mutation accepted '+label)
    reject('baseline-not-permitted-by-default',args,dataclasses.replace(contract,mask_metadata_required=True))
    fixtures=HERE/'v2-fixtures';fixtures.mkdir(exist_ok=True);base=E.load(args[5])
    for label,fields in [('false-unexpected-mask-flag',{'auxiliary_mask_verified':False}),('partial-true-mask-block',{'auxiliary_mask_verified':True}),('malformed-mask-counter',{'auxiliary_computed_factor_state_pairs':'569'})]:
        target=fixtures/(label+'.json');target.write_text(json.dumps({**base,**fields},indent=2)+'\n');changed=args.copy();changed[5]=target;reject(label,changed,contract)
    controls=root/'hierarchy-transport/pr9-prototype-guard1000-substeps4-v5';cr=E.load(controls/'run-binding.json');strict=E.StepContract(22,6,-4,E.sha(con),E.sha(pf),cr['source_equation_sha256'],4319,1000,1300,E.sha(controls/'run-binding.json'),cr['initial_sha256'],'imaginary_center_power',w)
    a=[controls/'step-000.in',controls/'step-000.json',root/'helper/frobenius-transport/pr9-API20280-prototype-guard1000-eta256-v1.json',con,pf,controls/'step-000-native.json',controls/'step-000-boundary.json'];r=E.check_step(*a,strict);E.require(r['mask_metadata_checked']is True,'Strict profile skipped mask');checks.append({'case':'actual-masked-default','passed':True})
    r2=E.check_step(*a,dataclasses.replace(strict,mask_metadata_required=False));E.require(r2['mask_metadata_checked']is True,'Present full mask block was not checked');checks.append({'case':'complete-present-mask-checked-even-if-optional','passed':True})
    out={'schema':'vakint.generic-RPF-v2-unmasked-profile-regression.v1','accepted_development_controls':True,'checker_sha256':E.sha(HERE/'exact_step_v2.py'),'v1_unchanged_sha256':E.sha(HERE/'exact_step.py'),'checks':checks,'rejections':rejects,'baseline_step_receipts':receipts,'native_or_preparer_invoked':False,'baseline_implementation_admission_remains_with_caller':True,'independent_delta_review_required':True};(HERE/'regression-v2.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',len(checks),'positive',len(rejects),'negative',out['checker_sha256'])
if __name__=='__main__':main()
