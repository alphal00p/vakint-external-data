#!/usr/bin/env python3
"""Complete physical PR9 epsilon/log boundary with explicit source errors."""
import argparse,json,sys,time
from pathlib import Path
from flint import arb,ctx
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'pr11-boundary'))
from pr9_source_recipes import build
from three_loop_boundary import load_plan,sparse,dot,key,ANCESTOR
from source_recipes import read,sha
from logjet_map import FactorJet
from expanded_boundary import ExpandedBoundary

def load_primitives(three_loop_input):
    path=ANCESTOR/'sunset-ratio-20300-normalized.json';source=read(path)
    rows=source['coefficients']['native_raw'];assert [r['epsilon_power'] for r in rows]==list(range(-2,4))
    primitives={'native::L2_P2':FactorJet(-2,tuple(arb(r['ball']) for r in rows),'Accepted exact sunset epsilon recurrence and rigorous complex-epsilon Cauchy bound','native::L2_P2; '+sha(path))}
    provenance=[{'source':str(path),'sha256':sha(path),'normalization':'native_raw','error_quality':'rigorous-bound'}]
    if three_loop_input:
        path=Path(three_loop_input);data=read(path)
        if data['normalization']!='native_raw' or data['error_quality']!='rigorous-bound':raise ValueError('Guarded ancestor inputs must retain native normalization and bounded errors')
        for name in ['native::L3_P13','native::L3_P14']:
            rows=data['coefficients'][name]
            if [r['epsilon_power'] for r in rows]!=list(range(-3,3)):raise ValueError('Six contiguous raw three-loop orders required')
            primitives[name]=FactorJet(-3,tuple(arb(r['ball']) for r in rows),'Accepted exact physical ancestor projection with raw support beginning epsilon^-3',name+'; '+sha(path))
        provenance.append({'source':str(path),'sha256':sha(path),'normalization':'native_raw','error_quality':'rigorous-bound'})
        quality='rigorous-bound'
    else:
        from prototype_boundary import estimated_decimal,native_from_fmft,ROOT
        for name in ['P13','P14']:
            path=ROOT/f'vakint-external-data/3L/masters/{name}/numerical.json'
            raw=native_from_fmft({p:estimated_decimal(s,200) for p,s in read(path)},3)
            first,last=min(raw),max(raw)
            primitives['native::L3_'+name]=FactorJet(first,tuple(raw[p] for p in range(first,last+1)),'Authenticated catalog Laurent support; prototype external200digit estimate','native::L3_'+name)
            provenance.append({'source':str(path),'sha256':sha(path),'normalization':'FMFTandMATAD converted once by exp(-3EulerGamma epsilon)','error_quality':'validated-digits-estimate','source_precision_digits':200})
        quality='validated-digits-estimate'
    return primitives,provenance,quality

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--working-digits',type=int,default=260);ap.add_argument('--three-loop-input');ap.add_argument('--output-prefix',required=True);args=ap.parse_args()
    ctx.dps=args.working_digits;ctx.threads=1;start=time.time();data=read(ANCESTOR/'pr9-22-matching.json')
    factors,source_receipt=build();plan=load_plan(HERE/'pr9-22-inventory.json',data['inventory_sha256'],'masters_4l::{}::epsilon')
    primitives,provenance,quality=load_primitives(args.three_loop_input)
    compiled=ExpandedBoundary(plan,factors,max_log_power=data['max_exact_log_degree'])
    required,_=compiled.required_primitive_orders(primitives,last_epsilon_power=1)
    raw=compiled.evaluate(primitives,first_epsilon_power=-4,last_epsilon_power=1);values={}
    for (i,a,p,l),v in raw.items():assert a.denominator==1;values[i,a.numerator,p,l]=v
    keys=[key(r) for r in data['all_boundary_selectors']];wanted=set(keys)
    for k,v in values.items():
        if k not in wanted and not v.contains(0):raise ValueError('Forbidden PR9 source support '+str(k)+':'+v.str(30))
    boundary=[values[k] for k in keys];rhs=[values[key(r)] for r in data['selected_selectors']]
    constants=[dot(row,rhs) for row in sparse(data['boundary_inverse'])]
    prefix=Path(args.output_prefix)
    payload={'schema':'vakint.pr9.complete-source-boundary.v1','inventory_sha256':data['inventory_sha256'],'matching_sha256':sha(ANCESTOR/'pr9-22-matching.json'),'normalization':'native_raw','error_quality':quality,'coefficient_count':len(keys),'free_constants':132,'working_decimal_digits':args.working_digits,'source_recipe_receipt':source_receipt,'primitive_provenance':provenance,'required_raw_primitive_through':required,
      'coefficients':[{**row,'real_ball':v.str(args.working_digits+8,more=True)} for row,v in zip(data['all_boundary_selectors'],boundary)],'free_constant_balls':[v.str(args.working_digits+8,more=True) for v in constants],'scientific_whole_master_accuracy_claimed':False,'implementation_sha256':sha(Path(__file__))}
    prefix.with_suffix('.unmatched.json').write_text(json.dumps(payload,indent=2)+'\n')
    for k,v,row in zip(keys,boundary,sparse(data['all_boundary_matrix'])):
        residual=dot(row,constants)-v
        if not residual.contains(0):raise ValueError('Inconsistent PR9 boundary '+str(k)+':'+residual.str(30))
    payload['all_overdetermined_residuals_contain_zero']=True;payload['all_prepared_rows_checked']=True;payload['wall_seconds']=time.time()-start
    prefix.with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
    print('PASS:231factors;',len(keys),'rows;132constants;needed',required,'seconds',time.time()-start,flush=True)
if __name__=='__main__':main()
