#!/usr/bin/env python3
"""Independent high-guard P853 arithmetic; original accepted20k files stay unchanged."""
import hashlib,json,math,pathlib,sys,time
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
from flint import fmpq
from validate import evaluate,rounded_cell,upper_decimal,cauchy_bound_proof,arb,ctx
if not __debug__:raise RuntimeError('Assertions required')
HERE=pathlib.Path(__file__).resolve().parent
SOURCE=HERE/'p853-exact-jet-through-order7.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 start=time.time();ctx.dps=20380;data=json.loads(SOURCE.read_text());proof=cauchy_bound_proof()
 constants={'z2':arb(2).zeta(),'z3':arb(3).zeta(),'z5':arb(5).zeta(),'z7':arb(7).zeta(),'gamma':arb.const_euler()}
 names={'native_raw':list(range(-3,5)),'FMFT_normalized':list(range(-3,5)),'K1_cubed_ratio':list(range(8))}
 mma_path=HERE/'mathematica-20300-coefficients-through-order7.json';mma=json.loads(mma_path.read_text())
 assert set(mma['coefficients'])==set(names) and mma['working_digits']==20300 and mma['constant_working_digits']==20380
 outputs={};checks=[]
 old=json.loads((HERE.parent/'p853-exact-jet.json').read_text())
 for group in names:assert data[group][:6]==old[group]
 review_path=HERE.parents[1]/'helper/h5-review/review.json';review=json.loads(review_path.read_text())
 assert review['status']=='passed_exact_H1_through_H6'
 for name,pin in review['reviewed_source_sha256'].items():assert sha(HERE/name)==pin
 oracle=HERE/'H-independent-finite-epsilon.json';oracle_data=json.loads(oracle.read_text());assert oracle_data['complete'] and oracle_data['passed'] and len(oracle_data['checks'])==2
 native=json.loads((HERE.parent/'native-points.json').read_text());native_checks=[]
 ctx.dps=350
 small_constants={'z2':arb(2).zeta(),'z3':arb(3).zeta(),'z5':arb(5).zeta(),'z7':arb(7).zeta(),'gamma':arb.const_euler()}
 from fractions import Fraction
 for point in native['points']:
  assert sha(pathlib.Path(point['source']))==point['sha256']
  rational=Fraction(point['epsilon']);epsilon=arb(fmpq(rational.numerator,rational.denominator))
  value=sum((evaluate(row['ast'],small_constants)*epsilon**row['epsilon_power'] for row in data['K1_cubed_ratio']),arb(0))
  delta=((value-arb(point['ratio'][0]))**2+arb(point['ratio'][1])**2).sqrt().upper();x=abs(epsilon)*16;tail=4*x**8/(1-x)
  assert delta<tail
  native_checks.append({'profile':point['profile'],'sample_index':point['index'],'difference':delta.str(30,more=True),'Cauchy_tail':tail.str(30,more=True),'passed':True})
 assert len(native_checks)==4
 ctx.dps=20380
 for name,powers in names.items():
  rows=data[name];observed=mma['coefficients'][name]
  assert len(rows)==len(observed)==8
  assert [x['epsilon_power'] for x in rows]==powers==[x['epsilon_power'] for x in observed]
  out=[]
  for row,other in zip(rows,observed):
   value=evaluate(row['ast'],constants);assert value.is_finite() and value.rel_accuracy_bits()>math.ceil(20330*math.log2(10))
   center,error=rounded_cell(value,20200)
   text=other['value'];mantissa,sep,exponent=text.partition('*^');mantissa=mantissa.split('`')[0]
   point=arb(mantissa+('e'+exponent if sep else ''))
   assert other['precision']>=20290 and point.is_finite()
   relative=abs(value-point).upper()/abs(value).lower();assert relative<arb(10)**-20280,(name,row['epsilon_power'],relative)
   digits=int((-relative.log()/arb(10).log()).lower().floor().fmpz())
   out.append({'epsilon_power':row['epsilon_power'],'value':center,'absolute_error_upper_bound':upper_decimal(error),'arithmetic_ball':value.str(20320,more=True),'validated_significant_digits':20200,'expression':row['expression']})
   checks.append({'normalization':name,'epsilon_power':row['epsilon_power'],'independent_agreed_digits_lower_bound':digits,'passed':True})
  outputs[name]=out
 assert len(checks)==24
 payload={'schema':'vakint.pr11d.p853-high-guard-jets.v1','source_exact_jet_sha256':sha(SOURCE),'digits':20200,'coefficient_arithmetic':'FLINT/Arb with outward error bounds and unambiguous nearest decimal cells','coefficients':outputs}
 target=HERE/'p853-20200-jets-through-order7.json';target.write_text(json.dumps(payload,indent=2)+'\n')
 report={'schema':'vakint.pr11d.p853-high-guard-validation.v1','seconds':time.time()-start,'tail_proof':proof,'previous_native_sign_and_family_receipt':str(HERE.parent/'validation-arb-native.json'),'previous_native_receipt_sha256':sha(HERE.parent/'validation-arb-native.json'),'independent_math_review':str(HERE.parents[1]/'helper/p853-independent-review.json'),'independent_math_review_sha256':sha(HERE.parents[1]/'helper/p853-independent-review.json'),'coefficient_data_sha256':sha(target),'source_exact_jet_sha256':sha(SOURCE),'Mathematica_source_sha256':sha(HERE/'mathematica_coefficients_extended.wl'),'Mathematica_result_sha256':sha(mma_path),'validator_sha256':sha(pathlib.Path(__file__)),'independent_checks':checks,'minimum_independent_agreed_digits':min(x['independent_agreed_digits_lower_bound'] for x in checks),'H5_H6_independent_math_review_sha256':sha(review_path),'H5_H6_independent_hypergeometric_oracle_sha256':sha(oracle),'extended_native_point_checks':native_checks,'old18exactASTrows_identical':True,'wholePR11dAccuracyClaimed':False}
 (HERE/'validation-through-order7.json').write_text(json.dumps(report,indent=2)+'\n')
 print('P853 high-guard PASS',report['minimum_independent_agreed_digits'],'independent agreed digits;',report['seconds'],'seconds')
if __name__=='__main__':main()
