"""Recognize archived rows by exact membership in local independent IBPs."""
from replay import *
from target import rowspace,reduce
import time

def candidates(row):
    possible=None
    for p in row:
        c={p}
        for r in range(10):
            n=list(p);n[r]-=1;c.add(tuple(n))
            for s in range(10):
                m=n.copy();m[s]+=1;c.add(tuple(m))
        possible=c if possible is None else possible&c
        if not possible:break
    return possible or set()

@functools.cache
def local_pivots(seed):
    rows=[((seed,i,j),ibp(seed,i,j)) for i,j in itertools.product(range(4),repeat=2)]
    return rowspace(rows)

def main():
    start=time.monotonic()
    matches=[];unmatched=[]
    for number,(path,ident,row) in enumerate(raw_system()):
        found=False
        for seed in sorted(candidates(row)):
            if seed[0]>0 or seed[9]>0 or sum(max(0,-n) for n in seed)>2:continue
            remainder,witness=reduce(row,local_pivots(seed))
            if not remainder:
                # Replay the returned linear combination rather than accepting
                # only the Gaussian solver's zero remainder.
                reconstructed={}
                for (n,i,j),v in witness.items():muladd(reconstructed,ibp(n,i,j),v)
                difference=row.copy();muladd(difference,reconstructed,-ONE)
                assert not difference
                matches.append({'source':path,'id':str(ident),'row_sha256':hashlib.sha256(repr(normalize(row)).encode()).hexdigest(),
                                'seed':seed,'witness':[{'derivative_loop':i,'vector_loop':j,'coefficient':str(v)} for (n,i,j),v in witness.items()]})
                found=True;break
        if not found:unmatched.append({'source':path,'id':str(ident),'terms':len(row)})
        if number%100==0:
            print(number,'matches',len(matches),'unmatched',len(unmatched),'cache',local_pivots.cache_info(),'seconds',time.monotonic()-start,flush=True)
        if time.monotonic()-start>300:
            print('bounded run exhausted at',number,flush=True);break
    report={'schema':'vakint.independent-local-ibp-membership.v1','complete':False,'rows_considered':number+1,
            'exact_matches':matches,'unmatched':unmatched,'seconds':time.monotonic()-start}
    (HERE/'local-replay.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()
