#!/usr/bin/env python3
"""Build the complete X8 boundary from bounded guarded ancestor endpoints.

Output is source/matching evidence only. A complete PR11d value additionally
requires certified ordinary transport, endpoint projection and final acceptance.
"""
import argparse,hashlib,importlib.util,json,sys,time
from pathlib import Path
from flint import arb,ctx
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'pr11-boundary'))
from endpoint_sources import load_native_endpoints
from source_recipes import build_factor_expressions,sha,read
from logjet_map import BoundaryLogJetMap,FactorJet
from expanded_boundary import ExpandedBoundary
PR11=HERE.parent.parent/'pr11d'
P853='pr11d::massless::8535684c37e21dfd38135b151cca892f3552977fef43ab9d0f2deb22f3762f64::raw_native'

def fixed_bounded_sources():
    sunset=PR11/'ancestor-flows/sunset-ratio-20300-normalized.json';data=read(sunset)
    if data.get('error_quality')!='rigorous-bound' or data.get('validated_analytic_truncation_and_rounding') is not True:
        raise ValueError('Accepted bounded sunset source required')
    rows=data['coefficients']['native_raw']
    if [r['epsilon_power'] for r in rows]!=list(range(-2,4)):raise ValueError('Six explicit sunset orders required')
    balls=tuple(arb(r['ball']) for r in rows)
    if any(not x.is_finite() for x in balls):raise ValueError('Nonfinite sunset source')
    out={'native::L2_P2':FactorJet(-2,balls,'Independently accepted exact sunset jet recurrence with bounded complex-epsilon tail','native::L2_P2; '+sha(sunset))}
    p853=PR11/'p853/higher-order/p853-20200-jets-through-order7.json';receipt=PR11/'p853/higher-order/validation-through-order7.json'
    checked=read(receipt);data=read(p853)
    if checked['coefficient_data_sha256']!=sha(p853) or checked['source_exact_jet_sha256']!=data['source_exact_jet_sha256']:
        raise ValueError('P853 source is inconsistent with its accepted receipt')
    rows=data['coefficients']['native_raw']
    if [r['epsilon_power'] for r in rows]!=list(range(-3,5)):raise ValueError('Eight explicit P853 orders required')
    balls=[]
    for row in rows:
        if row['validated_significant_digits']<20200:raise ValueError('P853 source guard is insufficient')
        center=arb(row['value']);error=arb(row['absolute_error_upper_bound'])
        if not center.is_finite() or not error.is_finite() or error.lower()<0:raise ValueError('Invalid P853 source/error')
        balls.append(center+arb(0,error.upper()))
    out[P853]=FactorJet(-3,tuple(balls),'Accepted exact hypergeometric Laurent derivation and independent 20200digit bounded coefficient validation',P853+'; '+sha(p853))
    return out,[{'source':str(sunset),'sha256':sha(sunset),'error_quality':'rigorous-bound','normalization':'native_raw'},
      {'source':str(p853),'sha256':sha(p853),'acceptance_receipt':str(receipt),'acceptance_receipt_sha256':sha(receipt),'error_quality':'rigorous-bound','normalization':'native_raw'}]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--working-digits',type=int,default=20400)
    ap.add_argument('--three-loop-input',required=True);ap.add_argument('--three-loop-sha256',required=True)
    ap.add_argument('--four-loop-input',required=True);ap.add_argument('--four-loop-sha256',required=True)
    ap.add_argument('--output-prefix',required=True);args=ap.parse_args()
    if args.working_digits<64:raise ValueError('At least64workingdigits required')
    prefix=Path(args.output_prefix)
    targets=[prefix.with_suffix('.boundary.json'),prefix.with_suffix('.constants.json')]
    if any(p.exists() for p in targets):raise ValueError('Preserve existing source/matching artifacts; choose a new output prefix')
    ctx.dps=args.working_digits;ctx.threads=1;start=time.monotonic()
    primitives,sources=fixed_bounded_sources()
    values,report=load_native_endpoints(args.three_loop_input,args.three_loop_sha256,{'native::L3_P13':(-3,2),'native::L3_P14':(-3,2)})
    primitives.update(values);sources.append(report)
    values,report=load_native_endpoints(args.four_loop_input,args.four_loop_sha256,{f'native::{s}':(-4,1) for s in ['PR3','PR4','PR4d','PR5','PR7','PR9','PR9d']})
    primitives.update(values);sources.append(report)
    factors,recipe_receipt=build_factor_expressions();inventory=HERE.parent/'pr11-boundary/inventory-full-v2.json'
    plan=BoundaryLogJetMap.from_file(inventory,'db5290bc8520499001d9998098d95474270ba2f5ffed1213dfa5ce2062eac7e9')
    spec=importlib.util.spec_from_file_location('guarded_x8_matching',PR11/'infinity-matching/match.py')
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module);matching=module.Matching()
    compiled=ExpandedBoundary(plan,factors,max_log_power=matching.data['max_exact_log_degree'])
    required,_=compiled.required_primitive_orders(primitives);raw=compiled.evaluate(primitives);boundary={}
    for (i,a,p,l),v in raw.items():
        if a.denominator!=1:raise ValueError('Noninteger inverse-eta source power')
        boundary[i,a.numerator,p,l]=v
    for k,v in boundary.items():
        if k not in matching.positions and not v.contains(0):raise ValueError('Forbidden prepared source support '+str(k)+':'+v.str(35))
    selected={k:boundary[k] for k in matching.all_keys}
    result=matching.solve(selected,inventory_sha256=sha(inventory),normalization='native_raw',error_quality='rigorous-bound')
    implementations={n:sha(HERE/n) for n in ['endpoint_sources.py','x8_guarded_boundary.py']}
    implementations.update({str((HERE.parent/'pr11-boundary'/n).relative_to(HERE.parent)):sha(HERE.parent/'pr11-boundary'/n) for n in ['gamma_jets.py','gamma_ast.py','expanded_boundary.py','source_recipes.py','logjet_map.py']})
    payload={'schema':'vakint.pr11d.guarded-complete-source-boundary.v1','normalization':'native_raw','error_quality':'rigorous-bound',
      'inventory_sha256':sha(inventory),'matching_sha256':matching.binding,'working_decimal_digits':args.working_digits,
      'all_prepared_rows_checked':True,'require_all_prepared_rows':True,'coefficient_count':len(selected),'source_receipts':sources,
      'recipe_receipt':recipe_receipt,'required_raw_primitive_through':required,'implementation_sha256':implementations,
      'coefficients':[{**module.label(k),'real_ball':v.str(args.working_digits+12,more=True)} for k,v in selected.items()],
      'whole_PR11d_accuracy_claimed':False}
    targets[0].write_text(json.dumps(payload,indent=2)+'\n')
    constants={**result.report,'free_constant_balls':[v.str(args.working_digits+12,more=True) for v in result.constants],
      'boundary_input_sha256':sha(targets[0]),'source_receipts':sources,'working_decimal_digits':args.working_digits,
      'wall_seconds':time.monotonic()-start,'whole_PR11d_accuracy_claimed':False}
    targets[1].write_text(json.dumps(constants,indent=2)+'\n')
    print('PASS: bounded324factor X8source;1587rows;252constants; seconds',time.monotonic()-start,flush=True)
if __name__=='__main__':main()
