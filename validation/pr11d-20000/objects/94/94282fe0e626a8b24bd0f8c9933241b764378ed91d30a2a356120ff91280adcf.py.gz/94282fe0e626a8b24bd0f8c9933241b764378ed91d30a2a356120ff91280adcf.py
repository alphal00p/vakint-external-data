"""Audit already completed oracle output; never launches or modifies a solve."""
from pathlib import Path
from fractions import Fraction as F
import hashlib, importlib.util, json, sys
from flint import arb, acb, fmpq, ctx

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location("independent_exact_review", HERE/"audit_exact.py")
exact = importlib.util.module_from_spec(spec)
spec.loader.exec_module(exact)
ctx.dps = 320
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
q = lambda f: fmpq(f.numerator, f.denominator)
def as_ball(z): return acb(arb(q(z[0])), arb(q(z[1])))
def mul(a, b): return (a[0]*b[0]-a[1]*b[1], a[0]*b[1]+a[1]*b[0])
def add(a, b): return a[0]+b[0], a[1]+b[1]
def subtract(a, b): return a[0]-b[0], a[1]-b[1]
def exact_digits(f):
    assert f >= 0
    if f == 0: return None
    n = len(str(f.denominator))-len(str(f.numerator))
    bound = F(1, 10**n) if n >= 0 else F(10**-n)
    return n if f <= bound else n-1
def ball_digits(error):
    assert error.is_finite() and error > 0
    return int((-error.log()/arb(10).log()).lower().floor().fmpz())

input_path = ROOT/"input.json"
input_data = json.loads(input_path.read_text())
V = [(F(p[0]["center"]), F(p[1]["center"])) for p in input_data["endpoint_adjoint"]]
ref_path = ROOT/"p17-reference-snapshot.json"
reference = json.loads(ref_path.read_text())
ref = dict((p, F(v)) for p, v in reference)
assert set(ref) == {-4, -3, -2, -1, 0, 1} and all(ref[p] == 0 for p in [-4, -3, -2, -1])
reference_provenance = json.loads((ROOT/"reference-provenance.json").read_text())
assert sha(ref_path) == reference_provenance["snapshot_sha256"] == reference_provenance["source_sha256"] == "76af128590f58a49fafb3b9a63e02915a4bacfd56266ef1ecff04f0ac6298203"
assert reference_provenance["first_read_after_baseline_completed"] is True
assert reference_provenance["reference_used_as_solver_input"] is False
native_path = ROOT.parent/"physical-prototype/result.json"
native = json.loads(native_path.read_text())
assert native["error_quality"] == "validated-digits-estimate"
assert not native["physical_accuracy_certified"] and not native["whole_PR11d_20000_accuracy_claimed"]
native_value = acb(arb(native["real_ball"]), arb(native["imaginary_ball"]))

labels = ["baseline170"]
if (ROOT/"refined200-result.json").exists(): labels.append("refined200")
results, numbers, source_hashes = [], {}, {}
for label in labels:
    p = ROOT/f"{label}-result.json"
    data = json.loads(p.read_text())
    process_path = ROOT/f"{label}-process.json"
    process = json.loads(process_path.read_text())
    assert process["exit_code"] == 0 and process["elapsed_seconds"] < process["timeout_seconds"]
    assert process["log_sha256"] == sha(ROOT/f"{label}.log")
    for path, digest in process["source_sha256"].items():
        path = Path(path)
        if label == "baseline170" and path.name == "run.py": path = ROOT/"run-baseline170.py"
        assert sha(path) == digest, path
        source_hashes[str(path)] = digest
    assert data["segments"] == 48 and data["eta_end"] == "I/16"
    assert data["solver"] == "Original AMFlow2.0 DESolver MMA CalcRun"
    assert data["source_error_quality"] == input_data["input_error_quality"] == "validated-digits-estimate"
    assert not data["physical_accuracy_certified"] and not data["whole_PR11d_20000_accuracy_claimed"]
    assert data["independence_scope"] == input_data["scope"] and data["normalization"] == input_data["normalization"]
    for path, field in [(input_path, "input_sha256"), (ROOT/"exact-lift.wl", "matrix_sha256"), (ROOT/"upstream/diffeq_solver/DESolver.m", "solver_sha256")]:
        assert sha(path) == data[field]
    vector = [exact.rational_complex(text) for text in data["vector"]]
    assert len(vector) == 252
    value = exact.rational_complex(data["finite_coefficient"])
    numbers[label] = value
    projection = (F(0), F(0))
    for k in range(6):
        for i in range(42): projection = add(projection, mul(V[k*42+i], vector[(5-k)*42+i]))
    projection_difference = subtract(projection, value)
    # Exact rational L1 bound avoids relying on the checked comparison parser.
    exact_projection_bound = abs(projection_difference[0])+abs(projection_difference[1])
    assert exact_projection_bound < F(1, 10**(data["working_digits"]-30))
    ref_digits = exact_digits(abs(value[0]-ref[0])/max(F(1), abs(ref[0])))
    imag_digits = exact_digits(abs(value[1])/max(F(1), abs(value[0])))
    native_delta = abs(as_ball(value)-native_value).upper()
    native_digits = ball_digits(native_delta/max(arb(1), abs(native_value).upper()))
    assert ref_digits >= 70 and imag_digits >= 70 and native_digits >= 70
    pole_path = ROOT/f"{label}-pole-check.json"
    pole = json.loads(pole_path.read_text())
    assert pole["source_result_sha256"] == sha(p)
    assert [row["epsilon_order"] for row in pole["coefficients"]] == list(range(-5,0))
    pole_norms = []
    for order, row in zip(range(-5,0), pole["coefficients"]):
        coefficient = (F(0),F(0))
        for k in range(order+6):
            for i in range(42): coefficient = add(coefficient,mul(V[k*42+i],vector[(order+5-k)*42+i]))
        norm = abs(as_ball(coefficient))
        assert norm < arb("1e-100")
        assert norm.overlaps(arb(row["central_projected_complex_norm"]))
        assert row["exact_zero_claimed_from_numerics"] is False
        pole_norms.append(norm.upper())
    source_hashes[str(pole_path)] = sha(pole_path)
    results.append({
        "label": label,
        "working_digits": data["working_digits"],
        "taylor_order": data["taylor_order"],
        "ordinary_steps": data["segments"],
        "exact_rational_projection_L1_difference_upper_bound": str(exact_projection_bound),
        "projection_difference_observed_absolute_digits": exact_digits(exact_projection_bound),
        "archived_reference_observed_scaled_real_agreement_digits": ref_digits,
        "observed_scaled_imaginary_suppression_digits": imag_digits,
        "native_estimated_enclosure_observed_scaled_complex_agreement_digits": native_digits,
        "five_apparent_negative_epsilon_coefficients_independently_checked": True,
        "largest_apparent_pole_central_norm": max(pole_norms).str(35),
        "wall_seconds": process["elapsed_seconds"],
        "cpu_seconds": process["user_cpu_seconds"]+process["system_cpu_seconds"],
        "peak_kernel_RSS_KiB": process["peak_child_rss_kib"],
        "result_sha256": sha(p),
        "process_sha256": sha(process_path),
    })
    source_hashes[str(p)] = sha(p)
    source_hashes[str(process_path)] = sha(process_path)

refinement_digits = None
if len(labels) == 2:
    a, b = results
    assert b["working_digits"] > a["working_digits"] and b["taylor_order"] > a["taylor_order"]
    delta = abs(as_ball(numbers[labels[0]])-as_ball(numbers[labels[1]])).upper()
    refinement_digits = ball_digits(delta/max(arb(1), abs(as_ball(numbers[labels[1]])).upper()))
    assert refinement_digits >= 70

for p in [HERE/"audit_outputs.py", ROOT/"compare.py", ROOT/"run.py", ref_path, ROOT/"reference-provenance.json", native_path]: source_hashes[str(p)] = sha(p)
report = {
    "schema": "vakint.pr11d.original-AMFlow-independent-output-review.v1",
    "status": "PASS_practical_70_digit_solver_crosscheck" if len(labels) == 2 else "PASS_baseline_only_refinement_pending",
    "results": results,
    "refinement_observed_scaled_complex_agreement_digits": refinement_digits,
    "practical_70_digit_solver_crosscheck_passed": len(labels) == 2,
    "independence_scope": "Ordinary numerical transport only. Exact DE/IBPs, estimated190-digit Frobenius starting boundary, and analytic endpoint adjoint remain shared.",
    "physical_accuracy_certified": False,
    "whole_PR11d_20000_accuracy_claimed": False,
    "central_parsing_rounding_is_not_physical_uncertainty": True,
    "new_Wolfram_solver_launched_by_review": False,
    "reference_used_as_solver_input": False,
    "source_sha256": source_hashes,
}
(HERE/"output-review.json").write_text(json.dumps(report, indent=2)+"\n")
print(json.dumps({k: v for k, v in report.items() if k != "source_sha256"}, indent=2))
