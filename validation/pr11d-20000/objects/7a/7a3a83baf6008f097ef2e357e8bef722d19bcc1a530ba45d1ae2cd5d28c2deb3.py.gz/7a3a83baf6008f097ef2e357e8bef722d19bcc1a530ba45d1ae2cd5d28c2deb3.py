#!/usr/bin/env python3
"""Diagnostic gate tests only; synthetic authority is never physical admission.

Runs the unmodified seal.main on temporary, SHA-bound diagnostic receipt copies.
No native, preparer, HPL, source assembly, transport or endpoint replay is run.
Accepted diagnostic output is deleted before this script emits its test receipt.
The final payload width/inventory block is also compiled directly from the
producer AST, so deliberate payload corruption can exercise those gates past
the immutable endpoint digest gate without modifying the producer.
"""
import ast
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ADMISSION = HERE.parent.parent
SEAL = ADMISSION / 'seal.py'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')
    return sha(path)


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def main():
    started = time.monotonic()
    seal = module('actual_A49_seal_diagnostic', SEAL)
    common = module('actual_A49_common_diagnostic', seal.COMMON)
    frozen = {str(p): sha(p) for p in [SEAL, seal.COMMON, ADMISSION / 'replay.py']}
    chain_source = ADMISSION / 'chain-data-review-v2.json'
    endpoint_source = ADMISSION / 'endpoint-replay/replay-snapshot.json'
    initial_source = ADMISSION / 'initial-review/accepted.json'
    for path in [chain_source, endpoint_source, initial_source]:
        frozen[str(path)] = sha(path)
    chain, endpoint, initial = map(load, [chain_source, endpoint_source, initial_source])
    payload = load(endpoint['endpoint_path'])
    frozen[endpoint['endpoint_path']] = sha(endpoint['endpoint_path'])
    frozen[endpoint['canonical_binding_proof_path']] = sha(endpoint['canonical_binding_proof_path'])

    # Diagnostic copies use a small, valid source graph to isolate every gate.
    # Actual component graphs are separately hashed below, never replaced.
    actual_graph = {}
    for data in [chain, endpoint, initial]:
        for field in ['source_pins', 'implementation_sha256', 'artifact_sha256']:
            for key, value in data.get(field, {}).items():
                if isinstance(value, dict):
                    key, value = value['path'], value['sha256']
                actual_graph.setdefault(key, set()).add(value)
    graph_checks = []
    for path, expected in sorted(actual_graph.items()):
        actual = sha(path)
        graph_checks.append({'path': path, 'expected_sha256': sorted(expected),
                             'actual_sha256': actual, 'matched': expected == {actual}})
    for data in [chain, endpoint, initial]:
        for field in ['source_pins', 'implementation_sha256', 'artifact_sha256']:
            data.pop(field, None)
        data['diagnostic_copy_only_not_physical_authority'] = True
        data['source_pins'] = {str(seal.COMMON): sha(seal.COMMON)}
    chain['checker_sha256'] = sha(ADMISSION / 'replay.py')
    initial.update(accepted=True, status='passed_for_frozen_production_A_physical_initial',
                   source_only=False, all_numerical_history_fields_identical=True,
                   both_132_normalized_and_raw_vectors_byte_identical=True)
    invocation = {'schema': 'vakint.pr9.production-A.fresh-native-invocation.v1',
                  'accepted_same_input_same_binary_replay': True, 'returncode': 0,
                  'all_numerical_history_and_contract_fields_equal': True,
                  'diagnostic_copy_only_not_physical_authority': True}
    initial_review = {'accepted': True,
                      'status': 'passed_for_frozen_production_A_initial_admission_checker_and_data',
                      'initial_artifact_sha256': seal.INITIAL_SHA,
                      'source_pins': {str(seal.COMMON): sha(seal.COMMON)},
                      'diagnostic_copy_only_not_physical_authority': True}
    review = {'accepted': True, 'status': 'passed_for_frozen_production_A_physical_source_checker',
              'checker_sha256': sha(ADMISSION / 'replay.py'), 'seal_sha256': sha(SEAL),
              'endpoint_sha256': seal.ENDPOINT_SHA,
              'canonical_binding_proof_sha256': endpoint['canonical_binding_proof_sha256'],
              'source_pins': {str(seal.COMMON): sha(seal.COMMON)},
              'implementation_sha256': {str(SEAL): sha(SEAL)},
              'diagnostic_copy_only_not_physical_authority': True}
    pole_path = ADMISSION / 'review/lineage/pole22/review.json'
    pole_certificate = load(pole_path)
    frozen[str(pole_path)] = sha(pole_path)
    review.update(raw_22_basis_pole_bound_verified=True, raw_source_sha256=chain['raw_source_sha256'])
    baseline = dict(pole_certificate=pole_certificate, chain=chain, endpoint=endpoint, initial=initial, invocation=invocation,
                    initial_review=initial_review, review=review)
    cases, positive_controls = [], []
    with tempfile.TemporaryDirectory(prefix='diagnostic-', dir=HERE) as temporary:
        tmp = Path(temporary)
        paths = {name: tmp / (name + '.json') for name in baseline}
        output = tmp / 'synthetic-diagnostic-output-to-be-deleted.json'

        def prepare(data):
            initial, initial_review, review = (data[k] for k in ['initial', 'initial_review', 'review'])
            review['raw_22_pole_bound_certificate_path'] = str(paths['pole_certificate'])
            review['raw_22_pole_bound_certificate_sha256'] = write(paths['pole_certificate'], data['pole_certificate'])
            initial['fresh_native_invocation_path'] = str(paths['invocation'])
            initial['fresh_native_invocation_sha256'] = write(paths['invocation'], data['invocation'])
            initial_review['native_invocation_sha256'] = initial['fresh_native_invocation_sha256']
            initial['independent_review_path'] = str(paths['initial_review'])
            initial['independent_review_sha256'] = write(paths['initial_review'], initial_review)
            review['chain_data_review_sha256'] = write(paths['chain'], data['chain'])
            review['endpoint_replay_sha256'] = write(paths['endpoint'], data['endpoint'])
            review['initial_admission_sha256'] = write(paths['initial'], initial)
            write(paths['review'], review)

        def execute(name, mutation=None, post=None, expected=None, output_override=None):
            data = copy.deepcopy(baseline)
            if mutation:
                mutation(data)
            prepare(data)
            if post:
                post(data)
            out = output if output_override is None else output_override
            sys.argv = [str(SEAL), '--chain-data', str(paths['chain']), '--endpoint-replay',
                        str(paths['endpoint']), '--initial-admission', str(paths['initial']),
                        '--initial-admission-sha256', sha(paths['initial']),
                        '--independent-review', str(paths['review']),
                        '--independent-review-sha256', sha(paths['review']), '--output', str(out)]
            try:
                with contextlib.redirect_stdout(io.StringIO()):
                    seal.main()
            except (ValueError, KeyError, TypeError, IndexError, FileNotFoundError) as exc:
                if expected is None:
                    raise AssertionError('Positive control failed: ' + name) from exc
                assert expected in str(exc), (name, str(exc), expected)
                assert not output.exists(), name
                cases.append({'name': name, 'rejected': True, 'reason': str(exc),
                              'producer_function': 'seal.main'})
            else:
                assert expected is None, 'Malformed diagnostic fixture accepted: ' + name
                result = load(output)
                assert result['accepted'] is True and result['whole_PR11d_20000_accuracy_claimed'] is False
                assert result['PR11d_validated_decimal_cap'] == 200
                positive_controls.append({'name': name, 'passed': True,
                                          'synthetic_authority_only': True,
                                          'coefficient_count': result['coefficient_count'],
                                          'maximum_component_radius': result['maximum_component_radius']})
                output.unlink()

        def change(group, key, value):
            return lambda data: data[group].__setitem__(key, value)

        execute('synthetic_authority_complete_gate_path')
        for name, group, key, value, reason in [
            ('review_missing_pole_bound', 'review', 'raw_22_basis_pole_bound_verified', False, 'six-jet closure'),
            ('review_wrong_raw_source', 'review', 'raw_source_sha256', '0'*64, 'six-jet closure'),
            ('pole_rejected', 'pole_certificate', 'accepted', False, 'another source or scope'),
            ('pole_wrong_schema', 'pole_certificate', 'schema', 'wrong', 'another source or scope'),
            ('pole_bound_unverified', 'pole_certificate', 'raw_22_basis_pole_bound_verified', False, 'another source or scope'),
            ('pole_wrong_basis_size', 'pole_certificate', 'basis_size', 42, 'another source or scope'),
            ('pole_float_basis_size', 'pole_certificate', 'basis_size', 22.0, 'another source or scope'),
            ('pole_wrong_raw_source', 'pole_certificate', 'raw_source_sha256', '0'*64, 'another source or scope'),
            ('pole_empty_source_graph', 'pole_certificate', 'source_and_checker_sha256', {}, 'lacks its source/checker graph'),
            ('pole_relative_source_path', 'pole_certificate', 'source_and_checker_sha256', {'relative': '0'*64}, 'pins must be absolute'),
            ('pole_wrong_source_digest', 'pole_certificate', 'source_and_checker_sha256', {str(seal.COMMON): '0'*64}, 'checksum mismatch'),
            ('review_rejected', 'review', 'accepted', False, 'not accepted'),
            ('review_truthy_not_boolean', 'review', 'accepted', 1, 'not accepted'),
            ('review_pending_status', 'review', 'status', 'pending', 'not accepted'),
            ('review_wrong_checker', 'review', 'checker_sha256', '0'*64, 'another checker'),
            ('review_wrong_seal', 'review', 'seal_sha256', '0'*64, 'another checker'),
            ('review_empty_source_graph', 'review', 'source_pins', {}, 'Missing independent review source graph'),
            ('review_empty_implementation_graph', 'review', 'implementation_sha256', {}, 'Missing independent review source graph'),
            ('review_relative_graph_path', 'review', 'source_pins', {'relative': '0'*64}, 'paths must be absolute'),
            ('review_stale_source_hash', 'review', 'source_pins', {str(seal.COMMON): '0'*64}, 'checksum mismatch'),
            ('review_wrong_endpoint', 'review', 'endpoint_sha256', '0'*64, 'other physical data'),
            ('chain_wrong_schema', 'chain', 'schema', 'wrong', 'Unaccepted or stale chain data'),
            ('chain_wrong_status', 'chain', 'status', 'pending', 'Unaccepted or stale chain data'),
            ('chain_wrong_checker', 'chain', 'checker_sha256', '0'*64, 'Unaccepted or stale chain data'),
            ('chain_count48', 'chain', 'completed_step_count', 48, 'Incomplete physical transport lineage'),
            ('chain_wrong_initial', 'chain', 'initial_sha256', '0'*64, 'Incomplete physical transport lineage'),
            ('chain_new_native_call', 'chain', 'new_native_or_preparer_calls', 1, 'Wrong physical chain admission method'),
            ('chain_overlap_only', 'chain', 'all_checks_use_exact_identity_full_containment_or_original_outward_replay', False, 'Wrong physical chain admission method'),
            ('initial_wrong_schema', 'initial', 'schema', 'wrong', 'not fully accepted'),
            ('initial_not_accepted', 'initial', 'accepted', False, 'not fully accepted'),
            ('initial_pending', 'initial', 'status', 'source_admitted_pending_fresh_native_invocation', 'not fully accepted'),
            ('initial_source_only', 'initial', 'source_only', True, 'not fully accepted'),
            ('initial_source_only_numeric_zero', 'initial', 'source_only', 0, 'not fully accepted'),
            ('initial_wrong_artifact', 'initial', 'initial_artifact_sha256', '0'*64, 'not fully accepted'),
            ('initial_556_rows', 'initial', 'source_boundary_rows_exactly_replayed_by_blessed_proof', 556, 'not exactly admitted'),
            ('initial_131_constants', 'initial', 'matched_constants_exactly_replayed_by_blessed_proof', 131, 'not exactly admitted'),
            ('initial_overlap_acceptance', 'initial', 'overlap_used_as_physical_acceptance', True, 'not exactly admitted'),
            ('initial_review_pending', 'initial_review', 'accepted', False, 'lack independent acceptance'),
            ('initial_review_wrong_status', 'initial_review', 'status', 'pending', 'lack independent acceptance'),
            ('initial_review_wrong_artifact', 'initial_review', 'initial_artifact_sha256', '0'*64, 'lack independent acceptance'),
            ('invocation_wrong_schema', 'invocation', 'schema', 'wrong', 'not successfully reproduced'),
            ('invocation_not_accepted', 'invocation', 'accepted_same_input_same_binary_replay', False, 'not successfully reproduced'),
            ('invocation_nonzero_exit', 'invocation', 'returncode', 1, 'not successfully reproduced'),
            ('invocation_boolean_exit', 'invocation', 'returncode', False, 'not successfully reproduced'),
            ('invocation_numerical_mismatch', 'invocation', 'all_numerical_history_and_contract_fields_equal', False, 'not successfully reproduced'),
            ('endpoint_wrong_schema', 'endpoint', 'schema', 'wrong', 'not accepted'),
            ('endpoint_rejected', 'endpoint', 'accepted', False, 'not accepted'),
            ('endpoint_pending', 'endpoint', 'status', 'pending', 'not accepted'),
            ('endpoint_wrong_payload_sha', 'endpoint', 'endpoint_sha256', '0'*64, 'not accepted'),
            ('endpoint_wrong_boundary_sha', 'endpoint', 'final_boundary_sha256', '0'*64, 'another transported boundary'),
            ('endpoint_wrong_boundary_path', 'endpoint', 'final_boundary_path', str(paths['initial']), 'another transported boundary'),
            ('endpoint_binding_count6', 'endpoint', 'canonical_binding_count', 6, 'not independently bound'),
            ('endpoint_binding_hash_mismatch', 'review', 'canonical_binding_proof_sha256', '0'*64, 'not independently bound'),
        ]:
            execute(name, change(group, key, value), expected=reason)
        execute('chain_duplicate_global_index', lambda d: d['chain']['steps'][1].__setitem__('global_index', 0), expected='Incomplete physical transport lineage')
        execute('chain_missing_step', lambda d: d['chain']['steps'].pop(), expected='Incomplete physical transport lineage')
        execute('chain_wrong_segment_partition', lambda d: d['chain']['segments'][0].__setitem__('steps', 1), expected='Incomplete physical transport lineage')
        for field in ['initial_physical_source_admitted', 'all_132_seed_full_source_boxes_contained',
                      'all_132_actual_native_seed_strings_reproduced_exactly', 'all_numerical_history_fields_identical',
                      'both_132_normalized_and_raw_vectors_byte_identical', 'physical_primitive_API_and_sunset_proofs_revalidated']:
            execute('initial_missing_' + field, change('initial', field, False), expected='open source edge')
        for field in ['all_source_and_adjoint_review_hashes_verified', 'all_canonical_family_power_and_order_bindings_verified',
                      'all_serialized_complex_boxes_fully_enclose_original_convolutions', 'all_original_coefficient_and_metadata_strings_byte_identical']:
            execute('endpoint_missing_' + field, change('endpoint', field, False), expected='Endpoint admission is incomplete')
        for field in ['working_decimal_digits', 'serialization_decimal_digits', 'master_count', 'complex_coefficient_count',
                      'component_full_box_containments', 'byte_identical_component_strings']:
            execute('endpoint_wrong_' + field, lambda d, f=field: d['endpoint']['endpoint_replay'].__setitem__(f, 0), expected='Incomplete endpoint replay')
        for group in ['chain', 'endpoint', 'initial', 'initial_review']:
            execute(group + '_malformed_graph', change(group, 'source_pins', []), expected='Malformed source/artifact graph')
            execute(group + '_relative_graph', change(group, 'source_pins', {'relative': '0'*64}), expected='paths must be absolute')
            execute(group + '_stale_graph_pin', change(group, 'source_pins', {str(seal.COMMON): '0'*64}), expected='checksum mismatch')
            execute(group + '_malformed_named_artifact', change(group, 'artifact_sha256', {'item': {'path': str(seal.COMMON)}}), expected='Malformed named artifact binding')
        for group in ['chain', 'endpoint', 'initial']:
            execute(group + '_tampered_after_authority_pin', post=lambda d, g=group: paths[g].write_text(paths[g].read_text()+' '), expected='other physical data' if group == 'initial' else 'checksum mismatch')
        def wrong_initial_review_invocation(data):
            data['initial_review']['native_invocation_sha256'] = '0'*64
            write(paths['initial_review'], data['initial_review'])
            data['initial']['independent_review_sha256'] = sha(paths['initial_review'])
            write(paths['initial'], data['initial'])
            data['review']['initial_admission_sha256'] = sha(paths['initial'])
            write(paths['review'], data['review'])
        execute('independent_initial_review_wrong_invocation', post=wrong_initial_review_invocation, expected='another native invocation')
        execute('protected_existing_output', expected='Output must be a fresh nonsymlink path', output_override=SEAL)
        execute('protected_outside_admission_output', expected='Output must be a fresh nonsymlink path', output_override=ADMISSION.parent / 'A49-seal-rejected-output-must-not-exist.json')
        execute('protected_missing_parent_output', expected='Output must be a fresh nonsymlink path', output_override=tmp / 'missing-parent' / 'no.json')
        symlink = tmp / 'symlink-output.json'
        symlink.symlink_to(tmp / 'nonexistent-symlink-target.json')
        execute('protected_dangling_symlink_output', expected='Output must be a fresh nonsymlink path', output_override=symlink)
        execute('positive_control_after_all_main_rejections')

    # Extract these exact producer statements, without rewriting their logic.
    source = SEAL.read_text()
    tree = ast.parse(source)
    body = next(node.body for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'main')
    start = next(i for i, node in enumerate(body) if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'expected_symbols' for t in node.targets))
    stop = next(i for i, node in enumerate(body[start:], start) if isinstance(node, ast.For) and isinstance(node.target, ast.Tuple)
                and [getattr(item, 'id', None) for item in node.target.elts] == ['path', 'digest'])
    selected = body[start:stop]
    code = compile(ast.Module(body=selected, type_ignores=[]), str(SEAL), 'exec')
    first, last = selected[0].lineno, selected[-1].end_lineno
    def payload_test(name, mutation=None, expected=None):
        data = copy.deepcopy(payload)
        if mutation:
            mutation(data)
        namespace = dict(seal.__dict__, payload=data, c=common)
        try:
            exec(code, namespace)
        except (ValueError, KeyError, TypeError) as exc:
            assert expected and expected in str(exc), (name, str(exc), expected)
            cases.append({'name': name, 'rejected': True, 'reason': str(exc),
                          'producer_function': 'unchanged AST statements from seal.main',
                          'producer_lines': [first, last]})
        else:
            assert expected is None, 'Malformed payload accepted: ' + name
            positive_controls.append({'name': name, 'passed': True, 'uses_actual_endpoint_payload': True})
    def first_row(data):
        return data['coefficients']['native::PR3'][0]
    payload_test('real_payload_width_and_inventory_control')
    payload_test('payload_missing_master', lambda d: d['coefficients'].pop('native::PR9d'), 'Canonical source inventory differs')
    payload_test('payload_missing_order', lambda d: d['coefficients']['native::PR3'].pop(), 'Missing source Laurent order')
    payload_test('payload_duplicate_order', lambda d: first_row(d).__setitem__('epsilon_power', -3), 'Missing source Laurent order')
    payload_test('payload_nonfinite_real', lambda d: first_row(d).__setitem__('ball', 'nan'), 'Nonfinite or nonreal physical source')
    payload_test('payload_nonfinite_imaginary', lambda d: first_row(d).__setitem__('imaginary_ball', 'nan'), 'Nonfinite or nonreal physical source')
    payload_test('payload_imaginary_excludes_zero', lambda d: first_row(d).__setitem__('imaginary_ball', '1'), 'Nonfinite or nonreal physical source')
    payload_test('payload_wide_real_total_error', lambda d: first_row(d).__setitem__('ball', '[0 +/- 1e-20049]'), 'guard is insufficient')
    payload_test('payload_wide_imaginary_total_error', lambda d: first_row(d).__setitem__('imaginary_ball', '[0 +/- 1e-20049]'), 'guard is insufficient')
    payload_test('payload_threshold_is_strict', lambda d: first_row(d).__setitem__('ball', '[0 +/- 1e-20050]'), 'guard is insufficient')
    payload_test('payload_tiny_width_inside_threshold', lambda d: first_row(d).__setitem__('ball', '[0 +/- 1e-20051]'))
    assert all(sha(path) == digest for path, digest in frozen.items()), 'Frozen input changed during diagnostic'
    receipt = {'schema': 'vakint.PR9-production-A-seal-diagnostic-guard-review.v1',
               'scope': 'Actual aggregate-seal gate tests; no physical acceptance authority',
               'physical_source_admission_claimed': False, 'final_actual_initial_receipt_available': True,
               'synthetic_authority_used_only_in_removed_temporary_fixtures': True,
               'accepted_synthetic_outputs_retained': False,
               'native_preparer_HPL_or_endpoint_replay_calls': 0,
               'seal_sha256': sha(SEAL), 'test_implementation_sha256': sha(__file__),
               'positive_controls': positive_controls, 'rejection_count': len(cases), 'cases': cases,
               'actual_component_graph_file_count': len(graph_checks), 'actual_component_graph_checks': graph_checks,
               'stale_actual_component_graph_pins': [row for row in graph_checks if not row['matched']],
               'source_pins': frozen, 'all_frozen_inputs_unchanged': True,
               'payload_gate_ast_line_range': [first, last], 'seconds': time.monotonic()-started}
    destination = HERE / 'guard-rejections-v2.json'
    with destination.open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'receipt': str(destination), 'sha256': sha(destination),
                      'rejections': len(cases), 'positive_controls': len(positive_controls),
                      'actual_graph_files': len(graph_checks),
                      'stale_graph_pins': len(receipt['stale_actual_component_graph_pins']),
                      'seconds': receipt['seconds']}, indent=2))


if __name__ == '__main__':
    main()
