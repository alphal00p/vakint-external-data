#!/usr/bin/env python3
"""Compose independently reviewed physical X8 initial admissions, fail closed.

No recurrence, source assembly, HPL evaluation or native computation is run.
The independent checker review and complete four-loop source receipt must be
explicitly blessed by their hashes before an admitted envelope is written.
"""
import argparse,hashlib,json
from pathlib import Path
from flint import arb,acb,ctx
if not __debug__:raise RuntimeError('Assertions required')
HERE=Path(__file__).resolve().parent;BASE=HERE.parents[1];HELPER=BASE/'helper'
SOURCE_HASH='a9ec06c3a076f3460e84ec3492ae314b29f4cf470dddbe2a5442b502f7181184'
FIXED={
 'non4L':(BASE.parent/'bessel/ancestor-boundary/production-runs-v1/non-four-loop-admission.json','6fe90ef57bd7cfcb885414cf8e3df003f0c8ecf0dab96fd88d84bdf99d0b8e17'),
 'source':(HELPER/'x8-production-source-replay/review.json','4ba15fcc5a3de2ae3c7c1f522969b270376aef5904fb98be4cd3af789e7652aa'),
 'input':(HELPER/'x8-production-native-input-review/review.json','fcba248b819478e80763b0094163f6054112b582c5d439459c1a847ba1d6171b'),
 'output':(HELPER/'x8-conditional-launcher-review/completed-output-review-v2.json','c829d4fc5480a40e71a01f21876858a319702ffa060e491842be741506a25389'),
 'kernel':(HELPER/'frobenius-transport/native/schedule-review/review.json','165a577ec48751c78df18e2522ecc60cedcfb076e4d38cb697e6dc7a8496ead6'),
 'raw_poles':(HELPER/'physical-poles-review/review.json','22f69516f6f2e0a8278b9a4913dfd85a74b0e82b5c7e8507d0b8655c13d8ef31'),
 'preparation':(HELPER/'frobenius-transport/preparation-audit/startup-replay-receipt.json','ff73929d91481a585f86e7f7475480f1917c117a6f86f8656d051aa27ce5cdba'),
 'raw_to_infinity':(HELPER/'augmented-gauge-exact-replay.json','13f0f1fc087a00f9add4945152d84094fa5f27a7ecafbc957a21950f0632b727'),
}
INITIAL_HASH={'A':'e68d82518214ffae10879beb129001c7233552d69e2b544c0a17fe2dc9a6d447','B':'c789f3587d02ecd3d9ca9ee0eb699120aa209c5bee88901c32d5c22068dc37b9'}
ENDPOINT_HASH={'A':'2b33f543f27e42ba6963fd6abc488b225a1f30d54c92fa1b2770bb42f6f839c1','B':'4f905a9a27d3b756cc551cff0ed893d1448e71dff9578d4143998578aebfbba2'}
PINS={}
def require(value,message):
 if not value:raise ValueError(message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pin(path,digest=None):
 path=Path(path).resolve();actual=sha(path)
 require(digest is None or actual==digest,'Changed artifact '+str(path))
 require(str(path) not in PINS or PINS[str(path)]==actual,'Conflicting source pin')
 PINS[str(path)]=actual;return path
def read(path,digest=None):return json.loads(pin(path,digest).read_text())
def merge_graphs(data):
 for field in ['source_pins','artifact_sha256','source_and_implementation_pins','source_and_output_sha256',
               'implementation_and_source_sha256','implementation_sha256','source_sha256','source_and_output_pins','transitive_source_sha256']:
  graph=data.get(field)
  if not isinstance(graph,dict):continue
  for key,value in graph.items():
   if isinstance(value,str):path,digest=key,value
   else:
    require(isinstance(value,dict) and set(value)=={'path','sha256'},'Malformed named graph binding')
    path,digest=value['path'],value['sha256']
   require(Path(path).is_absolute(),'Admission graphs require absolute paths');pin(path,digest)
def selected(data,profile):
 rows=[row for row in data['profiles'] if row['profile']==profile]
 require(len(rows)==1,'Missing or duplicate selected profile');return rows[0]
def four_loop_binding_gates(profile,review,path,digest):
 bindings=review.get('four_loop_admissions')
 require(isinstance(bindings,dict) and set(bindings)=={'A','B'},'Independent review lacks the complete blessed four-loop admission map')
 binding=bindings[profile]
 require(isinstance(binding,dict) and set(binding)=={'path','sha256'},'Malformed blessed four-loop admission binding')
 require(Path(binding['path']).is_absolute() and Path(binding['path']).resolve()==Path(path).resolve()
         and binding['sha256']==digest,'Four-loop receipt is not the independently blessed profile receipt')
def origin_gates(profile,four,non4,boundary):
 require(four['schema']==f'vakint.PR9-production-{profile}-complete-physical-source-admission.v1'
         and four['accepted'] is True and four['whole_chain_physical_source_admitted'] is True,
         'Four-loop physical source is not completely admitted')
 require(isinstance(four.get('artifact_sha256'),dict) and bool(four['artifact_sha256']),
         'Four-loop admission lacks its complete nonempty proof/artifact graph')
 require(four['endpoint_sha256']==ENDPOINT_HASH[profile], 'Wrong four-loop endpoint')
 require(four['normalization']=='native_raw' and four['error_quality']=='rigorous-bound',
         'Wrong four-loop source normalization/quality')
 require(four['coefficient_count']==42 and four['epsilon_powers']==list(range(-4,2)), 'Incomplete four-loop support')
 expected={'native::'+x for x in ['PR3','PR4','PR4d','PR5','PR7','PR9','PR9d']}
 require(set(four['canonical_masters'])==expected and len(four['canonical_masters'])==7,'Wrong canonical four-loop names')
 require(non4['accepted_for_non4L_source_edges'] is True
         and non4['all_explicit_source_data_and_mathematical_review_bindings_verified'] is True
         and non4['normalization']=='native_raw' and non4['error_quality']=='rigorous-bound','Non-four-loop origins unaccepted')
 require(set(non4['profiles'][profile])=={'three_loop','sunset','p853'},'Unexpected non-four-loop origin inventory')
 actual={}
 for row in boundary['source_receipts']:
  path=str(Path(row.get('source',row.get('path'))).resolve())
  require(path not in actual,'Duplicate primitive source datum')
  require(row['normalization']=='native_raw' and row['error_quality']=='rigorous-bound','Primitive source convention differs')
  pin(path,row['sha256']);actual[path]=row['sha256']
 admitted={str(Path(four['endpoint_path']).resolve()):four['endpoint_sha256']}
 for role in ['three_loop','sunset','p853']:
  item=non4['profiles'][profile][role];datum=item['data'];proof=item['admission']
  path=str(pin(datum['path'],datum['sha256']));pin(proof['path'],proof['sha256']);admitted[path]=datum['sha256']
  if role=='three_loop':require(item['support']=={'native::L3_P13':[-3,2],'native::L3_P14':[-3,2]} and item['additional_Euler_conversion'] is False,'Incomplete three-loop support or extra Euler conversion')
  elif role=='sunset':require(item['support']=={'native::L2_P2':[-2,3]} and item['additional_Euler_conversion'] is False,'Incomplete sunset support or extra Euler conversion')
  else:require(item['support']=={'P853_native_raw':[-3,4]} and item['arithmetic_ball_diagnostic_used'] is False,'Wrong P853 fields/support')
 require(len(actual)==len(admitted)==4 and actual==admitted,'Physical source admission does not cover the exact complete primitive datum set')
 for row in boundary['source_receipts']:
  if row.get('source_schema') in ['vakint.ancestor.certified-canonical-master-jets.v1','vakint.native-three-loop-guard20600-from-public-API.v1']:
   require(row['no_Euler_conversion_applied'] is True,'Imported native primitive received another Euler conversion')
 return admitted

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--profile',choices=['A','B'],required=True)
 ap.add_argument('--four-loop-admission',type=Path,required=True);ap.add_argument('--four-loop-sha256',required=True)
 ap.add_argument('--independent-review',type=Path,required=True);ap.add_argument('--independent-review-sha256',required=True)
 ap.add_argument('--output',type=Path,required=True);ap.add_argument('--check-only',action='store_true')
 a=ap.parse_args();require(not a.output.exists(),'Immutable output exists')
 review=read(a.independent_review,a.independent_review_sha256)
 require(review['accepted'] is True and review['status']=='passed_frozen_X8_physical_initial_envelope_author', 'Envelope author lacks independent blessing')
 require(review['author_sha256']==sha(__file__),'Independent review addresses a different author')
 four_loop_binding_gates(a.profile,review,a.four_loop_admission,a.four_loop_sha256)
 merge_graphs(review)
 docs={name:read(path,digest) for name,(path,digest) in FIXED.items()}
 pin(HELPER/'check_augmented_gauge.py','8021a11250a9174d4078f5daccc520d9979ca04932591109dee9356d51e7b32f')
 pin(HELPER/'exact_system.py','c43d7f63e316d4bd0a9be7e23eda3486ce29c907d7a0ed768bbc3a8840ab581a')
 require(docs['raw_poles']['accepted'] is True and docs['raw_poles']['status']=='passed_raw42_physical_pole_bound_and_P17_exact_finiteness'
         and docs['raw_poles']['source_identity']['prepared_system_sha256']==SOURCE_HASH,'Physical raw42 lower-pole theorem is unadmitted')
 gauge=docs['raw_to_infinity'];prep=docs['preparation']
 require(gauge['passed'] is True and gauge['source_sha256']==SOURCE_HASH and gauge['entries_checked']==63504
         and gauge['epsilon_orders']==[0,5],'Raw epsilon lift/infinity gauge is not exactly admitted')
 require(prep['accepted_for_scope'] is True and prep['dimension']==252 and prep['normalized_fraction_identities_checked']==63504
         and prep['independent_free_constants']==252 and prep['selected_boundary_exact_inverse_verified'] is True
         and prep['generic_all_orders_log_degree_bound']==8 and prep['modular_observation_used_as_proof'] is False,
         'Frobenius preparation/rank/log proof is incomplete')
 require(prep['artifact_sha256']['normalized_source']['sha256']==gauge['normalized_source_sha256'],
         'Raw lift and Frobenius preparation use different normalized systems')
 four=read(a.four_loop_admission,a.four_loop_sha256)
 for data in [four,*docs.values()]:merge_graphs(data)
 for receipt in docs['source']['receipts']:
  merge_graphs(read(receipt['path'],receipt['sha256']))
 run=HELPER/f'frobenius-transport/x8-production-{a.profile}-scheduled-v1'
 initial_path=run/'conditional-initial.json';initial=read(initial_path,INITIAL_HASH[a.profile])
 boundary=read(initial['source_boundary_path'],initial['source_boundary_sha256'])
 constants=read(initial['source_constants_path'],initial['source_constants_sha256'])
 admitted_origins=origin_gates(a.profile,four,docs['non4L'],boundary)
 source=docs['source'];source_profile=source['profiles'][a.profile]
 require(source['accepted_for_frozen_numeric_source_replay_matching_metadata_and_caps'] is True
         and source['overlap_used_as_replay_acceptance'] is False,'Source expression/matching was not exactly replayed')
 for key in ['all_1587_boundary_ids_exact','all_1587_source_row_strings_reproduced_exactly',
             'all_252_matched_constant_strings_reproduced_exactly','primitive_provenance_recipe_and_original_arguments_replayed']:
  require(source_profile[key] is True,'Missing exact source replay '+key)
 require(source_profile['boundary_sha256']==initial['source_boundary_sha256']
         and source_profile['constants_sha256']==initial['source_constants_sha256'],'Source replay binds another profile')
 required_support={'native::L2_P2':3,'native::L3_P13':2,'native::L3_P14':2,
   'pr11d::massless::8535684c37e21dfd38135b151cca892f3552977fef43ab9d0f2deb22f3762f64::raw_native':4,
   **{'native::'+name:1 for name in ['PR3','PR4','PR4d','PR5','PR7','PR9','PR9d']}}
 require(source_profile['required_raw_primitive_through']==required_support,'Primitive identity/order requirements differ')
 require(constants['boundary_input_sha256']==initial['source_boundary_sha256']
         and constants['exact_matching_sha256']==boundary['matching_sha256']==initial['matching_sha256'],'Matching linkage differs')
 input_review=docs['input'];inp=selected(input_review,a.profile);out=selected(docs['output'],a.profile)
 require(input_review['accepted_for_native_input_provenance'] is True and docs['output']['accepted'] is True,'Input/output source checks incomplete')
 require(inp['native_input_sha256']==initial['native_input_sha256'] and inp['native_metadata_sha256']==initial['native_preparation_sha256']
         and inp['source_boundary_sha256']==initial['source_boundary_sha256'] and inp['source_constants_sha256']==initial['source_constants_sha256'],'Actual native input source binding differs')
 require(len(inp['seed_checks'])==252 and all(all(row[k] is True for k in ['literal_string_unchanged','native_binary_parse_identical','contains_exact_decimal_source_box','imaginary_part_exact_zero']) for row in inp['seed_checks']), 'A native seed is unadmitted')
 require(out['conditional_initial_sha256']==INITIAL_HASH[a.profile] and out['native_output_sha256']==initial['native_output_sha256']
         and out['all252_raw_output_strings_preserved_exactly'] is True and out['returncode']==0 and out['actual_workers']==8,'Output review binds another initial or lacks exact preservation')
 require(initial['source_equation_sha256']==SOURCE_HASH and initial['basis']=='original_raw_epsilon_jets'
         and initial['dimension']==42 and initial['jets']==6 and initial['epsilon_min_power']==-4 and initial['epsilon_max_power']==1
         and initial['eta_center']==['0','256'] and initial['normalization']=='native_raw' and initial['error_quality']=='rigorous-bound','Initial scientific convention differs')
 require(initial['local_tail_certified'] is True and initial['raw_total_width_gate_passed'] is True,'Initial tail/total width unaccepted')
 ctx.dps=21400;values=[acb(arb(re),arb(im)) for re,im in initial['values']]
 require(len(values)==252 and all(x.is_finite() for x in values),'Malformed initial vector')
 target=20060 if a.profile=='A' else 20340
 require(initial['raw_total_digits_target']==target and all(x.real.rad()+x.imag.rad()<arb(10)**(-target) for x in values),'Initial actual total-error gate failed')
 invocation_path=run/'native-invocation.json';inv=read(invocation_path,initial['native_invocation_receipt_sha256'])
 require(inv['schema']=='vakint.pr11d.direct-native-invocation.v1' and type(inv['returncode']) is int and inv['returncode']==0,'Native invocation failed')
 require(type(inv['requested_workers']) is int and type(inv['actual_workers']) is int and inv['requested_workers']==inv['actual_workers']==8,'Native actual worker count differs')
 require(inv['input_source_binary_wrapper_unchanged_after_invocation'] is True,'Invocation source snapshots changed')
 require(inv['command']==[inv[k+'_path'] for k in ['binary','input','output']],'Native command does not name the reviewed executable/input/output')
 bindings={}
 for role,key in [('source_boundary','source_boundary'),('source_constants','source_constants'),('native_input','native_input'),('native_output','native_output'),('native_preparation','native_preparation')]:
  path=pin(initial[key+'_path'],initial[key+'_sha256']);bindings[role]={'path':str(path),'sha256':sha(path)}
 for role,key in [('input','native_input_sha256'),('output','native_output_sha256'),('source','native_source_sha256'),('binary','native_binary_sha256'),('wrapper','validator_sha256')]:
  require(inv[role+'_sha256']==initial[key],'Invocation implementation/data differs: '+role)
  pin(inv[role+'_path'],inv[role+'_sha256'])
 require(docs['kernel']['accepted'] is True and docs['kernel']['candidate_source_sha256']==initial['native_source_sha256']
         and docs['kernel']['candidate_binary_sha256']==initial['native_binary_sha256'],'Unreviewed native mathematical kernel')
 merge_graphs(inv);pin(__file__)
 proof={name:{'path':str(path),'sha256':digest} for name,(path,digest) in FIXED.items()}
 proof['four_loop']={'path':str(a.four_loop_admission.resolve()),'sha256':a.four_loop_sha256}
 proof['envelope_author']={'path':str(a.independent_review.resolve()),'sha256':a.independent_review_sha256}
 for path,digest in PINS.items():require(sha(path)==digest,'Pinned artifact changed during sealing')
 envelope={'schema':'vakint.pr11d.independent-physical-initial-admission.v1','status':'passed_for_frozen_physical_X8_initial',
  'accepted':True,'profile':a.profile,'initial_artifact_path':str(initial_path),'initial_artifact_sha256':INITIAL_HASH[a.profile],
  'initial_physical_provenance_verified':True,'native_input_source_assembly_verified':True,'source_expression_and_matching_verified':True,
  'primitive_sources_physically_admitted':True,'source_equation_sha256':SOURCE_HASH,'basis':'original_raw_epsilon_jets',
  'dimension':42,'jets':6,'epsilon_min_power':-4,'epsilon_max_power':1,'eta_center':['0','256'],'normalization':'native_raw','error_quality':'rigorous-bound',
  **bindings,'native_invocation':{**inv,'receipt_path':str(invocation_path),'receipt_sha256':sha(invocation_path),'direct_invocation_verified':True},
  'native_invocation_receipt_sha256':sha(invocation_path),'initial_physical_proof_pins':proof,'admitted_primitive_data':admitted_origins,
  'independent_author_review_path':str(a.independent_review.resolve()),'independent_author_review_sha256':a.independent_review_sha256,
  'author_sha256':sha(__file__),'source_pins':PINS,'artifact_sha256':PINS,'actual_raw_total_radius_gate_digits':target,
  'conditional_generation_scope_closed_by_this_separate_admission':True,'new_native_or_HPL_computations':0,
  'overlap_used_as_physical_admission':False,'whole_PR11d_20000_accuracy_claimed':False,
  'scope':'Physical ordinary-point initial enclosure only. Final transport, endpoint projection, precision certification and public-data promotion remain separate.',
  'IBP_trust_scope':four.get('IBP_trust_scope',four.get('raw_IBP_source_trust_scope','Authenticated source IBP/differential systems; no new IBP regeneration by this aggregate.'))}
 if a.check_only:
  print(json.dumps({'check_only':True,'all_gates_passed':True,'profile':a.profile,'pins':len(PINS),'admitted_envelope_written':False}));return envelope
 with a.output.open('x') as stream:json.dump(envelope,stream,indent=2);stream.write('\n')
 print(a.output);print(sha(a.output))
if __name__=='__main__':main()
