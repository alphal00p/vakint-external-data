#!/usr/bin/env python3
"""Analytic adjoint V=epsilon*W with rigorous Taylor residual enclosure."""
from pathlib import Path
import argparse,hashlib,json,sys,time
from fractions import Fraction
from flint import arb,acb,ctx,fmpq,fmpq_mat,fmpq_poly
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'helper'))
from exact_system import CTX,Rat,parse,SOURCE

def qsplit(text):return fmpq(text)
def sparse(matrix):return [[(j,q) for j,q in enumerate(row) if q] for row in matrix]
def dot(row,vector):return sum((vector[j]*q for j,q in row),arb(0))
def eps_coeff(text,count=6):
    rat=parse(text,'e','x')*Rat(CTX.gen(0))
    assert all(x==0 for e,x in rat.num.to_dict()) and all(x==0 for e,x in rat.den.to_dict())
    ns=[rat.num.to_dict().get((j,0),fmpq(0)) for j in range(count)]
    ds=[rat.den.to_dict().get((j,0),fmpq(0)) for j in range(count)];assert ds[0]
    out=[]
    for n in range(count):out.append((ns[n]-sum((ds[k]*out[n-k] for k in range(1,n+1)),fmpq(0)))/ds[0])
    return out
class System:
    def __init__(self):
        path=HERE.parent/'jet-transport/polynomial-connection.json';self.source_hash=hashlib.sha256(path.read_bytes()).hexdigest();data=json.loads(path.read_text())
        assert data['dimension']==42 and data['epsilon_jet_count']==6 and data['source_sha256']==hashlib.sha256(SOURCE.read_bytes()).hexdigest()
        self.dimension=252;self.D=[fmpq(q) for q in data['denominator_coefficients']];self.ndeg=data['numerator_degree'];self.deg=len(self.D)-1
        self.N=[[[fmpq(0) for j in range(252)] for i in range(252)] for k in range(self.ndeg+1)]
        for entry in data['entries']:
            for k in range(entry['epsilon_power'],6):
                dst=42*k+entry['column'];src=42*(k-entry['epsilon_power'])+entry['row']
                for term in entry['terms']:self.N[term['eta_power']][dst][src]-=fmpq(int(term['numerator']),int(term['denominator']))
        self.sp=[sparse(A) for A in self.N]
        blocks=json.loads(SOURCE.read_text())['differential_blocks']
        self.blocks=[tuple(42*k+i for i in block) for k in range(6) for block in reversed(blocks)]
        self.blockof={i:b for b,block in enumerate(self.blocks) for i in block};assert len(self.blockof)==252
        assert all(self.blockof[j]<=self.blockof[i] for matrix in self.sp for i,row in enumerate(matrix) for j,q in row)
        proof_path=HERE.parent/'helper/endpoint-adjoint-proof.json';proof=json.loads(proof_path.read_text());self.projector_hash=hashlib.sha256(proof_path.read_bytes()).hexdigest()
        assert proof['source_sha256']==data['source_sha256']
        first=[eps_coeff(text) for text in proof['row_coefficients'][0]]
        self.initial=tuple(first[i][k] for k in range(6) for i in range(42))
        assert all(sum((q*self.initial[j] for j,q in row),fmpq(0))==0 for row in self.sp[0])
        self.reference_prefix=[[eps_coeff(text) for text in row] for row in proof['row_coefficients']]
    def coefficients(self,order):
        output=[tuple(arb(q) for q in self.initial)]
        for n in range(1,order+1):
            rhs=[arb(0) for _ in range(252)]
            for power in range(1,min(self.ndeg,n)+1):
                previous=output[n-power]
                for i,row in enumerate(self.sp[power]):rhs[i]+=dot(row,previous)
            for power in range(2,min(self.deg,n+1)+1):
                previous=output[n-power+1];weight=(n-power+1)*self.D[power]
                if weight:
                    for i in range(252):rhs[i]-=previous[i]*weight
            current=[arb(0) for _ in range(252)]
            for b,block in enumerate(self.blocks):
                A=fmpq_mat([[int(i==j)*n*self.D[1]-self.N[0][i][j] for j in block] for i in block]);inverse=A.inv()
                local=[]
                for i in block:local.append(rhs[i]+sum((current[j]*q for j,q in self.sp[0][i] if self.blockof[j]<b),arb(0)))
                for p,i in enumerate(block):current[i]=sum((local[q]*inverse[p,q] for q in range(len(block))),arb(0))
            output.append(tuple(current))
            if n<len(self.reference_prefix):
                for k in range(6):
                    for i in range(42):
                        expected=self.reference_prefix[n][i][k]
                        if not current[42*k+i].lower().fmpq()<=expected<=current[42*k+i].upper().fmpq():
                            raise AssertionError((n,i,k,current[42*k+i].str(50,more=True),str(expected),(current[42*k+i]-arb(expected)).str(40,more=True)))
        return output
    def bound_matrix(self,r):
        Dbar=fmpq_poly(self.D[1:]);unit,factors=Dbar.factor();lower=abs(unit)
        for poly,multiplicity in factors:
            assert poly.degree()==1
            root=-poly[0]/poly[1];assert abs(root)>r
            lower*=abs(poly[1])**multiplicity*(abs(root)-r)**multiplicity
        assert lower>0
        R=[[q/self.D[1] for q in row] for row in self.N[0]]
        M=[[abs(q) for q in row] for row in R]
        for i in range(252):
            for j in range(252):
                if not any(A[i][j] for A in self.N):continue
                h=[self.N[k][i][j]-(R[i][j]*Dbar[k] if k<=Dbar.degree() else 0) for k in range(self.ndeg+1)]
                assert h[0]==0
                bound=sum((abs(h[k])*r**(k-1) for k in range(1,len(h))),fmpq(0))/lower
                M[i][j]+=r*bound
        return M,lower
    def evaluate(self,order,r):
        if not 0<r<1 or order<7:raise ValueError('Endpoint adjoint requires0<radius<1 and order>=7')
        start=time.monotonic();values=self.coefficients(order);M,lower=self.bound_matrix(r)
        # Defect coefficients above the mathematically exact prefix equations.
        forcing=[arb(0) for _ in range(252)]
        for n in range(order+1,order+max(self.ndeg,self.deg-1)+1):
            defect=[arb(0) for _ in range(252)]
            for power in range(1,self.deg+1):
                index=n-power+1
                if 1<=index<=order:
                    weight=index*self.D[power]
                    for i in range(252):defect[i]+=values[index][i]*weight
            for power in range(self.ndeg+1):
                index=n-power
                if 0<=index<=order:
                    for i,row in enumerate(self.sp[power]):defect[i]-=dot(row,values[index])
            for i in range(252):forcing[i]+=abs(defect[i]).upper()*r**(n-order-1)/lower
        budgets=[arb(0) for _ in range(252)]
        for b,block in enumerate(self.blocks):
            A=fmpq_mat([[int(i==j)*(order+1)-M[i][j] for j in block] for i in block]);inverse=A.inv()
            assert all(q>=0 for row in inverse.tolist() for q in row),'Tail block does not have a nonnegative inverse; increase order'
            local=[forcing[i]+sum((budgets[j]*M[i][j] for j in range(252) if self.blockof[j]<b and M[i][j]),arb(0)) for i in block]
            for p,i in enumerate(block):budgets[i]=sum((local[q]*inverse[p,q] for q in range(len(block))),arb(0))
        result=[];tail=[]
        for i in range(252):
            real=arb(0);imag=arb(0)
            for n,row in enumerate(values):
                term=row[i]*r**n
                if n%4==0:real+=term
                elif n%4==1:imag+=term
                elif n%4==2:real-=term
                else:imag-=term
            radius=(budgets[i]*r**(order+1)).upper();tail.append(radius)
            result.append(acb(real+arb(0,radius),imag+arb(0,radius)))
        report={'schema':'vakint.pr11d.analytic-endpoint-adjoint.v1','definition':'V=epsilon*W, Vprime=-V*A; finite target coefficient=[epsilon^1](V dot rawY)','eta_center':['0',str(r)],'epsilon_range':[0,5],'order':order,'working_bits':ctx.prec,'source_polynomial_sha256':self.source_hash,'endpoint_projector_proof_sha256':self.projector_hash,'all_polynomial_coefficients_respect_block_order':True,'exact_initial_residue_kernel_verified':True,'prefix_coefficients_exact_reference_checks':min(order+1,len(self.reference_prefix))*252,'residual_tail_method':'block positive resolvent of (order+1)I-|R|-rH, including all polynomial defect coefficients beyond the exact prefix','seconds':time.monotonic()-start,'maximum_tail_radius':max(tail).str(30,more=True),'whole_PR11d_accuracy_claimed':False}
        return tuple(result),report

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--digits',type=int,default=260);parser.add_argument('--order',type=int,default=250);parser.add_argument('--radius-denominator',type=int,default=16);parser.add_argument('--output',type=Path,default=HERE/'adjoint-260.json');args=parser.parse_args()
    ctx.dps=args.digits;r=fmpq(1,args.radius_denominator);values,report=System().evaluate(args.order,r)
    output={**report,'complex_balls':[[v.real.str(args.digits+8,more=True),v.imag.str(args.digits+8,more=True)] for v in values]}
    args.output.write_text(json.dumps(output,indent=2)+'\n');print('ADJOINT PASS',report['seconds'],'seconds; max tail',report['maximum_tail_radius'])
if __name__=='__main__':main()
