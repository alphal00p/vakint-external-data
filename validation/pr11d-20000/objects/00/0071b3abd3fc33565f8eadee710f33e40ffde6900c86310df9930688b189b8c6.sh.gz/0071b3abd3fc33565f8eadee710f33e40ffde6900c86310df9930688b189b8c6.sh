#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
export TMPDIR="$PWD/tmp-v2-scheduled"
mkdir -p "$TMPDIR"
# Set OPENBLAS_NUM_THREADS=1 when running; OpenMP workers are capped at sixteen.
/nix/store/j1938gsbvbhkyz4kbmvjk56r479mkw3s-gcc-wrapper-16.2.0/bin/cc -O3 -fopenmp -std=c11 -Wall -Wextra -Werror \
  -I/nix/store/cih4nsn8mqam0q8s3pn6866mdfbkhvwp-flint-3.6.0/include \
  -I/nix/store/lppdjhzf5vp1gvz4c7r5y7fcxkr69dyr-mpfr-4.2.2-dev/include \
  -I/nix/store/1sj0rbpn9nzz1mp754r15yxbnvzbdhfb-gmp-with-cxx-6.3.0-dev/include \
  contracted_v2_scheduled.c -L/nix/store/cih4nsn8mqam0q8s3pn6866mdfbkhvwp-flint-3.6.0/lib \
  -Wl,-rpath,/nix/store/cih4nsn8mqam0q8s3pn6866mdfbkhvwp-flint-3.6.0/lib -lflint -o contracted-native-v2-scheduled-new
mv contracted-native-v2-scheduled-new contracted-native-v2-scheduled
