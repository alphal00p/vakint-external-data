#!/usr/bin/env python3
"""Build guarded native3L inputs from accepted public API/HPL Float records.

This optional development bridge imports exact binary midpoint/error rationals
and performs the sole FMFT-to-native Euler convolution with Arb ball arithmetic.
It computes no new HPL values, downloads nothing and never upgrades source digits.
"""
import argparse,hashlib,json,sys,time
from fractions import Fraction
from pathlib import Path
from flint import arb,ctx,fmpq
from endpoint_sources import sha
sys.set_int_max_str_digits(300000)
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'pr11-boundary'))
from prototype_boundary import native_from_fmft

FAMILY='56d4ac620f0309e551e825ce435d23ee4b58e887f2ee639e1bf14006bc9e9f93'
POWERS={'P13':[0,1,1,1,1,0],'P14':[0,1,1,1,1,1]}

def rational(value):
    q=value['exact_binary_value'];n,d=int(q['numerator']),int(q['denominator'])
    if d<=0:raise ValueError('Float rational denominators must be positive')
    return Fraction(n,d)

def aa(q):return arb(fmpq(q.numerator,q.denominator))

def load_api(path,digest,name,minimum_digits):
    path=Path(path)
    if sha(path)!=digest:raise ValueError('Accepted API source checksum mismatch: '+name)
    data=json.loads(path.read_bytes());expected_id='L3_'+FAMILY+''.join('_p'+str(n) for n in POWERS[name])
    if data['loop_count']!=3 or data['family_sha256']!=FAMILY or data['powers']!=POWERS[name] or data['master_id']!=expected_id:
        raise ValueError('API source does not match the canonical literal native family/powers: '+name)
    if data['normalization']!='FMFTandMATAD' or data.get('mass_squared') not in ('1',1):
        raise ValueError('API source convention must be canonical unit-mass FMFTandMATAD')
    values={};checks=[]
    for row in data['coefficients']:
        p=row['epsilon_power']
        if type(p) is not int or p in values:raise ValueError('Duplicate or invalid API epsilon order')
        real,imag=row['precision']['real'],row['precision']['imaginary']
        if real['quality']!='Bounded' or imag['quality']!='Bounded':raise ValueError('Only rigorously bounded API records are accepted')
        if row['available_precision']!='ArbitraryPrecision':raise ValueError('An exact arbitrary-precision formula is required for this independent source pathway')
        center,error=rational(row['numerical_value']),rational(real['absolute_error'])
        if error<0 or rational(imag['absolute_error']) or not imag['exact_zero']:
            raise ValueError('Real native master source requires an exact-zero imaginary component and nonnegative error')
        if center:
            if error*10**minimum_digits>abs(center)-error:raise ValueError('Exact API rational enclosure lacks required relative source precision')
        elif error:raise ValueError('An uncertain zero requires a separate absolute-accuracy source contract')
        values[p]=aa(center)+arb(0,aa(error).upper())
        checks.append({'epsilon_power':p,'exact_rational_precision_at_least':minimum_digits,'source_achieved_digits':real['significant_digits'],
          'source_error_quality':real['quality'],'formula_sha256':row['formula_sha256']})
    if sorted(values)!=list(range(min(values),max(values)+1)) or min(values)!=-3 or max(values)<2:
        raise ValueError('All required contiguous canonical3L orders must be explicit')
    native=native_from_fmft(values,3)
    return {p:native[p] for p in range(-3,3)}, {'path':str(path.resolve()),'sha256':digest,'master_id':expected_id,'family_sha256':FAMILY,
      'powers':POWERS[name],'loop_count':3,'API_provenance':data['provenance'],'native_source_hashes':data['source_hashes'],'checked_API_orders':checks}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--p13',required=True);ap.add_argument('--p13-sha256',required=True)
    ap.add_argument('--p14',required=True);ap.add_argument('--p14-sha256',required=True)
    ap.add_argument('--working-digits',type=int,default=20400);ap.add_argument('--minimum-source-digits',type=int,default=20250)
    ap.add_argument('--output',required=True);args=ap.parse_args()
    if not __debug__:raise RuntimeError('Scientific source validation requires assertions enabled')
    output=Path(args.output)
    if output.exists():raise ValueError('Preserve earlier source artifacts; choose a new output path')
    if args.working_digits<args.minimum_source_digits+40 or args.minimum_source_digits<1:raise ValueError('A fixed source-conversion guard is required')
    ctx.dps=args.working_digits;ctx.threads=1;start=time.monotonic();coefficients={};bindings={}
    for name,path,digest in [('P13',args.p13,args.p13_sha256),('P14',args.p14,args.p14_sha256)]:
        values,binding=load_api(path,digest,name,args.minimum_source_digits)
        coefficients['native::L3_'+name]=[{'epsilon_power':p,'ball':v.str(args.working_digits+12,more=True),'relative_accuracy_bits':int(v.rel_accuracy_bits()) if not v.contains(0) else None} for p,v in values.items()]
        bindings['native::L3_'+name]=binding
    receipt={'schema':'vakint.native-three-loop-endpoints-from-public-API.v1','normalization':'native_raw','error_quality':'rigorous-bound',
      'coefficients':coefficients,'canonical_alias_bindings':bindings,'source_kind':'independent arbitrary-precision public API/HPL formulas',
      'native_conversion':'exp(-3*EulerGamma*epsilon) exactly once; exact input binary rationals and outward Arb convolution',
      'minimum_API_source_digits_checked':args.minimum_source_digits,'working_decimal_digits':args.working_digits,
      'whole_PR11d_accuracy_claimed':False,'producer_sha256':sha(Path(__file__)),'seconds':time.monotonic()-start}
    output.write_text(json.dumps(receipt,indent=2)+'\n');print('PASS:12bounded native3L coefficient balls from accepted API/HPL sources')
if __name__=='__main__':main()
