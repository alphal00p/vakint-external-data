"""Admit a physical X8 initial enclosure through an explicitly blessed review.

This module does not reassemble a boundary, rerun matching, or execute a native
kernel. The original c104 initial reuses the complete accepted PFv7 admission.
A new physical initial needs its own independently reviewed source and actual
native-invocation receipt. Labels and overlapping enclosures are insufficient.
"""
from pathlib import Path
from flint import arb, acb

OLD_INITIAL_SHA = 'c104cf8e58a3b10883cc239cd3dbb1f202078c8fcaa4c3bbe9cc132eab0e45f1'
OLD_ADMISSION_SHA = 'd293f144955496e286a2e979fda596c589597e6d344217e970dea37269eb5325'
OLD_REVIEW_SHA = '6b6b008c64c8196e2c4aeae4d3d2f348f4a07a5abd14ea75aa2f0413ecce017d'


def graph(c, data, key, target):
    pins = data[key]
    c.require(type(pins) is dict and pins, 'Missing admission graph ' + key)
    for path, digest in pins.items():
        c.require(Path(path).is_absolute(), 'Admission pins must use absolute paths')
        c.pin(path, digest, target)


def verify(c, root, initial_path, admission_path, admission_sha, sources, artifacts):
    initial_path = initial_path.resolve()
    c.pin(admission_path, admission_sha, sources)
    admitted = c.load(admission_path)
    initial_sha = c.sha(initial_path)
    old = admission_sha == OLD_ADMISSION_SHA
    if old:
        c.require(initial_sha == OLD_INITIAL_SHA, 'Old source admission addresses another initial')
        c.require(admitted['schema'] == 'vakint.pr11d.physical-X8-chain-acceptance.v1'
                  and admitted['status'] == 'passed_for_frozen_completed_physical_chain',
                  'Original physical source admission is not accepted')
        c.require(admitted['initial_physical_boundary_sha256'] == initial_sha
                  and admitted['independent_validator_review_sha256'] == OLD_REVIEW_SHA,
                  'Original initial or validator review differs')
        review_path = c.pin(admitted['independent_validator_review_path'], OLD_REVIEW_SHA, sources)
        review = c.load(review_path)
        c.require(review['validator_sha256'] == admitted['validator_sha256']
                  and review['status'] == 'passed_for_frozen_physical_X8_chain_validator',
                  'Original initial-source validator was not reviewed')
        for data in (admitted, review):
            graph(c, data, 'source_pins', sources)
        graph(c, admitted, 'artifact_sha256', artifacts)
        c.require(admitted['initial_physical_provenance_verified'] is True,
                  'Original initial physical provenance is incomplete')
    else:
        c.require(admitted['schema'] == 'vakint.pr11d.independent-physical-initial-admission.v1'
                  and admitted['status'] == 'passed_for_frozen_physical_X8_initial'
                  and admitted['accepted'] is True,
                  'Alternate initial requires an independently accepted source admission')
        c.require(admitted['initial_artifact_sha256'] == initial_sha
                  and Path(admitted['initial_artifact_path']).resolve() == initial_path,
                  'Alternate source admission addresses another initial')
        c.require(admitted['initial_physical_provenance_verified'] is True
                  and admitted['native_input_source_assembly_verified'] is True
                  and admitted['source_expression_and_matching_verified'] is True
                  and admitted['primitive_sources_physically_admitted'] is True,
                  'Alternate initial admission leaves a physical source edge open')
        graph(c, admitted, 'source_pins', sources)
        graph(c, admitted, 'artifact_sha256', artifacts)
        c.require(artifacts.get(str(initial_path)) == initial_sha,
                  'Alternate initial is absent from the admitted artifact graph')

    c.pin(initial_path, initial_sha, artifacts)
    initial = c.load(initial_path)
    for key, wanted in [('basis', 'original_raw_epsilon_jets'), ('dimension', 42),
                        ('epsilon_min_power', -4), ('epsilon_max_power', 1),
                        ('normalization', 'native_raw'), ('error_quality', 'rigorous-bound'),
                        ('eta_center', ['0', '256'])]:
        c.require(type(initial[key]) is type(wanted) and initial[key] == wanted,
                  'Initial convention differs: ' + key)
    c.require(initial.get('jets', 6) == 6 and type(initial.get('jets', 6)) is int,
              'Initial jet count differs')
    c.require(initial.get('local_tail_certified') is True
              or initial.get('local_truncation_rigorously_enclosed') is True,
              'Initial local tail is not certified')
    c.require(initial.get('physical_accuracy_certified', True) is not False,
              'Initial explicitly disclaims physical accuracy')
    c.require(initial['source_equation_sha256'] == admitted['source_equation_sha256'],
              'Initial source equation differs from its admission')
    values = initial['values']
    c.require(type(values) is list and len(values) == 252, 'Incomplete initial vector')
    for pair in values:
        c.require(type(pair) is list and len(pair) == 2
                  and all(type(x) is str for x in pair), 'Malformed initial ball')
        c.require(acb(arb(pair[0]), arb(pair[1])).is_finite(), 'Nonfinite initial ball')

    proof = admitted['initial_physical_proof_pins']
    if not old:
        for field, initial_key in [('source_boundary', 'source_boundary'),
                                   ('source_constants', 'source_constants'),
                                   ('native_input', 'native_input'),
                                   ('native_output', 'native_output'),
                                   ('native_preparation', 'native_preparation')]:
            item = admitted[field]
            c.require(type(item) is dict, 'Missing initial artifact binding ' + field)
            path = c.pin(item['path'], item['sha256'], artifacts)
            c.require(initial[initial_key + '_sha256'] == item['sha256'],
                      'Initial artifact binding differs: ' + field)
            if initial_key + '_path' in initial:
                c.require(Path(initial[initial_key + '_path']).resolve() == path,
                          'Initial artifact path differs: ' + field)
        invocation = admitted['native_invocation']
        c.require(type(invocation) is dict, 'Missing native invocation admission')
        invocation_path = c.pin(invocation['receipt_path'], invocation['receipt_sha256'], sources)
        invocation_receipt = c.load(invocation_path)
        c.require(invocation['direct_invocation_verified'] is True,
                  'Actual native invocation was not independently admitted')
        for role in ['input', 'output']:
            c.require(invocation[role + '_sha256'] == admitted['native_' + role]['sha256'],
                      'Native invocation addresses different ' + role)
            path = c.pin(invocation[role + '_path'], invocation[role + '_sha256'], artifacts)
            c.require(path == Path(admitted['native_' + role]['path']).resolve(),
                      'Native invocation path differs: ' + role)
        for role in ['source', 'binary', 'wrapper']:
            path = c.pin(invocation[role + '_path'], invocation[role + '_sha256'], sources)
            key = {'source': 'native_source_sha256', 'binary': 'native_binary_sha256',
                   'wrapper': 'validator_sha256'}[role]
            c.require(initial[key] == invocation[role + '_sha256'],
                      'Native invocation implementation differs: ' + role)
        requested, actual = invocation['requested_workers'], invocation['actual_workers']
        c.require(type(requested) is int and requested in (1, 2, 4, 8)
                  and type(actual) is int and actual == requested,
                  'Native initial requested/actual workers differ')
        c.require(admitted['native_invocation_receipt_sha256'] == c.sha(invocation_path),
                  'Native invocation receipt binding differs')
        c.require(invocation_receipt['schema'] == 'vakint.pr11d.direct-native-invocation.v1'
                  and type(invocation_receipt['returncode']) is int
                  and invocation_receipt['returncode'] == 0,
                  'Native invocation did not complete successfully')
        for key in ['input_sha256', 'output_sha256', 'source_sha256', 'binary_sha256',
                    'requested_workers', 'actual_workers']:
            c.require(type(invocation_receipt[key]) is type(invocation[key])
                      and invocation_receipt[key] == invocation[key],
                      'Native invocation receipt differs: ' + key)
        command = invocation_receipt['command']
        c.require(type(command) is list and len(command) == 3
                  and all(type(argument) is str for argument in command)
                  and [Path(argument).resolve() for argument in command]
                  == [Path(invocation[role + '_path']).resolve() for role in ['binary', 'input', 'output']],
                  'Native invocation command differs from the reviewed binary/input/output')
        c.require(type(proof) is dict and proof, 'Missing physical initial proof bindings')

    return initial, {'admission_path': str(Path(admission_path).resolve()),
                     'admission_sha256': admission_sha,
                     'initial_physical_boundary_sha256': initial_sha,
                     'initial_physical_proof_pins': proof,
                     'physical_provenance_verified': True,
                     'reused_original_PFv7_source_admission': old,
                     'native_or_source_reassembly_rerun': False}
