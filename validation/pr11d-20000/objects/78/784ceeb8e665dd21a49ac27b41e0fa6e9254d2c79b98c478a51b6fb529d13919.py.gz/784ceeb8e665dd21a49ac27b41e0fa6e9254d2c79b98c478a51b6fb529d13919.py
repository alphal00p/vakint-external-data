#!/usr/bin/env python3
"""Seal the bounded PR9 INIT review; no producer or transport execution."""
import hashlib
import json
import re
from fractions import Fraction as Q
from pathlib import Path
from flint import fmpq, fmpq_poly

if not __debug__:
    raise RuntimeError("Assertions required")
HERE = Path(__file__).resolve().parent
PR11 = HERE.parents[1]
PERIODS = PR11.parent
NATIVE = PR11 / "helper/frobenius-transport/native"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def main():
    pins = {}

    def pin(path, digest):
        path = str(Path(path).resolve())
        assert sha(path) == digest, path
        assert path not in pins or pins[path] == digest
        pins[path] = digest

    names = ["native-input-receipt.json", "source-box-review.json", "output-review/output-contract-review.json", "output-review/review.json", "invocation-review.json", "output-review/source-audit-adaptation-review.json"]
    reports = [read(HERE / name) for name in names]
    for name, report in zip(names, reports, strict=True):
        pin(HERE / name, sha(HERE / name))
        for field in ["source_sha256", "nested_source_sha256"]:
            for path, digest in report.get(field, {}).items():
                pin(path, digest)
        for key, value in report.get("artifact_sha256", {}).items():
            if isinstance(value, str):
                pin(key, value)
            else:
                pin(value["path"], value["sha256"])
    prefix, source, output, output_aggregate, invocation, adaptation = reports
    assert adaptation["accepted_for_bounded_source_audit_code_review"]
    assert output_aggregate["accepted_for_saved_INIT_output_and_wrapper_scope"]
    assert invocation["accepted"] and invocation["returncode"] == 0
    assert invocation["observed_max_process_task_count"] == 4
    assert invocation["all_original_inputs_sources_and_outputs_unchanged"]
    for row in output_aggregate["receipts"]:
        pin(row["path"], row["sha256"])
    for row in invocation["pre_artifact_sha256"].values():
        pin(row["path"], row["sha256"])
    for path, digest in invocation["new_artifacts"].items():
        pin(path, digest)
    pin(invocation["start_receipt"]["path"], invocation["start_receipt"]["sha256"])
    for path, digest in invocation["mapped_file_sha256"].items():
        pin(path, digest)
    assert invocation["comparison"]["all_numerical_and_semantic_fields_exactly_equal"]
    assert invocation["comparison"]["all_certificate_log_fields_exact_except_elapsed_seconds"]
    assert invocation["comparison"]["all_528_scalar_outward_strings_identical"]
    telemetry = r'("(?:seconds|setup_seconds|initialization_seconds|certificate_seconds|peak_rss_bytes)":)[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?'
    retained_bytes = []
    for path in [NATIVE / "pr9-API20600-init-v1-output.json", HERE / "replay-output.json"]:
        normalized, count = re.subn(telemetry, r'\1<telemetry>', path.read_text())
        assert count == 5
        retained_bytes.append(normalized)
    assert retained_bytes[0] == retained_bytes[1]
    assert prefix["accepted"] and source["accepted"]
    assert output["accepted_for_serialized_INIT_output_contract"]
    assert source["source_boundary_outward_strings_reproduced_exactly"] == 557
    assert source["source_matched_constant_outward_strings_reproduced_exactly"] == 132
    assert source["all132_exact_matched_decimal_source_boxes_contained_by_native_seeds"]
    assert source["all132_actual_native_seed_strings_reproduced_exactly"]
    assert source["all132_seed_binary_midpoints_and_radii_identical"]
    assert not source["overlap_used_as_acceptance"]
    assert output["all_complex_total_radii_strictly_below_1e_minus20500"]
    assert output["wrapper_original_Y_full_decimal_box_equality_count"] == 132
    assert output["native_source_binary_and_build_match_accepted_v2_review"]
    assert output["working_bits"] == 69429 and output["order"] == 17000
    assert output["normalization"] == "native_raw"

    polynomial_path = PR11 / "ancestor-flows/pr9-22-polynomial.json"
    polynomial = read(polynomial_path)
    lines = (NATIVE / "pr9-API20600-init-v1.in").read_text().splitlines()
    header = lines[0].split()
    assert int(header[7]) == polynomial["denominator_degree"] - 1 == 8
    assert int(header[8]) == polynomial["numerator_degree"] == 10
    assert max(term["z_power"] for e in polynomial["entries"] for term in e["terms"]) == 10
    assert lines[1] == "0 -1 256"
    scale = Q(lines[2])
    assert scale > 0 and Q(lines[3]) == scale
    coefficients = [fmpq(x) for x in polynomial["denominator_coefficients"]]
    assert coefficients[0] == 0 and coefficients[1] != 0
    reduced_denominator = fmpq_poly(coefficients[1:])
    unit, factors = reduced_denominator.factor()
    product = fmpq_poly([unit])
    real_factor_checks = []
    for factor, power in factors:
        assert power > 0 and factor[0] != 0
        degree = factor.degree()
        assert degree in [1, 2]
        discriminant = factor[1] ** 2 - 4 * factor[2] * factor[0] if degree == 2 else None
        assert degree == 1 or discriminant >= 0
        product *= factor ** power
        real_factor_checks.append({
            "ascending_coefficients": [str(x) for x in factor.coeffs()],
            "multiplicity": power,
            "nonzero_constant": True,
            "real_roots_exactly_verified": True,
            "quadratic_discriminant": None if discriminant is None else str(discriminant),
        })
    assert product == reduced_denominator
    pin(Path(__file__), sha(__file__))
    receipt = {
        "schema": "vakint.pr9.production-B.INIT-independent-admission-review.v1",
        "accepted": True,
        "accepted_source_seed_and_initial_output": True,
        "accepted_for_physical_source_and_freshly_replayed_INIT_contract": True,
        "scope": "API20600 PR9 source assembly, exact native preparation and saved eta=256i INIT output only",
        "wrapper_sha256": output["wrapper_sha256"],
        "source_boundary_sha256": prefix["source_boundary_sha256"],
        "native_input_sha256": prefix["input_sha256"],
        "fresh_invocation_receipt_sha256": sha(HERE / "invocation-review.json"),
        "fresh_invocation_review_path": str(HERE / "invocation-review.json"),
        "fresh_invocation_review_sha256": sha(HERE / "invocation-review.json"),
        "fresh_replay_output_sha256": sha(HERE / "replay-output.json"),
        "native_output_sha256": sha(NATIVE / "pr9-API20600-init-v1-output.json"),
        "dimension": 132,
        "boundary_row_count": 557,
        "native_working_bits": 69429,
        "native_local_tail_target_digits": 20600,
        "saved_native_accepted_order": 17000,
        "absolute_INIT_radius_target_digits": 20500,
        "source_error_quality": "rigorous-bound",
        "source_working_decimal_digits": 20800,
        "source_outward_row_strings_replayed_exactly": 557,
        "source_outward_matched_constant_strings_replayed_exactly": 132,
        "required_primitive_orders": source["required_primitive_orders"],
        "normalization": "native_raw; accepted API bridge applies exp(-3*EulerGamma*epsilon) once; no downstream Euler conversion",
        "complete_exact_rational_source_boxes_contained_by_actual_native_seeds": 132,
        "native_seed_strings_and_binary_midpoint_radius_replayed_exactly": 132,
        "exact_prefix_counts": {
            "polynomial_entries": 1297, "residue_entries": 809,
            "startup_entries": 38363, "gauge_rows": 132,
            "SCC_blocks": 84, "maximum_block_size": 4,
            "log_slots": 9, "startup_orders": [-4, -1],
        },
        "denominator_lower_bound_independent_proof": {
            "exact_factorization_verified": True,
            "factor_checks": real_factor_checks,
            "proof": "After removing the simple zero at z=0, all denominator roots are real and nonzero. For z=-it/256, 0<=t<=1, each factor |1-z/r|>=1. Therefore the scaled normalized denominator has modulus >= the positive integer scale stored as the input denominator bound.",
            "actual_pure_imaginary_z0_verified": True,
            "actual_stored_lower_bound_equals_positive_scale": True,
        },
        "saved_J_and_Y_complex_boxes_below_absolute_radius_target": 264,
        "maximum_saved_decimal_radius_sums": output["maximum_total_radius_exact"],
        "wrapper_preserves_full_native_Y_decimal_boxes_exactly": 132,
        "overlap_is_not_admission_proof": True,
        "mathematical_certification_basis": "Frozen accepted contracted Frobenius v2 proof/implementation plus exact PR9 preparation and saved local_tail_certified output; source, binary, build and all numerical artifacts are hash-bound below.",
        "fresh_invocation_provenance": "The exact saved input was freshly run through the frozen reviewed binary with four observed process tasks and controlled four-worker configuration. Command, executable digest, pre/post artifact hashes, loaded library hashes, returncode0 and logs are recorded. All numerical/semantic output fields and certificate history match the original exactly after excluding runtime and RSS telemetry. This fresh witnessed computation supplies execution evidence without relying on an attestation of the original historical invocation.",
        "hidden_binary_output_balls_recovered": False,
        "all_528_fresh_native_outward_scalar_strings_equal_original": True,
        "whole_output_bytes_identical_after_replacing_only_five_telemetry_fields": True,
        "all_certificate_log_fields_equal_except_elapsed_seconds": True,
        "scope_limits": [
            "The admitted result is the 132-component physical raw-epsilon-jet ordinary point at eta=256i with an absolute radius-sum bound below 1e-20500; no relative precision claim is attached to uncertain zeros.",
            "The accepted physical source and exact preparation chain retain the frozen IBP/reduction trust boundary; this is not an independent derivation of the physical differential equation.",
            "No separately rounded J-to-Y full-box image containment or recovery of hidden binary output balls is claimed. The reviewed native engine applies the gauge to its certified binary balls before outward decimal serialization.",
            "Subsequent ordinary transport, adjoints, endpoint projections, and whole-master precision are outside this INIT review."
        ],
        "source_row_assembly_replayed": True,
        "native_engine_freshly_replayed_same_saved_input": True,
        "preparer_or_HPL_program_rerun": False,
        "subsequent_RPF_steps_or_adjoints_reviewed": False,
        "producer_or_handoff_files_modified": False,
        "whole_master_or_20k_accuracy_claimed": False,
        "component_receipts": [{"path": str(HERE / name), "sha256": sha(HERE / name)} for name in names],
        "artifact_sha256": pins,
    }
    destination = HERE / "init-review.json"
    destination.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"path": str(destination), "sha256": sha(destination), "accepted": True,
                      "artifacts_bound": len(pins)}, indent=2))


if __name__ == "__main__":
    main()
