#!/usr/bin/env python3
"""Versioned higher-guard X8 source consumer with explicit finite ingredients."""
import argparse,importlib.util,json,sys,time
from pathlib import Path
from flint import arb,ctx
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from endpoint_sources import load_native_endpoints,sha
from x8_guarded_boundary import P853,PR11
from source_recipes import build_factor_expressions,read
from logjet_map import BoundaryLogJetMap,FactorJet
from expanded_boundary import ExpandedBoundary

def main():
    ap=argparse.ArgumentParser()
    for prefix in ['three-loop','four-loop','sunset','p853']:
        ap.add_argument('--'+prefix+'-input',required=True);ap.add_argument('--'+prefix+'-sha256',required=True)
    ap.add_argument('--p853-validation',required=True);ap.add_argument('--working-digits',type=int,default=21000)
    ap.add_argument('--minimum-constant-error-power',type=int);ap.add_argument('--output-prefix',required=True);a=ap.parse_args()
    if not __debug__:raise RuntimeError('Scientific source validation requires assertions enabled')
    prefix=Path(a.output_prefix);targets=[prefix.with_suffix('.boundary.json'),prefix.with_suffix('.constants.json')]
    if any(p.exists() for p in targets):raise ValueError('Preserve all previous source versions')
    ctx.dps=a.working_digits;ctx.threads=1;start=time.monotonic();primitives={};sources=[]
    for path,digest,expected in [(a.three_loop_input,a.three_loop_sha256,{'native::L3_P13':(-3,2),'native::L3_P14':(-3,2)}),
      (a.four_loop_input,a.four_loop_sha256,{f'native::{s}':(-4,1) for s in ['PR3','PR4','PR4d','PR5','PR7','PR9','PR9d']})]:
        values,receipt=load_native_endpoints(path,digest,expected);primitives.update(values);sources.append(receipt)
    sunset=Path(a.sunset_input)
    if sha(sunset)!=a.sunset_sha256:raise ValueError('Sunset source checksum mismatch')
    s=read(sunset);rows=s['coefficients']['native_raw']
    if s['error_quality']!='rigorous-bound' or not s['validated_analytic_truncation_and_rounding'] or [r['epsilon_power'] for r in rows]!=list(range(-2,4)):
        raise ValueError('Explicit bounded sixjet sunset source required')
    balls=tuple(arb(r['ball']) for r in rows)
    if any(not b.is_finite() for b in balls):raise ValueError('Nonfinite sunset source')
    primitives['native::L2_P2']=FactorJet(-2,balls,'Accepted exact sunset recurrence with rigorous complex-epsilon Cauchy tail','native::L2_P2; '+a.sunset_sha256)
    sources.append({'source':str(sunset.resolve()),'sha256':a.sunset_sha256,'error_quality':'rigorous-bound','normalization':'native_raw'})
    p853=Path(a.p853_input);checked=read(Path(a.p853_validation))
    if sha(p853)!=a.p853_sha256 or checked['coefficient_data_sha256']!=a.p853_sha256:raise ValueError('P853 source/acceptance checksum mismatch')
    data=read(p853);rows=data['coefficients']['native_raw']
    if checked['source_exact_jet_sha256']!=data['source_exact_jet_sha256'] or [r['epsilon_power'] for r in rows]!=list(range(-3,5)):
        raise ValueError('Exact extended P853 source orders and binding required')
    balls=[]
    for r in rows:
        c,e=arb(r['value']),arb(r['absolute_error_upper_bound'])
        if not c.is_finite() or not e.is_finite() or e.lower()<0:raise ValueError('Invalid P853 source enclosure')
        balls.append(c+arb(0,e.upper()))
    primitives[P853]=FactorJet(-3,tuple(balls),'Accepted exact hypergeometric Laurent coefficients with independent highprecision validation',P853+'; '+a.p853_sha256)
    sources.append({'source':str(p853.resolve()),'sha256':a.p853_sha256,'acceptance_sha256':sha(Path(a.p853_validation)),'error_quality':'rigorous-bound','normalization':'native_raw'})
    factors,recipe=build_factor_expressions();inventory=HERE.parent.parent/'pr11-boundary/inventory-full-v2.json'
    plan=BoundaryLogJetMap.from_file(inventory,'db5290bc8520499001d9998098d95474270ba2f5ffed1213dfa5ce2062eac7e9')
    spec=importlib.util.spec_from_file_location('higherguard_x8_matching',PR11/'infinity-matching/match.py');module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module);matching=module.Matching()
    compiled=ExpandedBoundary(plan,factors,max_log_power=matching.data['max_exact_log_degree']);required,_=compiled.required_primitive_orders(primitives)
    raw=compiled.evaluate(primitives);values={}
    for (i,alpha,p,l),v in raw.items():
        if alpha.denominator!=1:raise ValueError('Noninteger prepared source exponent')
        values[i,int(alpha),p,l]=v
    for k,v in values.items():
        if k not in matching.positions and not v.contains(0):raise ValueError('Forbidden prepared source support '+str(k))
    boundary={k:values[k] for k in matching.all_keys};solution=matching.solve(boundary,inventory_sha256=sha(inventory),normalization='native_raw',error_quality='rigorous-bound')
    maximum=max(v.rad() for v in solution.constants)
    if a.minimum_constant_error_power is not None and not maximum.upper()<(arb(10)**-a.minimum_constant_error_power).lower():
        raise ValueError('Actual source/matching errors lack the explicit requested guard: '+maximum.str(35))
    payload={'schema':'vakint.pr11d.higher-guard-complete-source-boundary.v1','normalization':'native_raw','error_quality':'rigorous-bound',
      'inventory_sha256':sha(inventory),'matching_sha256':matching.binding,'working_decimal_digits':a.working_digits,'all_prepared_rows_checked':True,'require_all_prepared_rows':True,
      'coefficient_count':len(boundary),'source_receipts':sources,'recipe_receipt':recipe,'required_raw_primitive_through':required,
      'coefficients':[{**module.label(k),'real_ball':v.str(a.working_digits+12,more=True)} for k,v in boundary.items()],
      'producer_sha256':sha(Path(__file__)),'whole_PR11d_accuracy_claimed':False}
    targets[0].write_text(json.dumps(payload,indent=2)+'\n')
    constants={**solution.report,'free_constant_balls':[v.str(a.working_digits+12,more=True) for v in solution.constants],
      'boundary_input_sha256':sha(targets[0]),'maximum_constant_radius':maximum.upper().str(45,more=True),'source_receipts':sources,
      'working_decimal_digits':a.working_digits,'wall_seconds':time.monotonic()-start,'whole_PR11d_accuracy_claimed':False}
    targets[1].write_text(json.dumps(constants,indent=2)+'\n')
    print('PASS:1587source rows/252constants; maxradius',constants['maximum_constant_radius'],'seconds',time.monotonic()-start,flush=True)
if __name__=='__main__':main()
