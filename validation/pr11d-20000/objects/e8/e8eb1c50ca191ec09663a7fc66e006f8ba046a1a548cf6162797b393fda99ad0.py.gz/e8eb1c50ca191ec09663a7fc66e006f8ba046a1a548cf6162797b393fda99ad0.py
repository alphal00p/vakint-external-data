"""Exact denominator-cleared normalized infinity connections for ancestor lifts."""
import argparse,hashlib,json,pathlib,sys
sys.path.insert(0,'/shared/codex-1/vakint_rustred/workspace/precision-periods/pr11d/helper')
from exact_system import CTX,ONE,parse
if not __debug__:raise RuntimeError('Assertions required')
ap=argparse.ArgumentParser();ap.add_argument('name');a=ap.parse_args();HERE=pathlib.Path(__file__).parent
source=HERE/f'{a.name}-augmented5.json.normalized.json';data=json.load(open(source));raw=json.load(open(HERE/f'{a.name}.json'));dim=data['state_dimension'];base=len(raw['differential_matrix']);assert dim==6*base
D=ONE;values=[]
for i,row in enumerate(data['matrix']):
 for j,text in enumerate(row):
  if text=='0':continue
  q=parse(text,raw['epsilon_symbol'],'pr11d_direct_helper::{}::z');assert all(e==0 for e,x in q.num.to_dict()) and all(e==0 for e,x in q.den.to_dict());D=D*q.den//D.gcd(q.den);values.append((i,j,q))
D=D/D.leading_coefficient();degree=int(D.degrees()[1]);assert D.to_dict().get((0,0),0)==0 and D.to_dict().get((0,1),0)!=0
entries=[];ndegree=0
for i,j,q in values:
 poly=q.num*(D//q.den);assert poly*q.den==q.num*D;terms=[]
 for (e,k),c in sorted(poly.to_dict().items(),key=lambda kv:kv[0][1]):
  assert e==0;ndegree=max(ndegree,int(k));terms.append({'z_power':int(k),'numerator':str(c.numerator),'denominator':str(c.denominator)})
 entries.append({'row':i,'column':j,'terms':terms})
matching=HERE/f'{a.name}-matching.json';m=json.load(open(matching));startup=HERE/f'{a.name}-startup.json';seed=json.load(open(startup));assert seed['source_matching_sha256']==hashlib.sha256(matching.read_bytes()).hexdigest() and seed['exact_recurrence_identity_verified']
maxlog=max(row['log_power'] for row in seed['coefficients']);assert maxlog==m['max_exact_log_degree'];lo,hi=m['normalized_power_range'];roots=[r['root'] for r in m['residue_blocks']];assert max(roots)==hi
result={'schema':'vakint.pr11d.exact-polynomial-infinity-connection.v1','name':a.name,'source_normalized_connection_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'dimension':dim,'base_dimension':base,'epsilon_range':[-m['loop_count'],5-m['loop_count']],'state_ordering':f'state={base}*(epsilon_power+{m["loop_count"]})+original_component','denominator_coefficients':[str(D.to_dict().get((0,k),0)) for k in range(degree+1)],'denominator_degree':degree,'numerator_degree':ndegree,'entries':entries,'all_exact_fraction_reconstruction_identities_verified':True,'matching_data_sha256':hashlib.sha256(matching.read_bytes()).hexdigest(),'startup_data_sha256':hashlib.sha256(startup.read_bytes()).hexdigest(),'residue_eigenvalues':roots,'generic_maximum_log_degree':maxlog,'normalized_power_range':[lo,hi],'generic_all_orders_log_bound_proof':f'Exact Q startup through powers{lo}..{hi} introduces all{dim}freeconstants and maximum logdegree{maxlog}. For each subsequent n>{hi}, nI-R is invertible because all residue roots are <= {hi}. Forcing from the lower-order analytic connection and descending log recurrence preserve the bound. No stronger physical cancellation is assumed.','scope':'Exact recurrence only; no numerical ancestor accuracy claimed.'}
(HERE/f'{a.name}-polynomial.json').write_text(json.dumps(result,indent=2)+'\n');print(a.name,'PASS Ddegree',degree,'Ndegree',ndegree,'entries',len(entries),'terms',sum(len(row['terms']) for row in entries),'startup',sum(len(row['entries']) for row in seed['coefficients']))
