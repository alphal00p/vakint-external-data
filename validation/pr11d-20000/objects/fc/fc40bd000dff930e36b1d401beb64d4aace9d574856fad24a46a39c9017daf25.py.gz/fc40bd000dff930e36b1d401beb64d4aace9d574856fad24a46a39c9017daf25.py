#!/usr/bin/env python3
"""Independent, read-only A49 continuation and native-profile audit.

Uses only Python standard-library exact rational arithmetic. Does not import the
producer, admission replay, preparer, or generic checker. Physical initial and
endpoint ownership, numerical recurrence, and interval enclosure are out of scope.
"""
import argparse
import copy
import hashlib
import json
import math
from fractions import Fraction as Q
from pathlib import Path

HERE = Path(__file__).resolve().parent
ADMISSION = HERE.parents[1]
ROOT = ADMISSION.parents[1]
PINS = {}


def require(ok, text):
    if not ok:
        raise ValueError(text)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def remember(path, expected=None):
    path = Path(path).resolve()
    digest = sha(path)
    require(expected is None or digest == expected, 'Hash mismatch: ' + str(path))
    require(str(path) not in PINS or PINS[str(path)] == digest, 'Conflicting source: ' + str(path))
    PINS[str(path)] = digest
    return digest


def pairs(items):
    out = {}
    for key, value in items:
        require(key not in out, 'Duplicate JSON key')
        out[key] = value
    return out


def load(path):
    remember(path)
    return json.loads(Path(path).read_bytes(), object_pairs_hook=pairs,
                      parse_constant=lambda s: (_ for _ in ()).throw(ValueError(s)))


def resolve(path):
    path = Path(path)
    return (path if path.is_absolute() else ROOT / path).resolve()


def equal(value, expected, label):
    require(type(value) is type(expected) and value == expected, label)


def route(start):
    points = []
    while start > Q(1, 16):
        lower = max(start / 2, Q(1, 16))
        points += [start + (lower - start) * Q(i, 4) for i in range(1, 5)]
        start = lower
    return points


def multiply(x, y):
    return x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0]


def power(x, n):
    out = (Q(1), Q(0))
    for _ in range(n):
        out = multiply(out, x)
    return out


def parse_profile(text, native, center, delta):
    """Reconstruct exact metadata from the saved RPF input, not producer JSON."""
    lines = text.splitlines()
    header = list(map(int, lines[0].split()))
    equal(header, [22, 6, 10, 241, 12, 68764, 20400, 80000, 1000], 'Uniform native policy')
    marks = [i for i, line in enumerate(lines) if line.startswith('RPF_V1 ')]
    equal(len(marks), 1, 'Single RPF suffix')
    cursor = iter(lines[marks[0]:])
    equal(next(cursor), 'RPF_V1 8 607', 'RPF suffix counts')

    def ints(count):
        out = list(map(int, next(cursor).split()))
        equal(len(out), count, 'RPF input row width')
        return out

    for wanted in [center, delta]:
        a, b, d = ints(3)
        require(d > 0 and a == 0 and Q(b, d) == wanted, 'RPF exact contour')
    denominator = ints(1)[0]
    require(denominator > 0, 'Positive numerator denominator')
    bank = []
    for _ in range(8):
        degree, exponent, den = ints(3)
        require(degree in (1, 2) and exponent in (1, 2, 3) and den > 0, 'RPF bank profile')
        bank.append(([Q(x, den) for x in ints(degree + 1)], exponent))
    masks = [set() for _ in bank]
    row_denominators = [1] * 22
    active = divisions = 0
    for _ in range(607):
        row, column, epower, factor, degree = ints(5)
        require(0 <= row < 22 and 0 <= column < 22 and 0 <= epower < 6
                and -1 <= factor < 8 and 0 <= degree <= 4, 'RPF term profile')
        coeff = [Q(v, denominator) for v in ints(degree + 1)]
        if not any(coeff):
            continue
        active += 1
        divisions += 6 - epower
        if factor >= 0:
            masks[factor].update(j * 22 + column for j in range(6 - epower))
        # Coefficients of h * n(c+h*t), in exact Gaussian rationals.
        for k in range(degree + 1):
            local = (Q(0), Q(0))
            for j in range(k, degree + 1):
                term = multiply(power((Q(0), center), j-k), power((Q(0), delta), k+1))
                multiplier = coeff[j] * math.comb(j, k)
                local = local[0] + multiplier * term[0], local[1] + multiplier * term[1]
            row_denominators[row] = math.lcm(row_denominators[row], local[0].denominator, local[1].denominator)
    require(not list(cursor), 'RPF input trailing data')
    factor_pairs = sum(map(len, masks))
    levels = sum(len(mask) * exponent for mask, (_, exponent) in zip(masks, bank))
    full_levels = 132 * sum(exponent for _, exponent in bank)
    mask_fields = {
        'auxiliary_mask_verified': True,
        'auxiliary_active_states_by_factor': [sorted(s) for s in masks],
        'auxiliary_total_factor_state_pairs': 1056,
        'auxiliary_computed_factor_state_pairs': factor_pairs,
        'auxiliary_skipped_factor_state_pairs': 1056-factor_pairs,
        'auxiliary_total_cascade_state_levels': full_levels,
        'auxiliary_computed_cascade_state_levels': levels,
        'auxiliary_skipped_cascade_state_levels': full_levels-levels,
    }
    row_fields = {
        'row_denominator_aggregation_verified': True,
        'row_common_denominators': list(map(str, row_denominators)),
        'row_numerator_identity_count': 10*active,
        'baseline_term_divisions_per_order': divisions,
        'row_divisions_per_order': 132,
    }
    guard = all(len(coeff) == 2 or coeff[1]**2 - 4*coeff[0]*coeff[2] >= 0 for coeff, _ in bank)
    ratio = (center/delta)**2
    slope, remainder = 0, ratio
    if guard:
        while remainder >= 4:
            slope += 1
            remainder /= 4
    schedule_fields = {
        'coefficient_precision_schedule': 'max(min(Pmax,1024),Pmax-slope*n), n starts at zero',
        'precision_max_bits': 68764,
        'coefficient_precision_floor_bits': 1024,
        'coefficient_precision_slope_bits_per_order': slope,
        'minimum_coefficient_precision_bits_used': max(1024, 68764-slope*(native['order']-1)),
        'schedule_real_roots_guard': guard,
        'schedule_radius_ratio_squared': str(ratio),
        'full_precision_total_and_certificate': True,
        'schedule_is_accuracy_guarantee': False,
    }
    return mask_fields, row_fields, schedule_fields


def profile(native, groups, segment):
    for fields, required in zip(groups, [segment >= 1, segment >= 1, segment >= 2]):
        for key, wanted in fields.items():
            require((key in native) is required, 'Wrong kernel profile field presence: ' + key)
            if required:
                equal(native[key], wanted, 'Wrong kernel metadata: ' + key)
    workers = {'openmp_thread_cap': 16, 'openmp_requested_threads': 8, 'openmp_actual_threads': 8}
    for key, wanted in workers.items():
        require((key in native) is (segment == 3), 'Wrong worker metadata presence')
        if segment == 3:
            equal(native[key], wanted, 'Wrong actual-eight worker metadata')


def main():
    config = load(ADMISSION / 'lineage-contract.json')
    replay_sha = remember(ADMISSION / 'replay.py')
    remember(__file__)
    for category in ['source_pins', 'checker_implementation_sha256']:
        for path, digest in config[category].items():
            remember(path, digest)
    previous = Path(config['initial_path'])
    remember(previous, config['initial_sha256'])
    # Boundary metadata only. No physical source audit is performed here.
    equal(load(previous)['eta_center'], ['0', '256'], 'Initial metadata center')
    center = Q(256)
    reports, steps, seams, rejection_results = [], [], [], []
    counts = [2, 2, 1, 44]
    equal([s['completed_steps'] for s in config['segments']], counts, 'Historical segment counts')
    names = ['pr9-production-API20280-v5', 'pr9-production-API20280-masked-rows-v5',
             'pr9-production-API20280-scheduled8-v8', 'pr9-production-API20280-actual8-v9']
    for segment_index, segment in enumerate(config['segments']):
        directory = Path(segment['directory']).resolve()
        equal(directory.name, names[segment_index], 'Historical segment name')
        start_center, start_path = center, previous
        points = route(center)
        count = counts[segment_index]
        binding_path = directory / 'run-binding.json'
        remember(binding_path, segment['run_binding_sha256'])
        binding, progress = load(binding_path), load(directory / 'progress.json')
        equal(binding['initial_sha256'], sha(previous), 'Continuation full-boundary binding')
        equal(progress['completed_steps'], count, 'Completed count')
        equal(progress['expected_steps'], len(points), 'Remaining exact contour size')
        equal(progress['run_binding_sha256'], sha(binding_path), 'Progress binding')
        equal(len(progress['steps']), count, 'Progress list size')
        for suffix in ['-native.json', '-boundary.json']:
            require(set(directory.glob('step-*' + suffix)) == {directory/f'step-{i:03}{suffix}' for i in range(count)}, 'Orphan accepted native or boundary')
        for key, wanted in [('mask_metadata_required', segment_index >= 1), ('row_metadata_required', segment_index >= 1), ('schedule_metadata_required', segment_index >= 2), ('expected_worker_threads', 8 if segment_index == 3 else None)]:
            equal(segment[key], wanted, 'Frozen profile contract')
        native_source = Path(segment['native_source_path'])
        remember(native_source, segment['native_source_sha256'])
        remember(segment['native_review_path'], segment['native_review_sha256'])
        native_review = load(segment['native_review_path'])
        equal(native_review['source_sha256'], sha(native_source), 'Review-to-source binding')
        equal(native_review['binary_sha256'], binding['native_sha256'], 'Review-to-binary binding')
        remember(binding['native_path'], binding['native_sha256'])
        require(config['source_pins'][str(native_source)] == sha(native_source)
                and config['source_pins'][segment['native_review_path']] == sha(segment['native_review_path'])
                and config['source_pins'][binding['native_path']] == sha(binding['native_path']), 'Profile files must be in frozen source graph')
        if segment_index < 3:
            require('omp_set_dynamic(0);if(omp_get_max_threads()>4)omp_set_num_threads(4);' in native_source.read_text(), 'Historical cap4 source')
        else:
            require('omp_set_dynamic(0);if(openmp_requested_threads>16)omp_set_num_threads(16);' in native_source.read_text()
                    and 'openmp_actual_threads=omp_get_num_threads();' in native_source.read_text(), 'Observed cap16 source')
        if segment_index >= 2:
            equal(binding['native_worker_threads'], 8, 'Historical requested workers')
        for local_index, dest in enumerate(points[:count]):
            ip, mp, np, bp = [directory/f'step-{local_index:03}{suffix}' for suffix in ['.in', '.json', '-native.json', '-boundary.json']]
            remember(ip)
            meta, native, boundary = load(mp), load(np), load(bp)
            equal(meta['center'], ['0', str(center)], 'Exact center')
            equal(meta['step'], ['0', str(dest-center)], 'Exact step')
            equal(meta['input_sha256'], sha(ip), 'Input binding')
            equal(meta['initial_data_sha256'], sha(previous), 'Initial source binding')
            equal(boundary['eta_center'], ['0', str(dest)], 'Exact next center')
            for key, value in [('previous_boundary_sha256', sha(previous)), ('transport_input_sha256', sha(ip)),
                               ('native_output_sha256', sha(np)), ('run_binding_sha256', sha(binding_path)),
                               ('initial_boundary_sha256', sha(start_path))]:
                equal(boundary[key], value, 'Boundary lineage ' + key)
            equal(boundary['whole_PR11d_20000_accuracy_claimed'], False, 'No whole-period promotion')
            groups = parse_profile(ip.read_text(), native, center, dest-center)
            profile(native, groups, segment_index)
            recorded = progress['steps'][local_index]
            expected = {'index': local_index, 'center': str(center), 'destination': str(dest),
                        'boundary_sha256': sha(bp), 'order': native['order'],
                        'native_seconds': native['seconds'], 'local_tail': native['tail_upper_enclosure']}
            for key, wanted in expected.items():
                equal(recorded[key], wanted, 'Progress per-step ' + key)
            steps.append({'global_index': len(steps), 'segment_index': segment_index, **expected,
                          'row_exact_numerator_slots': groups[1]['row_numerator_identity_count'] if segment_index else 0,
                          'mask_factor_state_pairs': groups[0]['auxiliary_computed_factor_state_pairs'] if segment_index else None,
                          'schedule_slope': groups[2]['coefficient_precision_slope_bits_per_order'] if segment_index >= 2 else None})
            if local_index == 0:
                changes = []
                if segment_index >= 1:
                    changes += [('omit-mask', {'auxiliary_mask_verified': None}, True),
                                ('wrong-row-count', {'row_divisions_per_order': 131}, False)]
                if segment_index >= 2:
                    changes += [('wrong-slope', {'coefficient_precision_slope_bits_per_order': 0}, False)]
                if segment_index == 3:
                    changes += [('forged-cap4-actual4', {'openmp_thread_cap': 4, 'openmp_actual_threads': 4}, False),
                                ('floating-workers', {'openmp_actual_threads': 8.0}, False)]
                for name, fields, delete in changes:
                    bad = copy.deepcopy(native)
                    for key, value in fields.items():
                        if delete:
                            del bad[key]
                        else:
                            bad[key] = value
                    try:
                        profile(bad, groups, segment_index)
                    except ValueError as error:
                        rejection_results.append({'segment': segment_index, 'mutation': name, 'rejected': True, 'reason': str(error)})
                    else:
                        raise ValueError('Negative control accepted: ' + name)
            previous, center = bp, dest
        require(resolve(progress['last_boundary']) == previous.resolve(), 'Progress terminal path')
        equal(progress['last_boundary_sha256'], sha(previous), 'Progress terminal hash')
        if segment_index < 3:
            name = 'actual-worker-continuation.json' if segment_index == 2 else 'optimization-continuation.json'
            continuation = load(directory / name)
            equal(continuation['completed_steps'], count, 'Continuation prefix size')
            require(resolve(continuation['last_boundary']) == previous.resolve(), 'Continuation terminal path')
            equal(continuation['last_boundary_sha256'], sha(previous), 'Continuation terminal hash')
            next_directory = Path(config['segments'][segment_index+1]['directory'])
            key = 'new_directory' if segment_index == 2 else 'new_continuation_directory'
            require(resolve(continuation[key]) == next_directory.resolve(), 'Next segment directory')
            require(resolve(continuation['new_engine']) == Path(load(next_directory/'run-binding.json')['native_path']).resolve(), 'Next segment engine')
            equal(continuation['whole_PR11d_accuracy_claimed'], False, 'Continuation accuracy qualification')
            if segment_index == 2:
                equal(continuation['configured_requested_workers'], 8, 'Corrected request8')
                equal(continuation['observed_actual_workers_previous_base_kernel'], 4, 'Corrected report4')
            seams.append({'after_global_step': len(steps)-1, 'center': str(center), 'boundary_sha256': sha(previous), 'continuation_sha256': sha(directory/name)})
        reports.append({'segment_index': segment_index, 'directory': str(directory), 'count': count,
                        'start': str(start_center), 'end': str(center), 'expected_steps_at_restart': len(points),
                        'native_source_sha256': sha(native_source), 'native_review_sha256': sha(segment['native_review_path']),
                        'binary_sha256': binding['native_sha256'], 'run_binding_sha256': sha(binding_path),
                        'native_observed_actual_workers': 8 if segment_index == 3 else None,
                        'fixed_source_worker_cap': 16 if segment_index == 3 else 4})
    require(len(steps) == 49 and center == Q(1,16), 'Complete compositional center route')
    complete = load(Path(config['segments'][-1]['directory'])/'complete.json')
    equal(complete['complete'], True, 'Completed final segment')
    equal(complete['steps'], progress['steps'], 'Completed step summaries')
    equal(complete['final_boundary_sha256'], sha(previous), 'Completed final hash')
    require(resolve(complete['final_boundary']) == previous.resolve(), 'Completed final path')
    for path, digest in list(PINS.items()):
        require(sha(path) == digest, 'File changed during independent audit')
    return {'schema': 'vakint.PR9-A49-independent-lineage-profile-review.v1',
            'status': 'saved_lineage_and_native_profiles_passed', 'admission_replay_sha256': replay_sha,
            'admission_contract_sha256': sha(ADMISSION/'lineage-contract.json'),
            'independent_checker_sha256': sha(__file__), 'segments': reports, 'seams': seams, 'steps': steps,
            'counts': {'completed_steps': 49, 'continuation_seams': 3, 'mask_profiles': 47,
                       'row_aggregation_profiles': 47, 'row_denominators_checked': 47*22,
                       'row_numerator_slots_reconstructed': 47*6070, 'schedule_profiles': 45,
                       'actual8_metadata_profiles': 44, 'negative_controls': len(rejection_results),
                       'unique_file_hashes_rechecked': len(PINS)},
            'worker_qualification': 'The single scheduled8 segment requested8. Its frozen source caps at4, and its immutable continuation reports actual4. Its native output has no observed-team fields. The final44 saved native results explicitly report request8/actual8/cap16.',
            'negative_controls': rejection_results, 'source_and_artifact_sha256': PINS,
            'scope': {'physical_initial_source_admitted': False, 'endpoint_admitted': False,
                      'interval_or_recurrence_replayed': False, 'native_preparer_HPL_calls': 0,
                      'producer_files_modified': False, 'whole_PR11d_accuracy_claimed': False}}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    require(output.is_relative_to(HERE) and not output.exists() and not args.output.is_symlink(), 'Fresh scoped output required')
    result = main()
    with output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'counts': result['counts'], 'output_sha256': sha(output)}))
