"""Independent exact graph/face and all-Hepp-sector replay; no producer imports."""
import ast,hashlib,itertools,json,math,time
from fractions import Fraction as Q
from pathlib import Path
from flint import fmpq,fmpq_mat
HERE=Path(__file__).resolve().parent
PR11=HERE.parents[1];BESSEL=PR11.parent/'bessel'
RAW_CERT=BESSEL/'raw-pole-support/certificate.json'
FINITE_CERT=PR11/'parametric-finiteness/certificate.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
raw=json.loads(RAW_CERT.read_text());finite=json.loads(FINITE_CERT.read_text())
source_path=Path(finite['original_X8_source_path']);source=json.loads(source_path.read_text());reference_path=Path(finite['canonical_reference_input_path']);reference=json.loads(reference_path.read_text())
assert sha(RAW_CERT)=='d5289b81989b14398ff3d8d65edbcbbd198f4bbab4811de9fd8b255f72b45dcd'
assert sha(FINITE_CERT)=='3aa4fe32825867a6ddeb6a5af35bc9e5d550bdd031db2f71834753a176a9da6a'
assert sha(source_path)==finite['original_X8_source_sha256']=='a9ec06c3a076f3460e84ec3492ae314b29f4cf470dddbe2a5442b502f7181184'
assert sha(reference_path)==finite['canonical_reference_input_sha256']
assert sha(PR11/'parametric-finiteness/verify.py')==finite['validator_sha256']
assert sha(BESSEL/'raw-pole-support/verify.py')==raw['verifier_sha256']
for path,pin in raw['input_sha256'].items():assert sha(path)==pin,path
family=source['family'];assert family['sha256']==source['source_family_sha256']==finite['family_sha256']==reference['family_sha256']
assert not family['external_momenta'] and len(family['loop_momenta'])==4 and family['coordinate_index_base']==0
assert source['deformed_propagators']==[3]
start=time.monotonic();vectors=[]
for prop in family['denominators']:
 assert Q(prop['constant'])==-1
 gram=[[Q(0)]*4 for _ in range(4)]
 for coord,coefficient in zip(family['coordinates'],prop['coefficients']):
  assert coord['kind']=='loop_loop'
  i,j=coord['left'],coord['right'];q=Q(coefficient)
  gram[i][j]=q if i==j else q/2;gram[j][i]=gram[i][j]
 # Different route from the production validator: require rank-one, then use
 # the first unit diagonal row as its factor and reconstruct every entry.
 G=fmpq_mat([[fmpq(q.numerator,q.denominator) for q in row] for row in gram]);assert G.rank()==1
 pivot=next(i for i in range(4) if gram[i][i]);assert gram[pivot][pivot]==1
 v=gram[pivot];assert all(gram[i][j]==v[i]*v[j] for i in range(4) for j in range(4));vectors.append(v)
assert [[int(x) for x in v] for v in vectors]==raw['graph_and_domain_checks']['quadratic_vectors']
slots=sorted(set(i for row in source['basis'] for i,v in enumerate(row) if v))
assert slots==list(range(1,9)) and len(source['basis'])==42
V=[vectors[i] for i in slots]
rank=lambda rows:fmpq_mat([[fmpq(q.numerator,q.denominator) for q in row] for row in rows]).rank() if rows else 0
ranks={mask:rank([V[i] for i in range(8) if mask>>i&1]) for mask in range(256)}
assert ranks[255]==4
edgepairs=raw['graph_and_domain_checks']['edge_endpoints'];B=[[0]*8 for _ in range(5)]
for j,(u,v) in enumerate(edgepairs):B[u][j]-=1;B[v][j]+=1
assert B==raw['graph_and_domain_checks']['vertex_incidence_matrix']
assert fmpq_mat(B)*fmpq_mat([[fmpq(q.numerator,q.denominator) for q in row] for row in V])==fmpq_mat(5,4)
assert fmpq_mat(B).rank()==4
bases={}
for combination in itertools.combinations(range(8),4):
 det=fmpq_mat([[fmpq(q.numerator,q.denominator) for q in V[i]] for i in combination]).det()
 if det:
  assert abs(det)==1;bases[sum(1<<i for i in combination)]=Q(str(det*det))
assert len(bases)==45
expected_bases={sum(1<<i for i in b['active_indices']):Q(b['coefficient']) for b in finite['positive_U_bases']}
assert bases==expected_bases
# Independently close the absent-edge equivalence relation by set merging.
for component,powers in enumerate(source['basis']):
 assert len(powers)==10 and all(type(v)is int and v>=0 for v in powers)
 classes=[{v} for v in range(5)]
 for j,(u,v) in enumerate(edgepairs):
  if powers[slots[j]]:continue
  a=next(c for c in classes if u in c);b=next(c for c in classes if v in c)
  if a is not b:
   joined=a|b;classes=[c for c in classes if c is not a and c is not b]+[joined]
 owner={v:i for i,c in enumerate(classes) for v in c};active=[j for j,s in enumerate(slots) if powers[s]]
 incidence=[[0]*len(active) for _ in classes]
 for k,j in enumerate(active):u,v=edgepairs[j];incidence[owner[u]][k]-=1;incidence[owner[v]][k]+=1
 rb=fmpq_mat(incidence).rank();loops=len(active)-rb
 assert loops==4 and rank([V[j] for j in active])==4
 expected=raw['graph_and_domain_checks']['basis_checks'][component]
 assert expected['powers']==powers and expected['independent_loops']==loops and expected['incidence_rank']==rb
powers=reference['powers'];assert powers==finite['powers']==[0,2,1,1,1,1,1,1,1,0]
assert reference['master_id']==finite['master_id'] and reference['loop_count']==4
nu=[powers[i] for i in slots];assert sum(nu)==9 and nu==finite['ordered_active_powers']
assert [[str(q) for q in v] for v in V]==finite['ordered_active_vectors']
assert finite['active_slot_indices']==slots
u_face={mask:4-ranks[255^mask] for mask in range(1,255)}
margins=[]
for row in finite['UV_face_checks']:
 mask=row['active_subset_mask'];valuation=min((b&mask).bit_count() for b in bases);assert valuation==u_face[mask]
 total=sum(nu[i] for i in range(8) if mask>>i&1);margin=total-2*valuation
 assert row['outside_rank']==ranks[255^mask] and row['U_face_valuation']==valuation and row['sum_propagator_powers']==total and row['D4_face_margin']==margin
 assert Q(row['closed_epsilon_disc_1_over_8_margin'])==Q(margin)-Q(valuation,8)>0
 margins.append(Q(margin)-Q(valuation,8))
assert len(finite['UV_face_checks'])==254 and len({r['active_subset_mask'] for r in finite['UV_face_checks']})==254
# Verify the simultaneous basis lower bound in every ordered Hepp sector.
sectors=0;prefix_checks=0
for order in itertools.permutations(range(8)):
 chosen=0
 for edge in reversed(order):
  candidate=chosen|(1<<edge)
  if ranks[candidate]>ranks[chosen]:chosen=candidate
 assert chosen in bases
 prefix=0
 for edge in order[:-1]:
  prefix|=1<<edge;assert (chosen&prefix).bit_count()==u_face[prefix];prefix_checks+=1
 sectors+=1
assert sectors==math.factorial(8) and prefix_checks==282240
# Exact target identity and normalization binding.
red=[r for r in source['target_reductions'] if r['powers']==powers];assert len(red)==1
terms={tuple(t['powers']):t['coefficient'] for t in red[0]['terms']}
assert terms=={tuple(source['basis'][30]):'1',tuple(source['basis'][36]):'-1',tuple(source['basis'][37]):'-1*masters_4l::{}::epsilon',tuple(source['basis'][38]):'-1'}
assert source['normalization_conversion_from_rustflow']=='exp(4*EulerGamma*epsilon)'
# Check deformation orientation using the decoupled tadpole in component0:
# only slot3 depends on q4. Its exact logarithmic mass derivative is
# (1-epsilon)/(1+eta), fixing mass_squared=1+eta from the unit mass ateta0.
assert vectors[3]==[0,0,0,1]
assert all(vectors[i][3]==0 for i,p in enumerate(source['basis'][0]) if p and i!=3)
assert source['differential_matrix'][0][0]=='(-1+masters_4l::{}::epsilon)*(1+symbolica_amflow::{}::eta)^(-1)*-1'
assert all(v=='0' for v in source['differential_matrix'][0][1:])
# Reproduce the independent momentum-subspace oracle using rank closure,
# rather than its integer-kernel construction.
oracle_path=PR11/'amflow-oracle/finiteness-validation.json';oracle=json.loads(oracle_path.read_text())
assert oracle['source_sha256']==sha(source_path) and oracle['target_powers']==powers
flat_rows={};nonzero_subspaces=0
for soft in range(256):
 dimension=4-ranks[soft]
 if not dimension:continue
 hard=[i for i in range(8) if ranks[soft|(1<<i)]>ranks[soft]]
 total=sum(nu[i] for i in hard);degree=4*dimension-2*total;assert degree<0
 key=tuple(slots[i] for i in hard)
 flat_rows[key]={'hard_line_slots':list(key),'hard_loop_subspace_dimension':dimension,'hard_denominator_power_sum':total,'UV_degree_at_d4':degree}
 nonzero_subspaces+=1
assert nonzero_subspaces==122 and len(flat_rows)==42
assert sorted(flat_rows.values(),key=lambda r:(r['hard_loop_subspace_dimension'],r['hard_line_slots']))==oracle['conditions']
result={'schema':'vakint.physical-poles.independent-graph-face-replay.v1','all_checks_passed':True,'raw42_graphs_checked':42,'all_contracted_loop_counts':4,'rank_one_massive_quadratics_checked':10,'positive_unimodular_U_bases':len(bases),'proper_face_checks':254,'minimum_margin_closed_eps_disc1over8':str(min(margins)),'overall_margin_closed_disc1over8':'1/2','all_Hepp_orderings_checked':sectors,'simultaneous_greedy_prefix_checks':prefix_checks,'exact_target_reduction_matched':True,'native_to_FMFT_factor_matched':True,'positive_deformation_sign_checked_by_decoupled_tadpole':True,'independent_momentum_flat_replay':{'nonzero_subspaces':nonzero_subspaces,'distinct_flats':len(flat_rows),'maximum_UV_degree':max(r['UV_degree_at_d4'] for r in flat_rows.values()),'oracle_sha256':sha(oracle_path),'oracle_source_sha256':sha(PR11/'amflow-oracle/check_finiteness.py')},'raw_pole_certificate_sha256':sha(RAW_CERT),'finiteness_certificate_sha256':sha(FINITE_CERT),'source_sha256':sha(source_path),'reference_sha256':sha(reference_path),'all_declared_source_pins_checked':True,'seconds':time.monotonic()-start,'scope':'Exact graph,identityandconvergence combinatorics; no numericalperiod evaluation.'}
(HERE/'independent-graph-faces.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
