#!/usr/bin/env python3
"""Seal v11 validator review; complete A/B execution receipts remain separate."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
ROOT = BASE.parents[1]


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def read(p):
    return json.loads(Path(p).read_bytes())


def main():
    checks = read(HERE / 'contract-checks.json')
    assert checks['negative_control_count'] == 110 and checks['all96_mode_combinations_correct'] is True
    implementations = checks['implementation_sha256']
    assert implementations == read(BASE / 'implementation-pins.json')
    assert implementations[str(BASE / 'validate.py')] == '13cc7e39ccd7fe50990cda32653ea2d4ad04cbd7f425f9233bac4196984f7396'
    assert implementations[str(BASE / 'checker-pins.json')] == 'b727bbf7c275fdcee12fc4c2a4a32ec8d3a43290d820452bf18a7264f6acfb58'
    pins = {}

    def pin(path, digest):
        p = Path(path)
        assert p.is_absolute() and p.resolve() == p and p.is_file()
        assert sha(p) == digest, str(p)
        assert str(p) not in pins or pins[str(p)] == digest, str(p)
        pins[str(p)] = digest

    def graph(data, field):
        for p, h in data.get(field, {}).items():
            if isinstance(h, dict):
                assert set(h) == {'path', 'sha256'}
                p, h = h['path'], h['sha256']
            pin(p, h)

    for p, h in implementations.items(): pin(p, h)
    for file in ['contract-checks.json', 'v4-delta-review.json', 'v4-independent-review.json',
                 'audit_contract.py', 'audit_v4.py']:
        pin(HERE / file, sha(HERE / file))
    v4 = read(HERE / 'v4-independent-review.json')
    assert sha(HERE / 'v4-independent-review.json') == '39275e9781f8aa94cba8f5cf28a1f65895f164f9206b5341c2b4336ab13d6918'
    assert v4['accepted'] is True and v4['status'] == 'passed_for_frozen_generic_RPF_step_checker'
    assert read(BASE / 'checker-pins.json')['implementation_sha256'] == v4['implementation_sha256']
    graph(v4, 'source_pins')
    profiles = {}
    for name, envelope_sha, initial_sha, run_sha, digits, gate in [
        ('A', '257375fba2d1dc7994d638faaaa4d684433ee64501bde988e3bb4f8809086895',
         'e68d82518214ffae10879beb129001c7233552d69e2b544c0a17fe2dc9a6d447',
         'a793849fe790107e25a368d026baa7e2a07414f8df83e18b24f9a3d5814b6190', 20300, 20010),
        ('B', 'cc49014f84a66cfa68ae921ac71bf07010a8dacf76844f49de03029c4809a547',
         'c789f3587d02ecd3d9ca9ee0eb699120aa209c5bee88901c32d5c22068dc37b9',
         'dfe211748be090484753f73eea5be1c4abecd853d14599903f178609d03d96a1', 20500, 20300)]:
        path = HERE / f'independent-{name}-prefix.json'
        pin(path, checks['actual_prefix_receipt_sha256'][str(path)])
        prefix = read(path)
        assert prefix['validator_sha256'] == implementations[str(BASE / 'validate.py')]
        assert prefix['status'] == 'checks_passed_prefix_only_no_physical_chain_acceptance'
        assert prefix['prefix_steps'] == prefix['steps_verified'] == 2
        assert prefix['completed_execution_verified'] is False
        assert prefix['physical_origin_established_by_separate_admission'] is True
        assert prefix['actual_initial_physical_accuracy_certified_field_present'] is False
        envelope_path = ROOT / f'helper/x8-production-initial-admission/production-{name}-admitted.json'
        pin(envelope_path, envelope_sha)
        envelope = read(envelope_path)
        assert envelope['accepted'] is True and envelope['profile'] == name
        assert envelope['initial_artifact_sha256'] == prefix['initial_physical_boundary_sha256'] == initial_sha
        assert envelope['conditional_generation_scope_closed_by_this_separate_admission'] is True
        assert envelope['independent_author_review_sha256'] == '740306cd63b8398fde05df8723742c0265140f5c107cb89d034ad7ee45f1964e'
        for data in [prefix, envelope]:
            for field in ['source_pins', 'artifact_sha256', 'implementation_sha256']:
                graph(data, field)
        binding_path = ROOT / f'hierarchy-transport/x8-production-{name}-halfsteps-v11/run-binding.json'
        pin(binding_path, run_sha)
        binding = read(binding_path)
        assert binding['initial_sha256'] == initial_sha
        assert binding['physical_source_admission_required'] is True
        assert binding['conditional_initial_explicitly_authorized'] is True
        profiles[name] = {'initial_artifact_sha256': initial_sha,
                          'source_admission_path': str(envelope_path), 'source_admission_sha256': envelope_sha,
                          'run_binding_sha256': run_sha, 'local_target_digits': digits,
                          'guard_digits': 300, 'required_final_absolute_digits': gate,
                          'expected_complete_steps': 12, 'actual_saved_prefix_steps_independently_replayed': 2,
                          'prefix_receipt_sha256': sha(path), 'complete_execution_admitted_here': False}
    pin(BASE / 'implementation-pins.json', sha(BASE / 'implementation-pins.json'))
    pin(Path(__file__).resolve(), sha(Path(__file__).resolve()))
    result = {
        'schema': 'vakint.X8-rpf-v11-chain-validator-independent-review.v1',
        'accepted': True,
        'status': 'passed_for_frozen_physical_X8_chain_validator',
        'validator_sha256': implementations[str(BASE / 'validate.py')],
        'implementation_sha256': implementations,
        'source_pins': dict(sorted(pins.items())),
        'scope': 'Frozen A/B v11 chain-validator code, exact profile/source-envelope bindings, generic v4 metadata and numerical checks, conditional-state preservation, prefix/check-only separation and complete-execution gates. The actual completed A/B twelve-step acceptance receipts must still be produced by this validator and separately pinned by the final publisher.',
        'production_profiles': profiles,
        'generic_v4_review_sha256': sha(HERE / 'v4-independent-review.json'),
        'contract_checks_sha256': sha(HERE / 'contract-checks.json'),
        'independent_checks': {
            'highlevel_negative_controls': 110,
            'acceptance_mode_combinations': 96,
            'generic_v4_negative_controls': 71,
            'generic_v4_actual_initial_and_resume_steps': 4,
            'highlevel_actual_AB_prefix_steps': 4,
            'exact_raw_to_regular_entries_per_profile': 1764,
            'full_input_and_output_box_containments_per_step': 252,
            'complete_ledger_and_total_width_gates_tested_by_actual_AST': True,
        },
        'source_admission_and_scope': [
            'Each profile fixes its actual initial, source-envelope and immutable run-binding digests. A/B envelope swapping is rejected. The old initial consumer rechecks the complete physical primitive/matching/native invocation proof graph; the envelope-author review is separately fixed.',
            'The two actual initial artifacts intentionally omit physical_accuracy_certified. That absence is admitted only as a source-bound historical metadata exception, never inferred to mean false or physical validity. The separate admitted envelope establishes physical origin.',
            'Every produced/resumed boundary and complete receipt must retain pending=true and explicit physical_accuracy_certified=false. Contradictory alternate whole-period markers reject. The original conditional source artifacts are never rewritten.',
            'Generic v4 preserves all numerical operations and mathematical inequalities. Its metadata policy must be explicitly conditional_v11, and the generic checker never admits physical origin by itself.',
            'Full acceptance requires all twelve exact steps, completion/progress agreement, the actual final total-radius gate, all review authorities and separate physical initial admission. Prefix mode, including a twelve-step prefix, and check-only mode cannot emit physical-chain acceptance.',
        ],
        'resolved_findings': [
            'The generic diagnostic now records the initial physical flag as absent with value null rather than implying false.',
            'The default generic policy rejects conditional-schema or pending/malformed markers unless the caller explicitly selects conditional_v11.',
            'The highlevel complete-receipt and initial guards now reject contradictory alternate whole-period markers, matching the generic boundary policy.',
        ],
        'findings': [],
        'complete_production_A_or_B_chain_admitted_by_this_review': False,
        'future_actual_receipts_require_complete_data_validation_and_separate_hash_pins': True,
        'native_preparer_HPL_or_transport_calls_by_reviewer': 0,
        'producer_files_modified': False,
        'A49_and_v10_accepted_bytes_preserved': True,
        'whole_PR11d_20000_accuracy_claimed': False,
        'final_PR11d_precision_cap_unchanged': 200,
        'IBP_scope': 'Inherits the authenticated prepared X8 differential/IBP system and accepted physical source envelopes; does not independently regenerate IBP relations.',
    }
    for p, h in pins.items(): assert sha(p) == h, p
    target = HERE / 'review.json'
    with target.open('x') as stream: json.dump(result, stream, indent=2); stream.write('\n')
    print(str(target)); print(sha(target)); print('source pins', len(pins))


if __name__ == '__main__':
    main()
