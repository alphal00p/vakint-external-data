#!/usr/bin/env python3
"""X8 V=epsilon*W endpoint adapter using the independently reviewed native kernel."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,time
from flint import arb,acb,ctx,fmpq
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(HERE));from evaluate import System
sys.path.insert(0,str(ROOT/'ancestor-flows'));from native_endpoint import prepare,enclose
if not __debug__:raise RuntimeError('Assertions required')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--digits',type=int,required=True);p.add_argument('--order',type=int,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--compare-python',action='store_true');a=p.parse_args();ctx.dps=a.digits;system=System();start=time.monotonic()
    assert not a.output.exists(),'Accepted output may not be overwritten'
    review=ROOT/'ancestor-flows/endpoint-review/native/review.json';kernel=ROOT/'ancestor-flows/endpoint-native';source=ROOT/'ancestor-flows/endpoint_native.c'
    record=json.loads(review.read_text());prefix=a.output.with_suffix('');inputpath=prefix.with_suffix('.in');nativepath=prefix.with_suffix('.native.json');metadata=prepare(system,a.order,a.digits,4,inputpath)
    result=subprocess.run([str(kernel),str(inputpath),str(nativepath)],capture_output=True,text=True,timeout=1800);assert result.returncode==0,result.stderr
    data=json.loads(nativepath.read_text());assert data['dimension']==252 and data['order']==a.order and data['working_bits']==ctx.prec and data['radius_power_of_two']==4
    values,tail=enclose(system,data,fmpq(1,16));checks=[]
    if a.compare_python:
        reference,receipt=system.evaluate(a.order,fmpq(1,16));assert len(values)==len(reference)==252
        assert all(x.overlaps(y) for x,y in zip(values,reference));checks.append({'independent_python_reference_components':252,'all_complex_ball_overlaps':True})
    output={'schema':'vakint.pr11d.native-analytic-endpoint-adjoint.v1','definition':'V=epsilon*W; Vprime=-VA; finite PR11d=[epsilon^1](V dot original rawY)','epsilon_range':[0,5],'eta_center':['0','1/16'],'dimension':252,'source_polynomial_sha256':system.source_hash,'endpoint_projector_proof_sha256':system.projector_hash,'native_source_sha256':sha(source),'native_binary_sha256':sha(kernel),'native_review_sha256':sha(review),'adapter_sha256':sha(Path(__file__)),'generic_adapter_sha256':sha(ROOT/'ancestor-flows/native_endpoint.py'),'input_metadata':metadata,'native_input':str(inputpath),'native_output':str(nativepath),'native_output_sha256':sha(nativepath),'order':a.order,'working_bits':ctx.prec,'native_seconds':data['native_seconds'],'peak_rss_bytes':data['peak_rss_bytes'],'seconds':time.monotonic()-start,'validation':checks,**tail,'complex_balls':[[v.real.str(a.digits+8,more=True),v.imag.str(a.digits+8,more=True)] for v in values],'whole_PR11d_20000_accuracy_claimed':False}
    a.output.write_text(json.dumps(output,indent=2)+'\n');print('X8 native adjointPASS',data['native_seconds'],'sec; max tail',tail['maximum_tail_radius'])
if __name__=='__main__':main()
