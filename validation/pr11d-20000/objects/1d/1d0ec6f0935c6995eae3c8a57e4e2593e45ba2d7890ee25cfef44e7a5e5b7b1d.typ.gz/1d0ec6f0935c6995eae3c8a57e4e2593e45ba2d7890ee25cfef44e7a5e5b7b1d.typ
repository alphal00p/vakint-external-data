= Native contracted Frobenius pilot input

All preparer output and numerical work remains under this helper namespace.
The accepted ../contracted.py reference is immutable.

Plaintext whitespace format, followed by newline-delimited Arb constants:

1. `FROB_V1 dim logs blocks constant_count n_min n_max d_degree b_degree polynomial_entry_count residue_entry_count startup_entry_count bits digits max_order check_every`
2. z0 as `real_numerator imaginary_numerator positive_denominator`.
3. Positive integer polynomial_scale L.
4. Positive Arb lower bound for abs(L*d(t)) on0<=t<=1, as one whole line.
5. dim integers block_of[i]. All blocks nonempty, size<=3, increasing dependency order.
6. d_degree+1 Gaussian integer lines for L*d_k, including d0=L real.
7. Each polynomial coupling: `row column` then b_degree+1 Gaussian integer lines for L*B_k[row,column].
8. Positive integer residue_scale LR, then residue_entry_count lines `row column numerator_integer`, representing R=Rint/LR.
9. startup_entry_count lines `power log state constant numerator positive_denominator`, representing exact REAL rational startup coefficient maps before z0/log scaling.
10. dim lines `gauge_weight gauge_scale_numerator positive_denominator`, giving originalY_i=z0^weight*scale*J_i.
11. constant_count whole lines `real_arb_ball|imaginary_arb_ball`.

Bounds: dim<=252, logs<=16, blocks<=dim, constant_count<=dim; startup powers integer n_min..n_max with -32<=n_min<=n_max<=32 and n_min<=0; max degrees<=16, sourceX8 ddegree7/bdegree12. All startup powers below n_min are exactly zero by the prepared source proof. n_max contains all required resonances. Numerical iteration starts n_max+1. The exact source audit/preparer binds the startup maps; no arbitrary independent startup balls are accepted. Enforce all input shape/ordering constraints and exact B0/L=R identity. Native seed consistency need not replay all5million startup matrix identities: preparer/validation binds the already independent exact-Q receipt and actual input hash.

Contract startup maps with the SAME constant balls into one temporary power slice at a time, then translate each log polynomial using z0^n sum_{ell>=k}binom(ell,k)Log(z0)^(ell-k). Log branch is principal. Ringlength max(ddegree,bdegree)+1 is safe; normalize negative modulo. Accumulate every startup power into the endpoint sum, including powers older than the finite ring; retain only the recent translated slices in the ring. Total at t=1 is the sum of log0 coefficient vectors. Only this initial translation uses AP×AP products; the recurrence uses integer/rational coefficient multipliers.

Equation: t*d(t)*J'=B(t)*J, d0=1, R=B0. For n>n_max and every log coefficient, first form integer-scaled forcing:
Fint=sum_{k>=1}LintBk*C_(n-k) - sum_{k>=1}Lintdk*((n-k)C_(n-k)+(ell+1)C_(n-k,ell+1)).
Use signed n-k factors. Then log degrees descending and blocks ascending solve
(n*LR*I-Rint_bb)*C_n,ell,b = (LR/L)*Fint - LR*(ell+1)*C_n,ell+1,b + sum_earlier Rint_ba*C_n,ell,a.
Blocksize<=3 permits exact integer adjugate/determinant per n/block, reused for every log. The implementation uses g=gcd(L,LR), p=LR/g, q=L/g: its RHS is p*Fint + q*(-LR*(ell+1)*C_higher + Rint_off*C_known), and it divides the adjugate product by q*determinant. This is algebraically the same solve without intermediate rational rounding. Offblock sums and adjugate multiplication use small integer addmul; divide once by determinant. Independent forcing components can use at most4 OpenMP workers. Do not overwrite ring history until all forcing reads complete.

Retain unchanged singular residual certificate from ../contracted.py and its bound-review receipt:
Q=t*d*P_m'-B*P_m has powers m+1..m+max(ddegree,bdegree). Form its scaled integer coefficient balls from history, sum magnitudes weighted by sup[t*abs(logt)^ell]=(ell/e)^ell (ell0=>1), then divide by lower abs(L*d). This gives F*t^(m-1) error forcing. Bound regular H=(B-R*d)/(t*d) after EXACT cancellation: coefficients numerator LR*(LB_k)-Rint*(Ld_k), k>=1, divided by LR*lower_abs(L*d). Add abs(Rint)/LR to get M. Per block use mu=max internal row sum; if m-mu>0, budget=max_row(F+incoming*M*priorbudgets)/(m-mu), outward rounded. Max budget must be<10^-digits/100. Enlarge each complex component by its block budget. Then restore original gauge exactly and emit both arrays.

Emit same useful JSON fields as Python: tail flag, dimensions, order, bits/digits, timings, peakRSS, normalized_J_values, original_Y_values, explicit synthetic/no-physical-claim metadata. Total widths remain a separate acceptance check. Cap addressspace2GiB, workers4, and document OPENBLAS_NUM_THREADS=1. Native exact degree/range/pole assumptions belong to prepared input metadata; no physical precision claim from working bits alone.

Startup may stop at a negative power such as -1; the next nonresonant iteration is then n=0. The engine rejects any encountered zero block determinant and never skips it. A certified selected analytic subspace may omit a fractional branch only when its source certificate explicitly proves the branch coefficient zero; there is no unconditional integer-spectrum gate or implicit mode truncation.
