#!/usr/bin/env python3
"""Seal the independent H5/H6 exact audit and its analytic justifications."""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent.parent/'p853'/'higher-order'
replay=json.loads((HERE/'independent-exact.json').read_text())
independent=json.loads((HERE/'mzv'/'independent-reductions.json').read_text())
red={tuple(row['indices']):{tuple(t['powers']):F(*t['rational']) for t in row['terms']} for row in independent['reductions']}
for row in replay['coefficients']:
    result={(0,0,0,0):F(*row['constant'])}
    for term in row['before_MZV_reduction']:
        for mon,c in red[tuple(term['indices'])].items():
            result[mon]=result.get(mon,F(0))+F(*term['rational'])*c
    result={m:c for m,c in result.items() if c}
    assert result=={tuple(t['powers']):F(*t['rational']) for t in row['terms']}

proof={
  'definition': 'H(e)=3F2(1,-e,1-2e;2-4e,2-2e;1)',
  'conventions': 'H_N(a1,...,ad)=sum_{N>=n1>...>nd>=1} product n_j^(-a_j); H_N(empty)=1. zeta(a)=lim H_N(a) for a1>=2. The associated iterated-integral word is 0^(a1-1)1 ... 0^(ad-1)1.',
  'summand_factorization': 'The n>=1 hypergeometric term is -e/[n(n+1)^2] times S_n(e), where S_n=product_{j=1}^{n-1}(1-e/j)*(1-2e)/(1-2e/(n+1))*product_{j=2}^{n+1}(1-4e/j)^(-1). This follows directly from Pochhammer products, including the cancellation of (1)_n/n!.',
  'logarithm': '[e^k] log S_n = ((4^k-1)H_n(k)+n^(-k)+(4^k+2^k)(n+1)^(-k)-(4^k+2^k))/k. With m=n+1 this is exactly the producer formula. The sign outside the sum is -e.',
  'termwise_expansion': 'For |e|<=1/16, |S_n(e)| <= (6/5) exp((39/112) H_{n+1}(1)): the numerator product contributes exp(H_{n-1}/16), (1-2e)/(1-2e/(n+1)) contributes at most 6/5, and -log(1-1/(4j)) <= (2/7)/j for j>=2 bounds the remaining inverse product. Hence |S_n|/[n(n+1)^2]=O(n^(-3+39/112)) uniformly. All factors are holomorphic on an open neighborhood of this disk. Uniform absolute convergence and Cauchy coefficient extraction justify summing every Taylor coefficient.',
  'exponential_coefficients': 'The independent replay uses [e^q] exp(sum_{k>=1}L_k e^k)=sum_{sum k*m_k=q} product L_k^(m_k)/m_k!, not the producer differential recurrence. Products of single harmonic sums are expanded by ordered partitions of their labeled factors, including equal-index blocks exactly once per labeled partition.',
  'partial_fractions': 'For a,b>=1, the coefficient of n^(-p), 1<=p<=a, in 1/[n^a(n+1)^b] is (-1)^(a-p)*binom(a+b-p-1,a-p). The coefficient of (n+1)^(-p), 1<=p<=b, is (-1)^a*binom(a+b-p-1,b-p). These follow from local binomial expansions. The independent code also verifies each used identity exactly after clearing the denominator.',
  'finite_cutoff_n_pole': 'For nonempty w, sum_{n=1}^N H_n(w)/n^p = H_N(p,w)+H_N(p+w1,w_tail). For w empty it is H_N(p), with no boundary subtraction.',
  'finite_cutoff_shifted_pole': 'For nonempty w, sum_{n=1}^N H_n(w)/(n+1)^p = H_{N+1}(p,w). For w empty it is H_{N+1}(p)-1. This is the origin of the constant boundary terms in the producer code.',
  'divergent_cancellation': 'Before taking limits, replace H_{N+1}(p,w) by H_N(p,w)+(N+1)^(-p)H_N(w). Every replacement error is O((log N)^depth(w)/N), hence tends to zero even for p=1. Both independent and producer algebra cancel the coefficient of every leading-one word exactly. Only convergent MZVs remain. No independently divergent sum is assigned a numerical value.',
  'convergent_mzv_relations': 'Stuffle follows by ordering and identifying finite sum indices. Shuffle follows by partitioning products of iterated-integral simplexes; positional interleavings preserve multiplicities. Reflection t->1-t reverses and complements the 0/1 word, giving the producer duality with this index convention.',
  'leading_one_regularization_proof': 'For every admissible b, C_b=sum_{n>=1}(zeta(b)-H_{n-1}(b))/n converges. Thus H_N(1,b)=H_N(1)*zeta(b)-C_b+o(1), while Li_(1,b)(z)=zeta(b)*(-log(1-z))-C_b+o(1) as z->1-. The cutoff error H_N(1)*(H_N(b)-zeta(b)) and the analogous Abel error both vanish. The only divergent word in the product of (1) with b is (1,b), with coefficient one on both the stuffle and shuffle sides. Their finite remainders therefore agree, proving the exact implemented stuffle((1),b)-shuffle((1),binary(b)) relation without an arbitrary finite-part convention.',
  'generators': 'The only even single-zeta substitutions are zeta(4)=(2/5)zeta(2)^2 and zeta(6)=(8/35)zeta(2)^3, following from their elementary pi-power values. zeta(3),zeta(5),zeta(7) are retained as formal generators. No assertion of algebraic independence is needed to deduce the resulting identities.',
  'linear_algebra': 'At each weight 2,...,7 the coefficient matrix has full column rank 1,2,4,8,16,32; the augmented matrices have the same ranks. The source checks an identity pivot block, so every admissible MZV is determined. An independent Fraction Gaussian-elimination replay matches all 63 reductions through weight 7. Using this independent map on the independently derived unreduced H coefficients again gives exactly H1,...,H6.'
}
source_files=['derive_h.py','mzv.py','H-through-epsilon5.json','derive_h_weight7.py','mzv_weight7.py','H-through-epsilon6.json']
artifacts=['independent_exact.py','independent-exact.json','mzv/independent_mzv_check.py','mzv/independent-reductions.json','finalize_review.py']
report={
  'schema':'vakint.pr11d.p853-H5-H6-independent-review.v1',
  'status':'passed_exact_H1_through_H6',
  'result_H5':'1094/5*zeta2^3+81*zeta3^2-1035*zeta5-90*zeta2*zeta3+303/5*zeta2^2+27*zeta3+3*zeta2-42',
  'result_H6':'3078*zeta7+198*zeta2*zeta5+1818/5*zeta2^2*zeta3-1094*zeta2^3-405*zeta3^2+621*zeta5+54*zeta2*zeta3+303/5*zeta2^2+27*zeta3+3*zeta2-123',
  'exact_checks':{
    'producer_H1_through_H6_coefficient_maps_matched':True,
    'producer_report_source_hashes_verified':True,
    'finite_direct_Pochhammer_coefficient_checks':replay['finite_Pochhammer_coefficient_checks'],
    'finite_stuffle_identity_checks':independent['finite_sum_stuffle_checks_N8'],
    'MZVs_independently_reduced_through_weight7':len(red),
    'independent_Fraction_reductions_applied_to_independent_H_expansion':True,
    'source_modules_imported_by_H_derivation_replay':False,
    'PSLQ_used':False
  },
  'proof':proof,
  'reviewed_source_sha256':{f:hashlib.sha256((SOURCE/f).read_bytes()).hexdigest() for f in source_files},
  'review_artifact_sha256':{f:hashlib.sha256((HERE/f).read_bytes()).hexdigest() for f in artifacts},
  'producer_files_modified':False,
  'scope':'Exact hypergeometric H epsilon coefficients only. Native-family and sign normalization are outside this audit and have separate prior evidence. This review establishes no numerical PR11d or 20000-digit physical enclosure.'
}
(HERE/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['status'])

if __name__=='__main__':pass
