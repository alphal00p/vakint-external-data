#!/usr/bin/env python3
"""Independent high-precision native-flow versus public API/HPL validation.

Both algorithms' complete coefficient enclosures are compared. The native flow
is converted from its raw convention to FMFT once using bounded Euler arithmetic.
Integer ratios preserve every bit of the public API's central values and errors.
"""
import argparse,hashlib,json,sys
from pathlib import Path
from flint import arb,ctx,fmpq
from endpoint_sources import load_native_endpoints,sha
sys.set_int_max_str_digits(300000)

def exact_binary(item):
    value=item['exact_binary_value']
    return arb(fmpq(int(value['numerator']),int(value['denominator'])))

def api_ball(row):
    center=exact_binary(row['numerical_value']);component=row['precision']['real']
    error=exact_binary(component['absolute_error'])
    if not center.is_finite() or not error.is_finite() or error.lower()<0:raise ValueError('Invalid API center/error rationals')
    return center+arb(0,error.upper())

def fmft_values(jet,loops):
    first,last=jet.first_power,jet.last_power
    exponent=loops*arb.const_euler();ee=[arb(1)]
    for n in range(1,last-first+1):ee.append(ee[-1]*exponent/n)
    return {p:sum((jet.coefficient(q)*ee[p-q] for q in range(first,p+1)),arb(0)) for p in range(first,last+1)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--endpoints',required=True);ap.add_argument('--endpoints-sha256',required=True)
    ap.add_argument('--api',action='append',required=True,help='Canonical source identity=accepted API artifact JSON')
    ap.add_argument('--first-power',type=int,required=True);ap.add_argument('--last-power',type=int,required=True)
    ap.add_argument('--working-digits',type=int,default=20400);ap.add_argument('--minimum-agreement-digits',type=int,default=20000)
    ap.add_argument('--output',required=True);args=ap.parse_args()
    if not __debug__:raise RuntimeError('Validation requires assertions enabled')
    output=Path(args.output)
    if output.exists():raise ValueError('Preserve earlier validation evidence; choose a new output path')
    if args.minimum_agreement_digits<1 or args.working_digits<args.minimum_agreement_digits+20:
        raise ValueError('A fixed validation guard is required')
    ctx.dps=args.working_digits;ctx.threads=1
    paths={}
    for value in args.api:
        symbol,sep,path=value.partition('=')
        if not sep or not symbol or symbol in paths:raise ValueError('Each canonical identity needs one API artifact')
        paths[symbol]=Path(path)
    jets,source=load_native_endpoints(args.endpoints,args.endpoints_sha256,{s:(args.first_power,args.last_power) for s in paths})
    results=[];artifacts={};threshold=(arb(10)**-args.minimum_agreement_digits).lower()
    for symbol,path in paths.items():
        data=json.loads(path.read_bytes());loops=data['loop_count']
        if type(loops) is not int or loops<1 or data['normalization']!='FMFTandMATAD':
            raise ValueError('Independent API source must preserve its recorded FMFT convention')
        by_order={}
        for row in data['coefficients']:
            p=row['epsilon_power']
            if p in by_order:raise ValueError('Duplicate public API coefficient order')
            by_order[p]=row
        fmft=fmft_values(jets[symbol],loops)
        for p,x in fmft.items():
            if p not in by_order:raise ValueError('Independent API coefficient is unavailable: '+symbol+f' epsilon^{p}')
            y=api_ball(by_order[p]);difference=abs(x-y).upper()
            if not x.overlaps(y):raise ValueError('Independent bounded algorithms disagree: '+symbol+f' epsilon^{p}; '+(x-y).str(30))
            if x.contains(0) or y.contains(0):
                if difference.upper()>threshold:raise ValueError('Independent uncertain-zero absolute accuracy is insufficient')
                agreed={'absolute_accuracy_digits_lower_bound':args.minimum_agreement_digits}
            else:
                relative=difference/min(abs(x).lower(),abs(y).lower())
                if relative.upper()>=threshold:raise ValueError('Independent relative accuracy is insufficient: '+symbol+f' epsilon^{p}')
                agreed={'relative_accuracy_digits_lower_bound':int((-relative.log()/arb(10).log()).lower().floor().fmpz())}
            results.append({'symbol':symbol,'epsilon_power':p,'bounded_balls_overlap':True,**agreed})
        artifacts[symbol]={'path':str(path.resolve()),'sha256':sha(path),'master_id':data['master_id'],'family_sha256':data['family_sha256'],'powers':data['powers']}
    receipt={'schema':'vakint.independent-native-endpoints-versus-public-API.v1','accepted':True,'source':source,'independent_APIs':artifacts,
      'conversion':'native_raw to FMFTandMATAD with exp(loop_count*EulerGamma*epsilon) exactly once, using outward Arb arithmetic',
      'working_decimal_digits':args.working_digits,'required_agreement_digits':args.minimum_agreement_digits,'checks':results,
      'validator_sha256':sha(Path(__file__)),'whole_PR11d_accuracy_claimed':False}
    output.write_text(json.dumps(receipt,indent=2)+'\n')
    print('PASS:',len(results),'independent bounded endpoint/API coefficient comparisons')
if __name__=='__main__':main()
