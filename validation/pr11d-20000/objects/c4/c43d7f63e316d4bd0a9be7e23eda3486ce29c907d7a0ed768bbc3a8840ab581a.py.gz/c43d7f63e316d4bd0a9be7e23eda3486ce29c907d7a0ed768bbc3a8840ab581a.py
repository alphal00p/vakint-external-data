#!/usr/bin/env python3
"""Exact read-only structural audit of the prepared X8 connection.

No sampled master values enter this analysis.  Polynomial arithmetic is FLINT
over Q[epsilon, eta], and all source expressions are parsed through a restricted
AST.  Outputs live beside this helper, never in the producer source tree.
"""
import ast
import hashlib
import json
from pathlib import Path

from flint import fmpq_mpoly_ctx

HERE = Path(__file__).resolve().parent
SOURCE = Path('/shared/codex-2/vacuum_masters/MASTERS/4L/artifacts/X8-Kira-derivative-closure-v1/prepared-system.json')
CTX = fmpq_mpoly_ctx.get(('e', 'x'))
ONE = CTX.constant(1)
ZERO = CTX.constant(0)


class Rat:
    def __init__(self, num, den=ONE):
        if isinstance(num, int):
            num = CTX.constant(num)
        if not den:
            raise ZeroDivisionError
        g = num.gcd(den)
        self.num, self.den = num // g, den // g
        leading = self.den.leading_coefficient()
        self.num, self.den = self.num / leading, self.den / leading

    def __add__(self, other):
        return Rat(self.num * other.den + other.num * self.den, self.den * other.den)

    def __neg__(self):
        return Rat(-self.num, self.den)

    def __sub__(self, other):
        return self + -other

    def __mul__(self, other):
        return Rat(self.num * other.num, self.den * other.den)

    def __truediv__(self, other):
        return Rat(self.num * other.den, self.den * other.num)

    def __pow__(self, power):
        if power < 0:
            return Rat(self.den ** -power, self.num ** -power)
        return Rat(self.num ** power, self.den ** power)

    def degree_x(self):
        return int(self.num.degrees()[1] - self.den.degrees()[1]) if self.num else None

    def coefficient_at_infinity(self):
        def leading_x(poly):
            degree = poly.degrees()[1]
            return CTX.from_dict({(e, 0): c for (e, x), c in poly.to_dict().items() if x == degree})
        return Rat(leading_x(self.num), leading_x(self.den))

    def __str__(self):
        return f'({self.num})/({self.den})'


def parse(source, epsilon_symbol, eta_symbol):
    source = source.replace(epsilon_symbol, 'e').replace(eta_symbol, 'x').replace('^', '**')
    tree = ast.parse(source, mode='eval')

    def visit(node):
        if isinstance(node, ast.Constant) and type(node.value) is int:
            return Rat(node.value)
        if isinstance(node, ast.Name) and node.id in ('e', 'x'):
            return Rat(CTX.gen(0 if node.id == 'e' else 1))
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
            return -visit(node.operand)
        if isinstance(node, ast.BinOp):
            left = visit(node.left)
            if isinstance(node.op, ast.Pow):
                power = node.right
                if isinstance(power, ast.Constant) and type(power.value) is int:
                    return left ** power.value
                if isinstance(power, ast.UnaryOp) and isinstance(power.op, ast.USub) and isinstance(power.operand, ast.Constant) and type(power.operand.value) is int:
                    return left ** -power.operand.value
                raise ValueError('only explicit integer powers are accepted')
            right = visit(node.right)
            if isinstance(node.op, ast.Add):
                return left + right
            if isinstance(node.op, ast.Sub):
                return left - right
            if isinstance(node.op, ast.Mult):
                return left * right
            if isinstance(node.op, ast.Div):
                return left / right
        raise ValueError(ast.dump(node))

    return visit(tree.body)


def main():
    data = json.loads(SOURCE.read_text())
    matrix = [[parse(v, data['epsilon_symbol'], data['variable']) for v in row] for row in data['differential_matrix']]
    # eta=1/z, I_i=z^w_i J_i, using engineering mass dimension.
    weights = [sum(powers) - 8 for powers in data['basis']]
    residue = [[Rat(0) for _ in matrix] for _ in matrix]
    defects = []
    epsilon_poles = []
    for i, row in enumerate(matrix):
        for j, value in enumerate(row):
            if not value.num:
                continue
            power = -value.degree_x() - 2 + weights[j] - weights[i]
            if power < -1:
                defects.append({'row': i, 'column': j, 'infinity_z_power': power})
            if power == -1:
                residue[i][j] = -value.coefficient_at_infinity()
            nv = min(k[0] for k in value.num.to_dict())
            dv = min(k[0] for k in value.den.to_dict())
            if nv < dv:
                epsilon_poles.append([i, j, int(nv-dv)])
        residue[i][i] = residue[i][i] - Rat(weights[i])
    # Find a diagonal z-gauge by exact difference constraints, independently
    # of engineering dimensions.  A positive cycle excludes this gauge class.
    constraints = [(i, j, v.degree_x() + 1) for i, row in enumerate(matrix) for j, v in enumerate(row) if v.num]
    feasible_weights = [0] * len(matrix)
    for iteration in range(len(matrix)):
        changed = False
        for i, j, bound in constraints:
            if feasible_weights[j] < feasible_weights[i] + bound:
                feasible_weights[j] = feasible_weights[i] + bound
                changed = True
        if not changed:
            break
    feasible = not changed
    if feasible:
        offset = max(feasible_weights)
        feasible_weights = [v-offset for v in feasible_weights]
        assert all(feasible_weights[j]-feasible_weights[i] >= bound for i,j,bound in constraints)
        simple_residue = [[Rat(0) for _ in matrix] for _ in matrix]
        for i,row in enumerate(matrix):
            for j,v in enumerate(row):
                if v.num and -v.degree_x()-2+feasible_weights[j]-feasible_weights[i] == -1:
                    simple_residue[i][j] = -v.coefficient_at_infinity()
            simple_residue[i][i] = simple_residue[i][i]-Rat(feasible_weights[i])
    else:
        simple_residue = []
    report = {
        'schema': 'vakint.pr11d.exact-connection-helper.v1',
        'source': str(SOURCE),
        'sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        'dimension': len(matrix),
        'nonzero_entries': sum(bool(v.num) for row in matrix for v in row),
        'raw_matrix_negative_epsilon_valuations': epsilon_poles,
        'engineering_infinity_gauge_I_equals_z_power_J': weights,
        'engineering_gauge_fuchsian': not defects,
        'higher_pole_entries_after_gauge': defects,
        'infinity_residue': [[str(v) for v in row] for row in residue],
        'differential_blocks': data['differential_blocks'],
        'diagonal_fuchsian_gauge_exists': feasible,
        'diagonal_infinity_gauge': feasible_weights if feasible else None,
        'diagonal_gauge_residue': [[str(v) for v in row] for row in simple_residue],
        'numeric_master_values_used': False,
    }
    (HERE / 'exact-system-audit.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('infinity_residue','diagonal_gauge_residue','differential_blocks','higher_pole_entries_after_gauge')}, indent=2))


if __name__ == '__main__':
    main()
