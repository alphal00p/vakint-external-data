#!/usr/bin/env python3
"""Independently replay the saved 252-state rational gauge identity over Q(z)."""
import hashlib
import json
import time

from exact_system import CTX, HERE, SOURCE, Rat, parse


def epsilon_series(value, count):
    if not value.num:return [Rat(0)]*count
    def split(poly):
        entries=poly.to_dict();low=min(e for e,x in entries);high=max(e for e,x in entries)
        return int(low),[Rat(CTX.from_dict({(0,x):c for (e,x),c in entries.items() if e==k})) for k in range(low,high+1)]
    nv,numerator=split(value.num);dv,denominator=split(value.den)
    assert nv>=dv
    leading=nv-dv;out=[Rat(0)]*count;coefficients=[]
    for k in range(max(0,count-leading)):
        rhs=numerator[k] if k<len(numerator) else Rat(0)
        for j in range(1,min(k+1,len(denominator))):rhs=rhs-denominator[j]*coefficients[k-j]
        coefficients.append(rhs/denominator[0]);out[k+leading]=coefficients[k]
    return out


def inverted_derivative(value, gauge_power, gauge_ratio):
    if not value.num:return Rat(0)
    def reverse(poly):
        entries=poly.to_dict();assert all(e==0 for e,x in entries)
        degree=int(poly.degrees()[1])
        return degree,CTX.from_dict({(0,degree-x):c for (e,x),c in entries.items()})
    nd,numerator=reverse(value.num);dd,denominator=reverse(value.den)
    return -Rat(numerator,denominator)*Rat(CTX.gen(1))**(dd-nd-2+gauge_power)*gauge_ratio


def main():
    started=time.monotonic();source=json.loads(SOURCE.read_text())
    path=HERE/'augmented5.json.normalized.json';saved=json.loads(path.read_text())
    weights=[];scales=[]
    for i,row in enumerate(saved['transformation']):
        entries=[(j,text) for j,text in enumerate(row) if text!='0'];assert len(entries)==1 and entries[0][0]==i
        value=parse(entries[0][1],'masters_4l::{}::epsilon','pr11d_direct_helper::{}::z')
        num,den=value.num.to_dict(),value.den.to_dict();assert len(num)==len(den)==1
        (e,n),a=next(iter(num.items()));(f,d),b=next(iter(den.items()));assert e==f==0
        weights.append(int(n-d));scales.append(Rat(CTX.constant(a/b)))
    expanded={}
    for i,row in enumerate(source['differential_matrix']):
        for j,text in enumerate(row):
            if text!='0':expanded[i,j]=epsilon_series(parse(text,source['epsilon_symbol'],source['variable']),6)
    checked=0
    for i,row in enumerate(saved['matrix']):
        k,a=divmod(i,42)
        for j,text in enumerate(row):
            l,b=divmod(j,42);expected=Rat(0)
            if k>=l and (a,b) in expanded:
                expected=inverted_derivative(expanded[a,b][k-l],weights[j]-weights[i],scales[j]/scales[i])
            if i==j:expected=expected-Rat(weights[i])/Rat(CTX.gen(1))
            actual=parse(text,'masters_4l::{}::epsilon','pr11d_direct_helper::{}::z')
            assert not (expected-actual).num,(i,j)
            checked+=1
    result={'schema':'vakint.pr11d.augmented-gauge-exact-replay.v1','source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'normalized_source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'entries_checked':checked,'coefficient_field':'Q(z), exact FLINT rational polynomials','epsilon_orders':[0,5],'identity':'B=T^-1*(-Aaug(1/z)/z^2)*T-T^-1*Tprime','passed':True,'seconds':time.monotonic()-started}
    (HERE/'augmented-gauge-exact-replay.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))


if __name__=='__main__':main()
