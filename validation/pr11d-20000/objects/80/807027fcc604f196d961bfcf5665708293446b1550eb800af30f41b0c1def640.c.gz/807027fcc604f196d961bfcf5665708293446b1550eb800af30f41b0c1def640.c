#define _POSIX_C_SOURCE 200809L
#include <flint/arb.h>
#include <flint/flint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/resource.h>
#include <math.h>

/* Exact pseudothreshold solution, x=-3.  Jets hold [epsilon^j].
 b_n=q binomial(1-epsilon,n)(-3/4)^n;
 v_n=(-3(2-n-2epsilon)v_(n-1)-2(1-epsilon)b_n)/(4n-2+4epsilon).
 Initial v_0=(1-epsilon)/(1-2epsilon)*(q-1), q=4^(1-epsilon).
 All arithmetic, including accumulated rounding, is Arb interval arithmetic.
 */
static void upper(arb_t out,const arb_t in){arf_t t;arf_init(t);arb_get_ubound_arf(t,in,128);arb_set_arf(out,t);arf_clear(t);}
static double secs(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+1e-9*t.tv_nsec;}
static void die(const char*s){fprintf(stderr,"%s\n",s);exit(2);}
int main(int argc,char**argv){
 if(argc!=4)die("usage: sunset-jets DECIMAL_DIGITS JET_COUNT OUTPUT_JSON");
 long digits=strtol(argv[1],NULL,10);int jets=atoi(argv[2]);if(digits<20||digits>100000||jets<1||jets>16)die("unsupported bounds");
 slong prec=(slong)ceil((digits+128)*3.32192809488736234787);double start=secs();
 arb_ptr q=_arb_vec_init(jets),b=_arb_vec_init(jets),v=_arb_vec_init(jets),bn=_arb_vec_init(jets),vn=_arb_vec_init(jets),total=_arb_vec_init(jets);
 arb_t log4,tmp,num,bb,vb,a,c,tail,target,radius;arb_init(log4);arb_init(tmp);arb_init(num);arb_init(bb);arb_init(vb);arb_init(a);arb_init(c);arb_init(tail);arb_init(target);arb_init(radius);
 arb_set_ui(log4,4);arb_log(log4,log4,prec);arb_set_ui(q,4);
 for(int j=1;j<jets;j++){arb_mul(q+j,q+j-1,log4,prec);arb_neg(q+j,q+j);arb_div_ui(q+j,q+j,j,prec);}
 for(int j=0;j<jets;j++){
  arb_set(b+j,q+j);arb_set(v+j,q+j);if(j==0)arb_sub_ui(v+j,v+j,1,prec);
  for(int k=1;k<=j;k++){
   arb_set(tmp,q+j-k);if(j-k==0)arb_sub_ui(tmp,tmp,1,prec);arb_mul_2exp_si(tmp,tmp,k-1);arb_add(v+j,v+j,tmp,prec);
  }
  arb_set(total+j,v+j);
 }
 /* On |epsilon|<=1/16, |q|<=4^(17/16)<5; |v0|<=51/7.
  bb and vb bound the entire analytic epsilon-disc, not just known jet data. */
 arb_set_ui(bb,5);arb_set_ui(vb,51);arb_div_ui(vb,vb,7,128);upper(vb,vb);
 arb_set_ui(target,10);arb_pow_ui(target,target,(ulong)(digits+16),128);arb_inv(target,target,128);arb_set_ui(radius,1);arb_div_ui(radius,radius,16,128);
 long n;
 for(n=1;n<2000000;n++){
  for(int j=0;j<jets;j++){
   arb_mul_si(bn+j,b+j,2-n,prec);if(j)arb_sub(bn+j,bn+j,b+j-1,prec);arb_mul_si(bn+j,bn+j,-3,prec);arb_div_ui(bn+j,bn+j,4*n,prec);
  }
  for(int j=0;j<jets;j++){
   arb_mul_si(num,v+j,2-n,prec);if(j){arb_mul_2exp_si(tmp,v+j-1,1);arb_sub(num,num,tmp,prec);}arb_mul_si(num,num,-3,prec);
   arb_set(tmp,bn+j);if(j)arb_sub(tmp,tmp,bn+j-1,prec);arb_mul_2exp_si(tmp,tmp,1);arb_sub(num,num,tmp,prec);
   if(j){arb_mul_2exp_si(tmp,vn+j-1,2);arb_sub(num,num,tmp,prec);}arb_div_ui(vn+j,num,4*n-2,prec);arb_add(total+j,total+j,vn+j,prec);
  }
  /* bb_n <= bb_(n-1)*3*(|2-n|+r)/(4n). */
  arb_set_ui(tmp,(ulong)(16*labs(2-n)+1));arb_mul_ui(tmp,tmp,3,128);arb_div_ui(tmp,tmp,64*n,128);arb_mul(bb,bb,tmp,128);upper(bb,bb);
  /* a_n=3*(|2-n|+2r)/(4n-2-4r), c_n=2*(1+r)/(4n-2-4r). */
  arb_set_ui(a,(ulong)(8*labs(2-n)+1));arb_mul_ui(a,a,3,128);arb_div_ui(a,a,2,128);arb_div_ui(a,a,16*n-9,128);
  arb_set_ui(c,17);arb_div_ui(c,c,2,128);arb_div_ui(c,c,16*n-9,128);
  arb_mul(vb,vb,a,128);arb_addmul(vb,c,bb,128);upper(vb,vb);
  arb_ptr swap=b;b=bn;bn=swap;swap=v;v=vn;vn=swap;
  if(n>=2 && n%64==0){
   /* Future a<=3/4, b-ratio<=3/4 and c decreases. Sum tail <=3vb+12c_(n+1)bb. */
   arb_mul_ui(tail,vb,3,128);arb_set_ui(c,17);arb_div_ui(c,c,2,128);arb_div_ui(c,c,16*n+7,128);arb_mul(tmp,c,bb,128);arb_mul_ui(tmp,tmp,12,128);arb_add(tail,tail,tmp,128);upper(tail,tail);
   arb_mul_2exp_si(tmp,tail,4*(jets-1));if(arb_lt(tmp,target))break;
  }
 }
 if(n>=2000000)die("term bound exhausted");
 FILE*f=fopen(argv[3],"w");if(!f)die("cannot create output");char*bound=arb_get_str(tail,50,ARB_STR_MORE);struct rusage usage;getrusage(RUSAGE_SELF,&usage);
 fprintf(f,"{\"schema\":\"vakint.ancestor.certified-sunset-ratio-jets.v1\",\"requested_decimal_digits\":%ld,\"working_bits\":%ld,\"jet_count\":%d,\"taylor_order\":%ld,\"seconds\":%.9f,\"peak_rss_bytes\":%ld,\"epsilon_cauchy_radius\":\"1/16\",\"entire_epsilon_disc_tail_bound\":\"%s\",\"normalization\":\"native_raw/I1^2\",\"coefficients\":[",digits,(long)prec,jets,n,secs()-start,usage.ru_maxrss*1024L,bound);flint_free(bound);
 for(int j=0;j<jets;j++){
  arb_mul_2exp_si(tmp,tail,4*j);upper(tmp,tmp);arb_add_error(total+j,tmp);if(!arb_is_finite(total+j))die("nonfinite coefficient");
  char*value=arb_get_str(total+j,digits+24,ARB_STR_MORE);char*err=arb_get_str(tmp,50,ARB_STR_MORE);
  fprintf(f,"%s{\"epsilon_power\":%d,\"ball\":\"%s\",\"analytic_truncation_bound\":\"%s\",\"relative_accuracy_bits\":%ld}",j?",":"",j,value,err,(long)arb_rel_accuracy_bits(total+j));flint_free(value);flint_free(err);
 }
 fprintf(f,"]}\n");fclose(f);fprintf(stderr,"PASS sunset ratio %lddigits %djets order%ld %.3fsec\n",digits,jets,n,secs()-start);
 _arb_vec_clear(q,jets);_arb_vec_clear(b,jets);_arb_vec_clear(v,jets);_arb_vec_clear(bn,jets);_arb_vec_clear(vn,jets);_arb_vec_clear(total,jets);
 arb_clear(log4);arb_clear(tmp);arb_clear(num);arb_clear(bb);arb_clear(vb);arb_clear(a);arb_clear(c);arb_clear(tail);arb_clear(target);arb_clear(radius);flint_cleanup();return 0;
}
