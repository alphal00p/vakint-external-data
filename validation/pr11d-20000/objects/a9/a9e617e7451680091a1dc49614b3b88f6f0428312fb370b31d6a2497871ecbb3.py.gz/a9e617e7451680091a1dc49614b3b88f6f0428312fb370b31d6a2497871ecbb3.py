#!/usr/bin/env python3
"""Exact outward source replay and independent rational seed-box containment."""
import hashlib
import json
import math
import re
import resource
import sys
import time
from fractions import Fraction as Q
from pathlib import Path
from flint import arb,ctx,fmpq

if not __debug__:raise RuntimeError("Assertions required")
sys.set_int_max_str_digits(300000)
HERE=Path(__file__).resolve().parent;PR11=HERE.parents[1];PERIODS=PR11.parent
BOUNDARY=PERIODS/"bessel/ancestor-boundary";NATIVE=PR11/"helper/frobenius-transport/native"
sys.path.insert(0,str(BOUNDARY))
import pr9_boundary as producer
from expanded_boundary import ExpandedBoundary


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def decimal_box(text):
    if text.startswith('['):
        match=re.fullmatch(r'\[(?:(.*?) )?\+/- (.*?)\]',text);assert match,text[:80]
        center=Q(match[1]) if match[1] else Q(0);radius=Q(match[2])
    else:center,radius=Q(text),Q(0)
    assert radius>=0
    return center,radius


def main():
    resource.setrlimit(resource.RLIMIT_AS,(2*2**30,2*2**30));resource.setrlimit(resource.RLIMIT_CPU,(60,65))
    started=time.monotonic()
    paths={
      "source_boundary":BOUNDARY/"pr9-boundary-API20280-working20400.json",
      "native_API_bridge":BOUNDARY/"three-loop-API20280-native.json",
      "accepted_source_review":PR11/"helper/pr9-api-boundary-review/pr9-source-review-receipt.json",
      "native_input":NATIVE/"pr9-API20280-proto1000-v1.in",
      "native_metadata":NATIVE/"pr9-API20280-proto1000-v1.json",
      "native_prefix_review":HERE/"native-input-receipt.json",
      "matching":PR11/"ancestor-flows/pr9-22-matching.json",
      "inventory":BOUNDARY/"pr9-22-inventory.json",
      "assembler":BOUNDARY/"pr9_boundary.py",
      "auditor":Path(__file__)}
    hashes={k:sha(p) for k,p in paths.items()}
    expected={"source_boundary":"8b35db3637aed6c4654a8b86bd3501b6357bff64c719aa52dc352b72eb4bc9b9",
      "native_input":"1c252378c24b47753e242b04d034b4a915e6475aa0b4aef94329bde8b6c9cd5c",
      "accepted_source_review":"2190357dd5232fe4d44b056ac555a711136f0f42af31ce3a30ce613e05b9282e"}
    for k,digest in expected.items():assert hashes[k]==digest
    accepted=read(paths["accepted_source_review"])
    assert accepted["accepted_for_source_and_native_input_scope"] and accepted["source_error_quality"]=="rigorous-bound"
    assert accepted["boundary_sha256"]==hashes["source_boundary"] and accepted["native_API_bridge_sha256"]==hashes["native_API_bridge"]
    nested_pins={}
    def pin(path,digest):
        assert sha(path)==digest,path;nested_pins[str(Path(path).resolve())]=digest
    for receipt in accepted["receipts"]:
        pin(receipt["path"],receipt["sha256"]);nested=read(receipt["path"])
        for row in nested.get("artifact_sha256",{}).values():pin(row["path"],row["sha256"])
        for row in nested.get("nested_source_pins",[]):pin(row["path"],row["sha256"])
        for field in ["source_sha256","input_sha256"]:
            if isinstance(nested.get(field),dict):
                for path,digest in nested[field].items():pin(path,digest)
    data=read(paths["source_boundary"]);matching=read(paths["matching"]);metadata=read(paths["native_metadata"])
    assert data["working_decimal_digits"]==20400 and data["normalization"]=="native_raw" and data["error_quality"]=="rigorous-bound"
    assert data["matching_sha256"]==hashes["matching"] and data["inventory_sha256"]==hashes["inventory"]
    # Reproduce the accepted assembler's actual outward operations at its
    # declared precision, including exact formal cancellations and source balls.
    # This is coefficient assembly only, never a new HPL evaluation.
    ctx.dps=20400;ctx.threads=1
    factors,recipe_receipt=producer.build();assert recipe_receipt==data["source_recipe_receipt"]
    primitives,provenance,quality=producer.load_primitives(paths["native_API_bridge"])
    assert provenance==data["primitive_provenance"] and quality=="rigorous-bound"
    plan=producer.load_plan(paths["inventory"],hashes["inventory"],"masters_4l::{}::epsilon")
    compiled=ExpandedBoundary(plan,factors,max_log_power=matching["max_exact_log_degree"])
    required,_=compiled.required_primitive_orders(primitives,last_epsilon_power=1)
    assert required==data["required_raw_primitive_through"]
    values=compiled.evaluate(primitives,first_epsilon_power=-4,last_epsilon_power=1)
    values={(i,int(a),p,l):v for (i,a,p,l),v in values.items()}
    key=producer.key
    saved={}
    for row in data["coefficients"]:
        k=key(row);assert k not in saved;saved[k]=row["real_ball"]
        assert values[k].str(20408,more=True)==row["real_ball"],(k,"source row outward replay mismatch")
    assert len(saved)==557 and set(saved)=={key(r) for r in matching["all_boundary_selectors"]}
    rhs=[values[key(row)] for row in matching["selected_selectors"]]
    source_constants=[producer.dot(row,rhs) for row in producer.sparse(matching["boundary_inverse"])]
    assert len(source_constants)==132 and len(data["free_constant_balls"])==132
    assert all(value.str(20408,more=True)==text for value,text in zip(source_constants,data["free_constant_balls"],strict=True))
    # Read the ACTUAL low-precision native seed block; exact prefix replay is
    # independently recorded by native-input-receipt.json.
    lines=paths["native_input"].read_text().splitlines();tokens=lines[0].split()
    assert tokens[0]=="FROB_V1"
    dim,logs,block_count,count,nmin,nmax,dd,bd,poly_count,residue_count,startup_count,bits,digits,maxorder,every=map(int,tokens[1:])
    assert (dim,count,bits,digits,nmin,nmax)==(132,132,4319,1100,-4,-1)
    seed_offset=5+(dd+1)+poly_count*(bd+2)+1+residue_count+startup_count+dim
    assert len(lines)-seed_offset==count
    native_seed_lines=lines[seed_offset:]
    # Independently propagate the complete exact decimal boxes through B^-1.
    # No dependency cancellation or mere interval overlap is used here.
    selected_boxes=[decimal_box(saved[key(row)]) for row in matching["selected_selectors"]]
    ctx.prec=bits
    selected_balls=[arb(saved[key(row)]) for row in matching["selected_selectors"]]
    checks=[]
    for index,(row,line) in enumerate(zip(matching["boundary_inverse"],native_seed_lines,strict=True)):
        real,imag=line.split('|');assert imag=='0'
        center=Q(0);radius=Q(0)
        for j,text in enumerate(row):
            q=Q(text)
            if q:
                center+=q*selected_boxes[j][0];radius+=abs(q)*selected_boxes[j][1]
        native=arb(real)
        native_center=Q(str(native.mid().fmpq()));native_radius=Q(str(native.rad().fmpq()))
        assert native_center-native_radius<=center-radius and native_center+native_radius>=center+radius,(index,"native seed misses exact matched source box")
        recomputed=sum((selected_balls[j]*arb(fmpq(q)) for j,q in enumerate(row) if q!='0'),arb(0))
        expected_text=recomputed.str(math.ceil(bits*math.log10(2))+10)
        assert expected_text==real,(index,"native seed string replay mismatch")
        parsed=arb(expected_text)
        assert parsed.mid()==native.mid() and parsed.rad()==native.rad()
        checks.append({"constant_index":index,"exact_matched_decimal_source_box_contained":True,"outward_preparer_string_identical":True,"native_binary_midpoint_radius_identical":True})
    prefix=read(paths["native_prefix_review"])
    assert prefix["accepted"] and prefix["input_sha256"]==hashes["native_input"] and prefix["constant_count"]==132
    assert metadata["seed_binding"]==hashes["source_boundary"] and metadata["input_sha256"]==hashes["native_input"]
    for k,path in paths.items():assert sha(path)==hashes[k],(k,"changed during audit")
    for path,digest in nested_pins.items():assert sha(path)==digest
    report={"schema":"vakint.pr9.proto1000-source-and-native-seed-full-box-review.v1","accepted":True,
      "accepted_source_chain_revalidated":True,"source_error_quality":"rigorous-bound",
      "source_working_decimal_digits":20400,"source_boundary_outward_strings_reproduced_exactly":557,
      "source_matched_constant_outward_strings_reproduced_exactly":132,
      "source_recipe_count":len(factors),"required_primitive_orders":required,
      "native_working_bits":bits,"native_requested_local_tail_digits":digits,
      "all132_exact_matched_decimal_source_boxes_contained_by_native_seeds":True,
      "all132_actual_native_seed_strings_reproduced_exactly":True,"all132_seed_binary_midpoints_and_radii_identical":True,
      "proof":"For each selected input row use its literal decimal midpoint/radius as exact rationals. For each exact B^-1 row form center=sum(q_j*c_j), radius=sum(abs(q_j)*r_j). The actual native seed's binary midpoint±radius encloses both exact endpoints. Independently replay the native4319-bit operations and outward string formatter and require exact string and binary-ball equality.",
      "overlap_used_as_acceptance":False,"seed_checks":checks,
      "source_row_numeric_assembly_replayed":True,"HPL_primitive_or_native_engine_recomputed":False,
      "preparer_program_rerun":False,"subsequent_RPF_steps_or_adjoints_reviewed":False,
      "producer_or_handoff_files_modified":False,"whole_period_or_20k_claimed":False,
      "artifact_sha256":{k:{"path":str(p),"sha256":hashes[k]} for k,p in paths.items()},
      "nested_source_sha256":nested_pins,"seconds":time.monotonic()-started,
      "peak_rss_bytes":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}
    destination=HERE/"source-box-review.json";destination.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['artifact_sha256','nested_source_sha256','seed_checks']},indent=2))


if __name__=='__main__':main()
