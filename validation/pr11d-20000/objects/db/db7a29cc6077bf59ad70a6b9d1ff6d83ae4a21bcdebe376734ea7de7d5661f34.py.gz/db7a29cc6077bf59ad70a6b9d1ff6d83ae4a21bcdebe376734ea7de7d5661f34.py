#!/usr/bin/env python3
"""Bounded independent exact check: cut masks, embeddings and Fraction RREF.

Source modules are imported only after all independent reductions are computed.
No numerical approximation or PSLQ is used.
"""
from collections import Counter
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[2] / 'p853' / 'higher-order'


def compositions(n):
    if n == 0:
        return [()]
    out = []
    for mask in range(1 << (n - 1)):
        cuts = [0] + [j for j in range(1, n) if mask & (1 << (j-1))] + [n]
        out.append(tuple(b-a for a, b in zip(cuts, cuts[1:])))
    return out


def words(n):
    return sorted(w for w in compositions(n) if w[0] > 1)


def encode(w):
    result = [0] * sum(w)
    at = 0
    for k in w:
        at += k
        result[at-1] = 1
    return tuple(result)


def decode(w):
    stops = [-1] + [j for j, x in enumerate(w) if x]
    assert stops[-1] == len(w)-1
    return tuple(b-a for a, b in zip(stops, stops[1:]))


def shuffles(a, b):
    result = Counter()
    for positions in combinations(range(len(a)+len(b)), len(a)):
        occupied = set(positions)
        left, right = iter(a), iter(b)
        result[tuple(next(left) if j in occupied else next(right)
                     for j in range(len(a)+len(b)))] += 1
    return result


def stuffles(a, b):
    result = Counter()
    for size in range(max(len(a), len(b)), len(a)+len(b)+1):
        all_slots = set(range(size))
        for pa in combinations(range(size), len(a)):
            for pb in combinations(range(size), len(b)):
                if set(pa) | set(pb) != all_slots:
                    continue
                value = [0] * size
                for j, k in zip(pa, a):
                    value[j] += k
                for j, k in zip(pb, b):
                    value[j] += k
                result[tuple(value)] += 1
    return result


def dual_by_blocks(w):
    blocks = []
    for k in w:
        if k > 1:
            blocks.append([k-1, 1])
        else:
            blocks[-1][1] += 1
    return tuple(k for p, q in reversed(blocks) for k in (q+1,)+(1,)*(p-1))


def poly_product(a, b):
    out = Counter()
    for ma, ca in a.items():
        for mb, cb in b.items():
            out[tuple(x+y for x, y in zip(ma, mb))] += ca*cb
    return {m:c for m,c in out.items() if c}


def rref(rows):
    a = [[F(x) for x in row] for row in rows]
    pivots = []
    row = 0
    for col in range(len(a[0])):
        choice = next((k for k in range(row, len(a)) if a[k][col]), None)
        if choice is None:
            continue
        a[row], a[choice] = a[choice], a[row]
        divisor = a[row][col]
        a[row] = [x/divisor for x in a[row]]
        for k in range(len(a)):
            if k != row and a[k][col]:
                factor = a[k][col]
                a[k] = [x-factor*y for x,y in zip(a[k], a[row])]
        pivots.append(col)
        row += 1
        if row == len(a):
            break
    return a, pivots


known = {}
evidence = []
all_pairs = []
for weight in range(2, 8):
    ws = words(weight)
    monos = sorted(m for m in product(range(4), range(3), range(2), range(2))
                   if sum(x*y for x,y in zip(m, (2,3,5,7))) == weight)
    rows = []

    def add_row(left, right=None):
        right = right or {}
        assert all(w in ws for w,c in left.items() if c)
        assert all(m in monos for m,c in right.items() if c)
        rows.append([F(left.get(w, 0)) for w in ws]+[-F(right.get(m, 0)) for m in monos])

    for w in ws:
        left = Counter({w:1})
        left[dual_by_blocks(w)] -= 1
        add_row(left)
    for degree in range(2, weight-1):
        for a in words(degree):
            for b in words(weight-degree):
                rhs = poly_product(known[a], known[b])
                add_row(stuffles(a,b), rhs)
                left = Counter()
                for w,c in shuffles(encode(a), encode(b)).items():
                    left[decode(w)] += c
                add_row(left,rhs)
                all_pairs.append((a,b))
    for b in words(weight-1) if weight > 2 else []:
        left = stuffles((1,),b)
        for w,c in shuffles((1,),encode(b)).items():
            left[decode(w)] -= c
        add_row(left)
        all_pairs.append(((1,),b))
    generator = {2:{(1,0,0,0):F(1)}, 3:{(0,1,0,0):F(1)},
                 4:{(2,0,0,0):F(2,5)}, 5:{(0,0,1,0):F(1)},
                 6:{(3,0,0,0):F(8,35)}, 7:{(0,0,0,1):F(1)}}[weight]
    add_row({(weight,):1},generator)
    reduced, pivots = rref(rows)
    assert pivots == list(range(len(ws)))
    for i,w in enumerate(ws):
        known[w] = {m:-reduced[i][len(ws)+j] for j,m in enumerate(monos)
                    if reduced[i][len(ws)+j]}
    evidence.append({'weight':weight, 'rows':len(rows), 'rank':len(pivots),
                     'convergent_words':len(ws), 'monomial_columns':len(monos)})

# Independent exact, finite-sum stuffle verification at N=8; this is separate
# from the combinatorial reduction replay above.
def harmonic(w, n):
    if not w:
        return F(1)
    return sum((F(1, k**w[0])*harmonic(w[1:], k-1) for k in range(1,n+1)), F(0))

for a,b in set(all_pairs):
    assert harmonic(a,8)*harmonic(b,8) == sum(
        (c*harmonic(w,8) for w,c in stuffles(a,b).items()), F(0))

comparison = []
for name in ('mzv', 'mzv_weight7'):
    filename = SOURCE / (name+'.py')
    spec = importlib.util.spec_from_file_location(name, filename)
    source = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(source)
    source_known, source_evidence = source.relations()
    for w,p in source_known.items():
        lifted = {m+(0,)*(4-len(m)):c for m,c in p.items()}
        assert known[w] == lifted, (name,w,known[w],lifted)
        assert encode(w) == source.binary(w)
        assert dual_by_blocks(w) == source.dual(w)
    for a,b in set(all_pairs):
        assert stuffles(a,b) == source.stuffle(a,b)
        assert shuffles(encode(a),encode(b)) == source.shuffle(encode(a),encode(b))
    comparison.append({'source':str(filename),
                       'sha256':hashlib.sha256(filename.read_bytes()).hexdigest(),
                       'reductions_matched':len(source_known)})

serial = [{'indices':w, 'terms':[{'powers':m, 'rational':[c.numerator,c.denominator]}
                               for m,c in sorted(p.items())]}
          for w,p in sorted(known.items(), key=lambda v:(sum(v[0]),v[0]))]
output = {'schema':'independent-mzv-review-v1', 'status':'passed',
          'monomial_order':['zeta2_power','zeta3_power','zeta5_power','zeta7_power'],
          'algorithm':'cut-mask compositions; positional binary interleavings; pair embeddings for stuffle; block duality; Fraction Gaussian elimination',
          'weights':evidence, 'source_comparisons':comparison,
          'finite_sum_stuffle_checks_N8':len(set(all_pairs)),
          'reductions':serial}
(HERE/'independent-reductions.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({k:v for k,v in output.items() if k != 'reductions'}, indent=2))
