#!/usr/bin/env python3
"""Exact canonical alias proof for the seven PR9 ancestor endpoints.

The PR9d nonliteral identity is proved by an explicit determinant-one linear
change of loop momenta.  This runs no IBP reduction or numerical integration.
"""
import argparse
import hashlib
import json
from pathlib import Path

from flint import fmpq, fmpq_mat

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
# ROOT = .../pr11d/ancestor-flows.
MANIFEST = Path("/shared/codex-1/vakint_rustred/vakint-external-data/4L/manifest.json")
NATIVE = Path("/shared/codex-2/vacuum_masters/MASTERS/4L/artifacts/PR9-generic-epsilon-native-verification-v1/v2-proof.json")
RAW = ROOT / "pr9-22.json"
PINS = {
    MANIFEST: "b40adfb858f4a10852d341aab0a8550de93e3c7526b953a6c4b21cbc7bb8f9b9",
    NATIVE: "bf46ece2c03d8df288ee2a63dc2be0e43fcacee01c37d509f1215439cc8f24cd",
    RAW: "88290b3fe7015e350046044c3a93236700eb180e8141af5781fdfd5dfbfd9c88",
}
FAMILY = "693719b1bc3d2f1d4d32c9312df66ced667a542591a2ada6f6498844fc5d0de1"
CATALOG = {"PR3": ("P3",11,2), "PR4": ("P6",47,8), "PR4d": ("P11",104,17), "PR5": ("P5",35,5), "PR7": ("P7",55,10), "PR9": ("P8",79,12), "PR9d": ("P15",89,20)}
WITNESS = {
    "source_powers": [0,0,1,2,1,1,1,1,1,0],
    "canonical_powers": [0,2,1,0,1,1,1,1,1,0],
    "loop_matrix_k_equals_U_l": [[-1,0,0,0],[0,0,0,-1],[-1,0,1,0],[0,-1,0,0]],
    "active_slot_mapping": [[2,4,-1],[3,1,-1],[4,2,-1],[5,6,1],[6,5,1],[7,8,1],[8,7,1]],
}


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def load(p):
    def pairs(items):
        out = {}
        for k,v in items:
            require(k not in out, "duplicate JSON key")
            out[k] = v
        return out
    return json.loads(Path(p).read_text(), object_pairs_hook=pairs,
                      parse_constant=lambda s: (_ for _ in ()).throw(ValueError("nonfinite JSON")))


def quadratic(denominator, coordinates):
    require(set(denominator) == {"coefficients","constant"} and len(denominator["coefficients"]) == 10, "malformed quadratic")
    matrix = [[fmpq(0) for _ in range(4)] for _ in range(4)]
    for coefficient, coordinate in zip(denominator["coefficients"], coordinates):
        a,b = coordinate["left"],coordinate["right"]
        c = fmpq(coefficient)
        matrix[a][b] = c if a == b else c/2
        matrix[b][a] = matrix[a][b]
    return fmpq_mat(matrix)


def check_witness(witness, manifest, native, raw):
    require(native["source_family_sha256"] == FAMILY and native["deformed_slot_zero_based"] == 2, "native family/deformation binding mismatch")
    require(native["selected_old_basis"] == raw["basis"] and native["selected_old_differential_matrix"] == raw["differential_matrix"], "selected source differs from authenticated mapping")
    families = [f for f in manifest["families"] if f["sha256"] == FAMILY]
    require(len(families) == 1, "family not unique")
    family = families[0]
    coordinates = [{"kind":"loop_loop","left":i,"right":j} for i in range(4) for j in range(i,4)]
    require(family["coordinates"] == coordinates and family["coordinate_index_base"] == 0 and family["external_momenta"] == [] and family["loop_momenta"] == ["k1","k2","k3","k4"] and family["power_shifts"] == ["0"]*10, "family coordinate/loop convention mismatch")
    require(len(family["denominators"]) == 10 and all(d["constant"] == "-1" for d in family["denominators"]), "not the common unit-mass vacuum family")
    Q = [quadratic(d, coordinates) for d in family["denominators"]]
    vectors = []
    for matrix in Q:
        pivots = [i for i in range(4) if matrix[i,i] != 0]
        require(pivots and matrix[pivots[0],pivots[0]] == 1, "not a normalized rank-one propagator")
        v = [matrix[pivots[0],j] for j in range(4)]
        require(matrix == fmpq_mat([[a*b for b in v] for a in v]) and all(x.q == 1 for x in v), "quadratic is not the exact integral squared momentum")
        vectors.append([int(x) for x in v])
    bindings = []
    for symbol,(catalog_name,old,selected) in CATALOG.items():
        rows = [m for m in manifest["masters"] if m["name"] == catalog_name and m["family_sha256"] == FAMILY]
        require(len(rows) == 1 and rows[0]["exact_basis_expression"] == "vakint::{}::"+symbol and rows[0]["loop_count"] == 4 and rows[0]["status"] == "accepted", f"{symbol}: canonical expression/catalog binding mismatch")
        row = rows[0]
        require(native["old_from_selected_old"][old] == [str(int(i == selected)) for i in range(22)], f"{symbol}: old endpoint is not the selected unit row")
        if symbol != "PR9d":
            require(row["powers"] == native["old_basis"][old], f"{symbol}: canonical powers differ from exact old endpoint")
            method = "literal canonical ordered powers plus authenticated exact old-to-selected unit row"
        else:
            require(witness["source_powers"] == native["old_basis"][old] == native["selected_old_basis"][selected], "PR9d: source endpoint powers mismatch")
            require(witness["canonical_powers"] == row["powers"], "PR9d: canonical endpoint powers mismatch")
            method = "exact determinant-one loop routing and power-preserving active-propagator permutation"
        bindings.append({"symbol":"native::"+symbol, "catalog_name":catalog_name, "master_id":row["master_id"], "family_sha256":FAMILY, "canonical_ordered_powers":row["powers"], "old_component":old, "selected_component":selected, "selected_ordered_powers":native["selected_old_basis"][selected], "method":method})
    Urows = witness["loop_matrix_k_equals_U_l"]
    require(isinstance(Urows,list) and len(Urows) == 4 and all(isinstance(r,list) and len(r) == 4 and all(type(x) is int for x in r) for r in Urows), "loop map must be a four-dimensional integer matrix")
    U = fmpq_mat(Urows)
    require(U.det() in (-1,1), "loop map is not unimodular")
    source = witness["source_powers"]
    target = witness["canonical_powers"]
    require(len(source) == len(target) == 10 and all(type(p) is int and p >= 0 for p in source+target), "unexpected numerator or malformed power")
    edges = witness["active_slot_mapping"]
    active_source = [i for i,p in enumerate(source) if p]
    active_target = [i for i,p in enumerate(target) if p]
    require(len(edges) == len(active_source) == len(active_target) == 7 and sorted(e[0] for e in edges) == active_source and sorted(e[1] for e in edges) == active_target, "active mapping is not a complete bijection")
    checks = []
    for i,j,sign in edges:
        require(type(i) is int and type(j) is int and sign in (-1,1), "malformed signed propagator map")
        require(source[i] == target[j] and family["denominators"][i]["constant"] == family["denominators"][j]["constant"], "powers/masses not preserved")
        require(U.transpose()*Q[i]*U == Q[j], "exact transformed quadratic does not equal target")
        image = (fmpq_mat([vectors[i]])*U).tolist()[0]
        require(image == [sign*x for x in vectors[j]], "signed momentum vector identity failed")
        checks.append({"source_slot":i,"target_slot":j,"momentum_sign":sign,"power":source[i],"source_momentum_vector":vectors[i],"transformed_vector":[int(x) for x in image],"target_momentum_vector":vectors[j],"exact_quadratic_matrix_identity":True,"equal_mass_constant":"-1"})
    return {"canonical_bindings":bindings,"PR9d_witness":witness,"determinant":int(U.det()),"family_propagator_vectors":vectors,"exact_active_propagator_checks":checks,"active_quadratic_identities":7,"active_signed_vector_identities":7,"all_masses_and_powers_preserved":True,"all_loops_measure_absolute_Jacobian":1,"no_external_momenta_or_numerator_factors":True,"inactive_denominators_need_not_permute":"Slots of power zero do not occur in either integrand; no assertion of a full ten-slot family automorphism is made.","identity_consequence":"The dimensionally regulated native-raw PR9d endpoint integral equals canonical P15 for generic dimension and hence every Laurent coefficient, with no normalization factor."}


def validate():
    for p,h in PINS.items():
        require(p.is_file() and not p.is_symlink() and sha(p) == h, f"source hash mismatch: {p}")
    result = check_witness(WITNESS, load(MANIFEST), load(NATIVE), load(RAW))
    return {"schema":"vakint.pr11d.exact-seven-ancestor-canonical-bindings.v1","status":"passed_exact_canonical_bindings_and_PR9d_unimodular_routing","accepted":True,"validator_sha256":sha(Path(__file__).resolve()),"source_pins":{str(p):h for p,h in PINS.items()},"proof":result,"numerical_values_used":False,"new_IBP_reduction_performed":False,"inherited_native_IBP_mapping_scope_preserved":True,"whole_PR11d_20000_accuracy_claimed":False}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output",type=Path,required=True)
    args = p.parse_args()
    out = args.output.absolute()
    require(out.parent.resolve() == HERE and not out.is_symlink() and not out.exists(), "output must be fresh inside canonical-routing")
    receipt = validate()
    with out.open("x") as stream: json.dump(receipt,stream,indent=2,allow_nan=False);stream.write("\n")
    print(receipt["status"])
