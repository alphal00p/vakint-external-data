"""Bound one original-MMA oracle, private licenses/config only in workspace."""
from pathlib import Path
import os,subprocess,resource,time,json,hashlib,sys,signal
ROOT=Path(__file__).resolve().parent
label=sys.argv[1];wp=int(sys.argv[2]);order=int(sys.argv[3]);segments=int(sys.argv[4]);timeout=int(sys.argv[5]) if len(sys.argv)>5 else 3600
assert label.replace('-','').replace('_','').isalnum() and 100<=wp<=260 and 40<=order<=300 and 1<=segments<=48 and 30<=timeout<=3600
assert not (ROOT/(label+'-result.json')).exists()
license=ROOT/'wolfram-license/mathpass';assert license.read_text()=='!itplic.itp.unibe.ch\n' and license.stat().st_mode&0o777==0o600
cpu=min(os.sched_getaffinity(0));env=dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',WOLFRAM_USERBASE=str(ROOT/'wolfram-userbase'),WOLFRAMINIT='-pwfile '+str(license),RUSTFLOW_WOLFRAM_KERNEL='/nix/store/m4xs334vv5qlr31q6ayqr5r2x8lx43bn-mathematica-15.0.1/bin/WolframKernel',TMPDIR=str(ROOT/'tmp'))
cmd=[sys.executable,str(ROOT/'wolfram_one_thread.py'),'-noinit','-noprompt','-script',str(ROOT/'oracle.wl'),label,str(wp),str(order),str(segments)]
def limits():
 os.sched_setaffinity(0,{cpu});resource.setrlimit(resource.RLIMIT_CPU,(timeout,timeout+10))
start=time.time();log=ROOT/(label+'.log');usage0=resource.getrusage(resource.RUSAGE_CHILDREN)
with log.open('w') as stream:
 process=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,preexec_fn=limits,start_new_session=True)
 running={'pid':process.pid,'process_group':process.pid,'cpu':cpu,'command':cmd,'start_unix':start,'timeout_seconds':timeout,'memory_rss_monitor_gib':8};(ROOT/(label+'-running.json')).write_text(json.dumps(running,indent=2)+'\n')
 try:
  while True:
   try:status=process.wait(timeout=0.5);break
   except subprocess.TimeoutExpired:
    stat=Path('/proc')/str(process.pid)/'status'
    if stat.exists():
     rss_kib=int(next(line.split()[1] for line in stat.read_text().splitlines() if line.startswith('VmRSS:')))
     if rss_kib>8*1024**2:raise MemoryError('Observed kernel RSS exceeds8GiB')
    if time.time()-start>timeout:raise TimeoutError('Oracle wallclock limit')
 except (MemoryError,TimeoutError):
  os.killpg(process.pid,signal.SIGTERM)
  try:status=process.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);status=process.wait()
usage=resource.getrusage(resource.RUSAGE_CHILDREN)
receipt=dict(running,exit_code=status,elapsed_seconds=time.time()-start,user_cpu_seconds=usage.ru_utime-usage0.ru_utime,system_cpu_seconds=usage.ru_stime-usage0.ru_stime,peak_child_rss_kib=usage.ru_maxrss,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),source_sha256={str(ROOT/n):hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['run.py','oracle.wl','input.json','exact-lift.wl','upstream/diffeq_solver/DESolver.m']})
(ROOT/(label+'-process.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));print(log.read_text()[-6000:]);assert status==0 and (ROOT/(label+'-result.json')).exists()
