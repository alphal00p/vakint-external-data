#!/usr/bin/env python3
"""Independent four-loop vacuum IBP assembly and exact witness experiments.

Kira is not called. Its serialized integral IDs are decoded only as an input
codec; all derivative identities are assembled directly from the quadratic
family, and all membership claims require exact Q(epsilon,eta) row witnesses.
"""
from __future__ import annotations
import functools
import hashlib
import itertools
import json
import pathlib
import re
import sqlite3
import sys
from fractions import Fraction

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'helper'))
from exact_system import Rat, parse, CTX

ZERO = Rat(0)
ONE = Rat(1)
EPS = Rat(CTX.gen(0))
ETA = Rat(CTX.gen(1))
DIM = Rat(4) - Rat(2)*EPS
DATA = json.loads((HERE/'source/prepared-system.json').read_text())
BASIS = [tuple(x) for x in DATA['basis']]
V=((1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1),
   (1,0,-1,0),(0,1,-1,0),(1,0,-1,-1),(0,1,-1,-1),
   (1,1,-1,-1),(0,0,1,1))

@functools.cache
def rank_sector(sector):
    rows=[[Fraction(x) for x in V[i]] for i in range(10) if sector>>i&1]
    rank=0
    for column in range(4):
        pivot=next((i for i in range(rank,len(rows)) if rows[i][column]),None)
        if pivot is None:continue
        rows[rank],rows[pivot]=rows[pivot],rows[rank]
        p=rows[rank][column];rows[rank]=[x/p for x in rows[rank]]
        for i in range(rank+1,len(rows)):
            p=rows[i][column]
            rows[i]=[x-p*y for x,y in zip(rows[i],rows[rank])]
        rank+=1
    return rank

def remove_scaleless(row):
    # A denominator-free linear combination of loop momenta leaves a polynomial
    # integral in a free momentum. It vanishes in dimensional regularization,
    # even if irreducible numerator powers are present.
    return {k:v for k,v in row.items() if rank_sector(sum(1<<i for i,x in enumerate(k) if x>0))==4}

def add(row, key, value):
    if not value.num:
        return
    result = row.get(key,ZERO)+value
    if result.num:
        row[key] = result
    else:
        row.pop(key,None)

def muladd(row, other, scale):
    for k,v in other.items():
        add(row,k,v*scale)

def frac_inverse(matrix):
    n=len(matrix)
    a=[[Fraction(x) for x in row]+[Fraction(i==j) for j in range(n)] for i,row in enumerate(matrix)]
    for i in range(n):
        j=next(j for j in range(i,n) if a[j][i]); a[i],a[j]=a[j],a[i]
        v=a[i][i];a[i]=[x/v for x in a[i]]
        for j in range(n):
            if j!=i and a[j][i]:
                v=a[j][i];a[j]=[x-v*y for x,y in zip(a[j],a[i])]
    return [row[n:] for row in a]

DEN = DATA['family']['denominators']
COORDS = [(x['left'],x['right']) for x in DATA['family']['coordinates']]
Q=[[Fraction(x) for x in row['coefficients']] for row in DEN]
assert all(row['constant']=='-1' for row in DEN)
for r,v in enumerate(V):
    assert Q[r]==[Fraction(v[a]*v[b]*(1 if a==b else 2)) for a,b in COORDS],r
QI=frac_inverse(Q)
MASSES=[Rat(1)+(ETA if i==3 else ZERO) for i in range(10)]

def rational(x):
    return Rat(x.numerator)/Rat(x.denominator)

# The contraction k_j . d/dk_i D_r, expanded in denominator coordinates.
CONTRACTION={}
for i,j,r in itertools.product(range(4),range(4),range(10)):
    c=[Fraction(0)]*10
    for (a,b),q in zip(COORDS,Q[r]):
        if a==i:
            c[COORDS.index(tuple(sorted((j,b))))]+=q
        if b==i:
            c[COORDS.index(tuple(sorted((a,j))))]+=q
    d=[sum(c[k]*QI[k][s] for k in range(10)) for s in range(10)]
    constant=ZERO
    for v,m in zip(d,MASSES):
        constant=constant+rational(v)*m
    CONTRACTION[i,j,r]=(d,constant)

@functools.cache
def ibp(seed,i,j):
    """0 = int d_k_i . (k_j prod_r D_r^-seed[r]), exact generic d/eta."""
    row={}
    if i==j:add(row,seed,DIM)
    for r,n in enumerate(seed):
        if not n:continue
        raised=list(seed);raised[r]+=1
        d,c=CONTRACTION[i,j,r]
        add(row,tuple(raised),Rat(-n)*c)
        for s,v in enumerate(d):
            if v:
                p=raised.copy();p[s]-=1
                add(row,tuple(p),Rat(-n)*rational(v))
    return remove_scaleless(row)

@functools.cache
def compositions(n,k):
    if k==0:return ((),) if n==0 else ()
    if k==1:return ((n,),)
    return tuple((i,)+v for i in range(n+1) for v in compositions(n-i,k-1))

def decode(w):
    w=int(w)
    if 1<=w<=len(BASIS):return BASIS[w-1]
    # Integral ordering 2, database WEIGHTBITS=(5,4,17,13).
    pp=w&((1<<17)-1);w>>=17
    sp=w&((1<<13)-1);w>>=13
    dots=w&15;w>>=4
    nums=w&31;w>>=5
    sector=w&1023;w>>=10
    assert w==0,(w,sector)
    # The archived Kira log authenticates its intermediate propagator order.
    # Sector bits and composition ranks refer to this order, not source slots.
    perm=[1,2,3,4,5,6,7,8,0,9]
    positive=[perm[i] for i in range(10) if sector>>i&1]
    negative=[perm[i] for i in range(10) if not sector>>i&1]
    a=compositions(dots,len(positive))[pp]
    c=compositions(nums,len(negative));b=c[len(c)-1-sp]
    out=[0]*10
    for i,v in zip(positive,a):out[i]=v+1
    for i,v in zip(negative,b):out[i]=-v
    return tuple(out)

def serialize(row):
    return [{'powers':list(k),'coefficient':str(v)} for k,v in sorted(row.items())]

def coefficient(source):
    source=re.sub(r'\bd\b','(4-2*e)',source)
    return parse(source,'e','eta')

def raw_system():
    import gzip
    root=HERE/'source/raw-system'
    for path in sorted(root.glob('SYSTEM_*.gz')):
        lines=gzip.decompress(path.read_bytes()).decode().splitlines()
        n=0
        while n<len(lines):
            assert lines[n]=='Eq';ident=int(lines[n+1]);length=int(lines[n+2]);n+=3
            row={}
            for k in range(length):
                s=lines[n+k].split(); assert len(s)==6
                add(row,decode(s[2]),coefficient(s[1]))
            n+=length
            yield str(path),ident,row

def normalize(row):
    if not row:return ()
    scale=ONE/row[min(row)]
    return tuple((k,str(v*scale)) for k,v in sorted(row.items()))

def main():
    assert len(COORDS)==10 and len(Q)==10 and len(BASIS)==42
    # Check inverse independently by both multiplication orders.
    for i,j in itertools.product(range(10),repeat=2):
        assert sum(Q[i][k]*QI[k][j] for k in range(10))==int(i==j)
        assert sum(QI[i][k]*Q[k][j] for k in range(10))==int(i==j)
    db=sqlite3.connect(f'file:{HERE}/source/kira-round3.db?mode=ro',uri=True)
    assert db.execute('select * from WEIGHTBITS').fetchall()==[(5,4,17,13)]
    assert db.execute('select * from INTEGRALORDERING').fetchall()==[(2,)]
    powers={decode(x[0]) for x in db.execute('select ID from EQUATION union select ARRAYID from EQUATION')}
    trivial_path=HERE/'source/trivialsector'
    declared_trivial={int(x) for x in trivial_path.read_text().replace('\n',',').split(',') if x.strip()}
    independent_trivial={s for s in range(1024) if rank_sector(s)<4}
    assert declared_trivial==independent_trivial,(len(declared_trivial),len(independent_trivial))
    rows=list(raw_system())
    print('rows',len(rows),'integrals',len(powers),flush=True)
    # Start from bases and every independent equation's decoded leading integral.
    seeds=set(BASIS)|powers
    # Every primitive IBP has integral seed itself or seed+e_r−e_s in support.
    # Keep bounded candidates by dot/rank profile seen in this imported system.
    index={}
    for n,seed in enumerate(sorted(seeds)):
        for i,j in itertools.product(range(4),repeat=2):
            row=ibp(seed,i,j)
            if row:index.setdefault(normalize(row),(seed,i,j))
        if n%250==0:print('indexed',n,'IBPforms',len(index),flush=True)
    direct=[];unmatched=[]
    for path,ident,row in rows:
        key=normalize(row)
        if key in index:
            seed,i,j=index[key]
            direct.append({'source':path,'id':str(ident),'seed':seed,'derivative_loop':i,'vector_loop':j,'row':serialize(row)})
        else:unmatched.append({'source':path,'id':str(ident),'terms':len(row),'powers':list(row)})
    receipt={'schema':'vakint.independent-vacuum-ibp-replay.v1','complete':False,
             'input_sha256':hashlib.sha256((HERE/'source/prepared-system.json').read_bytes()).hexdigest(),
             'independent_derivative_assembly':True,'generic_dimension':'d=4-2*epsilon',
             'generic_deformation':'D3=k4^2-1-eta','Kira_invoked':False,
             'generated_seed_count':len(seeds),'primitive_ibp_count':16*len(seeds),
             'independently_proved_scaleless_sectors':len(independent_trivial),
             'raw_equation_count':len(rows),'direct_ibp_matches':direct,'unmatched':unmatched}
    (HERE/'direct-replay.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('direct',len(direct),'unmatched',len(unmatched),flush=True)

if __name__=='__main__':main()
