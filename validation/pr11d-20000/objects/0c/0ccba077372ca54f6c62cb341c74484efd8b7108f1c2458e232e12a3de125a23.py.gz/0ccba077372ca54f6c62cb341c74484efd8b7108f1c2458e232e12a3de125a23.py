#!/usr/bin/env python3
"""Bounded exact ancestor matching/startup audit; never imports a producer."""
import ast
import hashlib
import importlib.util
import json
import resource
import time
from functools import lru_cache
from pathlib import Path
from flint import fmpq, fmpq_mat, fmpq_poly

if not __debug__:
    raise RuntimeError("Exact audit requires assertions")
HERE=Path(__file__).resolve().parent
PR11=HERE.parents[1]
ANCESTORS=PR11/"ancestor-flows"
PARSER=PR11/"helper/frobenius-transport/preparation-audit/audit_startup.py"
spec=importlib.util.spec_from_file_location("independent_startup_parser",PARSER)
parser=importlib.util.module_from_spec(spec);spec.loader.exec_module(parser)
R,parse=parser.Rational,parser.parse
Z,O=R(0),R(1)
JETS=6


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def constant(n):return [R(n)]+[Z]*(JETS-1)
def add(a,b):return [x+y for x,y in zip(a,b)]
def neg(a):return [-x for x in a]
def mul(a,b):
    return [sum((a[j]*b[k-j] for j in range(k+1) if a[j].n and b[k-j].n),Z) for k in range(JETS)]
def inv(a):
    out=[a[0].inverse()]
    for k in range(1,JETS):out.append(-out[0]*sum((a[j]*out[k-j] for j in range(1,k+1)),Z))
    return out
def power(a,n):
    if n<0:return power(inv(a),-n)
    result=constant(1)
    while n:
        if n&1:result=mul(result,a)
        a=mul(a,a);n//=2
    return result


def jet_ast(node):
    if isinstance(node,ast.Constant) and type(node.value) is int:return constant(node.value)
    if isinstance(node,ast.Name):
        if node.id=="e":return [Z,O]+[Z]*(JETS-2)
        if node.id=="eta":return [R(fmpq_poly([1]),fmpq_poly([0,1]))]+[Z]*(JETS-1)
    if isinstance(node,ast.UnaryOp) and isinstance(node.op,ast.USub):return neg(jet_ast(node.operand))
    if isinstance(node,ast.BinOp):
        a=jet_ast(node.left)
        if isinstance(node.op,ast.Pow):return power(a,parser.literal_integer(node.right))
        b=jet_ast(node.right)
        if isinstance(node.op,ast.Add):return add(a,b)
        if isinstance(node.op,ast.Sub):return add(a,neg(b))
        if isinstance(node.op,ast.Mult):return mul(a,b)
        if isinstance(node.op,ast.Div):return mul(a,inv(b))
    raise ValueError(ast.dump(node))


@lru_cache(maxsize=None)
def parse_jet(text,epsilon,eta):
    text=text.replace(epsilon,"e").replace(eta,"eta").replace("^","**")
    return jet_ast(ast.parse(text,mode="eval").body)


def dense(rows,size):
    assert len(rows)==size and all(len(r)==size for r in rows)
    return fmpq_mat([[fmpq(v) for v in row] for row in rows])


def audit(name,size,base,loops,lower,maxlog):
    start=time.monotonic()
    paths={key:ANCESTORS/(name+suffix) for key,suffix in [
      ("raw_source",".json"),("augmented_source","-augmented5.json"),
      ("normalized_source","-augmented5.json.normalized.json"),
      ("polynomial","-polynomial.json"),("startup","-startup.json"),
      ("matching","-matching.json"),("groups","-groups.json")]}
    paths.update({"matching_generator":ANCESTORS/"prepare_matching.py",
                  "polynomial_exporter":ANCESTORS/"export_polynomial.py",
                  "independent_parser":PARSER,"auditor":Path(__file__)})
    hashes={key:sha(p) for key,p in paths.items()}
    raw,aug,source,poly,seed,matching,groups=[json.loads(paths[key].read_text()) for key in
      ["raw_source","augmented_source","normalized_source","polynomial","startup","matching","groups"]]
    assert len(raw["basis"])==len(raw["differential_matrix"])==base
    assert all(len(row)==base for row in raw["differential_matrix"])
    assert source["state_dimension"]==poly["dimension"]==seed["dimension"]==matching["dimension"]==size==6*base
    assert matching["base_dimension"]==poly["base_dimension"]==base
    assert matching["loop_count"]==loops and matching["jet_count"]==6
    assert poly["epsilon_range"]==[-loops,5-loops]
    assert poly["state_ordering"]==f"state={base}*(epsilon_power+{loops})+original_component"
    assert matching["normalized_power_range"]==seed["normalized_power_range"]==poly["normalized_power_range"]==[lower,-1]
    assert poly["generic_maximum_log_degree"]==matching["max_exact_log_degree"]==maxlog
    assert poly["source_normalized_connection_sha256"]==matching["source_sha256"]==hashes["normalized_source"]
    assert poly["matching_data_sha256"]==seed["source_matching_sha256"]==hashes["matching"]
    assert poly["startup_data_sha256"]==hashes["startup"]
    assert Path(aug["source"]).resolve()==paths["raw_source"].resolve()
    assert aug["matrix"]==source["matrix"] and aug["residue"]==source["residue"] and aug["transformation"]==source["transformation"]
    eps_shear=aug["epsilon_diagonal_shearing"]["transformation"]
    assert aug["epsilon_diagonal_shearing"]["success"]
    assert len(eps_shear)==size and all(len(row)==size for row in eps_shear)
    assert all(parse(text).n==parse(text).d*int(i==j) for i,row in enumerate(eps_shear) for j,text in enumerate(row))
    d=[fmpq(v) for v in poly["denominator_coefficients"]];D=fmpq_poly(d)
    assert D.degree()==poly["denominator_degree"] and d[0]==0 and d[1]!=0 and D[D.degree()]==1
    numerators={};N=[fmpq_mat(size,size) for _ in range(poly["numerator_degree"]+1)]
    for row in poly["entries"]:
        i,j=row["row"],row["column"];assert (i,j) not in numerators and 0<=i<size and 0<=j<size
        numerator=fmpq_poly();seen=set()
        for term in row["terms"]:
            k=term["z_power"];assert type(k) is int and 0<=k<len(N) and k not in seen;seen.add(k)
            q=fmpq(int(term["numerator"]),int(term["denominator"]));assert q
            numerator[k]=q;N[k][i,j]=q
        assert numerator;numerators[i,j]=numerator
    assert len(source["matrix"])==size and all(len(row)==size for row in source["matrix"])
    normalized={}
    for i,row in enumerate(source["matrix"]):
        for j,text in enumerate(row):
            q=parse(text);assert q.n*D==q.d*numerators.get((i,j),fmpq_poly()),(name,i,j,"normalized export")
            if q.n:normalized[i,j]=q
    residue=N[0]/d[1]
    for i,row in enumerate(source["residue"]):
        for j,text in enumerate(row):
            q=parse(text);assert q.n==q.d*residue[i,j]
    weights,scales,gauges=[],[],[]
    assert len(source["transformation"])==size
    for i,row in enumerate(source["transformation"]):
        assert len(row)==size
        nz=[(j,parse(text)) for j,text in enumerate(row) if text!="0"]
        assert len(nz)==1 and nz[0][0]==i
        q=nz[0][1];nn=[(k,q.n[k]) for k in range(q.n.degree()+1) if q.n[k]];dd=[(k,q.d[k]) for k in range(q.d.degree()+1) if q.d[k]]
        assert len(nn)==len(dd)==1
        weights.append(nn[0][0]-dd[0][0]);scales.append(nn[0][1]/dd[0][1]);gauges.append(q)
    assert weights==matching["gauge_weights"] and scales==[fmpq(v) for v in matching["gauge_scales"]]
    # Independently replay eta=1/z, six epsilon coefficients, and Y=T(z)J.
    # The source scalar normalization in epsilon is irrelevant to this ODE;
    # no Euler-exponential conversion is introduced by the z-only gauge.
    raw_jets=[[parse_jet(text,raw["epsilon_symbol"],raw["variable"]) for text in row] for row in raw["differential_matrix"]]
    jacobian=R(fmpq_poly([-1]),fmpq_poly([0,0,1]))
    for i in range(size):
        ei,ci=divmod(i,base)
        for j in range(size):
            ej,cj=divmod(j,base)
            expected=Z if ei<ej else jacobian*raw_jets[ci][cj][ei-ej]*gauges[j]*gauges[i].inverse()
            if i==j:expected=expected+-R(fmpq_poly([weights[i]]),fmpq_poly([0,1]))
            actual=normalized.get((i,j),Z)
            assert expected.n*actual.d==actual.n*expected.d,(name,i,j,"raw lift and gauge")
    roots={}
    for factor,count in residue.charpoly().factor()[1]:
        assert factor.degree()==1
        root=-factor[0]/factor[1];assert root.denominator==1
        roots[int(root)]=int(count)
    assert set(roots)==set(range(lower,0))
    assert roots=={b["root"]:b["width"] for b in matching["residue_blocks"]}
    identity=fmpq_mat([[int(i==j) for j in range(size)] for i in range(size)])
    change=dense(matching["generalized_eigenspace_change"],size);inverse=dense(matching["generalized_eigenspace_inverse"],size)
    assert change*inverse==identity
    transformed=inverse*residue*change;block_matrix=fmpq_mat(size,size);nilpotence=[]
    for block,stored in zip(matching["residue_blocks"],matching["nilpotent_blocks"]):
        root,offset,width=block["root"],block["start"],block["width"]
        assert len(stored)==width and all(len(row)==width for row in stored)
        nil=fmpq_mat([[fmpq(v) for v in row] for row in stored]);power_nil=fmpq_mat([[int(i==j) for j in range(width)] for i in range(width)])
        for k in range(1,width+1):
            power_nil=power_nil*nil
            if not power_nil:break
        else:raise AssertionError("Not nilpotent")
        nilpotence.append({"root":root,"nilpotence_index":k})
        for i in range(width):
            for j in range(width):block_matrix[offset+i,offset+j]=nil[i,j]+int(i==j)*root
    assert transformed==block_matrix
    print(name,"raw gauge, normalized export, residue spectrum exact PASS",flush=True)
    C={};sparse_count=0
    for row in seed["coefficients"]:
        m,l=row["normalized_z_power"],row["log_power"]
        assert lower<=m<=-1 and 0<=l<=maxlog and (m,l) not in C
        matrix=fmpq_mat(size,size);seen=set()
        for i,j,text in row["entries"]:
            assert 0<=i<size and 0<=j<size and (i,j) not in seen;seen.add((i,j))
            q=fmpq(text);assert q;matrix[i,j]=q;sparse_count+=1
        assert matrix;C[m,l]=matrix
    zero=fmpq_mat(size,size);get=lambda m,l:C.get((m,l),zero)
    def residual(m,l):
        value=(get(m,l)*m+get(m,l+1)*(l+1))*d[1]
        for k,coefficient in enumerate(N):
            previous=get(m-k,l)
            if coefficient and previous:value-=coefficient*previous
        for k in range(2,len(d)):
            previous=m+1-k
            value+=(get(previous,l)*previous+get(previous,l+1)*(l+1))*d[k]
        return value
    for m in range(lower,0):
        for l in range(maxlog+1):assert not residual(m,l),(name,m,l,"startup residual")
    assert max(l for m,l in C)==maxlog
    # The first continuation order is n=0, not n=1. Prove it by one exact step.
    resolver=(-residue).inv();assert (-residue)*resolver==identity
    for l in range(maxlog,-1,-1):
        forcing=zero
        for k in range(1,len(N)):
            previous=get(-k,l)
            if N[k] and previous:forcing+=N[k]*previous
        for k in range(2,len(d)):
            previous=1-k
            forcing-=(get(previous,l)*previous+get(previous,l+1)*(l+1))*d[k]
        C[0,l]=resolver*(forcing/d[1]-get(0,l+1)*(l+1))
        assert not residual(0,l),(name,l,"first continuation order zero")
    all_rows=[];all_labels=[]
    for m in range(lower,0):
        for l in range(maxlog+1):
            matrix=get(m,l)
            for i,row in enumerate(matrix.tolist()):
                if any(row):
                    all_rows.append([v*scales[i] for v in row])
                    all_labels.append((i%base,i//base-loops,m+weights[i],l))
    fields=("component","epsilon_power","integer_z_power","log_power")
    key=lambda label:tuple(label[f] for f in fields)
    lookup={label:row for label,row in zip(all_labels,all_rows)}
    assert len(lookup)==len(all_labels)
    selected=[key(label) for label in matching["selected_selectors"]]
    assert len(selected)==size and len(set(selected))==size
    B=dense(matching["boundary_matrix"],size);Binv=dense(matching["boundary_inverse"],size)
    assert B.tolist()==[lookup[label] for label in selected]
    assert B*Binv==identity;det=B.det();assert det
    wanted=sorted(set((label[0],label[2]) for label in selected))
    assert groups==[{"component":i,"integer_power":str(p)} for i,p in wanted]
    scoped=[(label,row) for label,row in zip(all_labels,all_rows) if (label[0],label[2]) in set(wanted)]
    assert [key(label) for label in matching["all_boundary_selectors"]]==[label for label,row in scoped]
    assert [[fmpq(v) for v in row] for row in matching["all_boundary_matrix"]]==[row for label,row in scoped]
    assert matching["other_prepared_rows_not_requested_count"]==len(all_rows)-len(scoped)
    inventory=Path(matching["inventory_path"]);assert sha(inventory)==matching["inventory_sha256"]
    inventory_data=json.loads(inventory.read_text());assert inventory_data["selected_integer_power_scope"]==groups
    assert inventory_data["loop_count"]==loops and len(inventory_data["basis"])==base
    paths["inventory"]=inventory;hashes["inventory"]=sha(inventory)
    assert matching["freeconstants"]==size
    for key,path in paths.items():assert sha(path)==hashes[key],(name,key,"changed during audit")
    proof=[
      "The independently verified normalized rational connection is Fuchsian: D has a simple zero at z=0, with R=N(0)/D'(0).",
      f"Every exact-Q startup equation for z powers {lower}..-1 and log powers 0..{maxlog} holds directly in D J'=N J.",
      f"The selected boundary coefficient matrix reconstructed from startup has a verified exact inverse, so its {size} startup columns are independent over Q.",
      f"The exact residue roots are {sorted(roots)}. Therefore nI-R is invertible for every integer n>=0, including the explicitly replayed first continuation n=0.",
      f"At each new power, the forcing uses only earlier log polynomials of degree at most {maxlog}. Downward solution in log degree preserves that bound, inductively at all orders.",
      f"Nonzero exact startup log-{maxlog} coefficients show that the generic bound is attained. No physical-solution cancellation or numerical period accuracy is inferred."
    ]
    report={"name":name,"accepted_for_exact_preparation_scope":True,"dimension":size,"base_dimension":base,"loop_count":loops,
      "epsilon_range":[-loops,5-loops],"normalized_fraction_identities":size*size,"raw_epsilon_lift_and_diagonal_gauge_identities":size*size,
      "gauge_equation":"Y(eta=1/z)=T(z)J; J'=T^-1[-z^-2 A(1/z,epsilon)]T J-T^-1 T' J, coefficientwise in the six epsilon jets",
      "epsilon_shearing_is_identity":True,"gauge_is_diagonal_monomial":True,"normalized_matches_augmented_source":True,
      "residue_root_multiplicities":{str(k):v for k,v in sorted(roots.items())},"generalized_basis_inverse_verified":True,"nilpotence_indices":nilpotence,
      "startup_power_range":[lower,-1],"startup_sparse_coefficients":sparse_count,"startup_matrix_equations":(-lower)*(maxlog+1),
      "startup_scalar_equations":(-lower)*(maxlog+1)*size*size,"first_continuation_power":0,"first_continuation_matrix_equations":maxlog+1,
      "boundary_rank_over_Q":size,"boundary_determinant":str(det),"boundary_exact_inverse_verified":True,
      "native_groups":len(groups),"scoped_boundary_rows":len(scoped),"other_prepared_rows_not_requested":len(all_rows)-len(scoped),
      "native_inventory_groups_and_sha_verified":True,"generic_all_orders_log_degree_bound":maxlog,"generic_bound_attained":True,
      "generic_log_bound_proof":proof,"modular_rank_used_as_proof":False,"Euler_exponential_inserted_by_gauge":False,
      "normalization_limit":"The ODE is invariant under z-independent epsilon normalization factors. This audit verifies the z gauge and epsilon indexing, not any numerical boundary normalization or values.",
      "numerical_boundary_or_period_accuracy_claimed":False,"producer_files_modified":False,
      "artifact_sha256":{k:{"path":str(p),"sha256":hashes[k]} for k,p in paths.items()},"seconds":time.monotonic()-start}
    (HERE/(name+"-audit-receipt.json")).write_text(json.dumps(report,indent=2)+"\n")
    print(name,"startup/rank/gauge/log-bound exact PASS",json.dumps({k:report[k] for k in ["dimension","startup_scalar_equations","scoped_boundary_rows","generic_all_orders_log_degree_bound","seconds"]}),flush=True)
    return report


def main():
    resource.setrlimit(resource.RLIMIT_AS,(2*2**30,2*2**30))
    resource.setrlimit(resource.RLIMIT_CPU,(60,65))
    results=[audit("pr9-22",132,22,4,-4,8),audit("three-loop-seven",42,7,3,-2,6)]
    report={"schema":"vakint.ancestor.independent-exact-matching-startup-review.v1","all_passed":True,
      "method":"Independent rational parser and six-jet AST lift, exact denominator-cleared startup equations, direct selected-group reconstruction, exact inverses and residue characteristic identities",
      "systems":[{k:r[k] for k in ["name","dimension","epsilon_range","startup_scalar_equations","first_continuation_power","boundary_rank_over_Q","native_groups","scoped_boundary_rows","generic_all_orders_log_degree_bound"]} for r in results],
      "numerical_boundary_or_period_accuracy_claimed":False,"producer_files_modified":False,
      "peak_rss_bytes":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
      "receipts":[{"path":str(HERE/(r["name"]+"-audit-receipt.json")),"sha256":sha(HERE/(r["name"]+"-audit-receipt.json"))} for r in results]}
    (HERE/"ancestor-review-receipt.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))


if __name__=="__main__":main()
