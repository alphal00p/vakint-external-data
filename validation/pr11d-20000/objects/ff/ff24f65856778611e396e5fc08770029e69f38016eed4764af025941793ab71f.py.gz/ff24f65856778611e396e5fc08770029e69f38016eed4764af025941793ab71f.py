#!/usr/bin/env python3
"""Independent frozen PR9 control-chain admission. No native/preparer execution.

The local Arb solver is admitted through its separately reviewed, pinned binary;
this checks the actual IVPs, exact rational connections, data conversions and
all stored local certificates. Initial physical source admission is separate.
"""
import argparse, hashlib, importlib.util, json, math, time
from fractions import Fraction as Q
from pathlib import Path
from flint import arb, acb, ctx, fmpq, fmpq_poly

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1] / 'pr11d'
COMMON = ROOT/'ancestor-flows/ordinary-chain-acceptance-v1/pf_input_review/check_step.py'
spec = importlib.util.spec_from_file_location('independent_simple_pf_reader', COMMON)
C = importlib.util.module_from_spec(spec); spec.loader.exec_module(C)
require, sha, load, real, decode, aq = C.require, C.sha, C.load, C.real, C.decode, C.aq
compose, pair, mul, add = C.compose, C.pair, C.mul, C.add
if not __debug__: raise RuntimeError('Acceptance cannot run with Python optimization')

PINNED = {
 'hierarchy-transport/pr9-prototype-guard1000-endpoints.json': '3e7f3745eb1b8df8e96f0253969d9f62547d982036054b8c0aa2ce50571d821f',
 'helper/frobenius-transport/pr9-API20280-prototype-guard1000-eta256-v1.json': '3e029ea8a80843dbb8ff3a7bde5aee6a20569ce9d854ee9c501d5324a215d79a',
 'ancestor-flows/pr9-22-ordinary-polynomial.json': '701b6c7b09257c46924354433027ff19effb8426fb1fd731e3b161cc2daa0aac',
 'ancestor-flows/pr9-22-ordinary-rational-pf.json': '08cfa37e3c4bd6d6b169fbd497f8e7b5c9be8387025c5aa6e380ad005fc85e6f',
 'ancestor-flows/pr9-22.json': '88290b3fe7015e350046044c3a93236700eb180e8141af5781fdfd5dfbfd9c88',
 'ancestor-flows/pr9-22-matching.json': '562b9ceff34721fbf1fcf964b4dc451fd6db63976e7f09cf6acb679a0261e0a9',
 'helper/jet-transport/transport-rpf-masked': 'c548cf9b770626c9e55d133e75b82fe3fa60c42cb29bef74ad00c4eee0156c62',
 'helper/jet-transport/transport_rpf_masked.c': '145abc0f0500703d0b6165a2ab3cf3aa793a6a412231334409c3793566791d35',
}
ARTIFACTS = {}
def bound(path, expected=None):
    path=Path(path).resolve(); digest=sha(path)
    if expected: require(digest==expected, 'Frozen hash mismatch '+str(path))
    ARTIFACTS[str(path)]=digest; return path
def read(path, expected=None): return load(bound(path,expected))
def fq(q): q=Q(q); return fmpq(q.numerator,q.denominator)
def poly(coeff): return fmpq_poly([fq(q) for q in coeff])
def verify_raw_connection(con):
    """Prove A(e,eta)D(eta)=N(e,eta) modulo e^6 over exactQ.

    This reuses only an independent reader's AST rational-polynomial type,
    never the connection exporter. Vanishing of all coefficients below6 and
    a nonzero epsilon-zero denominator proves the required formal identity.
    """
    path=bound(ROOT/'ancestor-flows/endpoint-review/independent_checks.py')
    spec=importlib.util.spec_from_file_location('exact_endpoint_auditor',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    raw=read(ROOT/'ancestor-flows/pr9-22.json');ring=module.C;E,X=ring.gens()
    D=sum((ring.constant(fq(q))*X**i for i,q in enumerate(con['denominator_coefficients'])),ring.constant(0))
    N={}
    for entry in con['entries']:
        key=entry['row'],entry['column'];value=N.get(key,ring.constant(0))
        for term in entry['terms']:value+=ring.constant(fmpq(int(term['numerator']),int(term['denominator'])))*E**entry['epsilon_power']*X**term['eta_power']
        N[key]=value
    require(len(raw['differential_matrix'])==22 and all(len(r)==22 for r in raw['differential_matrix']),'Raw equation shape')
    for i,row in enumerate(raw['differential_matrix']):
        for j,text in enumerate(row):
            v=module.parsed(text.replace(raw['epsilon_symbol'],'e').replace(raw['variable'],'x'),{'constant':module.B,'e':module.B(E),'x':module.B(X)})
            require(min(e for e,x in v.d.to_dict())==0,'Raw connection has epsilon-singular denominator')
            residual=v.n*D-v.d*N.get((i,j),ring.constant(0))
            require(all(e>=6 for e,x in residual.to_dict()),'Raw to ordinary six-jet identity failed '+str((i,j)))
    return {'exact_raw_matrix_entries':484,'maximum_epsilon_power_kept':5,'epsilon_zero_denominators_nonzero':True,'all484_polynomial_crossmultiplication_identities_mod_epsilon6':True,'independent_AST_reader_sha256':sha(path)}
def boundary(data, point, dim=22):
    require(data['basis']=='original_raw_epsilon_jets' and data['normalization']=='native_raw' and data['error_quality']=='rigorous-bound','Boundary conventions')
    require(data['dimension']==dim and data['epsilon_min_power']==-4 and data['epsilon_max_power']==1,'Boundary range')
    require(data.get('source_equation_sha256',data.get('original_source_equation_sha256'))==PINNED['ancestor-flows/pr9-22.json'],'Boundary equation binding')
    require(pair(data['eta_center'],'eta')==point,'Boundary point mismatch')
    require(data.get('local_truncation_rigorously_enclosed') is True or data.get('local_tail_certified') is True,'No certified boundary tail')
    require(data.get('physical_accuracy_certified',True) is not False,'Explicitly uncertified source')
    return decode(data['values'],dim*6)

def exact_source(con,rpf):
    require(con['dimension']==rpf['dimension']==22 and con['epsilon_jet_count']==rpf['epsilon_jet_count']==6,'Connection dimensions')
    require(rpf['schema']=='vakint.ancestor.exact-rational-polynomial-partial-fractions.v1','Unknown RPF schema')
    require(rpf['source_polynomial_connection_sha256']==PINNED['ancestor-flows/pr9-22-ordinary-polynomial.json'],'RPF binding')
    D=[Q(q) for q in con['denominator_coefficients']]; den=poly(D); original={}; numerators=[]
    for e in con['entries']:
        key=(e['row'],e['column'],e['epsilon_power']); require(key not in original,'Duplicate polynomial key')
        require(all(type(v) is int for v in key) and 0<=key[0]<22 and 0<=key[1]<22 and 0<=key[2]<6,'Invalid polynomial key')
        coeff=[Q(0)]*11; seen=set()
        for t in e['terms']:
            p=t['eta_power'];require(type(p) is int and 0<=p<=10 and p not in seen,'Bad polynomial degree');seen.add(p);coeff[p]=Q(int(t['numerator']),int(t['denominator']))
        original[key]=poly(coeff);numerators.append((key,coeff))
    factors={f['index']:[Q(x) for x in f['coefficients']] for f in rpf['denominator_factors']}
    require(len(factors)==len(rpf['denominator_factors']),'Duplicate factor index')
    rebuilt={}; rpfkeys=set()
    for e in rpf['entries']:
        key=(e['row'],e['column'],e['epsilon_power']);require(key in original and key not in rpfkeys,'Unknown or repeated RPF key');rpfkeys.add(key)
        p=poly([Q(x) for x in e['polynomial_part']])*den
        for t in e['terms']:
            require(t['factor_index'] in factors and type(t['factor_power']) is int and 1<=t['factor_power']<=3,'Bad factor term')
            divisor=poly(factors[t['factor_index']])**t['factor_power'];q,rem=divmod(den,divisor);require(not rem,'RPF factor not a common-denominator divisor')
            p+=q*poly([Q(x) for x in t['numerator_coefficients']])
        require(p==original[key],'Exact Q(eta) RPF identity failed '+str(key));rebuilt[key]=p
    require(rpfkeys==set(original),'Missing RPF couplings')
    return D,numerators,factors

def factor_minimum(coeff,center,step):
    degree=len(coeff)-1
    if degree==1:
        t,sq=C.pole_minimum(center,step,-coeff[0]/coeff[1]);sq*=coeff[1]**2;kind='t'
    else:
        require(degree==2 and center[0]==step[0]==0,'Unsupported factor/path')
        ys=[center[1],center[1]+step[1]];lo=Q(0) if min(ys)<=0<=max(ys) else min(y*y for y in ys);hi=max(y*y for y in ys)
        c0,c1,c2=coeff;t=max(lo,min(hi,(2*c2*c0-c1*c1)/(2*c2*c2)));sq=(c0-c2*t)**2+c1*c1*t;kind='y_squared'
    require(sq>0,'Factor zero on path');return t,sq,kind

def step_check(index,prior_path,run,con,rpf,D,numerators,factors,matching):
    start=time.monotonic();directory=ROOT/'hierarchy-transport/pr9-prototype-guard1000-substeps4-v5';stem=directory/f'step-{index:03}'
    ip=bound(stem.with_suffix('.in'));meta=read(stem.with_suffix('.json'));rp=bound(directory/f'step-{index:03}-native.json');result=load(rp);np=bound(directory/f'step-{index:03}-boundary.json');following=load(np);prior=read(prior_path)
    center=pair(meta['center'],'center');step=pair(meta['step'],'step');end=add(center,step)
    require(center[0]==step[0]==0 and center[1]>end[1]>0,'Off reviewed positive imaginary contour')
    ctx.prec=4600;prior_values=boundary(prior,center);boundary(following,end)
    require(meta['schema']=='vakint.constant-scaled-rational-pf-step.v1','Metadata schema')
    for k,want in [('input_sha256',sha(ip)),('initial_data_sha256',sha(prior_path)),('source_equation_sha256',con['source_sha256']),('polynomial_connection_sha256',PINNED['ancestor-flows/pr9-22-ordinary-polynomial.json']),('rational_pf_source_sha256',PINNED['ancestor-flows/pr9-22-ordinary-rational-pf.json'])]:require(meta[k]==want,'Metadata hash '+k)
    require(meta['normalization']=='native_raw' and meta['source_error_quality']=='rigorous-bound' and meta['physical_period_accuracy_claimed'] is False,'Metadata quality')
    require(meta['regular_epsilon_gauge']==con['regular_epsilon_gauge'],'Epsilon gauge binding')
    gauge=C.gauge_contract(con['regular_epsilon_gauge'],22)
    raw_weights=matching['gauge_weights'][:22];minimum=min(raw_weights);weights=[w-minimum for w in raw_weights];scales=[abs(center[1])**(-w) for w in weights]
    require(meta['constant_scale_weights']==weights and [Q(x) for x in meta['constant_component_scale']]==scales,'Constant scale identity')
    require(meta['scale_matching_sha256']==PINNED['ancestor-flows/pr9-22-matching.json'],'Scale source binding')
    for p,digest in meta['implementation_dependency_sha256'].items():bound(p,digest)
    prefix_path=bound(meta['saved_polynomial_input_path'],meta['saved_polynomial_input_sha256']);prefix_meta=read(prefix_path.with_suffix('.json'),meta['saved_polynomial_metadata_sha256'])
    require(prefix_meta['input_sha256']==sha(prefix_path),'Prefix metadata input binding')
    rawlines=ip.read_text().splitlines();prefixlines=prefix_path.read_text().splitlines();require(rawlines[:len(prefixlines)]==prefixlines,'Appendix modified IVP prefix');lines=iter(rawlines)
    def ints(n):
        row=next(lines).split();require(len(row)==n,'Wrong integer row width');return [int(x) for x in row]
    header=ints(9);dim,jets,degree,count,nb,bits,digits,maxorder,checkevery=header
    require(header[:5]==[22,6,10,len(numerators),12] and bits==4319 and digits==1000 and maxorder>=8 and checkevery>=1,'Bad frozen header')
    require(meta['dimension']==dim and meta['jets']==jets and meta['degree']==degree and meta['working_bits']==bits and meta['requested_digits']==digits,'Header metadata disagreement')
    lower_text=next(lines);ctx.prec=128;native_lower=real(lower_text);require(native_lower>0,'Nonpositive denominator bound');ctx.prec=4600;lower=real(lower_text)
    owners=ints(dim);blocks,wanted_owners=C.block_owners(dim,con['entries']);require(owners==wanted_owners and nb==len(blocks),'Invalid SCC ordering')
    shifted_D=compose(D,center,step,degree);expected=[(key,[mul(step,z) for z in compose(co,center,step,degree)]) for key,co in numerators]
    unscaled=math.lcm(*(q.denominator for co in [shifted_D]+[co for _,co in expected] for z in co for q in z))
    ratios=[scales[k[1]]/scales[k[0]] for k,_ in expected];clear=math.lcm(*(x.denominator for x in ratios));scale=unscaled*clear
    require(str(unscaled)==meta['denominator_scale'] and str(clear)==meta['clear_denominator_factor'],'Integer clearing factors')
    require(ints(2)==[int(shifted_D[0][0]*scale),int(shifted_D[0][1]*scale)],'Shifted D0')
    for a,b in shifted_D[1:]:require(ints(2)==[int(a*scale),int(b*scale)],'Shifted denominator coefficient')
    polybounds={}
    for (key,co),ratio in zip(expected,ratios):
        require(ints(3)==list(key),'Polynomial entry ordering')
        for a,b in co:require(ints(2)==[int(a*scale*ratio),int(b*scale*ratio)],'Shifted scaled numerator')
        polybounds[key]=aq(sum(abs(a)+abs(b) for a,b in co)*scale*ratio)/native_lower
    factor_bound,certs=C.segment_bound(D,center,step)
    require(meta['denominator_segment_certificates']==certs,'Segment minimum certificates')
    # The scaling adapter deliberately retains the unscaled preparer's bound
    # in metadata; the literal IVP bound is multiplied by ``clear`` at128bits.
    require(lower.lower()>0 and native_lower.lower()<=(factor_bound*scale).lower(),'Invalid scaled denominator lower bound')
    require(real(meta['denominator_lower_bound']).lower()<=(factor_bound*unscaled).lower(),'Invalid unscaled metadata denominator bound')
    ctx.prec=128;scaled_bound=real(meta['denominator_lower_bound'])*clear
    require(lower_text==scaled_bound.str(85,more=True),'Original scaled lower-bound serialization differs');ctx.prec=4600
    serial=[]
    for _ in range(132):
        fields=next(lines).split('|');require(len(fields)==2,'Invalid seed pair');serial.append(acb(real(fields[0]),real(fields[1])))
    converted=[]
    for k in range(6):
        for i in range(22):
            value=sum((prior_values[(k-j)*22+i]*2**j for j in range(k+1)),acb(0)) if gauge[i] else prior_values[k*22+i]
            converted.append(value/fq(scales[i]))
    require(all(a.contains(b) for a,b in zip(serial,converted)),'Input conversion narrowed physical source boxes')
    bank=[];indices={};terms=[]
    for e in rpf['entries']:
        ratio=scales[e['column']]/scales[e['row']]
        if e['polynomial_part']:terms.append((e,-1,[Q(x)*ratio for x in e['polynomial_part']]))
        for t in e['terms']:
            key=t['factor_index'],t['factor_power']
            if key not in indices:indices[key]=len(bank);bank.append((factors[key[0]],key[1]))
            terms.append((e,indices[key],[Q(x)*ratio for x in t['numerator_coefficients']]))
    require(next(lines)==f'RPF_V1 {len(bank)} {len(terms)}','RPF counts')
    require(ints(3)==C.scaled(center) and ints(3)==C.scaled(step),'RPF center/step')
    common=math.lcm(*(q.denominator for _,_,co in terms for q in co));require(ints(1)==[common] and str(common)==meta['rpf_shared_numerator_denominator'],'RPF numerator denominator')
    require(meta['rpf_factor_bank_count']==len(bank) and meta['rpf_term_count']==len(terms),'RPF metadata counts')
    minimums=[];minimum_certs=[]
    for a,(co,power) in enumerate(bank):
        den=math.lcm(*(q.denominator for q in co));require(ints(3)==[len(co)-1,power,den] and ints(len(co))==[int(q*den) for q in co],'RPF factor bank')
        t,sq,kind=factor_minimum(co,center,step);minimums.append(aq(sq).sqrt());minimum_certs.append({'factor_index':a,'base_degree':len(co)-1,'power':power,'parameter_kind':kind,'minimizing_parameter':str(t),'minimum_factor_modulus_squared':str(sq)})
    rpfbounds={};mask=[set() for _ in bank];habs=aq(sum(x*x for x in step)).sqrt()
    for e,a,co in terms:
        key=(e['row'],e['column'],e['epsilon_power']);require(ints(5)==list(key)+[a,len(co)-1] and ints(len(co))==[int(q*common) for q in co],'RPF serialized term')
        loc=compose(co,center,step,len(co)-1);v=habs*aq(sum(abs(x)+abs(y) for x,y in loc))
        if a>=0:
            v/=minimums[a]**bank[a][1]
            if any(co):
                for J in range(key[2],6):mask[a].add((J-key[2])*22+key[1])
        rpfbounds[key]=rpfbounds.get(key,arb(0))+v
    require(not list(lines),'Trailing input')
    require(result['schema']=='vakint.pr11d.arb-local-transport-pilot.v1' and result['local_tail_certified'] is True and result['no_PR11d_value_claimed'] is True,'Uncertified native output')
    require(result['working_bits']==bits and result['target_absolute_digits']==digits and 8<=result['order']<=maxorder and (result['order']%checkevery==0 or result['order']==maxorder),'Native order/precision')
    tail=real(result['tail_upper_enclosure']);require(tail>=0 and tail.upper()<(arb(10)**(-digits)/16).lower(),'Native residual tail exceeds local gate')
    require(result['coefficient_method']=='exact rational-factor auxiliary cascades' and result['connection_bound_method']=='entrywise minimum of polynomial and exact rational-factor segment bounds','Unreviewed native algorithm')
    require(result['rational_pf_identity_verified'] is True and result['auxiliary_mask_verified'] is True and result['factor_minimum_certificates']==minimum_certs,'Native exact identity/factor minima')
    require(result['coefficient_ring_width']==11,'Coefficient history width')
    wanted_mask=[sorted(x) for x in mask];pairs=sum(map(len,mask));levels=sum(len(s)*b[1] for s,b in zip(mask,bank));totallevels=132*sum(b[1] for b in bank)
    require(result['auxiliary_active_states_by_factor']==wanted_mask,'Exact dependency mask differs')
    for key,want in [('auxiliary_total_factor_state_pairs',len(bank)*132),('auxiliary_computed_factor_state_pairs',pairs),('auxiliary_skipped_factor_state_pairs',len(bank)*132-pairs),('auxiliary_total_cascade_state_levels',totallevels),('auxiliary_computed_cascade_state_levels',levels),('auxiliary_skipped_cascade_state_levels',totallevels-levels)]:require(result[key]==want,'Mask count '+key)
    def mu(bounds):return max(sum((v for (i,j,k),v in bounds.items() if i==r and k==0 and owners[i]==owners[j]),arb(0)).upper() for r in range(22))
    chosen={k:arb.min(polybounds[k],rpfbounds[k]) for k in polybounds}
    for key,values in [('polynomial_maximum_internal_row_bound',polybounds),('rpf_maximum_internal_row_bound',rpfbounds),('chosen_maximum_internal_row_bound',chosen)]:require(real(result[key]).upper()>=mu(values),'Native aggregate bound too small '+key)
    for key,want in [('previous_boundary_sha256',sha(prior_path)),('transport_input_sha256',sha(ip)),('native_output_sha256',sha(rp)),('run_binding_sha256',sha(directory/'run-binding.json')),('initial_boundary_sha256',run['initial_sha256'])]:require(following[key]==want,'Following binding '+key)
    require(following['whole_PR11d_20000_accuracy_claimed'] is False,'Unexpected physical precision promotion')
    # First check high-precision enclosure, then exactly replay the original
    # outward serialization to close the mathematical conversion step.
    Z=decode(result['values'],132);U=[z*fq(scales[i%22]) for i,z in enumerate(Z)];raw=[U[k*22+i]-2*U[(k-1)*22+i] if k and gauge[i] else U[k*22+i] for k in range(6) for i in range(22)];saved=decode(following['values'],132)
    require(all(a.contains(b) for a,b in zip(saved,raw)),'Restored raw boxes fail full containment')
    ctx.dps=1300;Z=decode(result['values'],132);U=[z*aq(scales[i%22]) for i,z in enumerate(Z)];raw=[U[k*22+i]-2*U[(k-1)*22+i] if k and gauge[i] else U[k*22+i] for k in range(6) for i in range(22)]
    encoded=[[z.real.str(1308,more=True),z.imag.str(1308,more=True)] for z in raw];require(encoded==following['values'],'Original outward raw serialization replay differs')
    print('STEP',index,'PASS',flush=True)
    return {'index':index,'center':list(map(str,center)),'destination':list(map(str,end)),'exact_polynomial_couplings':len(numerators),'exact_RPF_terms':len(terms),'factor_minima':len(bank),'input_physical_box_containments':132,'output_physical_box_containments':132,'outward_driver_serialization_byte_identical':True,'local_tail_target':digits,'order':result['order'],'native_tail':result['tail_upper_enclosure'],'seconds':time.monotonic()-start}

def endpoints(final_path):
    output_path=ROOT/'hierarchy-transport/pr9-prototype-guard1000-endpoints.json';output=read(output_path,PINNED['hierarchy-transport/pr9-prototype-guard1000-endpoints.json']);final=read(final_path)
    proof_path=ROOT/'ancestor-flows/pr9-22-endpoint-adjoints.json';proof=read(proof_path)
    require(output['schema']=='vakint.ancestor.certified-canonical-master-jets.v1' and output['name']=='pr9-22' and output['normalization']=='native_raw' and output['error_quality']=='rigorous-bound','Endpoint conventions')
    require(output['boundary_sha256']==sha(final_path) and output['source_sha256']==PINNED['ancestor-flows/pr9-22.json'] and output['adjoint_proof_sha256']==sha(proof_path),'Endpoint source binding')
    require(output['target_bindings']==proof['target_bindings'],'Canonical target binding changed')
    admission_path=ROOT/'ancestor-flows/production-native-input-audit.json';admission=read(admission_path);require(admission['all_completed_production_inputs_valid'] is True and admission['pending_symbols']==[],'Incomplete native adjoint admission')
    native_review=bound(admission['implementation_review'],admission['implementation_review_sha256']);nd=load(native_review)
    for p,digest in nd['source_sha256'].items():bound(p,digest)
    accepted={r['sha256']:r for r in admission['checks']};wanted={'native::'+s for s in ['PR3','PR4','PR4d','PR5','PR7','PR9','PR9d']};require(set(output['coefficients'])==wanted and len(output['adjoint_inputs'])==7,'Canonical master inventory')
    ctx.dps=1600;Y=boundary(final,(Q(0),Q(1,16)));receipts=[];symbols=set()
    for record in output['adjoint_inputs']:
        ap=Path(record['path']);ap=ap if ap.is_absolute() else ROOT/ap;ad=read(ap,record['sha256']);require(record['sha256'] in accepted,'Adjoint not independently admitted')
        require(ad['symbol'] in wanted and ad['symbol'] not in symbols,'Duplicate/unknown adjoint');symbols.add(ad['symbol'])
        require(ad['name']=='pr9-22' and ad['base_dimension']==22 and ad['endpoint_projector_proof_sha256']==sha(proof_path) and pair(ad['eta_center'],'adjoint eta')==(Q(0),Q(1,16)),'Adjoint equation/projector/point')
        require(ad['order']==record['order']==24000 and ad['source_polynomial_sha256']==record['source_polynomial_sha256'],'Adjoint record binding')
        W=decode(ad['complex_balls'],132);rows=output['coefficients'][ad['symbol']];require(len(rows)==6 and [r['epsilon_power'] for r in rows]==list(range(-4,2)),'Endpoint missing Laurent order')
        enclosed=[]
        for p,row in enumerate(rows):
            value=sum((W[j*22+i]*Y[(p-j)*22+i] for j in range(p+1) for i in range(22)),acb(0));saved=acb(real(row['ball']),real(row['imaginary_ball']));require(saved.contains(value),'Endpoint does not contain independently convolved balls '+ad['symbol']+str(p));require(saved.imag.contains(0),'Vacuum result excludes real axis');enclosed.append(saved)
        ctx.dps=1300;YY=decode(final['values'],132);WW=decode(ad['complex_balls'],132)
        for p,row in enumerate(rows):
            v=sum((WW[j*22+i]*YY[(p-j)*22+i] for j in range(p+1) for i in range(22)),acb(0))
            require(row['ball']==v.real.str(1308,more=True) and row['imaginary_ball']==v.imag.str(1308,more=True),'Endpoint original outward serialization differs')
            require(row['relative_accuracy_bits']==int(v.real.rel_accuracy_bits()) and row['absolute_radius']==v.real.rad().str(35,more=True),'Endpoint precision metadata differs')
        receipts.append({'symbol':ad['symbol'],'adjoint_sha256':sha(ap),'complex_coefficient_containments':6,'original1300digit_projection_byte_identical':True,'maximum_component_radius':max(max(z.real.rad(),z.imag.rad()) for z in enclosed).str(35,more=True)})
        ctx.dps=1600
    require(symbols==wanted,'Missing endpoint adjoint')
    return receipts

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=HERE/'chain-data-review.json');ap.add_argument('--first',type=int,default=0);ap.add_argument('--count',type=int,default=48);args=ap.parse_args();start=time.monotonic()
    for rel,digest in PINNED.items():bound(ROOT/rel,digest)
    bound(COMMON);directory=ROOT/'hierarchy-transport/pr9-prototype-guard1000-substeps4-v5';run=read(directory/'run-binding.json');complete=read(directory/'complete.json')
    for p,digest in run['implementation_and_source_dependency_sha256'].items():bound(p,digest)
    require(run['dimension']==22 and run['epsilon_jet_count']==6 and run['local_target_digits']==1000 and run['guard_digits']==300 and run['substeps_per_halving']==4 and Q(run['end_eta_imag'])==Q(1,16),'Run specification')
    require(run['native_sha256']==PINNED['helper/jet-transport/transport-rpf-masked'] and sha(run['native_path'])==run['native_sha256'],'Native binary binding')
    mask_review=read(ROOT/'helper/jet-transport/rpf-masked-implementation-review.json');aux_review=read(ROOT/'helper/jet-transport/rpf-auxiliary-implementation-review.json');bounds_review=read(ROOT/'helper/jet-transport/rpf-bounds-implementation-review.json')
    require(mask_review['source_sha256']==PINNED['helper/jet-transport/transport_rpf_masked.c'] and mask_review['binary_sha256']==run['native_sha256'],'Masked implementation admission')
    require(mask_review['baseline_source_sha256']==aux_review['source_sha256'] and mask_review['baseline_binary_sha256']==aux_review['binary_sha256'],'Auxiliary implementation lineage')
    require(mask_review['controls']['all_passed'] is True,'Masked implementation controls')
    con=read(ROOT/'ancestor-flows/pr9-22-ordinary-polynomial.json');rpf=read(ROOT/'ancestor-flows/pr9-22-ordinary-rational-pf.json');matching=read(ROOT/'ancestor-flows/pr9-22-matching.json');source_identity=verify_raw_connection(con);D,numerators,factors=exact_source(con,rpf)
    initial_path=ROOT/'helper/frobenius-transport/pr9-API20280-prototype-guard1000-eta256-v1.json';require(run['initial_sha256']==sha(initial_path),'Actual initial binding')
    require(complete['complete'] is True and len(complete['steps'])==48 and complete['run_binding_sha256']==sha(directory/'run-binding.json'),'Incomplete48-step chain')
    rows=[];prior_path=initial_path if args.first==0 else directory/f'step-{args.first-1:03}-boundary.json';last=Q(256) if args.first==0 else Q(load(prior_path)['eta_center'][1])
    for i in range(args.first,args.first+args.count):
        row=step_check(i,prior_path,run,con,rpf,D,numerators,factors,matching);s=complete['steps'][i]
        require(s['index']==i and Q(s['center'])==last and Q(s['destination'])==Q(row['destination'][1]) and s['order']==row['order'] and s['local_tail']==row['native_tail'],'Complete manifest step mismatch')
        prior_path=directory/f'step-{i:03}-boundary.json';require(s['boundary_sha256']==sha(prior_path),'Complete step output binding');last=Q(row['destination'][1]);rows.append(row)
    projection=None
    if args.first==0 and args.count==48:
        require(last==Q(1,16) and complete['final_boundary_sha256']==sha(prior_path),'Final chain endpoint')
        projection=endpoints(prior_path)
    for p,digest in ARTIFACTS.items():require(sha(p)==digest,'Artifact changed during review '+p)
    payload={'schema':'vakint.PR9-control-source-chain-data-review.v1','status':'passed_actual_data_and_reviewed_native_certificate_chain','physical_initial_source_admission':'separate init-only receipt required','whole_chain_physical_source_admitted':False,'raw_connection_identity':source_identity,'steps':rows,'endpoint_projections':projection,'artifact_sha256':ARTIFACTS,'checker_sha256':sha(__file__),'seconds':time.monotonic()-start,'new_native_or_preparer_calls':0,'all_checks_use_exact_identity_full_containment_or_original_outward_replay':True,'whole_PR11d_precision_claimed':False}
    args.output.write_text(json.dumps(payload,indent=2)+'\n');print('PASS',args.output,flush=True)
if __name__=='__main__':main()
