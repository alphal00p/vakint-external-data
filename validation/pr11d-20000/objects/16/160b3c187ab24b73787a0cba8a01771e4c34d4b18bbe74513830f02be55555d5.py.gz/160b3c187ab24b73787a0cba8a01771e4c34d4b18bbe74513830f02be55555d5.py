#!/usr/bin/env python3
"""Read-only review of accepted API->native 3L endpoint imports.

The independent high precision check is exact rational interval propagation,
using one Arb EulerGamma enclosure, not a repeated master/HPL evaluation.
"""
from copy import deepcopy
from fractions import Fraction as Q
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
sys.set_int_max_str_digits(300000)
from flint import arb, ctx, fmpq

HERE = Path(__file__).resolve().parent
PERIODS = HERE.parents[1]
EXPORTS = PERIODS / 'lower-ancestors'
BRIDGE = HERE.parent / 'ancestor-boundary'
FAMILY = '56d4ac620f0309e551e825ce435d23ee4b58e887f2ee639e1bf14006bc9e9f93'
POWERS = {'P13': [0,1,1,1,1,0], 'P14': [0,1,1,1,1,1]}
PINS = {
    '3L-P13.json':'dfc2a6e5b402ef7cf39a7c8c91ebf71b8890ff1d76497c9bbd20b55f0de01a10',
    '3L-P14.json':'519a202d505cb34093b8ac75cd03d655fad9e235fa67020b3ab13d585956006c',
    'three-loop-API20280-native.json':'9502a5fb678eee9d9a225c380ac200ab55bd424fcbde8267b22257320b975b31',
    'pr9-boundary-API20280-working20400.json':'8b35db3637aed6c4654a8b86bd3501b6357bff64c719aa52dc352b72eb4bc9b9',
    'pr9-boundary-API20280-working20400.guard-validation.json':'74906e693b01008c20492dc124f16432b82f4278bae56bf900e4be47c96ce1a0',
}
INPUTS = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path, expected=None):
    actual = digest(path)
    require(expected is None or actual == expected, f'Input hash changed: {path}')
    INPUTS[str(path)] = actual
    return json.loads(path.read_bytes())


def ratio(value):
    pair = value['exact_binary_value']
    n, d = int(pair['numerator']), int(pair['denominator'])
    require(d > 0 and d & (d-1) == 0, 'Float denominator must be a positive binary power')
    return Q(n,d)


def aq(value):
    return arb(fmpq(value.numerator, value.denominator))


def exact_q(value):
    rational = value.fmpq()
    return Q(int(rational.numerator), int(rational.denominator))


def ball_bounds(value):
    return exact_q(value.lower()), exact_q(value.upper())


def main():
    ctx.dps = 20420
    ctx.threads = 1
    release = load(EXPORTS / 'source/release-manifest.json')
    manifest = load(EXPORTS / 'source/3L-manifest.json')
    production = load(EXPORTS / 'receipt.json')
    verification = load(EXPORTS / 'export-validation.json')
    require(production['success'] and not production['failures'], 'Export production did not succeed')
    require(verification['complete'] and verification['native_run_complete'], 'Export verification incomplete')
    require(production['normalization_transform_applied'] is False and production['evaluation_passes_per_master'] == 1,
            'API export normalization or evaluation-pass contract differs')
    require(digest(EXPORTS / 'source/release-manifest.json') == production['root_manifest_sha256'], 'Root manifest binding mismatch')
    require(digest(EXPORTS / 'source/3L-manifest.json') == next(p['manifest_sha256'] for p in release['loop_packs'] if p['loop_count']==3), '3L manifest binding mismatch')
    require(release['version'] == manifest['version'] == 'v0.1.1', 'Unexpected snapshot version')
    require(digest(EXPORTS/'evaluate_native.py') == production['script_sha256'], 'API producer script changed')
    require(digest(EXPORTS/'verify_exports.py') == verification['verifier_sha256'], 'Export verifier changed')
    host = load(EXPORTS/'host-provenance.json')
    require(host['sha256'] == production['extension_sha256'], 'Production extension provenance mismatch')

    native = load(BRIDGE/'three-loop-API20280-native.json', PINS['three-loop-API20280-native.json'])
    require(native['normalization'] == 'native_raw' and native['error_quality'] == 'rigorous-bound', 'Native source quality or convention changed')
    require(native['producer_sha256'] == digest(BRIDGE/'api_three_loop_native.py'), 'Native conversion producer changed')
    require(native['minimum_API_source_digits_checked'] == 20250, 'Wrong source precision gate')
    INPUTS[str(BRIDGE/'api_three_loop_native.py')] = digest(BRIDGE/'api_three_loop_native.py')
    INPUTS[str(HERE.parent/'pr11-boundary/prototype_boundary.py')] = digest(HERE.parent/'pr11-boundary/prototype_boundary.py')

    gamma = arb.const_euler()
    gamma_center = exact_q(gamma.mid())
    gamma_radius = exact_q(gamma.rad().upper())
    gamma_max = abs(gamma_center) + gamma_radius
    imported, metadata_checks, coefficient_checks = {}, [], []
    for name in ('P13','P14'):
        record = load(EXPORTS/f'3L-{name}.json', PINS[f'3L-{name}.json'])
        source = EXPORTS/f'source/3L-{name}'
        metadata = load(source/'master-metadata.json')
        require(metadata == next(m for m in manifest['masters'] if m['name']==name), 'Master metadata not part of snapshotted pack')
        canonical = 'L3_'+FAMILY+''.join('_p'+str(p) for p in POWERS[name])
        metadata_digest = hashlib.sha256(json.dumps(metadata,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
        require(record['master_id'] == canonical == metadata['master_id'], 'Canonical master identity mismatch')
        require(record['family_sha256'] == FAMILY == metadata['family_sha256'], 'Canonical family mismatch')
        require(record['powers'] == POWERS[name] == metadata['powers'] and record['loop_count']==3, 'Ordered powers or loop count differs')
        require(record['normalization']=='FMFTandMATAD' and record['mass_squared']=='1', 'Source normalization differs')
        require(record['normalization_formula']==metadata['graph_definition']['normalization']=='(i*pi^(d/2)*exp(-EulerGamma*epsilon))^(-3)', 'Normalization definition differs')
        require(record['provenance']['version']==release['version'] and record['provenance']['master_id']==canonical
                and record['provenance']['source_sha256']==metadata_digest, 'Master snapshot provenance mismatch')
        require(record['source_hashes']['loop_manifest']==digest(EXPORTS/'source/3L-manifest.json'), 'Record pack binding mismatch')
        for filename, binding in metadata['files'].items():
            load_path = source/filename
            require(digest(load_path)==binding['sha256']==record['source_hashes'][filename], 'Authenticated payload changed: '+filename)
            INPUTS[str(load_path)] = digest(load_path)
        formulas = dict(load(source/'symbolic.json'))
        orders = [r['epsilon_power'] for r in record['coefficients']]
        require(orders==metadata['available_epsilon_powers']==list(range(-3, 5 if name=='P13' else 4)), 'Export orders missing, duplicated, or reordered')
        summary = next(s for s in production['completed'] if s['master']=='3L-'+name)
        require(summary['sha256']==PINS[f'3L-{name}.json'] and summary['orders']==orders, 'Production output binding mismatch')
        imported[name] = {}
        for row in record['coefficients']:
            power = row['epsilon_power']
            provenance = row['provenance']
            require(provenance == dict(record['provenance'], epsilon_power=power), 'Coefficient provenance differs')
            require(row['formula_sha256']==hashlib.sha256(formulas[power].encode()).hexdigest(), 'Formula identity changed')
            require(row['available_precision']=='ArbitraryPrecision' and not row['warnings'], 'Source capability or warning differs')
            require(row['requested_decimal_precision']==20280 and row['meets_20200_digit_bounded_requirement'], 'Requested source precision differs')
            central = ratio(row['numerical_value'])
            real, imaginary = row['precision']['real'], row['precision']['imaginary']
            error = ratio(real['absolute_error'])
            require(real['quality']==imaginary['quality']=='Bounded' and error>=0, 'Missing rigorous source error bound')
            require(imaginary['exact_zero'] and ratio(imaginary['absolute_error'])==0, 'Imaginary source is not exactly zero')
            require(real['exact_zero'] == (central==0 and error==0), 'Contradictory source zero metadata')
            require(real['significant_digits']>=20250, 'Insufficient declared source accuracy')
            require(error*10**20250 <= abs(central)-error, 'Exact source radius fails the 20250-digit relative gate')
            imported[name][power] = (central,error)
        symbol = 'native::L3_'+name
        binding = native['canonical_alias_bindings'][symbol]
        require(binding['sha256']==PINS[f'3L-{name}.json'] and binding['API_provenance']==record['provenance']
                and binding['native_source_hashes']==record['source_hashes'] and binding['powers']==POWERS[name]
                and binding['master_id']==canonical, 'Native output identity or source snapshot binding differs')
        output_orders = [r['epsilon_power'] for r in native['coefficients'][symbol]]
        require(output_orders==list(range(-3,3)), 'Native output must carry exactly six required contiguous orders')
        for row in native['coefficients'][symbol]:
            power = row['epsilon_power']
            # Direct powers and factorials of the exact rational midpoint of
            # gamma, plus a derivative bound for its certified interval.
            center, radius = Q(0), Q(0)
            for q in range(-3,power+1):
                n = power-q
                c, error = imported[name][q]
                multiplier = (-3*gamma_center)**n / math.factorial(n)
                center += c*multiplier
                radius += error*abs(multiplier)
                if n:
                    derivative = Q(3**n,math.factorial(n-1))*gamma_max**(n-1)
                    radius += (abs(c)+error)*derivative*gamma_radius
            ball = arb(row['ball'])
            require(ball.is_finite(), 'Nonfinite native output enclosure')
            lower, upper = ball_bounds(ball)
            require(lower <= center-radius and upper >= center+radius,
                    f'Native output fails independent full source-box enclosure: {name}, epsilon^{power}')
            coefficient_checks.append({'master':name,'epsilon_power':power,'full_exact_rational_source_box_contained':True,
                                       'relative_accuracy_bits':ball.rel_accuracy_bits(), 'normalization_convolutions':1})
        metadata_checks.append({'master':name,'master_id':canonical,'version':release['version'],'source_orders':orders,
                                'all_exact_binary_relative_error_checks':20250,'metadata_sha256':metadata_digest,
                                'formula_hashes_bound':True,'native_output_orders':output_orders})

    # Exercise the actual bridge at bounded working precision using immutable
    # source files; this computes only EulerGamma and the finite convolution.
    sys.path.insert(0,str(BRIDGE))
    spec = importlib.util.spec_from_file_location('reviewed_api_bridge',BRIDGE/'api_three_loop_native.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    ctx.dps = 260
    replay_checks = []
    for name in ('P13','P14'):
        values, binding = module.load_api(EXPORTS/f'3L-{name}.json',PINS[f'3L-{name}.json'],name,20250)
        target = {r['epsilon_power']:r for r in native['coefficients']['native::L3_'+name]}
        for power, value in values.items():
            high = arb(target[power]['ball'])
            require(value.is_finite() and value.overlaps(high), '260-digit bridge replay contradicts production')
            replay_checks.append({'master':name,'epsilon_power':power,'working_digits':260,'overlaps_accepted_output':True})

    # Corrupt data controls are confined to this review's directory. The accepted
    # source digest is a trust boundary; mutated files receive a fresh digest so
    # the structural/quality/precision checks themselves are exercised.
    base = json.loads((EXPORTS/'3L-P13.json').read_bytes())
    mutations = {
        'wrong_family':lambda d:d.__setitem__('family_sha256','0'*64),
        'wrong_ordered_powers':lambda d:d.__setitem__('powers',[1,1,1,1,0,0]),
        'wrong_normalization':lambda d:d.__setitem__('normalization','native_raw'),
        'finite_source':lambda d:d['coefficients'][0].__setitem__('available_precision','FixedPrecision'),
        'estimated_error':lambda d:d['coefficients'][0]['precision']['real'].__setitem__('quality','Estimate'),
        'uncertain_imaginary_zero':lambda d:d['coefficients'][0]['precision']['imaginary'].__setitem__('exact_zero',False),
        'duplicate_order':lambda d:d['coefficients'][1].__setitem__('epsilon_power',-3),
        'missing_order':lambda d:d['coefficients'].pop(3),
        'insufficient_error_bound':lambda d:d['coefficients'][0]['precision']['real']['absolute_error'].__setitem__('exact_binary_value',{'numerator':'1','denominator':'1'}),
    }
    negative_controls = []
    bad = HERE/'negative-controls'
    bad.mkdir(exist_ok=True)
    for label, mutate in mutations.items():
        data = deepcopy(base)
        mutate(data)
        path = bad/(label+'.json')
        path.write_text(json.dumps(data)+'\n')
        try:
            module.load_api(path,digest(path),'P13',20250)
        except ValueError as error:
            negative_controls.append({'control':label,'rejected':True,'message':str(error)})
        else:
            raise ValueError('Malformed source was accepted: '+label)
    try:
        module.load_api(EXPORTS/'3L-P13.json','0'*64,'P13',20250)
    except ValueError as error:
        negative_controls.append({'control':'unaccepted_checksum','rejected':True,'message':str(error)})
    else:
        raise ValueError('Unaccepted source checksum accepted')

    # The downstream reviewer owns full matching reassembly. Here bind the
    # actual output and verify all 132 measured radii against its stated gate.
    ctx.dps = 20420
    guard = load(BRIDGE/'pr9-boundary-API20280-working20400.guard-validation.json',PINS['pr9-boundary-API20280-working20400.guard-validation.json'])
    pr9 = load(BRIDGE/'pr9-boundary-API20280-working20400.json',PINS['pr9-boundary-API20280-working20400.json'])
    require(guard['accepted'] and guard['source']['sha256']==PINS['three-loop-API20280-native.json']
            and guard['boundary_sha256']==PINS['pr9-boundary-API20280-working20400.json'], 'Downstream source/output binding changed')
    require(guard['source']['no_Euler_conversion_applied'] and guard['source']['normalization']=='native_raw', 'Downstream applied an extra normalization')
    values = [arb(s) for s in pr9['free_constant_balls']]
    require(len(values)==132 and all(v.is_finite() for v in values), 'Invalid PR9 constant balls')
    maximum = max(v.rad().upper() for v in values)
    require(maximum < (arb(10)**(-20240)).lower(), 'Actual PR9 output radii violate the accepted contract')
    report = {
        'schema':'vakint.independent-API-ancestor-source-review.v1','accepted':True,
        'scope':'AP export binding and exact binary rational enclosure import; one FMFT-to-native conversion; actual native/PR9 output-ball sanity. Full PR9 reassembly is a separate downstream review.',
        'metadata_checks':metadata_checks,'native_output_checks':coefficient_checks,'bounded_replay_checks':replay_checks,
        'negative_controls':negative_controls,
        'Euler_conversion':{'factor':'exp(-3 EulerGamma epsilon)','applications':1,
                            'independent_check':'Exact rational center and source-radius box plus rational mean-value bound for one 20420-digit Arb EulerGamma enclosure',
                            'why':'FMFT/MATAD measure includes exp(+3 EulerGamma epsilon) relative to native raw measure'},
        'downstream_output':{'sha256':PINS['pr9-boundary-API20280-working20400.json'],'constants':132,
                             'maximum_actual_constant_radius':maximum.str(45,more=True),'all_radii_below':'1e-20240',
                             'source_digest_verified':True,'no_extra_Euler_conversion':True},
        'no_HPL_or_master_recomputation':True,'whole_PR11d_accuracy_claimed':False,
        'input_sha256':INPUTS,'review_script_sha256':digest(Path(__file__)),
    }
    output = HERE/'audit.json'
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'accepted':True,'source_coefficients':sum(len(v) for v in imported.values()),
                      'native_coefficient_boxes':len(coefficient_checks),'260_digit_replays':len(replay_checks),
                      'negative_controls':len(negative_controls),'receipt':str(output),'sha256':digest(output)}))


if __name__ == '__main__':
    main()
