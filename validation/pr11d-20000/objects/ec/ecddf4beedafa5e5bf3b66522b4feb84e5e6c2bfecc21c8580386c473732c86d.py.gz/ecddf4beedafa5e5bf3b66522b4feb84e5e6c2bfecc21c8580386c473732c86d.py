#!/usr/bin/env python3
"""Read-only guarded three-loop source/boundary audit; no transport rerun."""
import hashlib
import importlib.util
import json
import resource
import sys
import time
from decimal import Decimal, localcontext, ROUND_CEILING
from fractions import Fraction as Q
from pathlib import Path
from flint import arb, arb_series, ctx, fmpq

if not __debug__:
    raise RuntimeError("Audit requires assertions")
HERE=Path(__file__).resolve().parent
PR11=HERE.parents[1]
BASE=PR11.parent
ANCESTOR=PR11/"ancestor-flows"
BOUNDARY=BASE/"bessel/ancestor-boundary"
sys.path.insert(0,str(BOUNDARY))
import three_loop_boundary as producer
from logjet_map import FactorJet,MissingCoefficient,valuation
from expanded_boundary import ExpandedBoundary


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())
def upper_decimal(value):
    q=value.upper().fmpq()
    with localcontext() as context:
        context.prec=30;context.rounding=ROUND_CEILING
        value=Decimal(int(q.numerator))/Decimal(int(q.denominator))
        text=str(value)
        if arb(text).lower()<arb(q):text=str(value.next_plus(context))
    assert arb(text).lower()>=arb(q)
    return text


def main():
    resource.setrlimit(resource.RLIMIT_AS,(2*2**30,2*2**30))
    resource.setrlimit(resource.RLIMIT_CPU,(60,65))
    start=time.monotonic();ctx.dps=20550;ctx.threads=1
    paths={
      "boundary":BOUNDARY/"three-loop-boundary20400.json",
      "generator":BOUNDARY/"three_loop_boundary.py",
      "inventory":BOUNDARY/"three-loop-seven-inventory.json",
      "matching":ANCESTOR/"three-loop-seven-matching.json",
      "startup":ANCESTOR/"three-loop-seven-startup.json",
      "polynomial":ANCESTOR/"three-loop-seven-polynomial.json",
      "matching_audit":PR11/"helper/ancestor-matching-review/three-loop-seven-audit-receipt.json",
      "sunset_normalized":ANCESTOR/"sunset-ratio-20300-normalized.json",
      "sunset_ratio":ANCESTOR/"sunset-ratio-20300.json",
      "sunset_review":ANCESTOR/"sunset-review/review.json",
      "sunset_build":ANCESTOR/"sunset-build-receipt.json",
      "ancestor_manifest":ANCESTOR/"handoff-manifest.json",
      "sunset_comparison":BOUNDARY/"sunset-API-independent-comparison.json",
      "sunset_comparison_code":BOUNDARY/"compare_sunset_api.py",
      "sunset_api":BASE/"lower-ancestors/2L-P2.json",
      "extra_massless_trees":BOUNDARY/"massless-one-two-loop/exact-trees.json",
      "native_singlemass":BOUNDARY/"three-loop-seven-singlemass.json",
      "native_products":BOUNDARY/"three-loop-seven-products.json",
      "auditor":Path(__file__),
    }
    for name in ["source_recipes.py","gamma_ast.py","gamma_jets.py","expanded_boundary.py","logjet_map.py"]:
        paths[name]=BASE/"bessel/pr11-boundary"/name
    hashes={key:sha(path) for key,path in paths.items()}
    data=read(paths["boundary"]);matching=read(paths["matching"]);sunset=read(paths["sunset_normalized"]);ratio=read(paths["sunset_ratio"])
    assert data["schema"]=="vakint.three-loop.complete-source-boundary.v1"
    assert data["normalization"]=="native_raw" and data["error_quality"]=="rigorous-bound"
    assert data["all_prepared_rows_checked"] is True and data["all_overdetermined_residuals_contain_zero"] is True
    assert data["coefficient_count"]==129 and data["free_constants"]==42
    assert not data["scientific_whole_master_accuracy_claimed"]
    assert data["matching_sha256"]==hashes["matching"]
    assert data["inventory_sha256"]==matching["inventory_sha256"]==hashes["inventory"]
    assert data["implementation_sha256"]==hashes["generator"]
    assert data["sunset_source_sha256"]==hashes["sunset_normalized"]
    assert sunset["ratio_input_sha256"]==hashes["sunset_ratio"]
    assert sunset["error_quality"]=="rigorous-bound" and sunset["validated_analytic_truncation_and_rounding"] is True
    assert ratio["normalization"]=="native_raw/I1^2" and ratio["jet_count"]==6
    assert [r["epsilon_power"] for r in ratio["coefficients"]]==list(range(6))
    assert [r["epsilon_power"] for r in sunset["coefficients"]["native_raw"]]==list(range(-2,4))
    # Bind the previously independent exact matching/startup/gauge audit.
    exact_audit=read(paths["matching_audit"])
    assert exact_audit["accepted_for_exact_preparation_scope"] and exact_audit["boundary_rank_over_Q"]==42
    for row in exact_audit["artifact_sha256"].values():assert sha(Path(row["path"]))==row["sha256"]
    # The source remains the frozen, independently reviewed rigorous algorithm.
    review=read(paths["sunset_review"])
    assert review["status"]=="passed_for_authenticated_sunset_ingredient"
    assert review["checks"]["status"]=="passed"
    sunset_pins=[]
    for name,digest in review["source_sha256"].items():
        path=ANCESTOR/name;assert sha(path)==digest
        sunset_pins.append({"path":str(path),"sha256":digest})
    manifest=read(paths["ancestor_manifest"]);manifest_index={row["path"]:row["sha256"] for row in manifest["files"]}
    assert len(manifest_index)==len(manifest["files"])
    # Only relevant immutable producer paths are required; unrelated handoff
    # text or ongoing ancestor work is not treated as scientific evidence.
    for pin in sunset_pins:
        if Path(pin["path"]).suffix in (".py",".c") or pin["path"] in manifest_index:
            assert manifest_index[pin["path"]]==pin["sha256"],pin["path"]
    comparison=read(paths["sunset_comparison"])
    assert comparison["accepted"] and comparison["Taylor_source_sha256"]==hashes["sunset_normalized"]
    assert comparison["API_source_sha256"]==hashes["sunset_api"]
    assert comparison["validator_sha256"]==hashes["sunset_comparison_code"]
    assert [r["epsilon_power"] for r in comparison["checks"]]==list(range(-2,4))
    assert all(r["bounded_balls_overlap"] and r["agreement_digits_lower_bound"]>=20250 for r in comparison["checks"])
    # Independent ordinary Gamma series proves normalization signs/convolution,
    # without the normalizer's log-Gamma Bell recurrence.
    ctx.cap=7;e=arb_series([0,1],prec=6)
    q=arb_series([arb(r["ball"]) for r in ratio["coefficients"]],prec=6)
    native=q*(1+e).gamma()**2/(1-e)**2
    fmft=native*(2*arb.const_euler()*e).exp()
    for group,computed in [("native_raw",native),("FMFTandMATAD",fmft)]:
        rows=sunset["coefficients"][group]
        assert [r["epsilon_power"] for r in rows]==list(range(-2,4))
        for j,row in enumerate(rows):
            saved=arb(row["ball"]);assert saved.is_finite() and saved.overlaps(computed[j])
            if "midpoint" in row or "radius" in row:
                m=row["midpoint"];r=row["radius"]
                midpoint=arb(fmpq(int(m["numerator"]),int(m["denominator"])))
                radius=arb(fmpq(int(r["numerator"]),int(r["denominator"])))
                assert radius>=0 and saved.contains(midpoint+arb(0,radius.upper()))
    # Full source registry and transitive actual recipe pins.
    factors,recipe_receipt=producer.factor_expressions()
    assert recipe_receipt==data["source_recipe_receipt"] and len(factors)==26
    assert recipe_receipt["native_inventory_sha256"]==hashes["inventory"]
    assert recipe_receipt["additional_child_trees_sha256"]==hashes["extra_massless_trees"]
    assert recipe_receipt["native_singlemass_sha256"]==hashes["native_singlemass"]
    assert recipe_receipt["native_products_sha256"]==hashes["native_products"]
    recipe_pins=[]
    for path,digest in recipe_receipt["reused_X8_source_bindings"]["source_sha256"].items():
        assert sha(Path(path))==digest;recipe_pins.append({"path":path,"sha256":digest})
    trees=read(paths["extra_massless_trees"]);assert sha(Path(trees["source_path"]))==trees["source_sha256"]
    assert trees["status"]=="all_selected_exact_massless_Gamma_trees_proved"
    assert "no exp(EulerGamma*epsilon)" in trees["conventions"]["raw_native_measure"]
    inventory=read(paths["inventory"]);bykey={f["key"]:f for f in inventory["factors"]}
    raw_weight_count=0
    for key,expression in factors.items():
        for rational,slopes,keys in expression.terms:
            assert all(k=="native::L2_P2" for k in keys)
            expected_loop=bykey[key]["loops"] if "loops" in bykey[key] else len(bykey[key]["family"]["loops"])
            assert sum((b*n for b,n in slopes),Q(0))+2*len(keys)==expected_loop
            raw_weight_count+=1
    plan=producer.load_plan(paths["inventory"],data["inventory_sha256"],"masters_3l::{}::epsilon")
    primitive=FactorJet(-2,tuple(arb(r["ball"]) for r in sunset["coefficients"]["native_raw"]),"Reviewed analytic sunset bound and exact Laurent support","native::L2_P2")
    primitives={"native::L2_P2":primitive}
    compiled=ExpandedBoundary(plan,factors,max_log_power=matching["max_exact_log_degree"])
    required,_=compiled.required_primitive_orders(primitives,last_epsilon_power=2)
    assert required==data["required_raw_primitive_through"]=={"native::L2_P2":3}
    try:compiled.required_primitive_orders({"native::L2_P2":FactorJet(-2,primitive.coefficients[:-1],primitive.pole_bound_proof,primitive.source_identity)},last_epsilon_power=2)
    except MissingCoefficient:pass
    else:raise AssertionError("Missing sunset epsilon^3 accepted")
    minimum_support=0
    for (_,_,_,keys),prefactor in plan.terms:
        if any(not factors[k].terms for k in keys):continue
        low=valuation(prefactor)
        for key in keys:low+=min(valuation(r)+sum(primitives[k].first_power for k in keys) for r,slopes,keys in factors[key].terms)
        minimum_support=min(minimum_support,int(low))
    assert 2-minimum_support<=matching["max_exact_log_degree"]
    assembled=compiled.evaluate(primitives,first_epsilon_power=-3,last_epsilon_power=2)
    assembled={(i,int(a),p,l):v for (i,a,p,l),v in assembled.items()}
    key=producer.key;wanted=[key(row) for row in matching["all_boundary_selectors"]]
    assert len(wanted)==len(set(wanted))==129
    saved={}
    for row in data["coefficients"]:
        label=key(row);assert label not in saved;saved[label]=arb(row["real_ball"])
    assert set(saved)==set(wanted)
    assert all(assembled[k].is_finite() and assembled[k].overlaps(saved[k]) for k in wanted)
    excluded=[v for k,v in assembled.items() if k not in saved]
    assert all(v.contains(0) for v in excluded)
    rhs=[saved[key(row)] for row in matching["selected_selectors"]]
    # This directly uses the exact inverse entries, independently of producer.dot.
    fresh=[sum((rhs[j]*fmpq(value) for j,value in enumerate(row) if value!="0"),arb(0)) for row in matching["boundary_inverse"]]
    constants=[arb(text) for text in data["free_constant_balls"]]
    assert len(constants)==len(fresh)==42
    assert all(v.is_finite() and v.overlaps(w) for v,w in zip(constants,fresh))
    for label,row in zip(wanted,matching["all_boundary_matrix"]):
        residual=sum((fresh[j]*fmpq(value) for j,value in enumerate(row) if value!="0"),arb(0))-saved[label]
        assert residual.contains(0)
    target=(arb(10)**-20250).lower()
    precision={}
    for group,values in [("saved_boundary_rows",[saved[k] for k in wanted]),("saved_constants",constants),("recomputed_constants",fresh)]:
        records=[]
        for i,value in enumerate(values):
            assert value.is_finite() and value.rad().upper()<target and 2*value.rad().upper()<target
            record={"index":i,"exact":value.is_exact(),"contains_zero":value.contains(0),"absolute_radius_upper":upper_decimal(value.rad())}
            if not value.contains(0) and not value.is_exact():
                relative=(value.rad()/abs(value).lower()).upper()
                assert relative<(arb(10)**-20250).lower()
                record["relative_decimal_digits_lower_bound"]=int((-relative.log()/arb(10).log()).lower().floor().fmpz())
                record["relative_accuracy_bits"]=int(value.rel_accuracy_bits())
            records.append(record)
        precision[group]={"count":len(values),"exact_zero_count":sum(v.is_zero() for v in values),"uncertain_zero_count":sum(v.contains(0) and not v.is_zero() for v in values),
          "minimum_relative_decimal_digits_nonzero_inexact":min(r["relative_decimal_digits_lower_bound"] for r in records if "relative_decimal_digits_lower_bound" in r),
          "maximum_absolute_radius_upper":upper_decimal(max(v.rad() for v in values)),"all_radius_and_diameter_below_10_to_minus20250":True,"coefficients":records}
    for key,path in paths.items():assert sha(path)==hashes[key],(key,"changed during audit")
    report={"schema":"vakint.three-loop.guarded-boundary-independent-review.v1","accepted":True,
      "review_scope":"Frozen rigorous sunset ingredient, exact source assembly, all matching rows/constants, and available input accuracy for a guarded 20250-digit native start; no propagated endpoint or whole-period accuracy claim",
      "target_guarded_decimal_digits":20250,"audit_working_decimal_digits":20550,
      "source_error_quality":"rigorous-bound","matching_and_inventory_hashes_verified":True,
      "independent_exact_matching_audit_bound":True,"sunset_rigorous_source_review_and_all_pins_verified":True,
      "sunset_direct_Gamma_normalization_coefficients_checked":12,
      "independent_API_Taylor_minimum_agreement_digits":comparison["minimum_agreement_digits"],
      "recipe_factors_reassembled":len(factors),"raw_native_Euler_weight_monomials_checked":raw_weight_count,
      "required_primitive_orders":required,"missing_sunset_epsilon3_rejected":True,
      "minimum_uncancelled_source_Laurent_support":minimum_support,"highest_log_needed_through_epsilon2":2-minimum_support,
      "full_boundary_rows_reassembled":129,"matched_constants_recomputed":42,"all_129_overdetermined_residuals_contain_zero":True,
      "precision":precision,"no_large_native_source_or_transport_run_duplicated":True,
      "producer_files_modified":False,"whole_period_precision_or_cap_claimed":False,
      "artifact_sha256":{key:{"path":str(path),"sha256":hashes[key]} for key,path in paths.items()},
      "transitive_sunset_source_pins":sunset_pins,"transitive_recipe_source_pins":recipe_pins,
      "seconds":time.monotonic()-start,"peak_rss_bytes":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}
    (HERE/"guarded-boundary-receipt.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({k:v for k,v in report.items() if k not in ("artifact_sha256","transitive_sunset_source_pins","transitive_recipe_source_pins","precision")},indent=2))
    print(json.dumps({k:{kk:vv for kk,vv in v.items() if kk!="coefficients"} for k,v in precision.items()},indent=2))


if __name__=="__main__":main()
