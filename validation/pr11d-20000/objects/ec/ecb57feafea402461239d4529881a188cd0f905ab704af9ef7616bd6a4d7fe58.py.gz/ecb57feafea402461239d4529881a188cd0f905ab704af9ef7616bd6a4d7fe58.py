#!/usr/bin/env python3
"""Fresh witnessed run of the saved PR9 input with the frozen v2 binary."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

HERE = Path(__file__).resolve().parent
NATIVE = HERE.parent / "frobenius-transport/native"
FILES = {
    "binary": NATIVE / "contracted-native-v2",
    "source": NATIVE / "contracted_v2.c",
    "build": NATIVE / "build-v2.sh",
    "input": NATIVE / "pr9-API20600-init-v1.in",
    "metadata": NATIVE / "pr9-API20600-init-v1.json",
    "original_output": NATIVE / "pr9-API20600-init-v1-output.json",
    "original_log": NATIVE / "pr9-API20600-init-v1.log",
    "wrapper": NATIVE.parent / "pr9-API20600-eta256-guard20500-v1.json",
    "auditor": Path(__file__),
}
EXPECTED = {
    "binary": "ff3d297816b301c010fb8ee4645207ecdec0f74cf8e7a8678b678d5bfb3175c3",
    "source": "5f9c381280172f1d388a3661fb13a3a799848391c29b334e5c1ebc150879ff60",
    "input": "4bc6ce44b56b1ac828ff7f74c6444f770ef700cf19eeb332dff50c5267c2bebf",
    "original_output": "3d03bb5deba210cb61b6dc1beb33a27bf0ee240a77407535c3f9b4f17b9f7955",
    "wrapper": "cdfe1cd91fa448fd6d65352689c170a7f52c538097b68ad9784bdf61bfafcf87",
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def main():
    if not __debug__:
        raise RuntimeError("Assertions required")
    pre = {key: {"path": str(path), "sha256": sha(path)} for key, path in FILES.items()}
    for key, digest in EXPECTED.items():
        assert pre[key]["sha256"] == digest, key
    output = HERE / "replay-output.json"
    stderr_path = HERE / "replay.stderr.log"
    stdout_path = HERE / "replay.stdout.log"
    for path in [output, stderr_path, stdout_path, HERE / "invocation-start.json", HERE / "invocation-review.json"]:
        assert not path.exists(), f"Refusing to replace {path}"
    environment = {"OMP_NUM_THREADS": "4", "OMP_DYNAMIC": "FALSE", "OPENBLAS_NUM_THREADS": "1"}
    env = os.environ.copy()
    env.update(environment)
    command = [str(FILES["binary"]), str(FILES["input"]), str(output)]
    started = time.monotonic()
    start_epoch = time.time()
    samples = []
    libraries = {}
    with stdout_path.open("xb") as out, stderr_path.open("xb") as err:
        process = subprocess.Popen(command, cwd=HERE, env=env, stdout=out, stderr=err)
        proc = Path("/proc") / str(process.pid)
        executable_sha = sha(proc / "exe")
        assert executable_sha == EXPECTED["binary"]
        actual_cmdline = (proc / "cmdline").read_bytes().split(b"\0")
        assert [x.decode() for x in actual_cmdline if x] == command
        start = {"schema": "vakint.native-fresh-invocation-start.v1", "pid": process.pid,
                 "command": command, "cwd": str(HERE), "controlled_environment": environment,
                 "start_epoch_seconds": start_epoch, "pre_artifact_sha256": pre,
                 "proc_executable_sha256": executable_sha, "actual_proc_command_matches": True,
                 "same_saved_input_no_preparer_run": True, "frozen_binary_no_rebuild": True,
                 "maximum_native_workers": 4, "native_address_space_cap_bytes": 2 * 2**30}
        save(HERE / "invocation-start.json", start)
        print(json.dumps({"started_pid": process.pid, "command": command, "start_receipt": str(HERE / 'invocation-start.json')}), flush=True)
        timed_out = False
        while process.poll() is None:
            try:
                tasks = list((proc / "task").iterdir())
                samples.append({"elapsed_seconds": time.monotonic() - started, "process_task_count": len(tasks)})
                for line in (proc / "maps").read_text().splitlines():
                    parts = line.split(maxsplit=5)
                    if len(parts) == 6 and parts[-1].startswith('/'):
                        path = parts[-1]
                        if path not in libraries and Path(path).is_file():
                            libraries[path] = sha(path)
            except FileNotFoundError:
                pass
            save(HERE / "invocation-progress.json", {"pid": process.pid, "elapsed_seconds": time.monotonic()-started,
                                                      "samples": samples, "mapped_file_sha256": libraries})
            if time.monotonic() - started > 7200:
                timed_out = True
                process.terminate()
                break
            time.sleep(15)
        returncode = process.wait(timeout=60)
    post = {key: sha(path) for key, path in FILES.items()}
    unchanged = all(post[key] == value["sha256"] for key, value in pre.items())
    comparison = {"output_exists": output.exists(), "excluded_fields": ["seconds", "setup_seconds", "initialization_seconds", "certificate_seconds", "peak_rss_bytes"]}
    if output.exists():
        actual = json.loads(output.read_bytes())
        original = json.loads(FILES["original_output"].read_bytes())
        keys = set(actual) | set(original)
        excluded = set(comparison["excluded_fields"])
        comparison["all_numerical_and_semantic_fields_exactly_equal"] = all(actual.get(k) == original.get(k) for k in keys - excluded)
        comparison["compared_field_names"] = sorted(keys - excluded)
        comparison["differing_field_names"] = sorted(k for k in keys - excluded if actual.get(k) != original.get(k))
        comparison["all_528_scalar_outward_strings_identical"] = all(actual[k] == original[k] for k in ["normalized_J_values", "original_Y_values"])
        comparison["local_tail_certified"] = actual.get("local_tail_certified") is True
        comparison["accepted_order"] = actual.get("order")
    clean_log = lambda text: re.sub(r"seconds [0-9.]+", "seconds <elapsed>", text)
    comparison["all_certificate_log_fields_exact_except_elapsed_seconds"] = clean_log(stderr_path.read_text()) == clean_log(FILES["original_log"].read_text())
    accepted = (returncode == 0 and not timed_out and unchanged and
                comparison.get("all_numerical_and_semantic_fields_exactly_equal", False) and
                comparison.get("all_certificate_log_fields_exact_except_elapsed_seconds", False) and
                comparison.get("all_528_scalar_outward_strings_identical", False) and comparison.get("local_tail_certified", False))
    report = {"schema": "vakint.pr9.production-B.fresh-native-invocation-review.v1", "accepted": accepted,
              "start_receipt": {"path": str(HERE / "invocation-start.json"), "sha256": sha(HERE / "invocation-start.json")},
              "command": command, "pid": process.pid, "returncode": returncode, "timed_out": timed_out,
              "elapsed_seconds": time.monotonic()-started, "pre_artifact_sha256": pre,
              "post_artifact_sha256": post, "all_original_inputs_sources_and_outputs_unchanged": unchanged,
              "mapped_file_sha256": libraries, "thread_observations": samples,
              "observed_max_process_task_count": max((s["process_task_count"] for s in samples), default=0),
              "comparison": comparison,
              "new_artifacts": {str(p): sha(p) for p in [output, stderr_path, stdout_path] if p.exists()},
              "source_precision_or_HPL_recomputed": False,
              "producer_or_original_output_mutated": False,
              "scope": "Fresh witnessed identical computation replaces the need to attest the original historical invocation; no subsequent transport or whole-master claim."}
    save(HERE / "invocation-review.json", report)
    print(json.dumps({"accepted": accepted, "receipt": str(HERE / 'invocation-review.json'), "sha256": sha(HERE / 'invocation-review.json'), "comparison": comparison}, indent=2), flush=True)
    if not accepted:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
