#!/usr/bin/env python3
"""Review actual X8 admission author and consumer using virtual test envelopes."""
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
AUTHOR_PATH = HERE.parent / "seal.py"
BASE = HERE.parents[2]
CONSUMER_PATH = BASE / "ancestor-flows/rpf-chain-acceptance-v1/initial_admission.py"
FOUR = {
    "A": {"path": str(BASE / "ancestor-flows/four-loop-production-A-admission-v1/physical-source-admission.json"),
          "sha256": "18a809a538a0edbad22e802d5a36d8c43568eceb241307c95fea5a1dd252858c"},
    "B": {"path": str(BASE / "helper/pr9-production-B-source-admission/admission.json"),
          "sha256": "e5054f6c23aaf9ced10e343cb4034f69d81bc76b84982e056463b6fe2201ed1e"},
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def json_sha(data):
    return hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    if not __debug__:
        raise RuntimeError("Assertions required")
    author_sha, consumer_sha = sha(AUTHOR_PATH), sha(CONSUMER_PATH)
    for binding in FOUR.values():
        assert sha(binding["path"]) == binding["sha256"]
    author = module("tested_x8_author", AUTHOR_PATH)
    consumer = module("tested_frozen_initial_consumer", CONSUMER_PATH)
    virtual_review_path = HERE / "VIRTUAL_REVIEW_NOT_WRITTEN.json"
    assert not virtual_review_path.exists()
    blessing = {
        "accepted": True, "status": "passed_frozen_X8_physical_initial_envelope_author",
        "author_sha256": author_sha, "four_loop_admissions": FOUR,
        "artifact_sha256": {str(AUTHOR_PATH): author_sha, **{r["path"]: r["sha256"] for r in FOUR.values()}},
    }
    virtual_review_hash = json_sha(blessing)
    original_read, original_sha = author.read, author.sha
    mutations = {}

    def test_sha(path):
        if Path(path).resolve() == virtual_review_path:
            return virtual_review_hash
        return original_sha(path)

    def test_read(path, digest=None):
        resolved = Path(path).resolve()
        if resolved == virtual_review_path:
            assert digest == virtual_review_hash
            author.PINS[str(resolved)] = virtual_review_hash
            data = copy.deepcopy(blessing)
        else:
            data = original_read(path, digest)
        if str(resolved) in mutations:
            mutations[str(resolved)](data)
        return data

    author.sha, author.read = test_sha, test_read
    controls = []
    profiles = {}
    all_pins = {str(AUTHOR_PATH): author_sha, str(CONSUMER_PATH): consumer_sha}

    def execute(profile):
        author.PINS.clear()
        destination = HERE / ("NEVER_EMITTED_" + profile + ".json")
        assert not destination.exists()
        saved_argv = sys.argv
        sys.argv = [str(AUTHOR_PATH), "--profile", profile,
                    "--four-loop-admission", FOUR[profile]["path"], "--four-loop-sha256", FOUR[profile]["sha256"],
                    "--independent-review", str(virtual_review_path), "--independent-review-sha256", virtual_review_hash,
                    "--output", str(destination), "--check-only"]
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                envelope = copy.deepcopy(author.main())
        finally:
            sys.argv = saved_argv
        assert not destination.exists() and not virtual_review_path.exists()
        return envelope

    class ConsumerContext:
        def __init__(self, virtual):
            self.virtual = virtual
        def require(self, value, message):
            if not value:
                raise ValueError(message)
        def sha(self, path):
            path = str(Path(path).resolve())
            return json_sha(self.virtual[path]) if path in self.virtual else sha(path)
        def pin(self, path, digest, target):
            path = Path(path).resolve()
            self.require(self.sha(path) == digest, "Consumer pin mismatch " + str(path))
            target[str(path)] = digest
            return path
        def load(self, path):
            path = str(Path(path).resolve())
            return copy.deepcopy(self.virtual[path]) if path in self.virtual else json.loads(Path(path).read_text())

    def consume(envelope, *, verify_files=True):
        virtual_path = HERE / "VIRTUAL_ENVELOPE_NOT_WRITTEN.json"
        assert not virtual_path.exists()
        c = ConsumerContext({str(virtual_path): envelope, str(virtual_review_path): blessing})
        if not verify_files:
            # Corruption controls test consumer semantics after baseline pin
            # closure has already been checked. Original files remain read-only.
            c.sha = lambda path: json_sha(c.virtual[str(Path(path).resolve())]) if str(Path(path).resolve()) in c.virtual else all_pins[str(Path(path).resolve())]
        sources, artifacts = {}, {}
        result = consumer.verify(c, BASE, Path(envelope["initial_artifact_path"]), virtual_path,
                                 json_sha(envelope), sources, artifacts)
        assert not virtual_path.exists()
        return result, sources, artifacts

    for profile in ["A", "B"]:
        envelope = execute(profile)
        assert envelope["initial_artifact_sha256"] == author.INITIAL_HASH[profile]
        assert len(envelope["admitted_primitive_data"]) == 4
        for path, digest in envelope["source_pins"].items():
            if path == str(virtual_review_path):
                continue
            assert path not in all_pins or all_pins[path] == digest
            all_pins[path] = digest
        result, sources, artifacts = consume(envelope)
        assert result[1]["physical_provenance_verified"] is True
        profiles[profile] = {
            "actual_author_check_only_passed": True,
            "frozen_consumer_verified_returned_envelope": True,
            "initial_sha256": envelope["initial_artifact_sha256"],
            "four_loop_admission": FOUR[profile],
            "primitive_data_count": len(envelope["admitted_primitive_data"]),
            "all_252_initial_balls_checked": len(result[0]["values"]) == 252,
            "absolute_total_radius_target_digits": envelope["actual_raw_total_radius_gate_digits"],
            "source_pin_count": len(sources), "artifact_pin_count": len(artifacts),
        }
        for field in ["accepted", "initial_physical_provenance_verified", "native_input_source_assembly_verified",
                      "source_expression_and_matching_verified", "primitive_sources_physically_admitted"]:
            bad = copy.deepcopy(envelope)
            bad[field] = False
            try:
                consume(bad, verify_files=False)
            except (ValueError, KeyError, TypeError) as error:
                controls.append({"profile": profile, "control": "consumer_false_" + field, "rejected": True, "message": str(error)})
            else:
                raise AssertionError("Consumer admitted false " + field)
        for field, value in [("source_pins", {}), ("artifact_sha256", {}),
                             ("initial_artifact_sha256", "0" * 64), ("status", "conditional")]:
            bad = copy.deepcopy(envelope)
            bad[field] = value
            try:
                consume(bad, verify_files=False)
            except (ValueError, KeyError, TypeError) as error:
                controls.append({"profile": profile, "control": "consumer_invalid_" + field, "rejected": True, "message": str(error)})
            else:
                raise AssertionError("Consumer admitted invalid " + field)

    # These controls are early author gates. Only the reviewed in-memory object
    # is mutated after real file/hash checking; no scientific artifact is edited.
    author_cases = [
        (virtual_review_path, "unaccepted_review", lambda d: d.__setitem__("accepted", False)),
        (virtual_review_path, "wrong_author_hash", lambda d: d.__setitem__("author_sha256", "0" * 64)),
        (virtual_review_path, "missing_blessed_four_map", lambda d: d.pop("four_loop_admissions")),
        (author.FIXED["raw_poles"][0], "raw_poles_not_accepted", lambda d: d.__setitem__("accepted", False)),
        (author.FIXED["raw_to_infinity"][0], "missing_lift_entry", lambda d: d.__setitem__("entries_checked", 63503)),
        (author.FIXED["raw_to_infinity"][0], "short_epsilon_lift", lambda d: d.__setitem__("epsilon_orders", [0, 4])),
        (author.FIXED["preparation"][0], "rank_deficit", lambda d: d.__setitem__("independent_free_constants", 251)),
        (author.FIXED["preparation"][0], "unproved_generic_log_bound", lambda d: d.__setitem__("modular_observation_used_as_proof", True)),
        (author.FIXED["preparation"][0], "wrong_log_bound", lambda d: d.__setitem__("generic_all_orders_log_degree_bound", 9)),
    ]
    for path, label, change in author_cases:
        mutations[str(Path(path).resolve())] = change
        try:
            execute("A")
        except (ValueError, KeyError, TypeError) as error:
            controls.append({"profile": "A", "control": label, "rejected": True, "message": str(error)})
        else:
            raise AssertionError("Author admitted invalid " + label)
        finally:
            mutations.clear()
    author.read, author.sha = original_read, original_sha
    for path, digest in all_pins.items():
        assert sha(path) == digest, "Original changed during review: " + path
    report = {
        "schema": "vakint.X8-initial-envelope-actual-author-consumer-controls.v1",
        "all_actual_check_only_and_consumer_checks_passed": True,
        "author_sha256": author_sha, "consumer_sha256": consumer_sha,
        "four_loop_admissions": FOUR, "profiles": profiles,
        "negative_controls": controls, "negative_control_count": len(controls),
        "artifact_sha256": all_pins,
        "review_script_sha256": sha(__file__),
        "mock_scope": "Only the not-yet-issued independent author-review object and returned envelope path are virtual in-memory objects. All actual four-loop receipts, fixed evidence, sources, native invocations, immutable initial artifacts, and artifact hashes are real and rechecked. Neither virtual accepted object is written.",
        "accepted_initial_or_author_review_written": False,
        "new_source_native_HPL_or_transport_computation": False,
        "original_files_modified": False,
    }
    destination = HERE / "complete-checks.json"
    destination.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"path": str(destination), "sha256": sha(destination), "profiles": profiles,
                      "negative_controls": len(controls), "artifact_pins": len(all_pins)}, indent=2))


if __name__ == "__main__":
    main()
