#!/usr/bin/env python3
"""Complete bounded-source three-loop infinity epsilon/log boundary."""
import argparse,copy,hashlib,json,sys,time
from pathlib import Path
from fractions import Fraction
from flint import arb,ctx,fmpq
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'pr11-boundary'))
from source_recipes import build_factor_expressions,gamma_expression,HELPER,primitive,read,sha
from gamma_jets import tadpole,radial
from gamma_ast import GammaExpression
from expanded_boundary import ExpandedBoundary
from logjet_map import BoundaryLogJetMap,EPS
ANCESTOR=HERE.parent.parent/'pr11d/ancestor-flows'

def load_plan(path,expected_sha,epsilon):
    if sha(path)!=expected_sha:raise ValueError('Native inventory checksum mismatch')
    data=read(path);view=copy.deepcopy(data)
    for row in view['coverage']:
        for field in ['leading_alpha','leading_beta']:row[field]=row[field].replace(epsilon,EPS)
    for row in view['boundary_coefficients']:
        row['inverse_eta_exponent']=row['inverse_eta_exponent'].replace(epsilon,EPS)
        for term in row['products']:term['coefficient']=term['coefficient'].replace(epsilon,EPS)
    return BoundaryLogJetMap(view)

def factor_expressions(name='three-loop-seven'):
    old,old_receipt=build_factor_expressions();inventory=read(HERE/(name+'-inventory.json'))
    requested={r['key']:r for r in inventory['factors']};out={k:old[k] for k in requested if k in old}
    children={}
    for row in read(HELPER/'massless-followup/all-212-trees.json')['children']:
        children[row['child_key']]=GammaExpression.from_tree(row['expression'],identity=row['child_key'])
    for row in read(HERE/'massless-one-two-loop/exact-trees.json')['children']:
        children[row['child_key']]=GammaExpression.from_tree(row['exact_tree'],identity=row['child_key'])
    for row in read(HERE/(name+'-singlemass.json'))['proofs']:
        key=row['factor_key'];proof=row['proof']
        if key in out:continue
        if proof['status']=='actual_native_single_mass_plan_proved':
            out[key]=children[proof['child_key']].multiply_recipe(radial(proof))
        elif proof['status']=='existing_one_loop_tadpole_terminal_shape_proved':
            source=requested[key];assert source['family']['propagators']==[{'constant':'-1','scalar_products':['1']}]
            out[key]=gamma_expression(tadpole(source['powers'][0]))
    seeds=read(HELPER/'massless-followup/product-seeds/bindings.json')
    seed_by_hash={r['definition_sha256']:r for r in seeds['seeds']}
    for row in read(HERE/(name+'-products.json'))['proofs']:
        key=row['factor_key'];proof=row['proof']
        if key in out or proof['status']!='native_vacuum_product_proved':continue
        from gamma_ast import Monomial
        from logjet_map import parse
        expr=GammaExpression([Monomial(parse(proof['coefficient'].replace('rustred::{}::d','(4-2*'+EPS+')'),EPS,'unused'))],identity='native vacuum product coefficient')
        for f in proof['factors']:
            if f['loops']==1:
                assert f['denominators']==[{'constant':'-1','coefficients':['1']}] and len(f['powers'])==1
                child=gamma_expression(tadpole(f['powers'][0]))
            else:
                canonical=json.dumps({k:f[k] for k in seeds['definition_fields']},sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
                s=seed_by_hash[hashlib.sha256(canonical).hexdigest()];ev=s['evaluation']
                from source_recipes import polynomial
                child=primitive(f"native::L{ev['catalog_loop_count']}_{ev['catalog_name']}").scale(polynomial(ev['coefficient_epsilon_polynomial']))
            expr=expr.multiply(child)
        out[key]=expr
    missing=set(requested)-set(out)
    if missing:raise ValueError('Explicit source recipes still missing: '+','.join(sorted(missing)))
    return out,{'native_inventory_sha256':sha(HERE/(name+'-inventory.json')),'factor_count':len(out),'reused_X8_source_bindings':old_receipt,
      'additional_child_trees_sha256':sha(HERE/'massless-one-two-loop/exact-trees.json'),'native_singlemass_sha256':sha(HERE/(name+'-singlemass.json')),'native_products_sha256':sha(HERE/(name+'-products.json'))}

def key(row):return tuple(int(row[k]) for k in ['component','integer_z_power','epsilon_power','log_power'])
def sparse(rows):return [[(j,fmpq(v)) for j,v in enumerate(row) if v!='0'] for row in rows]
def dot(row,vector):return sum((vector[j]*q for j,q in row),arb(0))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--working-digits',type=int,default=260);ap.add_argument('--output-prefix',required=True);args=ap.parse_args()
    ctx.dps=args.working_digits;ctx.threads=1;start=time.time();name='three-loop-seven'
    data=read(ANCESTOR/(name+'-matching.json'));inventory=HERE/(name+'-inventory.json')
    plan=load_plan(inventory,data['inventory_sha256'],'masters_3l::{}::epsilon')
    factors,source_receipt=factor_expressions(name)
    sunsetpath=ANCESTOR/'sunset-ratio-20300-normalized.json';sunset=read(sunsetpath)
    assert sunset['error_quality']=='rigorous-bound' and sunset['validated_analytic_truncation_and_rounding'] is True
    rows=sunset['coefficients']['native_raw'];assert [r['epsilon_power'] for r in rows]==list(range(-2,4))
    from logjet_map import FactorJet
    primitives={'native::L2_P2':FactorJet(-2,tuple(arb(r['ball']) for r in rows),
      'Exact sunset hypergeometric epsilon-jet recurrence with analytic complex-epsilon Cauchy bound; native raw support begins epsilon^-2','native::L2_P2; '+sha(sunsetpath))}
    compiled=ExpandedBoundary(plan,factors,max_log_power=data['max_exact_log_degree'])
    required,_=compiled.required_primitive_orders(primitives,last_epsilon_power=2)
    out=compiled.evaluate(primitives,first_epsilon_power=-3,last_epsilon_power=2)
    values={}
    for (i,a,p,l),v in out.items():
        assert a.denominator==1;values[i,a.numerator,p,l]=v
    allkeys=[key(r) for r in data['all_boundary_selectors']];wanted=set(allkeys)
    for k,v in values.items():
        if k not in wanted and not v.contains(0):raise ValueError('Unexpected source support '+str(k)+' '+v.str(30))
    boundary=[values[k] for k in allkeys]
    positions={k:i for i,k in enumerate(allkeys)};rhs=[values[key(r)] for r in data['selected_selectors']]
    constants=[dot(row,rhs) for row in sparse(data['boundary_inverse'])]
    for k,v,row in zip(allkeys,boundary,sparse(data['all_boundary_matrix'])):
        residual=dot(row,constants)-v
        if not residual.contains(0):raise ValueError('Inconsistent three-loop boundary '+str(k)+':'+residual.str(30))
    prefix=Path(args.output_prefix)
    payload={'schema':'vakint.three-loop.complete-source-boundary.v1','inventory_sha256':data['inventory_sha256'],'matching_sha256':sha(ANCESTOR/(name+'-matching.json')),'normalization':'native_raw','error_quality':'rigorous-bound','all_prepared_rows_checked':True,'coefficient_count':len(boundary),'free_constants':42,'working_decimal_digits':args.working_digits,'source_recipe_receipt':source_receipt,'sunset_source_sha256':sha(sunsetpath),'required_raw_primitive_through':required,
      'coefficients':[{**row,'real_ball':v.str(args.working_digits+8,more=True)} for row,v in zip(data['all_boundary_selectors'],boundary)],'free_constant_balls':[v.str(args.working_digits+8,more=True) for v in constants],
      'all_overdetermined_residuals_contain_zero':True,'scientific_whole_master_accuracy_claimed':False,'wall_seconds':time.time()-start,'implementation_sha256':sha(Path(__file__))}
    prefix.with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
    print('PASS:',len(factors),'factors;',len(boundary),'rows;42constants;needed',required,'seconds',time.time()-start,flush=True)
if __name__=='__main__':main()
