#!/usr/bin/env python3
"""Independent v11 source/metadata/final-mode guard audit; no engine calls."""
import ast
import contextlib
import copy
import hashlib
import importlib.util
import io
import itertools
import json
import sys
from pathlib import Path
from types import SimpleNamespace
from flint import arb, ctx

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
BASE = HERE.parent


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def module(name, p):
    spec = importlib.util.spec_from_file_location(name, p)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


def main():
    v = module('independent_v11_validator', BASE / 'validate.py')
    c = module('independent_v11_common', v.COMMON)
    pin_doc = v.load(BASE / 'checker-pins.json')
    implementations = {str(p): sha(p) for p in [BASE / 'validate.py', v.INITIAL_MODULE,
                                               v.COMMON, BASE / 'checker-pins.json']}
    implementations.update(pin_doc['implementation_sha256'])
    before = dict(implementations)
    cases = []

    def reject(name, f, allowed=(ValueError, KeyError, TypeError, FileNotFoundError)):
        try:
            f()
        except allowed as e:
            cases.append({'case': name, 'rejected': True, 'diagnostic': str(e)})
        else:
            raise AssertionError('Corruption accepted: ' + name)

    initials = {}
    for profile in 'AB':
        p = v.ROOT / f'helper/frobenius-transport/x8-production-{profile}-scheduled-v1/conditional-initial.json'
        initials[profile] = v.load(p)
        before[str(p)] = sha(p)
        assert before[str(p)] == v.PROFILES[profile]['initial_sha256']
        v.initial_metadata(c, initials[profile])
    initial = initials['A']
    for key in ['schema', 'physical_source_admission_required', 'whole_PR11d_accuracy_claimed',
                'raw_total_width_gate_passed', 'local_tail_certified']:
        d = dict(initial); d.pop(key)
        reject('initial_missing_' + key, lambda d=d: v.initial_metadata(c, d))
    for key, bads in [('physical_accuracy_certified', [False, True, None, 0]),
                      ('physical_source_admission_required', [False, None, 0, 1, 'true']),
                      ('whole_PR11d_accuracy_claimed', [True, None, 0, 'false']),
                      ('whole_PR11d_20000_accuracy_claimed', [True, None, 0]),
                      ('raw_total_width_gate_passed', [False, None, 1]),
                      ('dimension', [41, 42.0]), ('jets', [5, 6.0]),
                      ('epsilon_min_power', [-3, -4.0]),
                      ('eta_center', [['0', '128']]), ('normalization', ['FMFT']),
                      ('error_quality', ['validated-digits-estimate'])]:
        for bad in bads:
            reject(f'initial_{key}_{bad!r}', lambda key=key, bad=bad: v.initial_metadata(c, {**initial, key: bad}))
    following = v.load(v.ROOT / 'hierarchy-transport/x8-production-A-halfsteps-v11/step-000-boundary.json')
    v.produced_metadata(c, following, 'boundary')
    for label in ['boundary', 'complete receipt']:
        for field in ['physical_source_admission_required', 'physical_accuracy_certified', 'whole_PR11d_20000_accuracy_claimed']:
            d = dict(following); d.pop(field)
            reject(f'{label}_missing_{field}', lambda d=d, label=label: v.produced_metadata(c, d, label))
            for bad in [None, 0, 1, 'false', not following[field]]:
                reject(f'{label}_{field}_{bad!r}', lambda field=field, bad=bad, label=label: v.produced_metadata(c, {**following, field: bad}, label))
        for bad in [True, None, 0]:
            reject(f'{label}_contradictory_legacy_{bad!r}', lambda bad=bad, label=label: v.produced_metadata(c, {**following, 'whole_PR11d_accuracy_claimed': bad}, label))

    tree = ast.parse((BASE / 'validate.py').read_text())
    main_node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    accepted_expr = next(n.value for n in ast.walk(main_node) if isinstance(n, ast.Assign)
                         and any(isinstance(t, ast.Name) and t.id == 'accepted' for t in n.targets))
    accepted_code = compile(ast.Expression(accepted_expr), '<actual-v11-acceptance-expression>', 'eval')
    mode_results = []
    for reviews in itertools.product((False, True), repeat=4):
        for check_only in (False, True):
            for prefix in (None, 1, 12):
                values = dict(zip(['accepted_review', 'checker_review_accepted', 'scientific_review_accepted',
                                   'initial_origin_accepted'], reviews))
                values.update(pending_only=v.pending_only, args=SimpleNamespace(check_only=check_only, prefix_steps=prefix))
                result = eval(accepted_code, values)
                assert result is (all(reviews) and not check_only and prefix is None)
                mode_results.append({'validator_checker_physical_initial_reviews': reviews,
                                     'check_only': check_only, 'prefix_steps': prefix, 'accepted': result})
    assert len(mode_results) == 96

    args = SimpleNamespace(independent_review=None, independent_review_sha256=None,
                           physical_proof_review=None, physical_proof_review_sha256=None,
                           check_only=False, prefix_steps=None)
    reject('final_without_validator_authority', lambda: v.reviewed_implementation(args, implementations))
    reject('final_without_physical_authority', lambda: v.physical_proof(c, args, {}))
    template = {'diagnostic_only_not_authority': True, 'accepted': True,
                'status': 'passed_for_frozen_physical_X8_chain_validator',
                'validator_sha256': sha(BASE / 'validate.py'), 'implementation_sha256': implementations}
    for name in ['wrong_status', 'unaccepted', 'wrong_validator', 'missing_helper', 'extra_helper', 'wrong_digest']:
        data = copy.deepcopy(template)
        if name == 'wrong_status': data['status'] = 'checks_passed_independent_review_pending'
        if name == 'unaccepted': data['accepted'] = False
        if name == 'wrong_validator': data['validator_sha256'] = '0' * 64
        if name == 'missing_helper': data['implementation_sha256'].pop(str(v.INITIAL_MODULE))
        if name == 'extra_helper': data['implementation_sha256']['/extra'] = '0' * 64
        p = HERE / (name + '.review-fixture.json')
        p.write_text(json.dumps(data))
        args.independent_review = p
        args.independent_review_sha256 = '0' * 64 if name == 'wrong_digest' else sha(p)
        reject('authority_' + name, lambda: v.reviewed_implementation(args, implementations))

    # Actual CLI gates stop before any numerical checker for these controls.
    def cli(extra):
        saved = sys.argv
        sys.argv = [str(BASE / 'validate.py'), '--profile', 'A', '--output', str(HERE / 'must-not-exist.json'), *extra]
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                v.main()
        finally:
            sys.argv = saved
    reject('final_no_initial_envelope', lambda: cli([]))
    for count in (0, 13, -1):
        reject('invalid_prefix_' + str(count), lambda count=count: cli(['--prefix-steps', str(count)]))
    reject('incomplete_envelope_arguments', lambda: cli(['--prefix-steps', '1', '--initial-admission', '/absent']))
    other = v.ROOT / 'helper/x8-production-initial-admission/production-B-admitted.json'
    reject('A_cannot_use_B_initial_envelope', lambda: cli(['--prefix-steps', '1', '--initial-admission', str(other),
                                                         '--initial-admission-sha256', v.PROFILES['B']['admission_sha256']]))
    assert not (HERE / 'must-not-exist.json').exists()

    # Exercise the unmodified completion branch on diagnostic metadata. The
    # earlier twelve exact-step checks are separate preconditions, not mocked
    # into a claimed physical result here; no report is written from this AST.
    completion = next(n for n in main_node.body if isinstance(n, ast.If)
                      and ast.unparse(n.test) == 'args.prefix_steps is None'
                      and any(isinstance(x, ast.Expr) and isinstance(x.value, ast.Call)
                              and len(x.value.args) > 1 and isinstance(x.value.args[1], ast.Constant)
                              and x.value.args[1].value == 'RPFv11 chain is not complete' for x in n.body))
    complete_code = compile(ast.Module(body=completion.body, type_ignores=[]), '<actual-v11-completion-gates>', 'exec')
    previous = v.ROOT / 'hierarchy-transport/x8-production-A-halfsteps-v11/step-001-boundary.json'
    binding_path = previous.parent / 'run-binding.json'
    ctx.dps = 20600
    width = arb(10) ** -20020
    steps = [{'index': i, 'center': str(256 // (2**i)) if i < 9 else '1', 'destination': '1/16',
              'boundary_sha256': sha(previous), 'native_order': 100, 'native_seconds': 1,
              'local_tail': '0'} for i in range(12)]
    summaries = [{**{k: val for k, val in row.items() if k != 'native_order'}, 'order': row['native_order']} for row in steps]
    complete = {'schema': 'vakint.certified-X8-rpf-ordinary-transport.v11', 'complete': True,
                'error_quality': 'rigorous-bound', 'physical_source_admission_required': True,
                'physical_accuracy_certified': False, 'whole_PR11d_20000_accuracy_claimed': False,
                'final_boundary': str(previous), 'final_boundary_sha256': sha(previous),
                'run_binding_sha256': sha(binding_path), 'steps': summaries,
                'maximum_component_radius': width.str(35, more=True), 'required_final_absolute_digits': 20010,
                'all_final_component_radii_meet_target': True, 'native_seconds': 12}
    progress = {'schema': 'vakint.certified-ancestor-transport-progress.v1', 'completed_steps': 12,
                'expected_steps': 12, 'last_boundary': str(previous), 'last_boundary_sha256': sha(previous),
                'run_binding_sha256': sha(binding_path), 'steps': summaries,
                'whole_PR11d_20000_accuracy_claimed': False}
    base_ns = dict(v.__dict__, c=c, args=SimpleNamespace(prefix_steps=None), complete=complete,
                   progress=progress, final={'whole_PR11d_20000_accuracy_claimed': False}, steps=steps,
                   count=12, previous=previous, binding_path=binding_path, width=width, required=20010)
    exec(complete_code, dict(base_ns))
    for name, group, key, bad in [
        ('v10_complete_schema', 'complete', 'schema', 'vakint.certified-X8-rpf-ordinary-transport.v10'),
        ('unfinished_chain', 'complete', 'complete', False),
        ('only11_completed', 'progress', 'completed_steps', 11),
        ('expected11_steps', 'progress', 'expected_steps', 11),
        ('ledger_physical_claim', 'progress', 'physical_accuracy_certified', True),
        ('ledger_pending_added', 'progress', 'physical_source_admission_required', True),
        ('complete_wrong_final_hash', 'complete', 'final_boundary_sha256', '0' * 64),
        ('ledger_wrong_binding', 'progress', 'run_binding_sha256', '0' * 64),
        ('false_total_width', 'complete', 'all_final_component_radii_meet_target', False),
        ('wrong_final_target', 'complete', 'required_final_absolute_digits', 100),
        ('wrong_radius_serialization', 'complete', 'maximum_component_radius', '0'),
        ('wrong_timing_sum', 'complete', 'native_seconds', -1)]:
        ns = dict(base_ns); ns[group] = copy.deepcopy(base_ns[group]); ns[group][key] = bad
        reject(name, lambda ns=ns: exec(complete_code, ns))
    ns = dict(base_ns, width=arb(10) ** -20010)
    ns['complete'] = {**complete, 'maximum_component_radius': ns['width'].str(35, more=True)}
    reject('strict_final_width_threshold', lambda: exec(complete_code, ns))

    for name, text in [('duplicate', '{"a":1,"a":2}'), ('nan', '[NaN]'), ('infinity', '[Infinity]'), ('overflow', '[1e309]')]:
        p = HERE / (name + '.json-fixture'); p.write_text(text)
        reject('strict_JSON_' + name, lambda p=p: v.load(p))
    for name, path in [('existing', BASE / 'validate.py'), ('outside', BASE.parent / 'forbidden.json'),
                       ('missing_parent', HERE / 'missing' / 'result.json'),
                       ('protected_A49', BASE.parent / 'four-loop-production-A-admission-v1/review/review.json')]:
        reject('output_' + name, lambda path=path: v.fresh_output(path))
    for p, h in before.items():
        assert sha(p) == h
    prefixes = {}
    for profile in 'AB':
        p = HERE / f'independent-{profile}-prefix.json'; d = v.load(p)
        assert d['status'] == 'checks_passed_prefix_only_no_physical_chain_acceptance'
        assert d['prefix_steps'] == d['steps_verified'] == 2
        assert d['physical_origin_established_by_separate_admission'] is True
        assert d['completed_execution_verified'] is False
        assert d['validator_sha256'] == sha(BASE / 'validate.py')
        prefixes[str(p)] = sha(p)
    result = {'schema': 'vakint.X8-v11-independent-highlevel-contract-checks.v1',
              'implementation_sha256': implementations, 'actual_prefix_receipt_sha256': prefixes,
              'negative_controls': cases, 'negative_control_count': len(cases),
              'acceptance_mode_combinations': mode_results,
              'all96_mode_combinations_correct': True,
              'completion_branch_AST_guards_exercised_without_physical_output': True,
              'all_frozen_implementations_and_initial_artifacts_unchanged': True,
              'no_complete_production_chain_claimed': True,
              'native_preparer_HPL_or_transport_calls': 0, 'producer_files_modified': False}
    out = HERE / 'contract-checks.json'
    with out.open('x') as stream: json.dump(result, stream, indent=2); stream.write('\n')
    print(sha(out)); print('negative controls', len(cases))


if __name__ == '__main__':
    main()
