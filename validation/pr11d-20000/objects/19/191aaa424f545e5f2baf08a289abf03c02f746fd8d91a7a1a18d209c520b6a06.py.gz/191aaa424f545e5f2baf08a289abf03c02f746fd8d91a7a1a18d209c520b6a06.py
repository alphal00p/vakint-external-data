"""Replay the authenticated exact4→3 sunset quotient and pseudothreshold shift."""
import json,sys,hashlib
from pathlib import Path
sys.path.insert(0,'/shared/codex-1/vakint_rustred/workspace/precision-periods/pr11d/helper')
from exact_system import Rat,CTX,parse
from endpoint_adjoint import eta_series,multiply,zero_row
here=Path(__file__).parent;source=here/'sunset.json';d=json.load(open(source));A=[[parse(v,d['epsilon_symbol'],d['variable']) for v in row] for row in d['differential_matrix']];select=[0,1,3];groups=[[0],[1,2],[3]]
B=[[sum((A[i][j] for j in group),Rat(0)) for group in groups] for i in select]
# E rows are canonical: Yold=(Z0,Z1,Z1,Z2).
for i in range(4):
 for j,g in enumerate(groups):
  lhs=sum((A[i][k] for k in g),Rat(0));rhs=B[[0,1,1,2][i]][j];assert not(lhs-rhs).num

def shift(poly):
 out=Rat(0);e=Rat(CTX.gen(0));x=Rat(CTX.gen(1))+Rat(3)
 for (ep,xp),v in poly.to_dict().items():out=out+Rat(CTX.constant(v))*e**ep*x**xp
 return out
C=[[shift(v.num)/shift(v.den) for v in row] for row in B]
# Separate q=4^(1-epsilon): the boundary is linear in this exact elementary factor.
e=Rat(CTX.gen(0));b0=[Rat(1),Rat(0),-(Rat(1)-e)/(Rat(1)-Rat(2)*e)];bq=[Rat(0),Rat(1),(Rat(1)-e)/(Rat(1)-Rat(2)*e)]
R=[[eta_series(v,1)[0] for v in row] for row in C]
assert not any(v.num for v in multiply(b0,[[R[j][i] for j in range(3)] for i in range(3)]))
assert not any(v.num for v in multiply(bq,[[R[j][i] for j in range(3)] for i in range(3)]))
result={'schema':'vakint.ancestor.exact-sunset-pseudothreshold.v1','variable':'x','epsilon_symbol':'e','differential_matrix':[[str(v) for v in row] for row in C],'basis':['Yoriginal0','Yoriginal1=Yoriginal2','Yoriginal3'],'epsilon_dependent_normalization':'raw I2/I1^2','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_implementation':'/shared/codex-2/vacuum_masters/MASTERS/3L/artifacts/remaining-physical-v1/primitives.rs:244','quotient_embedding':[[1,0,0],[0,1,0],[0,1,0],[0,0,1]],'selected_rows':select,'original_eta':'x+3','physical_endpoint_x':'-3','boundary_x':'0','boundary_exact':['1','4^(1-e)','(1-e)/(1-2*e)*(4^(1-e)-1)'],'boundary_residue_annihilates_each_elementary_factor_separately':True,'excluded_fractional_exponent':'1/2-e','excluded_fractional_branch_coefficient':'0','numerical_integrals_evaluated':False}
(here/'sunset-shifted3.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS exactquotient+boundaryresidue')
