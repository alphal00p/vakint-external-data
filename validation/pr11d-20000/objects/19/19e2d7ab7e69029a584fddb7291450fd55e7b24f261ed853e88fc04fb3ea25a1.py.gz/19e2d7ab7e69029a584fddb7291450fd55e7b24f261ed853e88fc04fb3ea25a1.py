#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
export=HERE/'export/review.json';saved=HERE/'saved-chain-replay.json';controls=HERE/'resume-controls.json'
assert load(export)['accepted'] is True and load(saved)['accepted'] is True and load(controls)['accepted'] is True
files=[ROOT/'hierarchy-transport/run_x8_rpf_v10.py',ROOT/'hierarchy-transport/prepare_x8_rpf_v1.py',ROOT/'jet-transport/export_x8_rpf.py',ROOT/'jet-transport/x8-ordinary-rational-pf.json',ROOT/'jet-transport/polynomial-connection-regular-gauge.json',ROOT/'helper/jet-transport/transport_rpf_scheduled_threads.c',ROOT/'helper/jet-transport/transport-rpf-scheduled-threads',ROOT/'helper/jet-transport/rpf-scheduled-threads-implementation-review.json',ROOT/'helper/jet-transport/x8-generic-rpf-review-v1.json',ROOT/'hierarchy-transport/x8-rpf-probes/full-control-overlap.json',ROOT/'helper/physical-poles-review/review.json',Path(__file__)]
report={
 'schema':'vakint.pr11d.independent-X8-rpf-v10-wrapper-review.v1',
 'accepted':True,
 'status':'passed_for_frozen_X8_RPF_v10_export_preparation_driver_and_saved_12_halfstep_chain',
 'findings':[],
 'source_identity_and_gauge':{
  'dimension':42,'epsilon_jet_count':6,'epsilon_support':[-4,1],
  'exact_full_rational_raw_to_regular_gauge_identities':1764,
  'exact_epsilon_entry_RPF_identities':648,
  'formula':'Y_i=(1-2*epsilon)^w_i U_i; A_U,ij=(1-2*epsilon)^(w_j-w_i) A_Y,ij, with w_i in {0,1}. The gauge is eta-independent.',
  'initial_conversion':'U_k=Y_k+2 U_(k-1) for weight 1, and U_k=Y_k for weight 0. No coefficients below epsilon^-4 are introduced.',
  'output_conversion':'Y_k=U_k-2 U_(k-1) for weight 1, and Y_k=U_k for weight 0. Every arithmetic and serialization operation retains Arb radii.',
  'finite_jet_closure':'The regular epsilon connection has no negative epsilon powers. Given the independently certified raw42 lower pole bound -4, coefficients through epsilon^1 require precisely the six supplied jets; no unknown higher jet feeds them.'
 },
 'local_input_and_path':{
  'equation':'With eta=c+h*t, the prepared equation is L*D(c+h*t) dU/dt = L*h*N(c+h*t) U. Exact common Gaussian-integer scaling L cancels.',
  'RPF_contract':'RPF numerator and factor polynomials are still in original eta; the native exact startup reconstruction performs its own local substitution and compares every coefficient with the prepared polynomial connection.',
  'constant_component_scale':'Exactly 1 in all 42 components. No eta-dependent basis change or unrecorded component scale.',
  'path':'For substeps=1, exact rational centers 256i,128i,...,i/16 give twelve halving steps. All denominator roots are real, and the positive imaginary segments avoid every root. General substeps split each halving into equal exact rational increments.',
  'denominator_bound':'Every real linear factor has its least modulus at the lower positive-imaginary endpoint. Multiplying these minima, including multiplicity and leading scale, is a valid product lower bound. The native Arb denominator division uses an interval containing a number no larger than this proven bound.'
 },
 'driver_and_error_preservation':{
  'initial_admission':'Checks raw normalization, rigorous-bound label, local enclosure flag, support, size, center, source pins, and either the explicit initial contract or initial artifact fields. It does not itself rebuild primitive source expressions; their scientific admission is upstream.',
  'execution_binding':'Pins initial data, driver, preparer, imported preparation helpers, connection/source, RPF artifacts/converter, and native executable. Rechecks these snapshots before every step. Direct subprocess calls use the exact prepared input and designated native output, with checked return status and requested/actual worker counts.',
  'continuation':'Saved steps bind preceding boundary, input, native output, initial boundary, run binding, source/connection, exact center/step and gauge; inverse gauge is recomputed and must serialize identically. Existing run binding must match before resume.',
  'total_errors':'Both the input and output conversions use full complex Arb balls, with no midpoint extraction. The frozen reviewed native engine retains source, rounding and tail errors. Every following coefficient must be finite.',
  'width_gate':'The optional require-final-digits gate compares the maximum of both Cartesian component radii across all 252 states with 10^(-digits). Failure records the false gate and raises; the driver never sets a whole-20000-digit physical claim.',
  'threading':'The audited wrapper admits 1,2,4,8 requested workers and verifies actual workers. This saved chain used 4; its mathematical kernel is the previously reviewed scheduled-threads executable.'
 },
 'independent_saved_artifact_replay':{
  'steps':12,'exact_local_D_N_polynomial_identities':7788,'exact_RPF_terms':25056,
  'initial_regular_gauge_ball_containments':3024,'inverse_gauge_serializations':3024,
  'segment_denominator_bounds':12,'all_252_terminal_overlaps_with_old_path':True,
  'old_terminal_enclosures_contain_new':True,
  'maximum_final_component_radius':load(saved)['maximum_terminal_component_radius'],
  'all_final_component_radii_below_1e_minus800':True
 },
 'controls':{'positive_saved_resume':True,'corruption_rejections':16,'subprocesses_forbidden':True,'coverage':['wrong actual worker count','false native tail flag','missing native coefficient','wrong endpoint','wrong basis or Laurent support','changed polynomial/source/seed/RPF pins','changed exact step or gauge','changed component scale','wrong previous-boundary or run-binding hash','narrowed native output','nonfinite native output']},
 'review_receipts':{str(p):sha(p) for p in [export,saved,controls]},
 'implementation_and_source_sha256':{str(p):sha(p) for p in files},
 'scope_limits':[
  'This accepts the frozen X8 source-to-gauge-to-RPF conversion, input preparation, driver error preservation, and saved bounded 12-step chain. Native transport was not rerun; native algorithm correctness is inherited from its independently reviewed frozen kernel.',
  'Hashes and a reviewed direct execution wrapper establish the normal workflow provenance contract; saved files alone are not a cryptographic attestation of past process execution.',
  'The c104 initial boundary must separately pass primitive/source-expression admission. This review does not infer that admission from overlap, metadata labels, or the raw-pole theorem.',
  'The exact raw42 pole bound is a separate accepted mathematical proof. Final endpoint projection, whole physical chain acceptance, and any precision promotion remain separate.'
 ],
 'whole_PR11d_20000_accuracy_claimed':False,
 'producer_files_modified':False,'native_transport_jobs_run':0
}
output=HERE/'review.json';assert not output.exists();output.write_text(json.dumps(report,indent=2)+'\n')
print(output);print(sha(output))
