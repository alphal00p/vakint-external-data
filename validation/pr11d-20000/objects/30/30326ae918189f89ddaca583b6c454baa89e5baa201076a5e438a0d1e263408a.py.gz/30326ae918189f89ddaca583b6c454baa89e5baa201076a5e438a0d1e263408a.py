#!/usr/bin/env python3
"""Independent source invariants and saved X8 output checks; no native reruns."""
from pathlib import Path
import hashlib,json
from flint import arb,acb,ctx
HERE=Path(__file__).resolve().parent;N=HERE.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
source=N/'contracted_v2_scheduled.c';base=N/'contracted_v2_threads.c';s,t=base.read_text(),source.read_text()
def function(text,name):
 start=text.index(name+'(');start=text.rfind('\nstatic ',0,start)+1
 ends=[i for i in [text.find('\nstatic ',start+1),text.find('\nint main(',start+1)] if i>=0]
 return text[start:min(ends)]
unchanged=['initialize','make_adjugates','certify','read_input','build_bounds','emit_array','set_z0']
for name in unchanged:assert function(s,name)==function(t,name),name
old=function(s,'next_coefficient');new=function(t,'next_coefficient')
assert new.replace('    /* Never round the O(1) accumulated sum to a coefficient\'s smaller precision. */\n','').replace('acb_add(total+i,total+i,result+i,precision_max);','acb_add(total+i,total+i,result+i,precision);')==old
proof=HERE/'proof/review.json';controls=HERE/'controls.json';negative=HERE/'negative-total-control.json';factors=HERE/'x8-factor-review.json';performance=N/'scheduled-performance-v1/receipt-v2.json'
assert load(proof)['mathematical_rule_accepted'] and all(load(p)['accepted'] for p in [controls,negative,factors])
perf=load(performance);assert perf['accepted_for_scope']
for path,digest in perf['source_and_output_sha256'].items():assert sha(Path(path))==digest
ctx.dps=21000
checks=[]
for label,a,b,complete in [('partial20k',N/'threads-review/x8-20000-first1000-workers8.json',N/'scheduled-performance-v1/x8-first1000-scheduled-workers8.json',False),('full1000',N/'scheduled-performance-v1/x8-full1000-baseline-workers8.json',N/'scheduled-performance-v1/x8-full1000-scheduled-workers8.json',True)]:
 x,y=load(a),load(b);assert x['local_tail_certified'] is y['local_tail_certified'] is complete
 assert x['actual_workers']==y['actual_workers']==8 and x['dimension']==y['dimension']==252
 assert y['precision_max_bits']==x['working_bits']==y['working_bits'] and y['coefficient_precision_slope_bits_per_order']==4 and y['schedule_radius_ratio_squared']=='65536/225'
 assert y['full_precision_startup_total_certificate_and_output'] is True and y['schedule_is_accuracy_guarantee'] is False
 assert y['minimum_coefficient_precision_bits_used']==max(1024,y['precision_max_bits']-4*y['order'])
 maxima={}
 for field in ['normalized_J_values','original_Y_values']:
  left=[acb(arb(re),arb(im)) for re,im in x[field]];right=[acb(arb(re),arb(im)) for re,im in y[field]]
  assert len(left)==len(right)==252 and all(u.is_finite() and v.is_finite() and u.overlaps(v) for u,v in zip(left,right))
  if complete:assert all(v.real.rad()+v.imag.rad()<arb('1e-1000') for v in left+right)
  maxima[field]=max(v.real.rad()+v.imag.rad() for v in right).str(45,more=True)
 checks.append({'scope':label,'accepted_for_scope':True,'all_504_original_and_normalized_complex_balls_overlap':True,'local_tail_certified':complete,'full_solution_1000_digit_total_width_gate_passed':complete,'maximum_radii_real_plus_imag':maxima,'order':y['order'],'Pmax':y['precision_max_bits'],'minimum_coefficient_bits':y['minimum_coefficient_precision_bits_used'],'baseline_seconds':x['seconds'],'scheduled_seconds':y['seconds'],'baseline_sha256':sha(a),'scheduled_sha256':sha(b)})
files=[source,base,N/'contracted-native-v2-scheduled',N/'contracted-native-v2-threads',N/'build-v2-scheduled.sh',proof,controls,negative,factors,performance,N/'review_scheduled_performance_v1.py',Path(__file__)]
report={
 'schema':'vakint.pr11d.independent-unmasked-Frobenius-precision-schedule-review.v1',
 'accepted':True,
 'status':'passed_frozen_code_math_active_schedule_controls_and_bounded_X8_checks',
 'findings':[],
 'candidate_source_sha256':sha(source),'candidate_binary_sha256':sha(N/'contracted-native-v2-scheduled'),
 'schedule':{'formula':'Pmax for n<=0; max(min(Pmax,1024), Pmax-s*n) for n>0','slope':'min(30,floor(log2(rho/abs(z0)))) clipped below at zero, where rho is minimum modulus of the exact nonzero real linear roots of recovered d(z); unsupported input gives zero slope.','exact_factor_reconstruction':True,'pure_imaginary_ray_guard':True,'X8_radius_ratio_squared':'65536/225','X8_slope':4,'role':'Efficiency heuristic only; no coefficient amplitude or output-accuracy assertion.'},
 'mathematical_argument':{
  'induction':'With the same consistent exact startup maps and common initial balls, outward coefficient forcing and exact-integer block inversion at any supported positive precision enclose the same exact coefficient sequence. Changing work precision changes ball widths, not the equation or selected solution family.',
  'residual':'Low-order residual coefficients vanish for that exact sequence. The unchanged high-order polynomial residual evaluated from coefficient balls at Pmax encloses the exact truncation residual, so the unchanged singular-endpoint supersolution proof applies.',
  'total':'Every coefficient ball, including all startup/source/rounding uncertainty, is added to the finite total at Pmax. The original tail enlargement and final gauge remain outward at Pmax. A poor precision schedule may fail the tail or total-width gate but cannot justify narrowing any radius.',
  'no_mode_discard':'All state/log coefficients, signed startup powers, exact block solves and determinant/resonance rejections remain in the unmasked recurrence.'
 },
 'implementation_invariants':{
  'initial_seed_parse_and_startup_full_precision':True,
  'only_forcing_and_coefficient_solve_use_work_precision':True,
  'TOTAL_add_explicitly_uses_precision_max':True,
  'global_precision_changed_only_outside_OpenMP_regions':True,
  'global_precision_restored_before_certificate_and_output':True,
  'clamp_before_multiply_handles_zero_gap_and_negative_n':True,
  'all_radii_retained_no_midpoints_or_resets':True,
  'unchanged_functions':unchanged,
  'schedule_disabled_matches_baseline':True,
  'one_and_four_worker_numerical_parity_on_all_toys':True
 },
 'independent_controls':{
  'analytic_fixtures':11,
  'active_floor':'Geometric rational solution, Pmax4096, slope4, order850, coefficient floor1024, total radius6.26e-1042 meets1000digits and encloses exact value.',
  'negative_TOTAL_control':'Diagnostic-only copied source changes precisely TOTAL add to work precision. Same coefficients/tail/order succeed, but total radius3.63e-307 fails1000digits. Candidate remains unchanged.',
  'source_error_control':'Initial radius1e-20 remains approximately4.9e-20 after locally certified transport; requested1000-digit total-width gate fails.',
  'other_cases':['negative startup powers and Jordan logarithms','nonreal/irreducible denominator factors fallback','nonimaginary ray fallback','nonreal recovered coefficients fallback','constant denominator fallback','exact slope threshold and just below threshold','root radius smaller than abs(z0)','precision floor equal to Pmax'],
  'actual_X8_factor_recovery':'Recovered [1,-29,264,-842,337,2247,-1386,-2160] equals exact normalized source denominator after removing its simple origin zero. Roots1/8,1/2,1/15,1/3 twice,-1 twice yield exact squared radius ratio65536/225.'
 },
 'X8_saved_output_checks':checks,
 'strict_total_width_gate_separate_from_local_tail_gate':True,
 'performance_limits':'The full1000 synthetic probe improved from10.7597s to8.70585s; the first1000-order20k probe improved only73.5180s to72.5619s. These bounded measurements do not establish completed20k timing or accuracy.',
 'source_sha256':{str(p):sha(p) for p in files},
 'producer_files_modified_by_reviewer':False,
 'large_native_jobs_run_by_reviewer':False,
 'whole_PR11d_20000_accuracy_claimed':False,
 'scope':'Accepted frozen arithmetic variant and bounded synthetic controls, conditional on the same independently authenticated startup/source family as baseline. Physical source admission, final endpoint interpretation and production total-width acceptance remain separate.'
}
out=HERE/'review.json';assert not out.exists();out.write_text(json.dumps(report,indent=2)+'\n');print(out);print(sha(out))
