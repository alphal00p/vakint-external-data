#!/usr/bin/env python3
"""Isolated malformed-witness tests; original inputs remain read-only."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("frozen_PR9d_routing_checker", HERE/"check.py")
CHECK = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CHECK)
inputs = (CHECK.WITNESS, CHECK.load(CHECK.MANIFEST), CHECK.load(CHECK.NATIVE), CHECK.load(CHECK.RAW))
original_pins = {str(p): CHECK.sha(p) for p in CHECK.PINS}
cases = []
def test(name, mutate):
    w,m,n,r = copy.deepcopy(inputs)
    mutate(w,m,n,r)
    try:
        CHECK.check_witness(w,m,n,r)
    except (ValueError,KeyError,IndexError,TypeError) as e:
        cases.append({"name":name,"rejected":True,"reason":str(e)[:240]})
    else: raise RuntimeError("Malformed witness accepted: "+name)
def family(m): return next(f for f in m["families"] if f["sha256"]==CHECK.FAMILY)
def catalog(m): return next(x for x in m["masters"] if x["name"]=="P15")
test("changed_unimodular_matrix",lambda w,m,n,r:w["loop_matrix_k_equals_U_l"][0].__setitem__(0,1))
test("nonunimodular_matrix",lambda w,m,n,r:w["loop_matrix_k_equals_U_l"][0].__setitem__(0,-2))
test("singular_matrix",lambda w,m,n,r:w["loop_matrix_k_equals_U_l"].__setitem__(0,[0,0,0,0]))
test("wrong_matrix_dimension",lambda w,m,n,r:w["loop_matrix_k_equals_U_l"].pop())
test("wrong_source_power",lambda w,m,n,r:w["source_powers"].__setitem__(3,1))
test("wrong_target_power",lambda w,m,n,r:w["canonical_powers"].__setitem__(1,1))
test("duplicate_target_slot",lambda w,m,n,r:w["active_slot_mapping"][0].__setitem__(1,1))
test("missing_active_edge",lambda w,m,n,r:w["active_slot_mapping"].pop())
test("wrong_vector_sign",lambda w,m,n,r:w["active_slot_mapping"][0].__setitem__(2,1))
test("changed_mass_constant",lambda w,m,n,r:family(m)["denominators"][2].__setitem__("constant","-2"))
test("changed_quadratic",lambda w,m,n,r:family(m)["denominators"][2]["coefficients"].__setitem__(7,"2"))
test("wrong_family_coordinates",lambda w,m,n,r:family(m)["coordinates"][0].__setitem__("right",1))
test("wrong_catalog_symbol",lambda w,m,n,r:catalog(m).__setitem__("exact_basis_expression","vakint::{}::PR9"))
test("wrong_exact_unit_mapping",lambda w,m,n,r:n["old_from_selected_old"][89].__setitem__(20,"2"))
test("wrong_selected_source",lambda w,m,n,r:r["differential_matrix"][0].__setitem__(0,"1"))
test("wrong_native_family",lambda w,m,n,r:n.__setitem__("source_family_sha256","0"*64))
CHECK.require(original_pins == {str(p): CHECK.sha(p) for p in CHECK.PINS}, "an original input changed")
out = HERE/"rejections.json"
receipt = {"schema":"vakint.pr11d.canonical-routing-negative-tests.v1","validator_sha256":CHECK.sha(HERE/"check.py"),"test_source_sha256":CHECK.sha(Path(__file__).resolve()),"cases":cases,"all_rejected":True,"original_source_hashes_unchanged":True,"source_pins":original_pins}
with out.open("x") as stream:json.dump(receipt,stream,indent=2);stream.write("\n")
print("PASS",len(cases),"isolated routing rejections")
