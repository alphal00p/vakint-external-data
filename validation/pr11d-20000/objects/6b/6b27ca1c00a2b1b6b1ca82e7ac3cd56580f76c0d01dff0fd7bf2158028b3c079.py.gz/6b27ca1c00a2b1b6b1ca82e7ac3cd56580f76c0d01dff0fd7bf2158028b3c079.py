"""Read-only independent exact audit; only writes this review directory."""
from pathlib import Path
from fractions import Fraction
import ast, hashlib, importlib.util, json, re, sys
from flint import fmpq_mpoly_ctx, fmpq_poly, fmpq, arb, acb, ctx

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
ctx.dps = 320
if not __debug__:
    raise RuntimeError("Audit requires assertions")
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
C = fmpq_mpoly_ctx.get(["e", "x"])
e, x = C.gens()

class Rational:
    def __init__(self, n, d=None):
        self.n = n if hasattr(n, "to_dict") else C.constant(n)
        self.d = C.constant(1) if d is None else d
        if not self.d:
            raise ValueError("Zero denominator")
    def __add__(self, other):
        return Rational(self.n*other.d + other.n*self.d, self.d*other.d)
    def __neg__(self): return Rational(-self.n, self.d)
    def __sub__(self, other): return self + -other
    def __mul__(self, other): return Rational(self.n*other.n, self.d*other.d)
    def __truediv__(self, other): return Rational(self.n*other.d, self.d*other.n)
    def __pow__(self, n):
        return Rational(self.n**n, self.d**n) if n >= 0 else Rational(self.d**-n, self.n**-n)

def exact(text):
    text = text.replace("masters_4l::{}::epsilon", "e").replace("symbolica_amflow::{}::eta", "x").replace("DESolver`eta", "x").replace("^", "**")
    def read(t):
        if isinstance(t, ast.Constant) and type(t.value) is int: return Rational(t.value)
        if isinstance(t, ast.Name) and t.id in ["e", "x"]: return Rational(e if t.id == "e" else x)
        if isinstance(t, ast.UnaryOp) and isinstance(t.op, ast.USub): return -read(t.operand)
        if isinstance(t, ast.BinOp):
            if isinstance(t.op, ast.Pow):
                p = ast.literal_eval(t.right)
                if type(p) is not int: raise ValueError("Noninteger exponent")
                return read(t.left)**p
            a, b = read(t.left), read(t.right)
            if isinstance(t.op, ast.Add): return a+b
            if isinstance(t.op, ast.Sub): return a-b
            if isinstance(t.op, ast.Mult): return a*b
            if isinstance(t.op, ast.Div): return a/b
        raise ValueError(ast.dump(t))
    return read(ast.parse(text, mode="eval").body)

input_path = ROOT/"input.json"
input_data = json.loads(input_path.read_text())
connection_path = ROOT.parent/"jet-transport/polynomial-connection.json"
connection = json.loads(connection_path.read_text())
source_path = Path(connection["source"])
source = json.loads(source_path.read_text())
assert source_path.name == "prepared-system.json"
assert sha(source_path) == connection["source_sha256"]
assert source["source_family_sha256"] == "693719b1bc3d2f1d4d32c9312df66ced667a542591a2ada6f6498844fc5d0de1"
assert len(source["basis"]) == 42 and len(source["differential_matrix"]) == 42
D = C.constant(0)
for k, coefficient in enumerate(connection["denominator_coefficients"]): D += C.constant(fmpq(coefficient))*x**k
P = {}
for entry in connection["entries"]:
    key = entry["row"], entry["column"], entry["epsilon_power"]
    assert key not in P and all(0 <= k < n for k, n in zip(key, [42, 42, 6]))
    value = C.constant(0)
    powers = set()
    for t in entry["terms"]:
        assert t["eta_power"] not in powers
        powers.add(t["eta_power"])
        value += C.constant(fmpq(int(t["numerator"]), int(t["denominator"])))*x**t["eta_power"]
    P[key] = value

# A direct polynomial identity, independent of the exporter's coefficient
# recurrence: D_source * P_trunc - N_source * D_common has no epsilon^0..5.
base_checks = 0
for i, row in enumerate(source["differential_matrix"]):
    assert len(row) == 42
    for j, text in enumerate(row):
        q = exact(text)
        assert any(a == 0 for a, b in q.d.to_dict()), (i, j, "epsilon pole")
        polynomial = sum((P.get((i, j, k), C.constant(0))*e**k for k in range(6)), C.constant(0))
        residual = q.d*polynomial - q.n*D
        assert all(k >= 6 for k, eta in residual.to_dict()), (i, j)
        base_checks += 6

# Check the emitted Mathematica file itself, not merely its JSON source.
wl_path = ROOT/"exact-lift.wl"
wl = wl_path.read_text()
match = re.fullmatch(r"den=(.*?);\nconnection=Normal\[SparseArray\[\{(.*)\},\{252,252\}\]\];\nClear\[den\];\n", wl, re.S)
assert match
den = exact(match[1])
assert not den.n-D*den.d
rule_text = match[2]
pattern = re.compile(r"\{(\d+),(\d+)\}->\(\((.*?)\)/den\)")
rules = list(pattern.finditer(rule_text))
assert ",".join(m.group(0) for m in rules) == rule_text
emitted = {}
for m in rules:
    i, j = int(m[1])-1, int(m[2])-1
    assert 0 <= i < 252 and 0 <= j < 252 and (i, j) not in emitted
    emitted[i, j] = exact(m[3])
lifted_checks = 0
for i in range(252):
    for j in range(252):
        order = i//42-j//42
        expected = P.get((i%42, j%42, order), C.constant(0)) if 0 <= order < 6 else C.constant(0)
        actual = emitted.get((i, j), Rational(0))
        assert not actual.n-expected*actual.d, (i, j)
        lifted_checks += 1

# Pin the complete path, source central-value exports and target identity.
path = [Fraction(s) for s in input_data["path_imaginary"]]
assert len(path) == 49 and path[0] == 256 and path[-1] == Fraction(1, 16)
assert all(Fraction(0) < b < a and a-b <= a/5 for a, b in zip(path, path[1:]))
target = next(t for t in source["target_reductions"] if t["powers"] == input_data["ordered_target_powers"])
basis = {tuple(p): i for i, p in enumerate(source["basis"])}
actual_projection = {basis[tuple(t["powers"])]: exact(t["coefficient"]) for t in target["terms"]}
expected_projection = {30: Rational(1), 36: Rational(-1), 37: Rational(-e), 38: Rational(-1)}
assert set(actual_projection) == set(expected_projection)
for i, q in actual_projection.items():
    p = expected_projection[i]
    assert not q.n*p.d-p.n*q.d

exports = []
for field, relative, value_key in [
    ("input_boundary", "helper/frobenius-transport/physical190-v2-eta256.json", "values"),
    ("endpoint_adjoint", "endpoint-adjoint/adjoint-260.json", "complex_balls")]:
    p = ROOT.parent/relative
    data = json.loads(p.read_text())
    assert input_data["source_paths_sha256"][str(p)] == sha(p)
    assert len(data[value_key]) == len(input_data[field]) == 252
    for index, (source_pair, out_pair) in enumerate(zip(data[value_key], input_data[field])):
        for component, (source_text, out) in enumerate(zip(source_pair, out_pair)):
            ball = arb(source_text)
            center = arb(out["center"])
            assert out["source_ball"] == source_text
            assert out["exact_zero"] == ball.is_zero()
            # Export rounding is much smaller than the printed245digitcenter;
            # it need not be contained in an exactly represented source point.
            difference = abs(center-ball.mid()).upper()
            assert difference < (abs(ball.mid()).upper()+1)*arb(10)**-243
    exports.append({"path": str(p), "sha256": sha(p), "components": 504})

# Independently parse central complex numbers as exact rational pairs. Native
# Python floats are never used as their values, even though ast tokenizes them.
def rational_complex(text):
    text = re.sub(r"`{1,2}(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)", "", text).replace("*^", "e").replace("^", "**")
    def read(t):
        if isinstance(t, ast.Constant) and type(t.value) in [int, float]:
            return Fraction(ast.get_source_segment(text, t)), Fraction(0)
        if isinstance(t, ast.Name) and t.id == "I": return Fraction(0), Fraction(1)
        if isinstance(t, ast.UnaryOp):
            a = read(t.operand)
            if isinstance(t.op, ast.USub): return -a[0], -a[1]
            if isinstance(t.op, ast.UAdd): return a
        if isinstance(t, ast.BinOp):
            a, b = read(t.left), read(t.right)
            if isinstance(t.op, ast.Add): return a[0]+b[0], a[1]+b[1]
            if isinstance(t.op, ast.Sub): return a[0]-b[0], a[1]-b[1]
            if isinstance(t.op, ast.Mult): return a[0]*b[0]-a[1]*b[1], a[0]*b[1]+a[1]*b[0]
            if isinstance(t.op, ast.Div):
                d = b[0]**2+b[1]**2
                return (a[0]*b[0]+a[1]*b[1])/d, (a[1]*b[0]-a[0]*b[1])/d
        raise ValueError(ast.dump(t))
    return read(ast.parse(text, mode="eval").body)

spec = importlib.util.spec_from_file_location("oracle_compare_reviewed", ROOT/"compare.py")
module = importlib.util.module_from_spec(spec)
sys.dont_write_bytecode = True
spec.loader.exec_module(module)
tests = [
    "1.234567890123456789012345678901234567890123456789`90.12345*^-400",
    "-2.34567890123456789012345678901234567890123456789`80. + 1.2345678901234567890123456789`70.*^-200*I",
    "0``170. - 1.2345678901234567890123456789`100.12345*^300*I",
    "-17/19 + 2/3*I", "0", "1.000000000000000000000000000000000000000000000001`90.",
]
smoke_path = ROOT/"smoke130c-result.json"
smoke = json.loads(smoke_path.read_text())
assert smoke["segments"] == 1 and smoke["finite_coefficient"] is None
tests += smoke["vector"]
baseline_path = ROOT/"baseline170-result.json"
if baseline_path.exists():
    baseline = json.loads(baseline_path.read_text())
    assert baseline["segments"] == 48 and len(baseline["vector"]) == 252
    tests += baseline["vector"] + [baseline["finite_coefficient"]]
refined_path = ROOT/"refined200-result.json"
if refined_path.exists():
    refined = json.loads(refined_path.read_text())
    assert refined["segments"] == 48 and len(refined["vector"]) == 252
    tests += refined["vector"] + [refined["finite_coefficient"]]
for text in tests:
    re_part, im_part = rational_complex(text)
    value = module.mma(text)
    real_q = fmpq(re_part.numerator, re_part.denominator)
    imag_q = fmpq(im_part.numerator, im_part.denominator)
    assert value.real.lower().fmpq() <= real_q <= value.real.upper().fmpq(), (text, "real", value)
    assert value.imag.lower().fmpq() <= imag_q <= value.imag.upper().fmpq(), (text, "imaginary", value)

upstream = Path("/shared/codex-2/vacuum_masters/SOURCES/amflow-upstream-26005517a288086c4cb4d1b26d829691bc088485-reference-v1/diffeq_solver/DESolver.m")
assert sha(upstream) == sha(ROOT/"upstream/diffeq_solver/DESolver.m")
assert sha(upstream) == "0dfa7f91bd8b8d160412dbc3a8c076413e488745bcefe58bc434999d03f76a46"
upstream_license = upstream.parents[1]/"LICENSE.md"
assert sha(upstream_license) == sha(ROOT/"upstream/LICENSE.md") == "1b49fd5cc024c607f31cb4b9472baabf7915befeb7dffeef56673a9ef12384ba"
reviewed = [HERE/"audit_exact.py", ROOT/"prepare.py", ROOT/"check_lift.py", ROOT/"check_guards.py", ROOT/"oracle.wl", ROOT/"compare.py", ROOT/"run.py", ROOT/"README.md", input_path, wl_path, connection_path, source_path, ROOT/"smoke130c-result.json", ROOT/"upstream/diffeq_solver/DESolver.m", upstream]
if baseline_path.exists():
    reviewed += [baseline_path, ROOT/"baseline170-process.json", ROOT/"baseline170-comparison.json", ROOT/"run-baseline170.py", ROOT/"p17-reference-snapshot.json", ROOT/"reference-provenance.json"]
if refined_path.exists():
    reviewed += [refined_path, ROOT/"refined200-process.json", ROOT/"refined200-comparison.json"]
reviewed += [upstream_license, ROOT/"upstream/LICENSE.md", ROOT/"check_finiteness.py", ROOT/"finiteness-validation.json", HERE/"audit_finiteness.py", HERE/"finiteness-review.json", HERE/"audit_outputs.py", HERE/"REVIEW.md", ROOT/"check_poles.py", ROOT/"path-convergence.json", ROOT/"feasibility.json", ROOT/"seal.py", ROOT/"runner-provenance.json", ROOT/"upstream-source.json"]
receipt = {
    "schema": "vakint.pr11d.original-AMFlow-independent-exact-review.v1",
    "status": "PASS_exact_input_algorithm_and_central_parser_only",
    "base_coefficient_crossproduct_checks": base_checks,
    "emitted_matrix_entry_checks": lifted_checks,
    "emitted_nonzero_entries": len(emitted),
    "central_complex_parser_checks": len(tests),
    "source_center_exports": exports,
    "path_segments": 48,
    "projection": "r=Y30-Y36-epsilon*Y37-Y38; finite=[epsilon^5](V dot epsilon^4 Y), V=epsilon W",
    "normalization": "Native raw to e^(4 gamma epsilon) leaves finite coefficient unchanged only because target epsilon^-4..-1 coefficients vanish; no extra conversion in this oracle.",
    "ordinary_solver_independence": "Pinned byte-identical original AMFlow2.0 MMA CalcRun/Calcx1x2 polynomial recurrence, not native Arb code. Starting Frobenius boundary, exact DE, target reduction and analytic endpoint adjoint remain shared.",
    "numerical_baseline_or_refinement_rerun": False,
    "practical_70_digit_acceptance_established_by_this_receipt": False,
    "independent_physical_boundary_claimed": False,
    "twenty_thousand_digit_PR11d_accuracy_claimed": False,
    "reviewed_sha256": {str(p): sha(p) for p in reviewed},
}
(HERE/"exact-review.json").write_text(json.dumps(receipt, indent=2)+"\n")
print(json.dumps({k: v for k, v in receipt.items() if k != "reviewed_sha256"}, indent=2))
