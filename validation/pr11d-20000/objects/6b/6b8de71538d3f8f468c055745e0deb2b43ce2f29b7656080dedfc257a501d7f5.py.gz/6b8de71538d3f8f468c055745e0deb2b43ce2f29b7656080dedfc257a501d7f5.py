"""Restore native/FMFT normalization once; compare independent archived HPL data."""
import argparse,hashlib,json,math
from pathlib import Path
from flint import arb,ctx,fmpq
if not __debug__:raise RuntimeError('Assertions required')
ap=argparse.ArgumentParser();ap.add_argument('input',type=Path);ap.add_argument('--compare-digits',type=int,required=True);args=ap.parse_args();d=json.load(open(args.input));jets=d['jet_count'];ctx.dps=d['requested_decimal_digits']+100
q=[arb(v['ball']) for v in d['coefficients']];assert len(q)==jets
# exp(2 Euler e)*Gamma(e-1)^2 = e^-2*(1-e)^-2 * exp(sum_(n>=2) 2(-1)^n zeta(n)e^n/n).
log=[arb(0)]*jets
for n in range(2,jets):log[n]=2*((-1)**n)*arb(n).zeta()/n
expo=[arb(1)]
for n in range(1,jets):expo.append(sum((k*log[k]*expo[n-k] for k in range(1,n+1)),arb(0))/n)
g=[sum(((k+1)*expo[n-k] for k in range(n+1)),arb(0)) for n in range(jets)]
fmft=[sum((q[k]*g[n-k] for k in range(n+1)),arb(0)) for n in range(jets)]
euler=-2*arb.const_euler();nativeexp=[arb(1)]
for n in range(1,jets):nativeexp.append(nativeexp[-1]*euler/n)
native=[sum((fmft[k]*nativeexp[n-k] for k in range(n+1)),arb(0)) for n in range(jets)]
ref=Path('/shared/codex-1/vakint_rustred/vakint-external-data/2L/masters/P2/numerical.json');refs=dict(json.load(open(ref)));checks=[]
for i,value in enumerate(fmft):
 power=i-2;s=refs[power];central=arb(s);delta=abs(value-central);scale=max(abs(central).upper(),arb(1));tol=scale*arb(10)**(-args.compare_digits);passed=bool(delta<tol);assert passed,(power,delta,tol)
 checks.append({'epsilon_power':power,'comparison_digits':args.compare_digits,'passed':passed,'absolute_difference_upper':str(delta.upper()),'computed_ball':value.str(80),'reference_prefix':s[:80]})
print('PASS',jets,'independentFMFTcoefficients at',args.compare_digits,'digits')
out=args.input.with_name(args.input.stem+'-normalized.json')
def rows(vals):
 out=[]
 for i,v in enumerate(vals):
  midpoint=v.mid().fmpq();radius=v.rad().fmpq()
  out.append({'epsilon_power':i-2,'ball':v.str(d['requested_decimal_digits']+24,more=True),'relative_accuracy_bits':int(v.rel_accuracy_bits()),'midpoint':{'numerator':str(midpoint.p),'denominator':str(midpoint.q)},'radius':{'numerator':str(radius.p),'denominator':str(radius.q)}})
 return out
payload={'schema':'vakint.ancestor.certified-sunset-normalized-jets.v1','ratio_input_sha256':hashlib.sha256(args.input.read_bytes()).hexdigest(),'normalization':'native_raw and FMFTandMATAD; exp(2Euler epsilon) conversion exactlyonce','coefficients':{'native_raw':rows(native),'FMFTandMATAD':rows(fmft)},'comparison_source':str(ref),'comparison_source_sha256':hashlib.sha256(ref.read_bytes()).hexdigest(),'comparison_checks':checks,'error_quality':'rigorous-bound','validated_analytic_truncation_and_rounding':True,'requested_decimal_digits':d['requested_decimal_digits']};out.write_text(json.dumps(payload,indent=2)+'\n')
