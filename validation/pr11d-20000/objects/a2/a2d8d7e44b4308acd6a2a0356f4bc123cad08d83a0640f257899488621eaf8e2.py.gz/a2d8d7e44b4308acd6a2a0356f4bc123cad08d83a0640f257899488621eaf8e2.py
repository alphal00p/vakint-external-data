#!/usr/bin/env python3
"""Bounded read-only reassembly and precision audit of guarded PR9 API boundary."""
import hashlib
import importlib.util
import json
import resource
import sys
import time
from decimal import Decimal,localcontext,ROUND_CEILING
from fractions import Fraction as Q
from pathlib import Path
from flint import arb,ctx,fmpq

if not __debug__:raise RuntimeError("Audit requires assertions")
sys.set_int_max_str_digits(300000)
HERE=Path(__file__).resolve().parent;PR11=HERE.parents[1];BASE=PR11.parent
BOUNDARY=BASE/"bessel/ancestor-boundary";ANCESTOR=PR11/"ancestor-flows"
sys.path.insert(0,str(BOUNDARY))
import pr9_boundary as producer
from pr9_source_recipes import build
from endpoint_sources import load_native_endpoints
from logjet_map import FactorJet,MissingCoefficient,valuation
from expanded_boundary import ExpandedBoundary


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def upper_decimal(v):
    upper=v.upper();q=upper.fmpq()
    with localcontext() as c:
        c.prec=30;c.rounding=ROUND_CEILING
        value=Decimal(int(q.numerator))/Decimal(int(q.denominator));text=str(value)
        if arb(text).lower()<upper:text=str(value.next_plus(c))
    assert arb(text).lower()>=upper
    return text


def main():
    resource.setrlimit(resource.RLIMIT_AS,(2*2**30,2*2**30))
    resource.setrlimit(resource.RLIMIT_CPU,(60,65))
    start=time.monotonic();ctx.dps=20550;ctx.threads=1
    paths={
      "boundary":BOUNDARY/"pr9-boundary-API20280-working20400.json",
      "guard_validation":BOUNDARY/"pr9-boundary-API20280-working20400.guard-validation.json",
      "native_api_bridge":BOUNDARY/"three-loop-API20280-native.json",
      "api_bridge_producer":BOUNDARY/"api_three_loop_native.py",
      "assembler":BOUNDARY/"pr9_boundary.py","wrapper":BOUNDARY/"pr9_guarded_boundary.py",
      "endpoint_importer":BOUNDARY/"endpoint_sources.py","source_builder":BOUNDARY/"pr9_source_recipes.py",
      "inventory":BOUNDARY/"pr9-22-inventory.json","singlemass":BOUNDARY/"pr9-22-singlemass.json","products":BOUNDARY/"pr9-22-products.json",
      "matching":ANCESTOR/"pr9-22-matching.json","startup":ANCESTOR/"pr9-22-startup.json","polynomial":ANCESTOR/"pr9-22-polynomial.json",
      "matching_review":PR11/"helper/ancestor-matching-review/pr9-22-audit-receipt.json",
      "sunset":ANCESTOR/"sunset-ratio-20300-normalized.json",
      "sunset_source_review":PR11/"helper/three-loop-boundary-review/guarded-boundary-receipt.json",
      "provider_validation":PR11/"numerator-helper/ancestor-followup/validation.json",
      "api_export_validation":BASE/"lower-ancestors/export-validation.json",
      "api_independent_review":BASE/"lower-ancestors/independent-audit.json",
      "auditor":Path(__file__),
    }
    for name in ["source_recipes.py","gamma_ast.py","gamma_jets.py","expanded_boundary.py","logjet_map.py"]:paths[name]=BASE/"bessel/pr11-boundary"/name
    hashes={k:sha(p) for k,p in paths.items()}
    assert hashes["boundary"]=="8b35db3637aed6c4654a8b86bd3501b6357bff64c719aa52dc352b72eb4bc9b9"
    assert hashes["guard_validation"]=="74906e693b01008c20492dc124f16432b82f4278bae56bf900e4be47c96ce1a0"
    assert hashes["native_api_bridge"]=="9502a5fb678eee9d9a225c380ac200ab55bd424fcbde8267b22257320b975b31"
    data=read(paths["boundary"]);guard=read(paths["guard_validation"]);matching=read(paths["matching"]);bridge=read(paths["native_api_bridge"])
    assert data["normalization"]==bridge["normalization"]=="native_raw"
    assert data["error_quality"]==bridge["error_quality"]=="rigorous-bound"
    assert data["all_overdetermined_residuals_contain_zero"] and data["all_prepared_rows_checked"]
    assert data["coefficient_count"]==557 and data["free_constants"]==132
    assert not data["scientific_whole_master_accuracy_claimed"]
    assert data["implementation_sha256"]==hashes["assembler"] and bridge["producer_sha256"]==hashes["api_bridge_producer"]
    assert data["matching_sha256"]==hashes["matching"]
    assert data["inventory_sha256"]==matching["inventory_sha256"]==hashes["inventory"]
    assert guard["accepted"] and guard["boundary_sha256"]==hashes["boundary"]
    assert guard["wrapper_sha256"]==hashes["wrapper"] and guard["assembler_sha256"]==hashes["assembler"]
    assert guard["source"]["sha256"]==hashes["native_api_bridge"] and guard["matched_constants"]==132 and guard["all557rows_consistent"]
    assert guard["source"]["no_Euler_conversion_applied"]
    # Freeze and verify every actual accepted primitive, exact matching proof,
    # sunset proof and source recipe hash. No numerical source rerun.
    nested_pins={};historical_non_scientific_pin_changes=[]
    def pin(path,digest):
        path=Path(path).resolve();assert sha(path)==digest,(path,"stale source")
        if str(path) in nested_pins:assert nested_pins[str(path)]==digest
        nested_pins[str(path)]=digest
    for row in data["primitive_provenance"]:
        pin(row["source"],row["sha256"])
        assert row["normalization"]=="native_raw" and row["error_quality"]=="rigorous-bound"
    for label in ["matching_review","sunset_source_review"]:
        review=read(paths[label])
        assert review.get("accepted",review.get("accepted_for_exact_preparation_scope"))
        for review_key,row in review["artifact_sha256"].items():
            if review_key=="ancestor_manifest" and sha(row["path"])!=row["sha256"]:
                historical_non_scientific_pin_changes.append({"path":row["path"],"old_sha256":row["sha256"],"current_sha256":sha(row["path"]),"scope":"Historical handoff manifest only; every substantive sunset source pin is rechecked separately"})
                continue
            pin(row["path"],row["sha256"])
        for group in ["transitive_sunset_source_pins","transitive_recipe_source_pins"]:
            for row in review.get(group,[]):pin(row["path"],row["sha256"])
    provider=read(paths["provider_validation"]);assert provider["status"]=="PASS"
    provider_dir=paths["provider_validation"].parent
    for name,digest in provider["source_files_sha256"].items():pin(provider_dir/name,digest)
    child=read(provider_dir/"all-109-three-loop-trees.json")
    pin(provider_dir/"three-loop-bubbles.json",child["input_sha256"])
    pin(provider_dir/"native-child-result.json",child["native_reduction_sha256"])
    pin(provider_dir/"native-numerator-result.json",read(provider_dir/"all-19-numerator-trees.json")["native_reduction_sha256"])
    pin(provider_dir/"native-scalar-result.json",read(provider_dir/"all-scalar-trees.json")["native_reduction_sha256"])
    products=read(provider_dir/"product-seed-bindings.json");pin(products["source_path"],products["source_sha256"])
    api_validation=read(paths["api_export_validation"]);assert api_validation["complete"] and api_validation["native_run_complete"]
    assert read(paths["api_independent_review"])["result"]=="All three findings closed"
    expected_api={"native::L3_P13":"dfc2a6e5b402ef7cf39a7c8c91ebf71b8890ff1d76497c9bbd20b55f0de01a10",
                  "native::L3_P14":"519a202d505cb34093b8ac75cd03d655fad9e235fa67020b3ab13d585956006c"}
    assert set(bridge["canonical_alias_bindings"])==set(expected_api)
    for name,binding in bridge["canonical_alias_bindings"].items():
        assert binding["sha256"]==expected_api[name];pin(binding["path"],binding["sha256"])
        assert binding["loop_count"]==3 and [r["epsilon_power"] for r in bridge["coefficients"][name]]==list(range(-3,3))
        assert all(r["exact_rational_precision_at_least"]>=20250 and r["source_error_quality"]=="Bounded" for r in binding["checked_API_orders"])
    # The bridge has already applied the sole Euler conversion; downstream
    # loaders import these exact same balls without applying another factor.
    imported,import_receipt=load_native_endpoints(paths["native_api_bridge"],hashes["native_api_bridge"],{"native::L3_P13":(-3,2),"native::L3_P14":(-3,2)})
    primitives,provenance,quality=producer.load_primitives(paths["native_api_bridge"])
    assert provenance==data["primitive_provenance"] and quality=="rigorous-bound" and import_receipt["no_Euler_conversion_applied"]
    for name in imported:
        for p in range(-3,3):
            a,b=imported[name].coefficient(p),primitives[name].coefficient(p)
            assert a.mid()==b.mid() and a.rad()==b.rad()
    factors,source_receipt=build()
    assert len(factors)==231 and source_receipt==data["source_recipe_receipt"]
    for group in [source_receipt["source_sha256"],source_receipt["X8_source_receipt"]["source_sha256"]]:
        for path,digest in group.items():pin(path,digest)
    assert source_receipt["native_singlemass_sha256"]==hashes["singlemass"] and source_receipt["native_products_sha256"]==hashes["products"]
    inventory=read(paths["inventory"]);requested={r["key"]:r for r in inventory["factors"]};assert set(factors)==set(requested)
    loop_counts={"native::L2_P2":2,"native::L3_P13":3,"native::L3_P14":3};monomial_count=0
    for name,expression in factors.items():
        row=requested[name];loops=row["loops"] if "loops" in row else len(row["family"]["loops"])
        for rational,slopes,keys in expression.terms:
            assert sum((b*n for b,n in slopes),Q(0))+sum(loop_counts[k] for k in keys)==loops
            monomial_count+=1
    plan=producer.load_plan(paths["inventory"],data["inventory_sha256"],"masters_4l::{}::epsilon")
    compiled=ExpandedBoundary(plan,factors,max_log_power=matching["max_exact_log_degree"])
    required,_=compiled.required_primitive_orders(primitives,last_epsilon_power=1)
    assert required==data["required_raw_primitive_through"]=={"native::L3_P13":2,"native::L2_P2":3,"native::L3_P14":2}
    for name,high in required.items():
        v=primitives[name];count=high-v.first_power;modified=dict(primitives)
        modified[name]=FactorJet(v.first_power,v.coefficients[:count],v.pole_bound_proof,v.source_identity)
        try:compiled.required_primitive_orders(modified,last_epsilon_power=1)
        except MissingCoefficient:pass
        else:raise AssertionError((name,"missing endpoint accepted"))
    lows=[]
    for (_,_,_,keys),r in plan.terms:
        if any(not factors[k].terms for k in keys):continue
        low=valuation(r)
        for k in keys:low+=min(valuation(rr)+sum(primitives[x].first_power for x in pp) for rr,ss,pp in factors[k].terms)
        lows.append(int(low))
    assert 1-min(lows)<=matching["max_exact_log_degree"]
    values=compiled.evaluate(primitives,first_epsilon_power=-4,last_epsilon_power=1)
    values={(i,int(a),p,l):v for (i,a,p,l),v in values.items()}
    key=producer.key;wanted=[key(row) for row in matching["all_boundary_selectors"]]
    assert len(wanted)==len(set(wanted))==557
    saved={}
    for row in data["coefficients"]:
        label=key(row);assert label not in saved;saved[label]=arb(row["real_ball"])
    assert set(saved)==set(wanted)
    assert all(values[k].is_finite() and saved[k].is_finite() and values[k].overlaps(saved[k]) for k in wanted)
    assert all(v.contains(0) for k,v in values.items() if k not in saved)
    rhs=[saved[key(row)] for row in matching["selected_selectors"]]
    fresh=[sum((rhs[j]*fmpq(value) for j,value in enumerate(row) if value!="0"),arb(0)) for row in matching["boundary_inverse"]]
    constants=[arb(v) for v in data["free_constant_balls"]];assert len(constants)==len(fresh)==132
    assert all(a.is_finite() and a.overlaps(b) for a,b in zip(constants,fresh))
    for label,row in zip(wanted,matching["all_boundary_matrix"]):
        residual=sum((fresh[j]*fmpq(value) for j,value in enumerate(row) if value!="0"),arb(0))-saved[label]
        assert residual.contains(0)
    target=(arb(10)**-20240).lower();precision={}
    for group,vs in [("saved_rows",[saved[k] for k in wanted]),("saved_constants",constants),("recomputed_constants",fresh)]:
        records=[]
        for i,v in enumerate(vs):
            assert v.is_finite() and v.rad().upper()<target and 2*v.rad().upper()<target
            record={"index":i,"exact_zero":v.is_zero(),"uncertain_zero":v.contains(0) and not v.is_zero(),"radius_upper":upper_decimal(v.rad())}
            if not v.is_exact() and not v.contains(0):record["relative_decimal_digits_lower_bound"]=int((-(v.rad()/abs(v).lower()).upper().log()/arb(10).log()).lower().floor().fmpz())
            records.append(record)
        precision[group]={"count":len(vs),"maximum_absolute_radius_upper":upper_decimal(max(v.rad() for v in vs)),"minimum_relative_decimal_digits_nonzero_inexact":min(r["relative_decimal_digits_lower_bound"] for r in records if "relative_decimal_digits_lower_bound" in r),"exact_zero_count":sum(r["exact_zero"] for r in records),"uncertain_zero_count":sum(r["uncertain_zero"] for r in records),"all_radius_and_diameter_below_10_to_minus20240":True,"records":records}
    assert arb(guard["maximum_constant_radius"]).contains(max(v.rad() for v in constants).upper())
    for k,p in paths.items():assert sha(p)==hashes[k],(k,"changed during audit")
    for path,digest in nested_pins.items():assert sha(path)==digest
    report={"schema":"vakint.pr9.API-boundary-independent-reassembly.v1","accepted":True,
      "scope":"Source bindings, exact support and raw normalization, full PR9 boundary reassembly/matching, and actual 20240-digit absolute input guard. Independent AP bridge proof is bound separately; no propagated endpoint or whole-period claim.",
      "absolute_source_guard_digits":20240,"final_transport_target_digits":20220,"audit_working_decimal_digits":20550,
      "boundary_sha256":hashes["boundary"],"guard_receipt_sha256":hashes["guard_validation"],"native_API_bridge_sha256":hashes["native_api_bridge"],
      "source_error_quality":"rigorous-bound","matching_exact_audit_and_source_pins_verified":True,"sunset_rigorous_source_chain_verified":True,
      "API_exports_match_accepted_hashes":True,"API_bridge_downstream_Euler_conversion_count":0,
      "source_recipe_count":231,"raw_Euler_weight_monomials_checked":monomial_count,"required_primitive_orders":required,
      "all_three_missing_endpoint_controls_rejected":True,"minimum_uncancelled_source_Laurent_support":min(lows),"maximum_log_needed_through_epsilon1":1-min(lows),
      "full_rows_reassembled":557,"constants_recomputed":132,"all557overdetermined_residuals_contain_zero":True,
      "precision":precision,"large_primitive_production_or_native_transport_duplicated":False,"producer_files_modified":False,
      "propagated_endpoint_or_whole_period_precision_claimed":False,
      "artifact_sha256":{k:{"path":str(p),"sha256":hashes[k]} for k,p in paths.items()},
      "nested_source_pins":[{"path":p,"sha256":digest} for p,digest in sorted(nested_pins.items())],
      "historical_non_scientific_pin_changes":historical_non_scientific_pin_changes,
      "seconds":time.monotonic()-start,"peak_rss_bytes":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}
    (HERE/"boundary-reassembly-receipt.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({k:v for k,v in report.items() if k not in ["artifact_sha256","nested_source_pins","precision"]},indent=2))
    print(json.dumps({k:{kk:vv for kk,vv in v.items() if kk!="records"} for k,v in precision.items()},indent=2))


if __name__=="__main__":main()
