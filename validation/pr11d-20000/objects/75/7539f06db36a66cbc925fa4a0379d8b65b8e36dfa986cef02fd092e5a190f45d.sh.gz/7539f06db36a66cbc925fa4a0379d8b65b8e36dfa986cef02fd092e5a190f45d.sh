#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
export TMPDIR="$PWD/tmp-rpf-scheduled-threads"
mkdir -p "$TMPDIR"
/nix/store/j1938gsbvbhkyz4kbmvjk56r479mkw3s-gcc-wrapper-16.2.0/bin/cc -O3 -fopenmp -std=c11 -Wall -Wextra -Werror \
  -I/nix/store/cih4nsn8mqam0q8s3pn6866mdfbkhvwp-flint-3.6.0/include \
  -I/nix/store/lppdjhzf5vp1gvz4c7r5y7fcxkr69dyr-mpfr-4.2.2-dev/include \
  -I/nix/store/1sj0rbpn9nzz1mp754r15yxbnvzbdhfb-gmp-with-cxx-6.3.0-dev/include \
  transport_rpf_scheduled_threads.c -L/nix/store/cih4nsn8mqam0q8s3pn6866mdfbkhvwp-flint-3.6.0/lib \
  -Wl,-rpath,/nix/store/cih4nsn8mqam0q8s3pn6866mdfbkhvwp-flint-3.6.0/lib -lflint -o transport-rpf-scheduled-threads-new
mv transport-rpf-scheduled-threads-new transport-rpf-scheduled-threads
