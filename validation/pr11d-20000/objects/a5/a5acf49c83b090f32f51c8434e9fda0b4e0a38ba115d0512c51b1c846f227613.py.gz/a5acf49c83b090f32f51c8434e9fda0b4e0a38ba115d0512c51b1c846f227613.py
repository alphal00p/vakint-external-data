#!/usr/bin/env python3
"""Bounded source-origin and binding corruption controls, without admission writes."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
AUTHOR = HERE.parent / "seal.py"
spec = importlib.util.spec_from_file_location("reviewed_x8_envelope_author", AUTHOR)
author = importlib.util.module_from_spec(spec)
spec.loader.exec_module(author)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    if not __debug__:
        raise RuntimeError("Assertions required")
    author_sha = sha(AUTHOR)
    non4_path, non4_sha = author.FIXED["non4L"]
    assert sha(non4_path) == non4_sha
    non4 = json.loads(non4_path.read_text())
    sources = author.BASE.parent / "bessel/ancestor-boundary/production-runs-v1"
    records = []

    def rejected(name, call):
        author.PINS.clear()
        try:
            call()
        except (ValueError, KeyError, TypeError, FileNotFoundError) as error:
            records.append({"control": name, "rejected": True, "error_type": type(error).__name__, "message": str(error)})
        else:
            raise AssertionError("Invalid fixture accepted: " + name)

    # This map is only an in-memory unit fixture for the binding function.
    # It is never presented as an accepted independent review or written out.
    mapping = {p: {"path": str(HERE / (p + "-review-only-mock.json")), "sha256": str(i) * 64}
               for i, p in enumerate(["A", "B"], 1)}
    for profile in ["A", "B"]:
        path, digest = mapping[profile]["path"], mapping[profile]["sha256"]
        author.four_loop_binding_gates(profile, {"four_loop_admissions": mapping}, path, digest)
        bad_maps = {
            "missing_map": {},
            "missing_other_profile": {"four_loop_admissions": {profile: mapping[profile]}},
            "extra_profile": {"four_loop_admissions": {**mapping, "C": mapping[profile]}},
            "wrong_selected_hash": {"four_loop_admissions": {**mapping, profile: {**mapping[profile], "sha256": "0" * 64}}},
            "wrong_selected_path": {"four_loop_admissions": {**mapping, profile: {**mapping[profile], "path": str(HERE / "different.json")}}},
            "relative_path": {"four_loop_admissions": {**mapping, profile: {**mapping[profile], "path": "relative.json"}}},
            "extra_binding_field": {"four_loop_admissions": {**mapping, profile: {**mapping[profile], "accepted": True}}},
            "selected_none": {"four_loop_admissions": {**mapping, profile: None}},
            "map_list": {"four_loop_admissions": []},
        }
        for label, review in bad_maps.items():
            rejected(profile + "/binding/" + label,
                     lambda review=review: author.four_loop_binding_gates(profile, review, path, digest))
        rejected(profile + "/binding/caller_checksum_replacement",
                 lambda: author.four_loop_binding_gates(profile, {"four_loop_admissions": mapping}, path, "0" * 64))

        actual_boundary = json.loads((sources / profile / "x8-source.boundary.json").read_text())
        boundary = {"source_receipts": actual_boundary["source_receipts"]}
        endpoint = next(row for row in boundary["source_receipts"] if row["sha256"] == author.ENDPOINT_HASH[profile])
        # A shape fixture lets us test origin_gates in isolation. It is not
        # accepted physical evidence; main must separately require the blessed
        # immutable four-loop receipt map tested immediately above.
        four = {
            "schema": f"vakint.PR9-production-{profile}-complete-physical-source-admission.v1",
            "accepted": True, "whole_chain_physical_source_admitted": True,
            "endpoint_path": endpoint["source"], "endpoint_sha256": endpoint["sha256"],
            "normalization": "native_raw", "error_quality": "rigorous-bound",
            "coefficient_count": 42, "epsilon_powers": list(range(-4, 2)),
            "canonical_masters": ["native::" + n for n in ["PR3", "PR4", "PR4d", "PR5", "PR7", "PR9", "PR9d"]],
            "artifact_sha256": {endpoint["source"]: endpoint["sha256"]},
        }
        author.PINS.clear()
        origins = author.origin_gates(profile, four, non4, boundary)
        assert len(origins) == 4
        cases = []

        def case(name, category, mutate):
            values = {"four": copy.deepcopy(four), "non4": copy.deepcopy(non4), "boundary": copy.deepcopy(boundary)}
            mutate(values[category])
            cases.append((name, values))

        for field, value in [("schema", "unreviewed"), ("accepted", False), ("whole_chain_physical_source_admitted", False),
                             ("normalization", "FMFTandMATAD"), ("error_quality", "estimated"),
                             ("coefficient_count", 41), ("epsilon_powers", list(range(-4, 1))),
                             ("endpoint_sha256", "0" * 64), ("artifact_sha256", {}), ("artifact_sha256", None)]:
            case("four_" + field + "_" + str(value), "four", lambda d, f=field, v=value: d.__setitem__(f, v))
        case("four_graph_missing", "four", lambda d: d.pop("artifact_sha256"))
        case("wrong_canonical_name", "four", lambda d: d["canonical_masters"].__setitem__(0, "native::PR11d"))
        case("duplicate_canonical_name", "four", lambda d: d["canonical_masters"].__setitem__(0, d["canonical_masters"][1]))
        case("wrong_endpoint_path", "four", lambda d: d.__setitem__("endpoint_path", str(HERE / "another-endpoint.json")))
        for field in ["accepted_for_non4L_source_edges", "all_explicit_source_data_and_mathematical_review_bindings_verified"]:
            case("non4_" + field, "non4", lambda d, f=field: d.__setitem__(f, False))
        case("missing_non4_role", "non4", lambda d: d["profiles"][profile].pop("p853"))
        case("extra_non4_role", "non4", lambda d: d["profiles"][profile].__setitem__("extra", {}))
        for role in ["three_loop", "sunset", "p853"]:
            case("short_support_" + role, "non4", lambda d, r=role: d["profiles"][profile][r].__setitem__("support", {}))
        for role in ["three_loop", "sunset"]:
            case("extra_Euler_" + role, "non4", lambda d, r=role: d["profiles"][profile][r].__setitem__("additional_Euler_conversion", True))
        case("diagnostic_P853_ball", "non4", lambda d: d["profiles"][profile]["p853"].__setitem__("arithmetic_ball_diagnostic_used", True))
        case("missing_primitive_datum", "boundary", lambda d: d["source_receipts"].pop())
        case("duplicate_primitive_datum", "boundary", lambda d: d["source_receipts"].append(copy.deepcopy(d["source_receipts"][0])))
        case("wrong_primitive_hash", "boundary", lambda d: d["source_receipts"][0].__setitem__("sha256", "0" * 64))
        case("wrong_primitive_normalization", "boundary", lambda d: d["source_receipts"][0].__setitem__("normalization", "FMFTandMATAD"))
        case("wrong_primitive_quality", "boundary", lambda d: d["source_receipts"][0].__setitem__("error_quality", "estimated"))
        native_index = next(i for i, row in enumerate(boundary["source_receipts"]) if "no_Euler_conversion_applied" in row)
        case("extra_downstream_Euler", "boundary", lambda d: d["source_receipts"][native_index].__setitem__("no_Euler_conversion_applied", False))
        for name, values in cases:
            rejected(profile + "/origins/" + name,
                     lambda v=values: author.origin_gates(profile, v["four"], v["non4"], v["boundary"]))
    assert sha(AUTHOR) == author_sha, "Author changed during controls"
    report = {
        "schema": "vakint.X8-initial-envelope-origin-binding-controls.v1",
        "all_negative_controls_rejected": True,
        "author_sha256": author_sha,
        "non4L_index_sha256": non4_sha,
        "review_script_sha256": sha(__file__),
        "negative_control_count": len(records),
        "controls": records,
        "unit_fixture_scope": "In-memory shape fixtures only. They are not accepted four-loop evidence; no independent blessing or accepted initial envelope was emitted.",
        "fresh_numerical_or_native_computation": False,
        "producer_or_original_files_modified": False,
    }
    output = HERE / "origin-binding-controls-final.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"negative_controls_rejected": len(records), "path": str(output), "sha256": sha(output)}, indent=2))


if __name__ == "__main__":
    main()
