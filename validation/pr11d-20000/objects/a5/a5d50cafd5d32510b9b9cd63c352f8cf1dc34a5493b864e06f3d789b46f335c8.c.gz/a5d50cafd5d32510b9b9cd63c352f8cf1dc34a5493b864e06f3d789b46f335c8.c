#define _POSIX_C_SOURCE 200809L
#include <flint/arb.h>
#include <flint/fmpq.h>
#include <flint/fmpq_mat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/resource.h>
typedef struct {int power,row,col;fmpz_t value;} term;
static void die(const char*s){fprintf(stderr,"%s\n",s);exit(2);}
static double secs(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+1e-9*t.tv_nsec;}
static void readz(FILE*f,fmpz_t z){char text[8192];if(fscanf(f,"%8191s",text)!=1||fmpz_set_str(z,text,10))die("invalid integer");}
int main(int argc,char**argv){
 if(argc!=3)die("usage endpoint-native INPUT OUTPUT_JSON");double started=secs();FILE*f=fopen(argv[1],"r");if(!f)die("input unavailable");
 int dim,blocks,degree,ndeg,count,order,bits,printdigits,rlog;if(fscanf(f,"%d%d%d%d%d%d%d%d%d",&dim,&blocks,&degree,&ndeg,&count,&order,&bits,&printdigits,&rlog)!=9)die("invalid header");
 if(dim<1||dim>252||blocks<1||blocks>dim||degree<1||degree>16||ndeg<0||ndeg>16||count<1||order<8||order>100000||bits<64||rlog<1||rlog>16)die("unsupported dimensions/budget");
 int width=(degree>ndeg?degree:ndeg)+2;int*bo=malloc(dim*sizeof(int));int*bs=calloc(blocks,sizeof(int));int*bi=calloc(blocks*4,sizeof(int));for(int i=0;i<dim;i++){if(fscanf(f,"%d",bo+i)!=1||bo[i]<0||bo[i]>=blocks)die("invalid block index");int b=bo[i];if(bs[b]>=4)die("block largerthan4");bi[4*b+bs[b]++]=i;}
 fmpz*D=malloc((degree+1)*sizeof(fmpz));for(int k=0;k<=degree;k++){fmpz_init(D+k);readz(f,D+k);}if(!fmpz_is_zero(D)||fmpz_is_zero(D+1))die("denominator requires simple endpointzero");
 term*T=malloc(count*sizeof(term));fmpq_mat_t residue;fmpq_mat_init(residue,dim,dim);
 for(int e=0;e<count;e++){term*t=T+e;if(fscanf(f,"%d%d%d",&t->power,&t->row,&t->col)!=3||t->power<0||t->power>ndeg||t->row<0||t->row>=dim||t->col<0||t->col>=dim||bo[t->col]>bo[t->row])die("invalid coupling");fmpz_init(t->value);readz(f,t->value);if(t->power==0)fmpq_set_fmpz(fmpq_mat_entry(residue,t->row,t->col),t->value);}
 arb_ptr hist=_arb_vec_init(width*dim),rhs=_arb_vec_init(dim),real=_arb_vec_init(dim),imag=_arb_vec_init(dim);arb_t tmp,sum;arb_init(tmp);arb_init(sum);fmpz_t scaled;fmpz_init(scaled);char text[8192];
 for(int i=0;i<dim;i++){if(fscanf(f,"%8191s",text)!=1)die("missing initial rational");fmpq_t q;fmpq_init(q);if(fmpq_set_str(q,text,10))die("invalid initial rational");arb_set_fmpq(hist+i,q,bits);arb_set(real+i,hist+i);fmpq_clear(q);}fclose(f);
 // Exact residue annihilation is also independently checked by the preparer.
 for(int n=1;n<=order;n++){
  _arb_vec_zero(rhs,dim);
  for(int e=0;e<count;e++){term*t=T+e;if(t->power<1||t->power>n)continue;arb_addmul_fmpz(rhs+t->row,hist+((n-t->power)%width)*dim+t->col,t->value,bits);}
  for(int k=2;k<=degree&&k<=n+1;k++){int previous=n-k+1;if(previous==0||fmpz_is_zero(D+k))continue;fmpz_mul_ui(scaled,D+k,previous);arb_ptr old=hist+(previous%width)*dim;for(int i=0;i<dim;i++)arb_submul_fmpz(rhs+i,old+i,scaled,bits);}
  arb_ptr current=hist+(n%width)*dim;_arb_vec_zero(current,dim);
  for(int b=0;b<blocks;b++){
   int size=bs[b];fmpq_mat_t A,inv;fmpq_mat_init(A,size,size);fmpq_mat_init(inv,size,size);
   for(int i=0;i<size;i++)for(int j=0;j<size;j++){int ri=bi[4*b+i],cj=bi[4*b+j];fmpq_neg(fmpq_mat_entry(A,i,j),fmpq_mat_entry(residue,ri,cj));if(i==j){fmpz_mul_ui(scaled,D+1,n);fmpq_t q;fmpq_init(q);fmpq_set_fmpz(q,scaled);fmpq_add(fmpq_mat_entry(A,i,j),fmpq_mat_entry(A,i,j),q);fmpq_clear(q);}}
   if(!fmpq_mat_inv(inv,A))die("singular exact adjoint recurrence");
   for(int e=0;e<count;e++){term*t=T+e;if(t->power==0&&bo[t->row]==b&&bo[t->col]<b)arb_addmul_fmpz(rhs+t->row,current+t->col,t->value,bits);}
   for(int i=0;i<size;i++){int ri=bi[4*b+i];arb_zero(sum);for(int j=0;j<size;j++){const fmpq*q=fmpq_mat_entry(inv,i,j);if(fmpq_is_zero(q))continue;arb_mul_fmpz(tmp,rhs+bi[4*b+j],fmpq_numref(q),bits);arb_div_fmpz(tmp,tmp,fmpq_denref(q),bits);arb_add(sum,sum,tmp,bits);}arb_set(current+ri,sum);}
   fmpq_mat_clear(A);fmpq_mat_clear(inv);
  }
  for(int i=0;i<dim;i++){arb_mul_2exp_si(tmp,current+i,-rlog*n);if(n%4==0)arb_add(real+i,real+i,tmp,bits);else if(n%4==1)arb_add(imag+i,imag+i,tmp,bits);else if(n%4==2)arb_sub(real+i,real+i,tmp,bits);else arb_sub(imag+i,imag+i,tmp,bits);}
 }
 FILE*out=fopen(argv[2],"w");if(!out)die("output unavailable");struct rusage usage;getrusage(RUSAGE_SELF,&usage);
 fprintf(out,"{\"schema\":\"vakint.ancestor.native-endpoint-coefficients.v1\",\"dimension\":%d,\"order\":%d,\"working_bits\":%d,\"radius_power_of_two\":%d,\"native_seconds\":%.9f,\"peak_rss_bytes\":%ld,\"truncation_bound_added\":false,\"polynomial_values\":[",dim,order,bits,rlog,secs()-started,usage.ru_maxrss*1024L);
 for(int i=0;i<dim;i++){char*a=arb_get_str(real+i,printdigits,ARB_STR_MORE),*b=arb_get_str(imag+i,printdigits,ARB_STR_MORE);fprintf(out,"%s[\"%s\",\"%s\"]",i?",":"",a,b);flint_free(a);flint_free(b);}fprintf(out,"],\"last_coefficients\":[");int first=order-width+1;if(first<0)first=0;
 for(int n=first;n<=order;n++){fprintf(out,"%s{\"eta_power\":%d,\"values\":[",n>first?",":"",n);for(int i=0;i<dim;i++){char*v=arb_get_str(hist+(n%width)*dim+i,printdigits,ARB_STR_MORE);fprintf(out,"%s\"%s\"",i?",":"",v);flint_free(v);}fprintf(out,"]}");}fprintf(out,"]}\n");fclose(out);fprintf(stderr,"PASS nativeadjoint dim%d order%d %.3fsec\n",dim,order,secs()-started);
 for(int k=0;k<=degree;k++)fmpz_clear(D+k);free(D);for(int e=0;e<count;e++)fmpz_clear(T[e].value);free(T);free(bo);free(bs);free(bi);fmpq_mat_clear(residue);_arb_vec_clear(hist,width*dim);_arb_vec_clear(rhs,dim);_arb_vec_clear(real,dim);_arb_vec_clear(imag,dim);arb_clear(tmp);arb_clear(sum);fmpz_clear(scaled);flint_cleanup();return 0;
}
