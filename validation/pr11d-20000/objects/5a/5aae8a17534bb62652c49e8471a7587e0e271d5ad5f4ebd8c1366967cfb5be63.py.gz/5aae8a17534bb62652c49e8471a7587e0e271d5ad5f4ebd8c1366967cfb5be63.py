#!/usr/bin/env python3
"""Check frozen X8 metadata/caps without source assembly or native execution."""
import hashlib,json,re,sys
from decimal import Decimal
from fractions import Fraction as Q
from pathlib import Path
from flint import arb,ctx
sys.set_int_max_str_digits(300000)
ROOT=Path('/shared/codex-1/vakint_rustred/workspace/precision-periods')
BASE=ROOT/'bessel/ancestor-boundary'; RUNS=BASE/'production-runs-v1'
HERE=Path(__file__).resolve().parent; pins={}
def pin(p,h=None):
    p=Path(p).resolve(); v=hashlib.sha256(p.read_bytes()).hexdigest()
    if h is not None:assert v==h,(str(p),v,h)
    pins[str(p)]=v;return v
def read(p):pin(p);return json.loads(Path(p).read_text())
def decimal_box(s):
    s=s.strip()
    if s.startswith('['):
        a,b=s[1:-1].split('+/-');c=Decimal(a.strip() or '0');r=Decimal(b.strip())
    else:c,r=Decimal(s),Decimal(0)
    assert c.is_finite() and r.is_finite() and r>=0
    return c,r
def rational(s):return Q(str(s))
def guard(v,n):
    if n is None:assert v==0
    else:assert Q(1,10**(n+1))<=v<Q(1,10**n)
matching_path=ROOT/'pr11d/infinity-matching/exact-boundary-matching.json'
matching=read(matching_path);mh=pin(matching_path,'649d059e55ac920aad980eaf444ae45c0f86e7302db0eb1a5096cece33686504')
inventory=ROOT/'bessel/pr11-boundary/inventory-full-v2.json'
ih=pin(inventory,'db5290bc8520499001d9998098d95474270ba2f5ffed1213dfa5ce2062eac7e9')
assert matching['inventory_sha256']==ih and matching['freeconstants']==matching['dimension']==252
fields=('component','integer_z_power','epsilon_power','log_power')
key=lambda r:tuple(r[k] for k in fields)
all_ids=[key(r) for r in matching['all_boundary_selectors']]
assert len(all_ids)==len(set(all_ids))==1587
assert len(matching['selected_selectors'])==len(matching['boundary_inverse'])==252
assert all(len(r)==252 for r in matching['boundary_inverse'])
manifest_path=BASE/'production-source-profiles-v1.json'
pin(manifest_path,'d1132ed3218ad71b28053956b61217e83b18fb44d0e198b6d0661165421b8987')
manifest=read(manifest_path);summary=read(RUNS/'source-capability-summary.json')
pin(RUNS/'measure_sources.py',summary['validator_sha256'])
assert manifest['p853_import_fields']==['value','absolute_error_upper_bound']
assert not manifest['p853_diagnostic_arithmetic_ball_used']
assert not manifest['source_profiles_may_be_mixed']
expected={
 'A':(20800,69099,'37b62d59e28eaff4b8e533399be12272a247d0ce4546b9e6533df54678186f95','77f47b270d66f53ebc64d46089cab300bdff8a35a73753cb05e1644d769348ad'),
 'B':(21200,70428,'b387e100fdba452cba39b2bc9df3f1aaefe91c421792911dabd7493075a46dd7','2bc55b7d4b6e8ff10533b91e39a2a80f40cbad671f927aff1ea84b429c81e18a')}
profiles={}
for name,(dps,bits,bh,ch) in expected.items():
    directory=RUNS/name;bp=directory/'x8-source.boundary.json';cp=directory/'x8-source.constants.json'
    pin(bp,bh);pin(cp,ch);b=read(bp);c=read(cp);cap=read(directory/'source-capability.json');inv=read(directory/'assemble-invocation.json')
    assert b['matching_sha256']==c['exact_matching_sha256']==mh
    assert b['inventory_sha256']==c['inventory_sha256']==ih
    assert c['boundary_input_sha256']==cap['boundary_sha256']==bh and cap['constants_sha256']==ch
    assert b['working_decimal_digits']==c['working_decimal_digits']==inv['working_decimal_digits']==dps
    ctx.dps=dps;assert ctx.prec==c['working_bits']==bits
    assert b['normalization']==c['normalization']=='native_raw' and b['error_quality']==c['error_quality']=='rigorous-bound'
    assert b['all_prepared_rows_checked'] and b['require_all_prepared_rows'] and c['all_prepared_coefficients_checked']
    assert c['all_overdetermined_residuals_contain_zero']
    assert b['coefficient_count']==c['checked_coefficients']==len(b['coefficients'])==1587
    assert [key(row) for row in b['coefficients']]==all_ids
    assert c['free_constants']==len(c['free_constant_balls'])==252
    assert c['source_receipts']==b['source_receipts'] and not b['whole_PR11d_accuracy_claimed'] and not c['whole_PR11d_accuracy_claimed']
    for row in b['coefficients']:decimal_box(row['real_ball'])
    assert inv['profile']==name and inv['action']=='assemble' and inv['success'] and inv['exit_code']==0
    assert inv['output_path']==str(bp) and inv['output_sha256']==bh
    assert not inv['source_profiles_mixed'] and inv['physical_4L_chain_admission_pending']
    for p,h in inv['artifact_sha256'].items():pin(p,h)
    pin(RUNS/'run_profile.py',inv['runner_sha256']);pin(directory/'assemble.log',inv['log_sha256'])
    argv=inv['argv'];option=lambda n:argv[argv.index(n)+1]
    assert option('--working-digits')==str(dps)
    assert option('--output-prefix')==str(directory/'x8-source')
    profile=manifest['profiles'][name]
    for item in profile.values():
        if isinstance(item,dict) and 'path' in item:pin(item['path'],item['sha256'])
    assert argv[1]==profile['assembler']['path']
    assert option('--three-loop-input')==profile['three_loop']['path'] and option('--three-loop-sha256')==profile['three_loop']['sha256']
    expected_sources={profile[s]['path']:profile[s]['sha256'] for s in ['three_loop','sunset','p853']}
    expected_sources[option('--four-loop-input')]=option('--four-loop-sha256')
    assert {r['source']:r['sha256'] for r in b['source_receipts']}==expected_sources
    support={};source_rows=0
    for item in b['source_receipts']:
        pin(item['source'],item['sha256']);data=read(item['source'])
        for imported in item.get('imported_support',[]):
            symbol=imported['symbol'];rows=data['coefficients'][symbol];first,last=imported['first_epsilon_power'],imported['last_epsilon_power']
            assert [r['epsilon_power'] for r in rows]==list(range(first,last+1))
            vals=[arb(r['ball']) for r in rows];assert all(v.is_finite() for v in vals)
            assert imported['relative_accuracy_bits']==[None if v.contains(0) else int(v.rel_accuracy_bits()) for v in vals]
            assert imported['exact_zero_orders']==[first+i for i,v in enumerate(vals) if v.is_zero()]
            support[symbol]=last;source_rows+=len(rows)
        if item['source']==profile['sunset']['path']:
            rows=data['coefficients']['native_raw'];assert [r['epsilon_power'] for r in rows]==list(range(-2,4))
            assert data['error_quality']=='rigorous-bound' and data['validated_analytic_truncation_and_rounding']
            for r in rows:decimal_box(r['ball'])
            support['native::L2_P2']=3;source_rows+=6
        if item['source']==profile['p853']['path']:
            rows=data['coefficients']['native_raw'];assert [r['epsilon_power'] for r in rows]==list(range(-3,5))
            acceptance=read(profile['p853_acceptance']['path'])
            assert acceptance['coefficient_data_sha256']==item['sha256'] and acceptance['source_exact_jet_sha256']==data['source_exact_jet_sha256']
            if name=='A':assert item['acceptance_receipt_sha256']==profile['p853_acceptance']['sha256']
            else:assert item['acceptance_sha256']==profile['p853_acceptance']['sha256']
            for r in rows:
                assert arb(r['value']).is_finite() and arb(r['absolute_error_upper_bound']).is_finite() and arb(r['absolute_error_upper_bound']).lower()>=0
            support['pr11d::massless::8535684c37e21dfd38135b151cca892f3552977fef43ab9d0f2deb22f3762f64::raw_native']=4;source_rows+=8
    assert support==b['required_raw_primitive_through']
    for p,h in b['recipe_receipt']['source_sha256'].items():pin(p,h)
    for p,h in b.get('implementation_sha256',{}).items():pin((BASE.parent if p.startswith('pr11-boundary/') else BASE)/p,h)
    if 'producer_sha256' in b:pin(profile['assembler']['path'],b['producer_sha256'])
    ctx.dps=21400;assert cap['working_digits_used_for_measurement']==21400
    assert [r['index'] for r in cap['constants']]==list(range(252))
    maximum=arb(0);zero=uncertain=0
    for index,(literal,row) in enumerate(zip(c['free_constant_balls'],cap['constants'])):
        mid,rad=decimal_box(literal);v=arb(literal);assert v.is_finite()
        r=v.rad();diameter=2*r;rq=rational(r.fmpq());dq=rational(diameter.fmpq())
        assert Q(rad)<=rq
        assert row['absolute_radius_upper_enclosure']==r.upper().str(45,more=True)
        assert row['diameter_upper_enclosure']==diameter.upper().str(45,more=True)
        guard(rq,row['guaranteed_absolute_radius_decimal_power']);guard(dq,row['guaranteed_diameter_decimal_power'])
        for text,exact in [(row['absolute_radius_upper_enclosure'],Q(rad)),(row['diameter_upper_enclosure'],2*Q(rad))]:
            cm,cr=decimal_box(text);assert exact<=Q(cm)+Q(cr)
        assert row['exact_zero']==v.is_zero() and row['uncertain_zero']==(v.contains(0) and not v.is_zero())
        assert row['relative_accuracy_bits']==(None if v.contains(0) else int(v.rel_accuracy_bits()))
        zero+=v.is_zero();uncertain+=v.contains(0) and not v.is_zero();maximum=max(maximum,r)
    assert zero==cap['exact_zero_count']==13 and uncertain==cap['uncertain_zero_count']==10
    assert cap['maximum_constant_radius']==maximum.upper().str(45,more=True)
    for field,rowsfield in [('all_radius_guaranteed_decimal_power','guaranteed_absolute_radius_decimal_power'),('all_diameter_guaranteed_decimal_power','guaranteed_diameter_decimal_power')]:
        assert cap[field]==min(r[rowsfield] for r in cap['constants'] if r[rowsfield] is not None)
    assert summary['profiles'][name]=={k:v for k,v in cap.items() if k!='constants'}
    assert cap['physical4Lsource_admission_pending'] and not cap['whole_PR11d_precision_claimed']
    profiles[name]={'boundary_sha256':bh,'constants_sha256':ch,'working_decimal_digits':dps,'working_bits':bits,'all_1587_boundary_ids_exact':True,'all_252_constant_positions_and_caps_verified':True,'all_252_cap_strings_exactly_reproduced_at_21400_dps':True,'all_252_cap_powers_independently_verified_by_exact_rational_inequalities':True,'explicit_source_coefficients_checked':source_rows,'required_raw_primitive_through':support,'maximum_constant_radius':cap['maximum_constant_radius'],'all_radius_guaranteed_decimal_power':cap['all_radius_guaranteed_decimal_power'],'all_diameter_guaranteed_decimal_power':cap['all_diameter_guaranteed_decimal_power'],'exact_zeros':zero,'uncertain_zeros':uncertain}
pin(__file__)
report={'schema':'vakint.x8.production-source-metadata-review.v1','accepted_for_metadata_and_saved_width_measurement_scope':True,'physical_source_admission_claimed':False,'source_origin_conditional_on_external_A_B_four_loop_reviews':True,'profiles':profiles,'artifact_sha256':pins,'all_504_constant_caps_verified':True,'constant_identity_convention':'Saved constant arrays use positions0..251 in the exact matching boundary-inverse row order; source value/solve replay belongs to the companion numerical review.','scope_limits':['No native/preparer/HPL/source assembly or matching numerical evaluation was run.','No source-origin,4L-chain,physical-alias or whole-period admission is made. Frozen source quality fields are checked as metadata; their mathematical validity belongs to external source proofs.','All cap rows reproduce parsed literal-radius widths at21400dps, including serialization enlargement. Internal working precision is not an accuracy claim.','The retained manifest/invocation/payload hash graph is verified; historical execution identity is not independently attested.'],'producer_files_modified':False}
dest=HERE/'review.json';dest.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'accepted':True,'receipt':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'pins':len(pins),'profiles':profiles}))
