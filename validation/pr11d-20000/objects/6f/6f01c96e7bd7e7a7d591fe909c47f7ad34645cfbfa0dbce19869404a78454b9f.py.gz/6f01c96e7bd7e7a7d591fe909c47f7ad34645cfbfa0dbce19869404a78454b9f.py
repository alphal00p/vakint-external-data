#!/usr/bin/env python3
"""Contract authenticated V=epsilon W endpoint balls with original raw X8 jets."""
from pathlib import Path
from fractions import Fraction
import argparse,hashlib,importlib.util,json,sys
from flint import arb,acb,ctx
ROOT=Path(__file__).resolve().parent.parent
DECIMAL_HELPER=ROOT/'p853/validate.py'
assert hashlib.sha256(DECIMAL_HELPER.read_bytes()).hexdigest()=='eaf83ed92f7f48a6ef198dc2dbcf29fe0b4be05dc46065115477526f837a2fa8', 'Unreviewed decimal rounding helper'
_spec=importlib.util.spec_from_file_location('pr11d_reviewed_decimal_helper',DECIMAL_HELPER);_helper=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_helper)
assert Path(_helper.__file__).resolve()==DECIMAL_HELPER.resolve()
rounded_cell,upper_decimal=_helper.rounded_cell,_helper.upper_decimal
if not __debug__:raise RuntimeError('Acceptance requires assertions enabled')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def unique(items):
 result={}
 for key,value in items:
  if key in result:raise ValueError('Duplicate JSON key: '+key)
  result[key]=value
 return result
def load(path):return json.loads(Path(path).read_text(),object_pairs_hook=unique)
def box(value):
 assert isinstance(value,list) and len(value)==2 and all(isinstance(v,str) for v in value)
 z=acb(arb(value[0]),arb(value[1]));assert z.is_finite();return z

def project(boundary_path,transport_path,chain_path,expected_chain_review_sha,adjoint_path,acceptance_path,digits,required,output):
 assert digits>=64 and (required is None or 16<=required<=digits-30)
 ctx.dps=digits
 boundary=load(boundary_path);transport=load(transport_path);chain=load(chain_path);adjoint=load(adjoint_path);accepted=load(acceptance_path)
 assert sha(acceptance_path)=='b523238139d137f911645bd179bd15cc7386bf89232abdac799421cbc85d3b38', 'Unreviewed endpoint-production acceptance artifact'
 assert not output.exists(),'Immutable projection output already exists'
 assert transport['complete'] is True and transport['error_quality']=='rigorous-bound'
 assert sha(boundary_path)==transport['final_boundary_sha256'] and Path(transport['final_boundary']).resolve()==boundary_path.resolve()
 assert boundary['basis']=='original_raw_epsilon_jets' and boundary['dimension']==42
 assert boundary['epsilon_min_power']==-4 and boundary['epsilon_max_power']==1
 assert boundary['normalization']=='native_raw' and boundary['error_quality']=='rigorous-bound'
 connection=load(ROOT/'jet-transport/polynomial-connection.json')
 assert boundary['source_equation_sha256']==connection['source_sha256']==sha(connection['source'])
 assert boundary['local_truncation_rigorously_enclosed'] is True
 assert chain['schema']=='vakint.pr11d.physical-X8-chain-acceptance.v1' and chain['status']=='passed_for_frozen_completed_physical_chain'
 assert chain['basis']=='original_raw_epsilon_jets' and chain['dimension']==42 and chain['epsilon_range']==[-4,1]
 assert chain['source_equation_sha256']==connection['source_sha256'] and chain['normalization']=='native_raw' and chain['error_quality']=='rigorous-bound'
 assert [Fraction(x) for x in chain['eta_center']]==[Fraction(0),Fraction(1,16)]
 for key in ['initial_physical_provenance_verified','all_step_source_hashes_and_centers_verified','all_local_tails_certified','all_interval_gauge_and_serialization_checks_passed']:assert chain[key] is True
 for pins in [chain['source_pins'],chain['artifact_sha256']]:
  for path,pin in pins.items():assert sha(path)==pin,'Changed accepted chain source/artifact: '+path
 assert chain['artifact_sha256'][str(boundary_path.resolve())]==sha(boundary_path) and chain['artifact_sha256'][str(transport_path.resolve())]==sha(transport_path)
 review_path=Path(chain['independent_validator_review_path']);assert sha(review_path)==chain['independent_validator_review_sha256']==expected_chain_review_sha
 review=load(review_path);assert review['validator_sha256']==chain['validator_sha256'] and review['status']=='passed_for_frozen_physical_X8_chain_validator'
 assert accepted['schema']=='vakint.pr11d.frozen-X8-endpoint-production-acceptance.v1'
 assert accepted['status']=='passed_for_frozen_completed_endpoint_production'
 assert accepted['all_252_saved_ball_reencodings_match'] is True and accepted['all_tail_metadata_replay_matches'] is True
 for pins in [accepted['source_pins'],accepted['artifact_sha256']]:
  for path,pin in pins.items():assert sha(path)==pin,'Changed accepted source or artifact: '+path
 assert accepted['artifact_sha256'][str(adjoint_path.resolve())]==sha(adjoint_path)
 assert accepted['dimension']==adjoint['dimension']==252 and accepted['epsilon_range']==adjoint['epsilon_range']==[0,5]
 assert adjoint['definition']=='V=epsilon*W; Vprime=-VA; finite PR11d=[epsilon^1](V dot original rawY)'
 assert adjoint['tail_bound_added'] is True and adjoint['source_polynomial_sha256']==sha(ROOT/'jet-transport/polynomial-connection.json')
 assert adjoint['endpoint_projector_proof_sha256']==sha(ROOT/'helper/endpoint-adjoint-proof.json')
 assert [Fraction(x) for x in boundary['eta_center']]==[Fraction(x) for x in adjoint['eta_center']]==[Fraction(0),Fraction(1,16)]
 assert isinstance(boundary['values'],list) and isinstance(adjoint['complex_balls'],list)
 assert len(boundary['values'])==len(adjoint['complex_balls'])==252
 Y=list(map(box,boundary['values']));V=list(map(box,adjoint['complex_balls']))
 # V begins at epsilon^0, rawY at epsilon^-4. Their shifted convolution
 # coefficient p represents target epsilon^(p-5), since W=V/epsilon.
 coefficients=[]
 for p in range(6):
  z=sum((V[42*j+i]*Y[42*(p-j)+i] for j in range(p+1) for i in range(42)),acb(0))
  assert z.is_finite() and z.imag.contains(0),'Physical coefficient has unresolved imaginary part'
  if p<5:assert z.real.contains(0),'Unexpected apparent pole before the finite PR11d coefficient'
  coefficients.append({'epsilon_power':p-5,'real_ball':z.real.str(digits+8,more=True),'imaginary_ball':z.imag.str(digits+8,more=True),'absolute_real_radius_upper_bound':upper_decimal(z.real.rad()),'absolute_imaginary_radius_upper_bound':upper_decimal(z.imag.rad()),'real_relative_accuracy_bits':int(z.real.rel_accuracy_bits()),'negative_power_zero_is_observed_enclosure_only':p<5})
 finite=acb(arb(coefficients[-1]['real_ball']),arb(coefficients[-1]['imaginary_ball']));assert not finite.real.contains(0)
 radius=max(finite.real.rad(),finite.imag.rad());capability=None if radius==0 else int((- (radius/abs(finite.real).lower()).log()/arb(10).log()).lower().floor().fmpz())
 decimal=None
 if required is not None:
  assert max(finite.real.rad(),finite.imag.rad())<abs(finite.real).lower()*arb(10)**(-required-3),'Total physical coefficient precision shortfall'
  center,error=rounded_cell(finite.real,required)
  decimal={'value':center,'validated_significant_digits':required,'absolute_error_upper_bound':upper_decimal(error),'rounding':'Unique nearest decimal rounding cell checked against both exact Arb endpoints'}
 payload={'schema':'vakint.pr11d.bounded-finite-endpoint-projection.v1','normalization':'native_raw','error_quality':'rigorous-bound','definition':'[epsilon^1](V dot rawY); V=epsilon W exactly once; no Euler/Gamma/mass/sign conversion','master_alias':'PR11dep0','epsilon_power':0,'source_equation_sha256':connection['source_sha256'],'boundary_path':str(boundary_path.resolve()),'boundary_sha256':sha(boundary_path),'transport_receipt_path':str(transport_path.resolve()),'transport_receipt_sha256':sha(transport_path),'chain_acceptance_path':str(chain_path.resolve()),'chain_acceptance_sha256':sha(chain_path),'adjoint_path':str(adjoint_path.resolve()),'adjoint_sha256':sha(adjoint_path),'adjoint_acceptance_path':str(acceptance_path.resolve()),'adjoint_acceptance_sha256':sha(acceptance_path),'coefficient_relative_radius_bound_decimal_digits':capability,'finite_coefficient_exact_ball':bool(radius==0),'coefficients':coefficients,'rounded_decimal':decimal,'working_decimal_precision':digits,'working_bits':ctx.prec,'serialization_decimal_digits':digits+8,'projection_sha256':sha(Path(__file__)),'decimal_helper_sha256':sha(ROOT/'p853/validate.py'),'assumptions':['Original raw X8 physical solution has no coefficient below epsilon^-4; source-bound physical pole certificate must accompany publication.','Endpoint adjoint and raw solution use the authenticated same42-integral original basis.','This numerical projection does not itself prove that exact physical poles vanish or change any published data cap.'],'whole_PR11d_20000_accuracy_claimed':False}
 with output.open('x') as stream:stream.write(json.dumps(payload,indent=2)+'\n')
 print('PR11d bounded finite projection:',capability,'relative-radius digits; requested nearest-decimal digits',required);return payload

def main():
 p=argparse.ArgumentParser();p.add_argument('--boundary',type=Path,required=True);p.add_argument('--transport',type=Path,required=True);p.add_argument('--chain-validation',type=Path,required=True);p.add_argument('--chain-validator-review-sha256',required=True);p.add_argument('--adjoint',type=Path,default=ROOT/'endpoint-adjoint/adjoint-native-20400.json');p.add_argument('--adjoint-acceptance',type=Path,default=ROOT/'ancestor-flows/production-validation-v1/accepted-v2.json');p.add_argument('--digits',type=int,required=True);p.add_argument('--require-digits',type=int);p.add_argument('--output',type=Path,required=True);a=p.parse_args();project(a.boundary,a.transport,a.chain_validation,a.chain_validator_review_sha256,a.adjoint,a.adjoint_acceptance,a.digits,a.require_digits,a.output)
if __name__=='__main__':main()
