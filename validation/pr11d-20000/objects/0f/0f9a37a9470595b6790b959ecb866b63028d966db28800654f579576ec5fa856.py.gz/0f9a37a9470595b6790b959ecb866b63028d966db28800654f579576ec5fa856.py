from replay import *
from target import rowspace,reduce
from symmetries import physical_automorphisms,transform_expression

def main():
    seed=BASIS[37]
    rows=[(('ibp',seed,i,j),ibp(seed,i,j)) for i,j in itertools.product(range(4),repeat=2)]
    support={p for _,row in rows for p in row}
    transports=[]
    for p in sorted(support):
        for index,(perm,t) in enumerate(physical_automorphisms()):
            row={p:ONE}
            image=transform_expression(p,t)
            assert image is not None
            muladd(row,image,-ONE)
            if row:
                rows.append((('routing',p,index),row))
                transports.append({'powers':p,'matrix':t,'row':serialize(row)})
    print('rows',len(rows),'transport',len(transports),flush=True)
    pivots=rowspace(rows)
    proofs=[]
    for target in DATA['target_reductions']:
        row={tuple(target['powers']):ONE}
        for term in target['terms']:add(row,tuple(term['powers']),-parse(term['coefficient'],DATA['epsilon_symbol'],DATA['variable']))
        remainder,witness=reduce(row,pivots)
        print('target',target['powers'],'remaining',len(remainder),serialize(remainder),flush=True)
        if not remainder:
            reconstructed={}
            original_rows=dict(rows)
            for ident,v in witness.items():muladd(reconstructed,original_rows[ident],v)
            difference=row.copy();muladd(difference,reconstructed,-ONE);assert not difference
        proofs.append({'target':target['powers'],'proved':not remainder,'witness':[{'row':ident,'coefficient':str(v)} for ident,v in witness.items()],
                       'remainder':serialize(remainder)})
    (HERE/'target-physical-replay.json').write_text(json.dumps({'rows':transports,'proofs':proofs},indent=2)+'\n')

if __name__=='__main__':main()
