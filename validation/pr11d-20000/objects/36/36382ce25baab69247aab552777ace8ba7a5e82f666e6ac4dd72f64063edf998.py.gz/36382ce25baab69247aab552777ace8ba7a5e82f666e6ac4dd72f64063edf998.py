"""Build a transparent original-AMFlow independent transport oracle input."""
from pathlib import Path
from fractions import Fraction
import json,hashlib,shutil,os,math
from flint import arb,ctx,fmpq_poly,fmpq
ROOT=Path(__file__).resolve().parent;PARENT=ROOT.parent
SOURCE=Path('/shared/codex-2/vacuum_masters/SOURCES/amflow-upstream-26005517a288086c4cb4d1b26d829691bc088485-reference-v1')
CONNECTION=PARENT/'jet-transport/polynomial-connection.json'
BOUNDARY=PARENT/'helper/frobenius-transport/physical190-v2-eta256.json'
ENDPOINT=PARENT/'endpoint-adjoint/adjoint-260.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if not __debug__:raise RuntimeError('Assertions required')
ctx.dps=280
connection=json.loads(CONNECTION.read_text());initial=json.loads(BOUNDARY.read_text());endpoint=json.loads(ENDPOINT.read_text());prepared=Path(connection['source']);system=json.loads(prepared.read_text())
assert connection['source_sha256']==sha(prepared) and connection['dimension']==42 and connection['epsilon_jet_count']==6 and connection['exact_six_jet_reconstruction_verified']
assert initial['basis']=='original_X8_raw_epsilon_minus4_through1' and initial['eta_center']==['0','256'] and initial['normalization']=='native_raw' and initial['epsilon_min_power']==-4 and initial['epsilon_max_power']==1 and len(initial['values'])==252
assert initial['error_quality']=='validated-digits-estimate' and not initial['physical_accuracy_certified'] and initial['local_truncation_rigorously_enclosed']
assert endpoint['eta_center']==['0','1/16'] and endpoint['epsilon_range']==[0,5] and len(endpoint['complex_balls'])==252
assert system['source_family_sha256']=='693719b1bc3d2f1d4d32c9312df66ced667a542591a2ada6f6498844fc5d0de1'
# Exact polynomial connection lift in the original raw basis. Row index j*42+i
# means physical Laurent coefficient epsilon^(j-4), with0<=j<=5.
rows=[];rules=[]
for entry in connection['entries']:
 p=entry['epsilon_power'];assert 0<=p<6
 polynomial='+'.join(f"({t['numerator']}/{t['denominator']})*DESolver`eta^{t['eta_power']}" for t in entry['terms']) or '0'
 for jet in range(p,6):
  i=jet*42+entry['row']+1;j=(jet-p)*42+entry['column']+1
  rules.append(f'{{{i},{j}}}->(({polynomial})/den)')
D='+'.join(f'({c})*DESolver`eta^{k}' for k,c in enumerate(connection['denominator_coefficients']))
# AMFlow accepts the exact rational matrix as input; do not substitute a finite
# epsilon point or import any numerical solution/physical reference value.
wl='den='+D+';\nconnection=Normal[SparseArray[{'+','.join(rules)+'},{252,252}]];\nClear[den];\n'
(ROOT/'exact-lift.wl').write_text(wl)
precision_checks=[]
def export(values):
 centers=[]
 for index,(re,im) in enumerate(values):
  pair=[]
  for name,text in [('real',re),('imaginary',im)]:
   value=arb(text);assert value.is_finite();mid=value.mid().str(245,radius=False);radius=value.rad()
   pair.append({'center':mid,'exact_zero':value.is_zero(),'source_ball':text})
   precision_checks.append({'index':index,'component':name,'absolute_source_radius':radius.str(30),'exact_zero':value.is_zero()})
  centers.append(pair)
 return centers
start=export(initial['values']);finish=export(endpoint['complex_balls'])
# Exact positive imaginary-axis path: four steps per halving, each <=1/4 of
# distance to the origin. This is the already reviewed physical homotopy.
path=[Fraction(256)];top=Fraction(256)
while top>Fraction(1,16):
 path += [top*Fraction(k,8) for k in [7,6,5,4]];top/=2
assert path[-1]==Fraction(1,16) and len(path)==49 and all(a>b>0 for a,b in zip(path,path[1:]))
# Every matrix pole is real, certified by exact factorization, hence the path
# has no matrix pole. Additional retained IBP guards stay bound verbatim.
constant,factors=fmpq_poly([fmpq(x) for x in connection['denominator_coefficients']]).factor();pole_proofs=[]
for polynomial,power in factors:
 if polynomial.degree()==1:
  root=-Fraction(str(polynomial[0]))/Fraction(str(polynomial[1]));pole_proofs.append({'linear_root':str(root),'multiplicity':power})
 elif polynomial.degree()==2:
  a,b,c=map(lambda k:Fraction(str(polynomial[k])),[2,1,0]);disc=b*b-4*a*c;assert disc>0;pole_proofs.append({'quadratic_coefficients':[str(c),str(b),str(a)],'positive_real_discriminant':str(disc),'multiplicity':power})
 else:raise RuntimeError('Unexpected matrix pole factor')
# Copy only original numerical package; algorithms remain byte-identical.
package=ROOT/'upstream'/'diffeq_solver';package.mkdir(parents=True,exist_ok=True)
for name in ['DESolver.m']:
 target=package/name
 if target.exists():assert sha(target)==sha(SOURCE/'diffeq_solver'/name)
 else:shutil.copyfile(SOURCE/'diffeq_solver'/name,target)
license_notice=ROOT/'upstream'/'LICENSE.md'
if license_notice.exists():assert sha(license_notice)==sha(SOURCE/'LICENSE.md')
else:shutil.copyfile(SOURCE/'LICENSE.md',license_notice)
for suffix in ['py','wl']:
 target=ROOT/f'wolfram_one_thread.{suffix}'
 if not target.exists():shutil.copyfile(PARENT/f'wolfram_one_thread.{suffix}',target)
license_dir=ROOT/'wolfram-license';license_dir.mkdir(exist_ok=True);license=license_dir/'mathpass'
if not license.exists():license.write_text('!itplic.itp.unibe.ch\n');license.chmod(0o600)
for folder in ['tmp','wolfram-userbase']:(ROOT/folder).mkdir(exist_ok=True)
inputdata={'schema':'vakint.pr11d.independent-AMFlow-MMA-oracle-input.v1','master_id':'L4_693719b1bc3d2f1d4d32c9312df66ced667a542591a2ada6f6498844fc5d0de1_p0_p2_p1_p1_p1_p1_p1_p1_p1_p0','ordered_target_powers':[0,2,1,1,1,1,1,1,1,0],'dimension':252,'base_dimension':42,'epsilon_orders':[-4,1],'basis_order':'epsilon-major j*42+i, j=0..5 corresponds rawYepsilon^(j-4)','input_boundary':start,'endpoint_adjoint':finish,'path_imaginary':[str(x) for x in path],'finite_coefficient_projection':'Sum[V[k*42+i]*Y[(5-k)*42+i],{k,0,5},{i,0,41}]','normalization':'native raw; finite PR11d equals FMFT finite since its negative Laurent coefficients vanish','input_error_quality':initial['error_quality'],'physical_accuracy_certified':False,'source_boundary_error_balls_preserved':True,'retained_native_nonzero_conditions':system['nonzero_conditions'],'matrix_path_pole_certificates':pole_proofs,'scope':'Original AMFlow Mathematica ordinary Taylor transport is independent; exact IBPs/DE, numerical Frobenius starting vector, physical source algebra and endpoint adjoint are shared. This is an independent solver crosscheck, not an independent four-loop boundary/reduction construction or a20k validation.','requested_comparison_digits':70,'source_paths_sha256':{str(p):sha(p) for p in [CONNECTION,BOUNDARY,ENDPOINT,prepared,SOURCE/'diffeq_solver/DESolver.m',ROOT/'upstream/diffeq_solver/DESolver.m',ROOT/'exact-lift.wl',ROOT/'wolfram_one_thread.py',ROOT/'wolfram_one_thread.wl']},'upstream_commit':'26005517a288086c4cb4d1b26d829691bc088485','no_reference_coefficient_imported_into_solve':True}
(ROOT/'input.json').write_text(json.dumps(inputdata,indent=2)+'\n')
(ROOT/'input-source-errors.json').write_text(json.dumps({'source_error_quality':initial['error_quality'],'input_component_errors':precision_checks,'interpretation':'Preserved input errors remain shared and are not numerically propagated by original AMFlow; independent refinement assesses solver central-value stability only.','source_boundary_sha256':sha(BOUNDARY)},indent=2)+'\n')
print('Prepared',len(rules),'lifted entries;',len(path)-1,'ordinary steps; allmatrixpolesreal; nativeguards',len(system['nonzero_conditions']))
