#!/usr/bin/env python3
"""Seal an immutable guarded PR9 ordinary boundary after total-width checks."""
import argparse,hashlib,json
from pathlib import Path
from flint import arb,acb,ctx
if not __debug__:raise RuntimeError('Assertions required')
HERE=Path(__file__).resolve().parent
REVIEW=HERE.parents[1]/'pr9-api-boundary-review/pr9-source-review-receipt.json'
SOURCE=HERE.parents[3]/'bessel/ancestor-boundary/pr9-boundary-API20280-working20400.json'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(path,digest):
    if sha(path)!=digest:raise ValueError('Source hash mismatch: '+str(path))
def preflight():
    r=json.loads(REVIEW.read_text());assert r['accepted_for_source_and_native_input_scope']
    assert r['source_error_quality']=='rigorous-bound' and r['actual_absolute_source_guard_digits']>=20240
    assert r['intended_final_transport_width_digits']==20220
    pin(SOURCE,r['boundary_sha256']);pin(HERE/'pr9-API20280-init-v1.in',r['native_input_sha256'])
    for item in r['receipts']:
        pin(item['path'],item['sha256']);nested=json.loads(Path(item['path']).read_text())
        for q in nested.get('artifact_sha256',{}).values():pin(q['path'],q['sha256'])
        for q in nested.get('nested_source_pins',[]):pin(q['path'],q['sha256'])
        for field in ['source_sha256','input_sha256']:
            mapping=nested.get(field,{})
            if isinstance(mapping,dict):
                for path,digest in mapping.items():pin(path,digest)
    s=json.loads(SOURCE.read_text());assert s['normalization']=='native_raw' and s['error_quality']=='rigorous-bound'
    assert s['all_prepared_rows_checked'] and s['all_overdetermined_residuals_contain_zero']
    assert s['coefficient_count']==557 and s['free_constants']==132
    m=json.loads((HERE/'pr9-API20280-init-v1.json').read_text())
    assert m['seed_binding']==sha(SOURCE) and m['input_sha256']==r['native_input_sha256']
    assert m['z0']==['0','-1/256'] and m['requested_digits']==20320
    ordinary=HERE.parents[2]/'ancestor-flows/pr9-22-ordinary-polynomial.json';o=json.loads(ordinary.read_text());pin(o['source'],o['source_sha256'])
    assert o['dimension']==22 and o['epsilon_jet_count']==6
    return r,s,m,ordinary,o

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--preflight-only',action='store_true');args=ap.parse_args()
    r,s,m,ordinary,o=preflight()
    if args.preflight_only:print('All current source, receipt, matching and native-input pins verified');return
    cross_path=HERE.parent/'independent-three-loop-source-crosscheck-v1.json'
    cross=json.loads(cross_path.read_text());assert cross['accepted'] and cross['all_12_complex_coefficients_pass']
    assert cross['required_decimal_agreement']>=20000 and cross['normalization']=='native_raw'
    for path,digest in cross['source_sha256'].items():pin(path,digest)
    ctx.dps=20600;j=json.loads((HERE/'pr9-API20280-init-v1-output.json').read_text())
    assert j['dimension']==132 and j['maximum_log_degree']==8
    assert j['local_tail_certified'] and j['exact_residue_identity_verified']
    assert j['working_bits']==m['bits'] and j['digits']==20320
    maxima={};minima={}
    for field in ['normalized_J_values','original_Y_values']:
        vals=[acb(arb(a),arb(b)) for a,b in j[field]]
        assert len(vals)==132 and all(z.is_finite() for z in vals)
        radii=[z.real.rad()+z.imag.rad() for z in vals]
        assert all(v<arb('1e-20220') for v in radii)
        maxima[field]=max(radii).str(40)
        minima[field]=min(z.rel_accuracy_bits() for z in vals if not z.contains(0))
    low=json.loads((HERE.parent/'pr9-bounded100-eta256-v1.json').read_text())
    a=[acb(arb(x),arb(y)) for x,y in low['values']];b=[acb(arb(x),arb(y)) for x,y in j['original_Y_values']]
    # Distinct accepted primitive sources: overlap is the proper independent
    # comparison, not an assumed nested-input refinement.
    assert all(x.overlaps(y) for x,y in zip(a,b))
    report={'schema':'vakint.pr9.guarded-ordinary-boundary.v2','basis':'original_raw_epsilon_jets','dimension':22,'jets':6,'epsilon_min_power':-4,'epsilon_max_power':1,'eta_center':['0','256'],'normalization':'native_raw','error_quality':'rigorous-bound','original_source_equation_path':o['source'],'original_source_equation_sha256':o['source_sha256'],'ordinary_polynomial_connection_path':str(ordinary),'ordinary_polynomial_connection_sha256':sha(ordinary),'source_boundary_path':str(SOURCE),'source_boundary_sha256':sha(SOURCE),'independent_source_review_path':str(REVIEW),'independent_source_review_sha256':sha(REVIEW),'independent_three_loop_flow_crosscheck_path':str(cross_path),'independent_three_loop_flow_crosscheck_sha256':sha(cross_path),'matching_sha256':s['matching_sha256'],'inventory_sha256':s['inventory_sha256'],'native_preparation_sha256':sha(HERE/'pr9-API20280-init-v1.json'),'native_input_sha256':m['input_sha256'],'native_output_sha256':sha(HERE/'pr9-API20280-init-v1-output.json'),'native_source_sha256':sha(HERE/'contracted_v2.c'),'native_binary_sha256':sha(HERE/'contracted-native-v2'),'validator_sha256':sha(__file__),'all_132_normalized_and_original_total_radii_below_1e_minus20220':True,'all_132_overlap_independent_bounded_100_digit_initialization':True,'local_tail_certified':True,'maximum_total_radius':maxima,'minimum_relative_bits_excluding_zero_containing':minima,'order':j['order'],'seconds':j['seconds'],'peak_rss_bytes':j['peak_rss_bytes'],'values':j['original_Y_values'],'whole_master_accuracy_claimed':False,'qualification':'Certified ordinary-point values only. Endpoint projection and independent final master controls remain required.'}
    out=HERE.parent/'pr9-API20280-eta256-guard20220-v1.json'
    if out.exists():raise ValueError('Refusing to overwrite immutable boundary')
    out.write_text(json.dumps(report,indent=2)+'\n');print('accepted',out,'sha256',sha(out),'radius',maxima)
if __name__=='__main__':main()
