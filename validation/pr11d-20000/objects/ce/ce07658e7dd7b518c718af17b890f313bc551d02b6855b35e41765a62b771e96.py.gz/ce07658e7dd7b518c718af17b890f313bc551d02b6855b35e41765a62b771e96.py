#!/usr/bin/env python3
"""Exact polynomial normalized infinity connection plus generic log-degree proof."""
import hashlib,json,pathlib,sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'helper'))
from exact_system import CTX,ONE,parse
if not __debug__:raise RuntimeError('Assertions required')
HERE=pathlib.Path(__file__).resolve().parent
source=HERE.parent/'helper/augmented5.json.normalized.json';data=json.loads(source.read_text());dim=data['state_dimension'];assert dim==252
D=ONE;values=[]
for i,row in enumerate(data['matrix']):
    for j,text in enumerate(row):
        if text=='0':continue
        q=parse(text,'masters_4l::{}::epsilon','pr11d_direct_helper::{}::z')
        assert all(e==0 for e,x in q.num.to_dict()) and all(e==0 for e,x in q.den.to_dict())
        D=D*q.den//D.gcd(q.den);values.append((i,j,q))
D=D/D.leading_coefficient();degree=int(D.degrees()[1]);assert D.to_dict().get((0,0),0)==0 and D.to_dict().get((0,1),0)!=0
entries=[];ndegree=0
for i,j,q in values:
    poly=q.num*(D//q.den);assert poly*q.den==q.num*D
    terms=[]
    for (e,k),c in sorted(poly.to_dict().items(),key=lambda kv:kv[0][1]):
        assert e==0;ndegree=max(ndegree,int(k));terms.append({'z_power':int(k),'numerator':str(c.numerator),'denominator':str(c.denominator)})
    entries.append({'row':i,'column':j,'terms':terms})
matching=HERE/'exact-boundary-matching.json';m=json.loads(matching.read_text());startup=HERE/'exact-startup-coefficients.json';seed=json.loads(startup.read_text())
assert seed['source_matching_sha256']==hashlib.sha256(matching.read_bytes()).hexdigest() and seed['exact_recurrence_identity_verified']
maxlog=max(row['log_power'] for row in seed['coefficients']);assert maxlog==m['max_exact_log_degree']==8
assert {row['root'] for row in m['residue_blocks']}==set(range(-8,0)) and m['normalized_power_range']==[-8,0]
result={'schema':'vakint.pr11d.exact-polynomial-infinity-connection.v1','source_normalized_connection_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'dimension':252,'epsilon_range':[-4,1],'state_ordering':'state=42*(epsilon_power+4)+original_component','denominator_coefficients':[str(D.to_dict().get((0,k),0)) for k in range(degree+1)],'denominator_degree':degree,'numerator_degree':ndegree,'entries':entries,'all_exact_fraction_reconstruction_identities_verified':True,'matching_data_sha256':hashlib.sha256(matching.read_bytes()).hexdigest(),'startup_data_sha256':hashlib.sha256(startup.read_bytes()).hexdigest(),'residue_eigenvalues':list(range(-8,0)),'generic_maximum_log_degree':8,'generic_all_orders_log_bound_proof':'Exact Q startup through powers -8..0 introduces all252freeconstants and has maximumlogdegree8. For every subsequent integern>=1, nI-R is invertible because residue roots are -8..-1. Forcing from the lower-order analytic connection preserves log degree; descending log recurrence therefore never introduces logdegree>8. This is a bound for the full generic252solution, not an asserted stronger physical-sector cancellation.','scope':'Exact recurrence inputs only; no physical boundary values or numerical PR11d capability claimed.'}
(HERE/'polynomial-normalized-connection.json').write_text(json.dumps(result,indent=2)+'\n')
print('Normalized polynomial connection exact PASS; Ddegree',degree,'Ndegree',ndegree,'entries',len(entries),'terms',sum(len(row['terms']) for row in entries),'startup sparse entries',sum(len(row['entries']) for row in seed['coefficients']))
