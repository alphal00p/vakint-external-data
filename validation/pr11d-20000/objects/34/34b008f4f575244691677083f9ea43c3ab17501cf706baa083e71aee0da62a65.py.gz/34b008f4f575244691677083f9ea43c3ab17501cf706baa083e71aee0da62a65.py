#!/usr/bin/env python3
"""Close the PR9d name binding with independent exact quadratic arithmetic."""
import hashlib
import itertools
import json
from fractions import Fraction as Q
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PINS = {}


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read(path, expected=None):
    path = Path(path).resolve()
    digest = sha(path)
    assert expected is None or digest == expected, str(path)
    PINS[str(path)] = digest
    return json.loads(path.read_text())


def determinant(matrix):
    value = Q(0)
    for permutation in itertools.permutations(range(4)):
        inversions = sum(permutation[i] > permutation[j] for i in range(4) for j in range(i+1, 4))
        term = Q((-1) ** inversions)
        for i in range(4):
            term *= matrix[i][permutation[i]]
        value += term
    return value


def transformed(matrix, U):
    return [[sum((Q(U[a][i])*matrix[a][b]*U[b][j] for a in range(4) for b in range(4)), Q(0))
             for j in range(4)] for i in range(4)]


arithmetic_path = HERE / "arithmetic-review.json"
arithmetic = read(arithmetic_path, "2cd8bcc82275188a5b221102d4f1c6cb87352c7bd3eb76ba959c7958f70ca4c5")
for path, digest in arithmetic["source_and_implementation_pins"].items():
    assert sha(path) == digest, path
    PINS[path] = digest
assert arithmetic["checker_sha256"] == sha(HERE / "check_endpoint.py")
PINS[str(HERE / "check_endpoint.py")] = sha(HERE / "check_endpoint.py")

witness_path = ROOT / "ancestor-flows/four-loop-production-A-admission-v1/endpoint-replay/canonical-routing/witness.json"
witness = read(witness_path, "9f16616a3aaed9ecc1a223b0f727e860787cd0fc383f29ed11715def80dcc662")
witness_checker = witness_path.with_name("check.py")
assert sha(witness_checker) == witness["validator_sha256"]
PINS[str(witness_checker)] = sha(witness_checker)
rejections_path = witness_path.with_name("rejections.json")
rejections = read(rejections_path, "418114d878201eaa9684f653e584a954ace62dd61b6d77d69ec5ef946148cfa5")
assert rejections["validator_sha256"] == witness["validator_sha256"]
assert rejections["all_rejected"] and len(rejections["cases"]) == 16 and all(case["rejected"] for case in rejections["cases"])
negative_checker = witness_path.with_name("test_rejections.py")
assert sha(negative_checker) == rejections["test_source_sha256"]
PINS[str(negative_checker)] = sha(negative_checker)
for path, digest in witness["source_pins"].items():
    assert sha(path) == digest, path
    PINS[path] = digest
manifest_path = Path("/shared/codex-1/vakint_rustred/vakint-external-data/4L/manifest.json")
manifest = read(manifest_path, witness["source_pins"][str(manifest_path)])
family_hash = "693719b1bc3d2f1d4d32c9312df66ced667a542591a2ada6f6498844fc5d0de1"
family = next(item for item in manifest["families"] if item["sha256"] == family_hash)
coordinates = [{"kind": "loop_loop", "left": i, "right": j} for i in range(4) for j in range(i, 4)]
assert family["coordinates"] == coordinates and family["coordinate_index_base"] == 0
assert family["loop_momenta"] == ["k1", "k2", "k3", "k4"] and family["external_momenta"] == []
assert family["power_shifts"] == ["0"]*10 and len(family["denominators"]) == 10
matrices = []
for denominator in family["denominators"]:
    assert denominator["constant"] == "-1" and len(denominator["coefficients"]) == 10
    matrix = [[Q(0) for _ in range(4)] for _ in range(4)]
    for coordinate, coefficient in zip(coordinates, denominator["coefficients"]):
        i, j = coordinate["left"], coordinate["right"]
        matrix[i][j] = matrix[j][i] = Q(coefficient) / (1 if i == j else 2)
    matrices.append(matrix)

proof = witness["proof"]
route = proof["PR9d_witness"]
U = route["loop_matrix_k_equals_U_l"]
assert len(U) == 4 and all(len(row) == 4 and all(type(x) is int for x in row) for row in U)
assert determinant(U) == 1
native_path = next(Path(path) for path in witness["source_pins"] if path.endswith("v2-proof.json"))
native = read(native_path, witness["source_pins"][str(native_path)])
canonical = next(item for item in manifest["masters"] if item["name"] == "P15" and item["family_sha256"] == family_hash)
assert canonical["exact_basis_expression"] == "vakint::{}::PR9d"
assert route["source_powers"] == native["old_basis"][89] == native["selected_old_basis"][20]
assert route["canonical_powers"] == canonical["powers"]
source, target = route["source_powers"], route["canonical_powers"]
assert len(source) == len(target) == 10 and all(type(p) is int and p >= 0 for p in source+target)
edges = route["active_slot_mapping"]
assert sorted(i for i, j, sign in edges) == [i for i, power in enumerate(source) if power]
assert sorted(j for i, j, sign in edges) == [i for i, power in enumerate(target) if power]
checks = []
for i, j, sign in edges:
    assert sign in (-1, 1) and source[i] == target[j]
    image = transformed(matrices[i], U)
    assert image == matrices[j], (i, j)
    checks.append({"source_slot": i, "canonical_slot": j, "power": source[i],
                   "exact_U_transpose_Q_U_identity": True, "equal_mass_constant": "-1"})
assert len(checks) == 7 and [edge for edge in edges if source[edge[0]] == 2] == [[3, 1, -1]]
assert canonical["graph_definition"]["numerator"] == "1"
assert canonical["graph_definition"]["overall_factor"] == "1"
assert canonical["graph_definition"]["symmetry_factor"] == "1"

canonical_checks = []
for item in arithmetic["canonical_mapping_checks"]:
    name = item["symbol"].split("::")[1]
    row = next(r for r in proof["canonical_bindings"] if r["symbol"] == item["symbol"])
    assert row["old_component"] == item["old_component"] and row["selected_component"] == item["selected_component"]
    assert row["canonical_ordered_powers"] == item["canonical_powers"]
    assert row["selected_ordered_powers"] == item["selected_powers"]
    assert item["old_to_selected_literal_unit_row"] and item["full_zero_sector_projector_replayed"]
    assert item["canonical_to_old_literal_identity"] or name == "PR9d"
    canonical_checks.append({**item, "canonical_name_edge_closed": True,
        "canonical_to_old_method": "independently replayed determinant-one quadratic routing" if name == "PR9d" else "literal same-family ordered powers"})

report = {
    "schema": "vakint.pr9.production-B.scoped-endpoint-acceptance.v1",
    "accepted": True,
    "accepted_scope": "Seven admitted endpoint operators and canonical master bindings, all42 full-ball Laurent convolutions, exact original serialization and strict stored-total-width gate, conditional on the supplied terminal boundary.",
    "endpoint_payload_sha256": arithmetic["source_and_implementation_pins"][str(ROOT / "hierarchy-transport/pr9-production-B-endpoints.json")],
    "terminal_boundary_sha256": arithmetic["terminal_boundary_sha256"],
    "arithmetic_review": str(arithmetic_path), "arithmetic_review_sha256": sha(arithmetic_path),
    "canonical_routing_witness": str(witness_path), "canonical_routing_witness_sha256": sha(witness_path),
    "canonical_routing_negative_control_receipt": str(rejections_path),
    "canonical_routing_negative_control_receipt_sha256": sha(rejections_path),
    "canonical_routing_negative_controls": {"bound_previously_executed_cases": 16, "all_recorded_rejected": True, "rerun_by_this_reviewer": False},
    "independent_routing_replay": {
        "method": "Separate standard-library Fraction matrices constructed directly from the pinned family scalar-product coefficients; determinant evaluated by all24 permutation terms; no witness checker imported.",
        "determinant": 1, "loop_matrix_k_equals_U_l": U, "quadratic_checks": checks,
        "active_mapping_bijective": True, "dotted_slot_mapping": [3, 1],
        "all_masses_and_powers_preserved": True,
        "no_numerator_or_overall_factor": True,
        "inactive_slots_do_not_enter_the_integrand": True,
        "generic_dimension_measure_factor": "|det U|^d=1; no epsilon or normalization correction."
    },
    "canonical_mapping_checks": canonical_checks,
    "all_seven_canonical_name_edges_closed": True,
    "PR9d_projection_uses_full_nontrivial_zero_sector_row": [6, 8, 9, 10, 13, 17, 18, 19, 20],
    "coefficient_count": 42,
    "all42_full_complex_ball_convolutions_contained": True,
    "original20400digit_projection_and20408digit_strings_byte_identical": True,
    "all42_strict_total_l1_radii_and_diameters_below_1e_minus20000": True,
    "maximum_total_complex_l1_radius_upper": arithmetic["maximum_total_complex_l1_radius_upper"],
    "maximum_total_complex_l1_diameter_upper": arithmetic["maximum_total_complex_l1_diameter_upper"],
    "per_coefficient_radius_bounds": [{"symbol": row["symbol"], "bounds": row["coefficient_bounds"]} for row in arithmetic["results"]],
    "source_and_implementation_pins": PINS,
    "checker_sha256": sha(__file__),
    "separate_prerequisites": ["Terminal36-step production-B chain admission by the assigned reviewer.", "Initial physical source and fresh Frobenius invocation admission by the assigned reviewer.", "The established common raw Laurent pole premise through epsilon^-4."],
    "whole_physical_source_admission": False,
    "whole_PR11d_20000_accuracy_claimed": False,
    "main_PR11d_published_precision_cap": 200,
    "production_native_HPL_reruns": 0,
    "historical_receipt_note": "The immutable arithmetic-review.json recorded PR9d routing as pending; this later receipt closes exactly that name edge with independently checked exact evidence."
}
for path, digest in PINS.items():
    assert sha(path) == digest, ("artifact changed", path)
out = HERE / "review.json"
with out.open("x") as stream:
    stream.write(json.dumps(report, indent=2) + "\n")
print(json.dumps({"accepted_scope": report["accepted_scope"], "receipt": str(out), "sha256": sha(out)}))
