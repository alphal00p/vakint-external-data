#define _POSIX_C_SOURCE 200809L
#include <flint/acb.h>
#include <flint/arb.h>
#include <flint/fmpz.h>
#include <flint/fmpz_mat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/resource.h>
#include <omp.h>

#define DEGREE_LIMIT 16
#define LOG_LIMIT 16
#define DIM_LIMIT 252

typedef struct { fmpz_t re,im; } gaussian;
typedef struct { int row,col,next; gaussian c[DEGREE_LIMIT+1]; arb_t bound; } coupling;
typedef struct { int row,col,next; fmpz_t value,scaled; } residue_entry;
typedef struct { int power,log,state,constant,next; fmpz_t num,den; } startup_entry;
typedef struct { int size,index[4]; fmpz_t adj[16],den; arb_t mu; } block;
typedef struct { slong weight; fmpz_t num,den; } gauge;
static int dim,logs,block_count,constant_count,n_min,n_max,ddegree,bdegree,K,ring_size,poly_count,residue_count,startup_count;
static int *block_of,*poly_head,*residue_head,*startup_head;
static slong precision;
static gaussian D[DEGREE_LIMIT+1],Dlog[LOG_LIMIT][DEGREE_LIMIT+1];
static coupling *B;
static residue_entry *Rlist;
static fmpz *R;
static startup_entry *seeds;
static block *blocks;
static gauge *gauges;
static fmpz_t L,LR,p_scale,q_scale;
static gaussian z0_num;
static fmpz_t z0_den;
static arb_t denominator_lower,logbounds[LOG_LIMIT];
static acb_ptr history,forcing,total;

static void die(const char *message){fprintf(stderr,"%s\n",message);exit(2);}
static double seconds(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+1e-9*t.tv_nsec;}
static void *allocate(size_t n,size_t size){void *p=calloc(n,size);if(n&&!p)die("allocation failed");return p;}
static void read_integer(FILE *f,fmpz_t out){char text[8192];if(fscanf(f,"%8191s",text)!=1||fmpz_set_str(out,text,10))die("invalid integer");}
static void gaussian_init(gaussian *a){fmpz_init(a->re);fmpz_init(a->im);}
static void gaussian_clear(gaussian *a){fmpz_clear(a->re);fmpz_clear(a->im);}
static void read_gaussian(FILE *f,gaussian *a){read_integer(f,a->re);read_integer(f,a->im);}
static int gaussian_zero(const gaussian *a){return fmpz_is_zero(a->re)&&fmpz_is_zero(a->im);}
static int slot(slong n){slong r=n%ring_size;return (int)(r<0?r+ring_size:r);}
static acb_ptr coefficient(slong n){return history+(slong)slot(n)*(dim*logs);}
static void upper(arb_t out,const arb_t value){arf_t x;arf_init(x);arb_get_ubound_arf(x,value,128);arb_set_arf(out,x);arf_clear(x);}
static void magnitude(arb_t out,const acb_t value){mag_t m;mag_init(m);acb_get_mag(m,value);arf_set_mag(arb_midref(out),m);mag_zero(arb_radref(out));mag_clear(m);}
/* result and value are distinct in every caller. */
static void addmul(acb_t result,const acb_t value,const gaussian *g,int subtract){
    if(!subtract){
        arb_addmul_fmpz(acb_realref(result),acb_realref(value),g->re,precision);
        arb_addmul_fmpz(acb_imagref(result),acb_imagref(value),g->re,precision);
        if(!fmpz_is_zero(g->im)){
            arb_submul_fmpz(acb_realref(result),acb_imagref(value),g->im,precision);
            arb_addmul_fmpz(acb_imagref(result),acb_realref(value),g->im,precision);
        }
    }else{
        arb_submul_fmpz(acb_realref(result),acb_realref(value),g->re,precision);
        arb_submul_fmpz(acb_imagref(result),acb_imagref(value),g->re,precision);
        if(!fmpz_is_zero(g->im)){
            arb_addmul_fmpz(acb_realref(result),acb_imagref(value),g->im,precision);
            arb_submul_fmpz(acb_imagref(result),acb_realref(value),g->im,precision);
        }
    }
}
static void set_z0(acb_t z){
    arb_set_fmpz(acb_realref(z),z0_num.re);arb_div_fmpz(acb_realref(z),acb_realref(z),z0_den,precision);
    arb_set_fmpz(acb_imagref(z),z0_num.im);arb_div_fmpz(acb_imagref(z),acb_imagref(z),z0_den,precision);
    if(!acb_is_finite(z)||acb_contains_zero(z))die("invalid or unresolved z0");
}
static void verify_residue(const int *entry_map){
    if(!fmpz_equal(D[0].re,L)||!fmpz_is_zero(D[0].im))die("normalized d0 must equal one exactly");
    fmpz_t left,right;fmpz_init(left);fmpz_init(right);
    for(int row=0;row<dim;row++)for(int col=0;col<dim;col++){
        int e=entry_map[row*dim+col];
        fmpz_mul(right,L,R+row*dim+col);
        if(e<0){if(!fmpz_is_zero(right))die("residue absent from polynomial matrix");}
        else{
            fmpz_mul(left,LR,B[e].c[0].re);
            if(!fmpz_equal(left,right)||!fmpz_is_zero(B[e].c[0].im))die("B0/L differs from exact residue");
        }
    }
    fmpz_clear(left);fmpz_clear(right);
    fprintf(stderr,"exact normalized d0 and residue identities verified\n");
}
static void build_bounds(void){
    fmpz_t re,im,tmp,absolute;fmpz_init(re);fmpz_init(im);fmpz_init(tmp);fmpz_init(absolute);
    arb_t sum,value,den,row_sum,euler;arb_init(sum);arb_init(value);arb_init(den);arb_init(row_sum);arb_init(euler);
    arb_mul_fmpz(den,denominator_lower,LR,128);
    for(int e=0;e<poly_count;e++){
        arb_zero(sum);fmpz *r=R+B[e].row*dim+B[e].col;
        for(int k=1;k<=K;k++){
            fmpz_mul(re,LR,B[e].c[k].re);fmpz_mul(tmp,r,D[k].re);fmpz_sub(re,re,tmp);
            fmpz_mul(im,LR,B[e].c[k].im);fmpz_mul(tmp,r,D[k].im);fmpz_sub(im,im,tmp);
            fmpz_abs(absolute,re);arb_set_fmpz(value,absolute);arb_add(sum,sum,value,128);
            fmpz_abs(absolute,im);arb_set_fmpz(value,absolute);arb_add(sum,sum,value,128);
        }
        arb_div(sum,sum,den,128);
        fmpz_abs(absolute,r);arb_set_fmpz(value,absolute);arb_div_fmpz(value,value,LR,128);arb_add(sum,sum,value,128);
        upper(B[e].bound,sum);
    }
    for(int b=0;b<block_count;b++){
        arb_zero(blocks[b].mu);
        for(int j=0;j<blocks[b].size;j++){
            int row=blocks[b].index[j];arb_zero(row_sum);
            for(int e=poly_head[row];e>=0;e=B[e].next)if(block_of[B[e].col]==b)arb_add(row_sum,row_sum,B[e].bound,128);
            upper(value,row_sum);arb_max(blocks[b].mu,blocks[b].mu,value,128);
        }
    }
    arb_one(logbounds[0]);arb_one(euler);arb_exp(euler,euler,128);
    for(int ell=1;ell<logs;ell++){
        arb_set_ui(value,ell);arb_div(value,value,euler,128);arb_pow_ui(value,value,ell,128);upper(logbounds[ell],value);
    }
    arb_clear(sum);arb_clear(value);arb_clear(den);arb_clear(row_sum);arb_clear(euler);
    fmpz_clear(re);fmpz_clear(im);fmpz_clear(tmp);fmpz_clear(absolute);
}
static void initialize(acb_srcptr constants){
    slong states=(slong)dim*logs;
    acb_ptr stage=_acb_vec_init(states),translated=_acb_vec_init(states),logpowers=_acb_vec_init(logs);
    acb_t z,logz,factor,scale,term;acb_init(z);acb_init(logz);acb_init(factor);acb_init(scale);acb_init(term);
    set_z0(z);acb_log(logz,z,precision);if(!acb_is_finite(logz))die("principal log z0 is unresolved");
    acb_one(logpowers);for(int ell=1;ell<logs;ell++)acb_mul(logpowers+ell,logpowers+ell-1,logz,precision);
    for(int n=n_min;n<=n_max;n++){
        _acb_vec_zero(stage,states);_acb_vec_zero(translated,states);
        for(int e=startup_head[n-n_min];e>=0;e=seeds[e].next){
            acb_mul_fmpz(term,constants+seeds[e].constant,seeds[e].num,precision);acb_div_fmpz(term,term,seeds[e].den,precision);
            acb_add(stage+seeds[e].log*dim+seeds[e].state,stage+seeds[e].log*dim+seeds[e].state,term,precision);
        }
        acb_pow_si(factor,z,n,precision);
        for(int ell=0;ell<logs;ell++){
            ulong binomial=1;
            for(int k=0;k<=ell;k++){
                acb_mul(scale,factor,logpowers+ell-k,precision);acb_mul_ui(scale,scale,binomial,precision);
                for(int i=0;i<dim;i++)if(!acb_is_zero(stage+ell*dim+i))acb_addmul(translated+k*dim+i,stage+ell*dim+i,scale,precision);
                if(k<ell)binomial=binomial*(ell-k)/(k+1);
            }
        }
        _acb_vec_set(coefficient(n),translated,states);
        for(int i=0;i<dim;i++)acb_add(total+i,total+i,translated+i,precision);
    }
    for(int i=0;i<dim;i++)if(!acb_is_finite(total+i))die("nonfinite startup contraction");
    _acb_vec_clear(stage,states);_acb_vec_clear(translated,states);_acb_vec_clear(logpowers,logs);
    acb_clear(z);acb_clear(logz);acb_clear(factor);acb_clear(scale);acb_clear(term);
}
static void make_adjugates(slong n){
    fmpz_t A[16],tmp,scaled_n;for(int k=0;k<16;k++)fmpz_init(A[k]);fmpz_init(tmp);fmpz_init(scaled_n);
    fmpz_mat_t matrix4,numerator4,check4;fmpz_mat_init(matrix4,4,4);fmpz_mat_init(numerator4,4,4);fmpz_mat_init(check4,4,4);
    fmpz_mul_si(scaled_n,LR,n);
    for(int b=0;b<block_count;b++){
        block *bb=blocks+b;int size=bb->size;
        for(int i=0;i<size;i++)for(int j=0;j<size;j++){
            fmpz_neg(A[4*i+j],R+bb->index[i]*dim+bb->index[j]);
            if(i==j)fmpz_add(A[4*i+j],A[4*i+j],scaled_n);
        }
        for(int k=0;k<16;k++)fmpz_zero(bb->adj[k]);
        if(size==4){
            /* FLINT returns an exact integer inverse numerator and denominator;
             * they need not be the classical adjugate and determinant. Verify
             * A*num=den*I explicitly before the extra q_scale is applied. */
            for(int i=0;i<4;i++)for(int j=0;j<4;j++)fmpz_set(fmpz_mat_entry(matrix4,i,j),A[4*i+j]);
            if(!fmpz_mat_inv(numerator4,bb->den,matrix4)||fmpz_is_zero(bb->den))die("zero residue-block determinant: startup must include this resonance");
            fmpz_mat_mul(check4,matrix4,numerator4);
            for(int i=0;i<4;i++)for(int j=0;j<4;j++){
                if(i==j){if(!fmpz_equal(fmpz_mat_entry(check4,i,j),bb->den))die("exact four-state inverse identity failed");}
                else if(!fmpz_is_zero(fmpz_mat_entry(check4,i,j)))die("exact four-state inverse identity failed");
                fmpz_set(bb->adj[4*i+j],fmpz_mat_entry(numerator4,i,j));
            }
        }else{
            if(size==1)fmpz_one(bb->adj[0]);
            else if(size==2){
                fmpz_set(bb->adj[0],A[5]);fmpz_neg(bb->adj[1],A[1]);fmpz_neg(bb->adj[4],A[4]);fmpz_set(bb->adj[5],A[0]);
            }else{
                for(int i=0;i<3;i++)for(int j=0;j<3;j++){
                    int rr[2],cc[2],nr=0,nc=0;
                    for(int r=0;r<3;r++)if(r!=j)rr[nr++]=r;
                    for(int c=0;c<3;c++)if(c!=i)cc[nc++]=c;
                    fmpz_mul(bb->adj[4*i+j],A[4*rr[0]+cc[0]],A[4*rr[1]+cc[1]]);
                    fmpz_mul(tmp,A[4*rr[0]+cc[1]],A[4*rr[1]+cc[0]]);fmpz_sub(bb->adj[4*i+j],bb->adj[4*i+j],tmp);
                    if((i+j)%2)fmpz_neg(bb->adj[4*i+j],bb->adj[4*i+j]);
                }
            }
            fmpz_zero(bb->den);
            for(int j=0;j<size;j++)fmpz_addmul(bb->den,A[j],bb->adj[4*j]);
            if(fmpz_is_zero(bb->den))die("zero residue-block determinant: startup must include this resonance");
        }
        fmpz_mul(bb->den,bb->den,q_scale);
    }
    for(int k=0;k<16;k++)fmpz_clear(A[k]);
    fmpz_clear(tmp);fmpz_clear(scaled_n);fmpz_mat_clear(matrix4);fmpz_mat_clear(numerator4);fmpz_mat_clear(check4);
}
static void next_coefficient(slong n){
    slong states=(slong)dim*logs;
    gaussian derivative[DEGREE_LIMIT+1];
    for(int k=1;k<=ddegree;k++){
        gaussian_init(derivative+k);fmpz_mul_si(derivative[k].re,D[k].re,n-k);fmpz_mul_si(derivative[k].im,D[k].im,n-k);
    }
    #pragma omp parallel for schedule(dynamic,8)
    for(slong index=0;index<states;index++){
        int ell=(int)(index/dim),row=(int)(index%dim);acb_zero(forcing+index);
        for(int e=poly_head[row];e>=0;e=B[e].next)for(int k=1;k<=bdegree;k++){
            slong prior=n-k;if(prior<n_min||gaussian_zero(B[e].c+k))continue;
            addmul(forcing+index,coefficient(prior)+ell*dim+B[e].col,B[e].c+k,0);
        }
        for(int k=1;k<=ddegree;k++){
            slong prior=n-k;if(prior<n_min)continue;
            addmul(forcing+index,coefficient(prior)+index,derivative+k,1);
            if(ell+1<logs)addmul(forcing+index,coefficient(prior)+(ell+1)*dim+row,&Dlog[ell][k],1);
        }
    }
    for(int k=1;k<=ddegree;k++)gaussian_clear(derivative+k);
    /* All history reads have completed before its oldest slot is replaced. */
    make_adjugates(n);acb_ptr result=coefficient(n);_acb_vec_zero(result,states);
    acb_t rhs[4],solved[4];for(int i=0;i<4;i++){acb_init(rhs[i]);acb_init(solved[i]);}
    fmpz_t log_factor;fmpz_init(log_factor);
    for(int ell=logs-1;ell>=0;ell--){
        fmpz_mul(log_factor,q_scale,LR);fmpz_mul_ui(log_factor,log_factor,ell+1);
        for(int b=0;b<block_count;b++){
            block *bb=blocks+b;
            for(int i=0;i<bb->size;i++){
                int row=bb->index[i];acb_mul_fmpz(rhs[i],forcing+ell*dim+row,p_scale,precision);
                if(ell+1<logs)acb_submul_fmpz(rhs[i],result+(ell+1)*dim+row,log_factor,precision);
                for(int e=residue_head[row];e>=0;e=Rlist[e].next)if(block_of[Rlist[e].col]<b)
                    acb_addmul_fmpz(rhs[i],result+ell*dim+Rlist[e].col,Rlist[e].scaled,precision);
            }
            for(int i=0;i<bb->size;i++){
                acb_zero(solved[i]);for(int j=0;j<bb->size;j++)acb_addmul_fmpz(solved[i],rhs[j],bb->adj[4*i+j],precision);
                acb_div_fmpz(solved[i],solved[i],bb->den,precision);
                if(!acb_is_finite(solved[i]))die("nonfinite Frobenius coefficient");
            }
            for(int i=0;i<bb->size;i++)acb_set(result+ell*dim+bb->index[i],solved[i]);
        }
    }
    fmpz_clear(log_factor);for(int i=0;i<4;i++){acb_clear(rhs[i]);acb_clear(solved[i]);}
    for(int i=0;i<dim;i++)acb_add(total+i,total+i,result+i,precision);
}
static int certify(slong m,arb_ptr budgets,arb_t maximum){
    slong states=(slong)dim*logs;
    arb_ptr F=_arb_vec_init(dim);
    arb_t mag,value,need,den;arb_init(mag);arb_init(value);arb_init(need);arb_init(den);
    gaussian derivative;gaussian_init(&derivative);
    for(slong power=m+1;power<=m+K;power++){
        _acb_vec_zero(forcing,states);
        for(int k=0;k<=ddegree;k++){
            slong n=power-k;if(n<n_min||n>m)continue;
            fmpz_mul_si(derivative.re,D[k].re,n);fmpz_mul_si(derivative.im,D[k].im,n);acb_ptr prior=coefficient(n);
            for(int ell=0;ell<logs;ell++)for(int i=0;i<dim;i++){
                addmul(forcing+ell*dim+i,prior+ell*dim+i,&derivative,0);
                if(ell+1<logs)addmul(forcing+ell*dim+i,prior+(ell+1)*dim+i,&Dlog[ell][k],0);
            }
        }
        for(int e=0;e<poly_count;e++)for(int k=0;k<=bdegree;k++){
            slong n=power-k;if(n<n_min||n>m||gaussian_zero(B[e].c+k))continue;acb_ptr prior=coefficient(n);
            for(int ell=0;ell<logs;ell++)addmul(forcing+ell*dim+B[e].row,prior+ell*dim+B[e].col,B[e].c+k,1);
        }
        for(int ell=0;ell<logs;ell++)for(int i=0;i<dim;i++){
            magnitude(mag,forcing+ell*dim+i);arb_mul(value,mag,logbounds[ell],128);arb_add(F+i,F+i,value,128);
        }
    }
    for(int i=0;i<dim;i++){arb_div(value,F+i,denominator_lower,128);upper(F+i,value);}
    _arb_vec_zero(budgets,block_count);arb_zero(maximum);int valid=1;
    for(int b=0;b<block_count;b++){
        arb_set_si(den,m);arb_sub(den,den,blocks[b].mu,128);
        if(!arb_is_positive(den)){valid=0;break;}
        arb_zero(need);
        for(int i=0;i<blocks[b].size;i++){
            int row=blocks[b].index[i];arb_set(value,F+row);
            for(int e=poly_head[row];e>=0;e=B[e].next)if(block_of[B[e].col]<b)
                arb_addmul(value,B[e].bound,budgets+block_of[B[e].col],128);
            upper(mag,value);arb_max(need,need,mag,128);
        }
        arb_div(value,need,den,128);upper(budgets+b,value);arb_max(maximum,maximum,budgets+b,128);
    }
    _arb_vec_clear(F,dim);arb_clear(mag);arb_clear(value);arb_clear(need);arb_clear(den);gaussian_clear(&derivative);return valid;
}
static acb_ptr read_input(FILE *input,int *digits,int *max_order,int *check_every){
    char marker[16];long bits;
    if(fscanf(input,"%15s %d %d %d %d %d %d %d %d %d %d %d %ld %d %d %d",marker,&dim,&logs,&block_count,&constant_count,&n_min,&n_max,&ddegree,&bdegree,&poly_count,&residue_count,&startup_count,&bits,digits,max_order,check_every)!=16||strcmp(marker,"FROB_V1"))die("invalid FROB_V1 header");
    if(dim<1||dim>DIM_LIMIT||logs<1||logs>LOG_LIMIT||block_count<1||block_count>dim||constant_count<1||constant_count>dim||n_min< -32||n_min>0||n_max<n_min||n_max>32||ddegree<0||ddegree>DEGREE_LIMIT||bdegree<0||bdegree>DEGREE_LIMIT||poly_count<0||poly_count>dim*dim||residue_count<0||residue_count>dim*dim||startup_count<0||startup_count>5000000||bits<64||bits>1000000||*digits<1||*digits>300000||*max_order<=n_max||*max_order<1||*max_order>1000000||*check_every<1)die("unsupported Frobenius input shape");
    precision=bits;K=ddegree>bdegree?ddegree:bdegree;ring_size=K+1;
    gaussian_init(&z0_num);fmpz_init(z0_den);read_gaussian(input,&z0_num);read_integer(input,z0_den);
    if(fmpz_sgn(z0_den)<=0||gaussian_zero(&z0_num))die("invalid z0 rational");
    fmpz_init(L);fmpz_init(LR);fmpz_init(p_scale);fmpz_init(q_scale);read_integer(input,L);if(fmpz_sgn(L)<=0)die("invalid polynomial scale");
    char *line=NULL;size_t capacity=0;
    if(getline(&line,&capacity,input)<0||getline(&line,&capacity,input)<0)die("missing denominator lower bound");
    arb_init(denominator_lower);if(arb_set_str(denominator_lower,line,128)||!arb_is_positive(denominator_lower))die("invalid denominator lower bound");
    block_of=allocate(dim,sizeof(int));blocks=allocate(block_count,sizeof(block));
    for(int b=0;b<block_count;b++){for(int j=0;j<16;j++)fmpz_init(blocks[b].adj[j]);fmpz_init(blocks[b].den);arb_init(blocks[b].mu);}
    for(int i=0;i<dim;i++){
        if(fscanf(input,"%d",block_of+i)!=1||block_of[i]<0||block_of[i]>=block_count)die("invalid block index");
        block *bb=blocks+block_of[i];if(bb->size>=4)die("diagonal block exceeds four states");bb->index[bb->size++]=i;
    }
    for(int b=0;b<block_count;b++)if(!blocks[b].size)die("empty block");
    for(int k=0;k<=DEGREE_LIMIT;k++){gaussian_init(D+k);if(k<=ddegree)read_gaussian(input,D+k);}
    poly_head=allocate(dim,sizeof(int));residue_head=allocate(dim,sizeof(int));int *poly_tail=allocate(dim,sizeof(int)),*residue_tail=allocate(dim,sizeof(int));
    int *entry_map=allocate((size_t)dim*dim,sizeof(int)),*residue_seen=allocate((size_t)dim*dim,sizeof(int));
    for(int i=0;i<dim;i++){poly_head[i]=-1;residue_head[i]=-1;poly_tail[i]=-1;residue_tail[i]=-1;}
    for(int i=0;i<dim*dim;i++)entry_map[i]=-1;
    B=allocate(poly_count,sizeof(coupling));
    for(int e=0;e<poly_count;e++){
        coupling *b=B+e;
        if(fscanf(input,"%d %d",&b->row,&b->col)!=2||b->row<0||b->row>=dim||b->col<0||b->col>=dim||block_of[b->col]>block_of[b->row])die("invalid or nontriangular polynomial entry");
        if(entry_map[b->row*dim+b->col]>=0)die("duplicate polynomial entry");
        entry_map[b->row*dim+b->col]=e;
        for(int k=0;k<=DEGREE_LIMIT;k++){gaussian_init(b->c+k);if(k<=bdegree)read_gaussian(input,b->c+k);}
        arb_init(b->bound);b->next=-1;
        if(poly_tail[b->row]<0)poly_head[b->row]=e;else B[poly_tail[b->row]].next=e;poly_tail[b->row]=e;
    }
    read_integer(input,LR);if(fmpz_sgn(LR)<=0)die("invalid residue scale");
    R=allocate((size_t)dim*dim,sizeof(fmpz));for(int i=0;i<dim*dim;i++)fmpz_init(R+i);
    Rlist=allocate(residue_count,sizeof(residue_entry));
    for(int e=0;e<residue_count;e++){
        residue_entry *r=Rlist+e;
        if(fscanf(input,"%d %d",&r->row,&r->col)!=2||r->row<0||r->row>=dim||r->col<0||r->col>=dim||block_of[r->col]>block_of[r->row])die("invalid or nontriangular residue entry");
        int key=r->row*dim+r->col;if(residue_seen[key])die("duplicate residue entry");residue_seen[key]=1;
        fmpz_init(r->value);fmpz_init(r->scaled);read_integer(input,r->value);fmpz_set(R+key,r->value);r->next=-1;
        if(residue_tail[r->row]<0)residue_head[r->row]=e;else Rlist[residue_tail[r->row]].next=e;residue_tail[r->row]=e;
    }
    verify_residue(entry_map);free(entry_map);free(residue_seen);free(poly_tail);free(residue_tail);
    fmpz_t gcd;fmpz_init(gcd);fmpz_gcd(gcd,L,LR);fmpz_divexact(p_scale,LR,gcd);fmpz_divexact(q_scale,L,gcd);fmpz_clear(gcd);
    for(int e=0;e<residue_count;e++)fmpz_mul(Rlist[e].scaled,Rlist[e].value,q_scale);
    startup_head=allocate(n_max-n_min+1,sizeof(int));for(int n=n_min;n<=n_max;n++)startup_head[n-n_min]=-1;
    seeds=allocate(startup_count,sizeof(startup_entry));
    for(int e=0;e<startup_count;e++){
        startup_entry *s=seeds+e;
        if(fscanf(input,"%d %d %d %d",&s->power,&s->log,&s->state,&s->constant)!=4||s->power<n_min||s->power>n_max||s->log<0||s->log>=logs||s->state<0||s->state>=dim||s->constant<0||s->constant>=constant_count)die("invalid startup map entry");
        fmpz_init(s->num);fmpz_init(s->den);read_integer(input,s->num);read_integer(input,s->den);if(fmpz_sgn(s->den)<=0)die("invalid startup rational denominator");
        s->next=startup_head[s->power-n_min];startup_head[s->power-n_min]=e;
    }
    gauges=allocate(dim,sizeof(gauge));
    for(int i=0;i<dim;i++){
        long weight;if(fscanf(input,"%ld",&weight)!=1)die("missing gauge weight");gauges[i].weight=weight;
        fmpz_init(gauges[i].num);fmpz_init(gauges[i].den);read_integer(input,gauges[i].num);read_integer(input,gauges[i].den);
        if(fmpz_sgn(gauges[i].den)<=0)die("invalid gauge denominator");
    }
    if(getline(&line,&capacity,input)<0)die("missing constant line separator");
    acb_ptr constants=_acb_vec_init(constant_count);
    for(int i=0;i<constant_count;i++){
        if(getline(&line,&capacity,input)<0)die("missing constant ball");
        char *bar=strchr(line,'|');if(!bar)die("constant ball separator missing");*bar=0;
        if(arb_set_str(acb_realref(constants+i),line,precision)||arb_set_str(acb_imagref(constants+i),bar+1,precision)||!acb_is_finite(constants+i))die("invalid constant ball");
    }
    char extra[2];if(fscanf(input,"%1s",extra)==1)die("unexpected trailing input");free(line);
    for(int ell=0;ell<logs;ell++){
        arb_init(logbounds[ell]);
        for(int k=0;k<=DEGREE_LIMIT;k++){
            gaussian_init(&Dlog[ell][k]);fmpz_mul_ui(Dlog[ell][k].re,D[k].re,ell+1);fmpz_mul_ui(Dlog[ell][k].im,D[k].im,ell+1);
        }
    }
    build_bounds();return constants;
}
static void emit_array(FILE *out,acb_srcptr values,int count,int digits){
    fprintf(out,"[");for(int i=0;i<count;i++){
        char *re=arb_get_str(acb_realref(values+i),digits+40,0),*im=arb_get_str(acb_imagref(values+i),digits+40,0);
        fprintf(out,"%s[\"%s\",\"%s\"]",i?",":"",re,im);flint_free(re);flint_free(im);
    }fprintf(out,"]");
}
int main(int argc,char **argv){
    if(argc!=3)die("usage: contracted-native-v2 INPUT OUTPUT_JSON; set OPENBLAS_NUM_THREADS=1");
    struct rlimit memory={2ULL<<30,2ULL<<30};if(setrlimit(RLIMIT_AS,&memory))die("cannot set address-space cap");
    omp_set_dynamic(0);if(omp_get_max_threads()>4)omp_set_num_threads(4);
    double started=seconds();FILE *input=fopen(argv[1],"r");if(!input)die("cannot read input");
    int digits,max_order,check_every;acb_ptr constants=read_input(input,&digits,&max_order,&check_every);fclose(input);
    slong states=(slong)dim*logs;
    history=_acb_vec_init((slong)ring_size*states);forcing=_acb_vec_init(states);total=_acb_vec_init(dim);
    double tick=seconds();initialize(constants);double initialization_seconds=seconds()-tick;_acb_vec_clear(constants,constant_count);
    for(int e=0;e<startup_count;e++){fmpz_clear(seeds[e].num);fmpz_clear(seeds[e].den);}free(seeds);free(startup_head);
    double setup_seconds=seconds()-started,certificate_seconds=0;
    arb_ptr budgets=_arb_vec_init(block_count);arb_t maximum,target;arb_init(maximum);arb_init(target);
    arb_set_ui(target,10);arb_pow_ui(target,target,digits,128);arb_inv(target,target,128);arb_div_ui(target,target,100,128);
    int accepted=0;slong order=n_max;
    for(slong n=n_max+1;n<=max_order;n++){
        next_coefficient(n);order=n;
        if(n>0&&(n%check_every==0||n==max_order)){
            tick=seconds();int valid=certify(n,budgets,maximum);certificate_seconds+=seconds()-tick;
            char *error=arb_get_str(maximum,10,0);fprintf(stderr,"order %ld seconds %.3f tail %s valid %d\n",(long)n,seconds()-started,error,valid);flint_free(error);
            if(valid&&arb_lt(maximum,target)){accepted=1;break;}
        }
    }
    if(accepted)for(int i=0;i<dim;i++)acb_add_error_arb(total+i,budgets+block_of[i]);
    acb_ptr original=_acb_vec_init(dim);acb_t z,factor;acb_init(z);acb_init(factor);set_z0(z);
    for(int i=0;i<dim;i++){
        acb_pow_si(factor,z,gauges[i].weight,precision);acb_mul(original+i,total+i,factor,precision);
        acb_mul_fmpz(original+i,original+i,gauges[i].num,precision);acb_div_fmpz(original+i,original+i,gauges[i].den,precision);
        if(!acb_is_finite(original+i))die("nonfinite restored gauge value");
    }
    slong accuracy=WORD_MAX;for(int i=0;i<dim;i++)if(!acb_is_zero(total+i)){slong a=acb_rel_accuracy_bits(total+i);if(a<accuracy)accuracy=a;}
    struct rusage usage;getrusage(RUSAGE_SELF,&usage);FILE *output=fopen(argv[2],"w");if(!output)die("cannot open output");
    char *error=arb_get_str(maximum,25,0);
    fprintf(output,"{\"schema\":\"vakint.pr11d.native-contracted-frobenius-pilot.v2\",\"local_tail_certified\":%s,\"physical_PR11d_claimed\":false,\"synthetic_constants\":\"not inferred; see prepared input metadata\",\"selected_solution_family\":\"prepared exact startup maps; no generic fractional mode is implicitly discarded\",\"dimension\":%d,\"constant_count\":%d,\"maximum_log_degree\":%d,\"startup_power_range\":[%d,%d],\"order\":%ld,\"working_bits\":%ld,\"digits\":%d,\"target_absolute_digits\":%d,\"seconds\":%.9f,\"setup_seconds\":%.9f,\"initialization_seconds\":%.9f,\"certificate_seconds\":%.9f,\"peak_rss_bytes\":%ld,\"minimum_relative_accuracy_bits\":%ld,\"tail_upper_enclosure\":\"%s\",\"exact_residue_identity_verified\":true,\"normalized_J_values\":",accepted?"true":"false",dim,constant_count,logs-1,n_min,n_max,(long)order,(long)precision,digits,digits,seconds()-started,setup_seconds,initialization_seconds,certificate_seconds,usage.ru_maxrss*1024L,(long)accuracy,error);flint_free(error);
    emit_array(output,total,dim,digits);fprintf(output,",\"original_Y_values\":");emit_array(output,original,dim,digits);fprintf(output,"}\n");fclose(output);return accepted?0:1;
}
