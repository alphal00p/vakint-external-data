#!/usr/bin/env python3
"""Independent bounded comparison of physical 4L PR4/PR4d flow and Bessel data."""
import argparse,ast,json
from pathlib import Path
from flint import arb,ctx
from endpoint_sources import load_native_endpoints,sha
from compare_endpoint_api import fmft_values
HERE=Path(__file__).resolve().parent
BASE=HERE.parent

def elementary(text):
    tree=ast.parse(text.replace('𝜋','Pi').replace('symbolica::zeta','zeta').replace('^','**'),mode='eval')
    def walk(n):
        if isinstance(n,ast.Constant) and type(n.value) is int:return arb(n.value)
        if isinstance(n,ast.Name) and n.id=='Pi':return arb.pi()
        if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):return -walk(n.operand)
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='zeta' and len(n.args)==1 and not n.keywords:
            k=n.args[0]
            if not isinstance(k,ast.Constant) or type(k.value) is not int or k.value<2:raise ValueError('An explicit integer zeta argument is required')
            return arb(k.value).zeta()
        if isinstance(n,ast.BinOp):
            a,b=walk(n.left),walk(n.right)
            if isinstance(n.op,ast.Add):return a+b
            if isinstance(n.op,ast.Sub):return a-b
            if isinstance(n.op,ast.Mult):return a*b
            if isinstance(n.op,ast.Div):return a/b
            if isinstance(n.op,ast.Pow):
                if not isinstance(n.right,ast.Constant) or type(n.right.value) is not int:raise ValueError('An explicit integer power is required')
                return a**n.right.value
        raise ValueError('Unsupported exact reference formula: '+ast.dump(n))
    return walk(tree.body)

def reference():
    payload=BASE/'high-guard/constants20200.json';receipt=BASE/'high-guard/validation.json'
    if sha(payload)!='bc9afa66faaaf01afef7ee4e90c2cc1a13691aa4cc8d674e3f39ce688c9afa31' or sha(receipt)!='1f641d1ddca038481e44cb4ce2d7bcc5d765faac4c5a765ea3a8dfc456d6bca4':
        raise ValueError('The independently accepted high-guard Bessel source changed')
    records=json.loads(payload.read_text());values={}
    for row in records['constants']:
        if row['significant_digits']!=20200 or row['normalization']!='FMFTandMATAD':raise ValueError('Unexpected Bessel source convention')
        c=arb(row['numerical_value']);e=arb(row['validation']['absolute_error_bound'])
        values[row['symbol']]=c+arb(0,e.upper())
    out={}
    for name,filename,finite,jet in [('PR4','P6','PR4fin','PR4ep1'),('PR4d','P11','PR4dfin','PR4dep1')]:
        path=BASE/f'upstream-moment-bindings/inputs/{filename}-symbolic-upstream277e876.json';symbolic=dict(json.loads(path.read_text()))
        refs={p:elementary(symbolic[p]) for p in range(-4,0)}
        refs[0]=values['vakint::'+finite];refs[1]=values['vakint::'+jet];out['native::'+name]=refs
    return out,{'Bessel_payload_sha256':sha(payload),'Bessel_acceptance_sha256':sha(receipt),
      'pole_formula_input_sha256':{name:sha(BASE/f'upstream-moment-bindings/inputs/{name}-symbolic-upstream277e876.json') for name in ['P6','P11']},
      'definition':'Independent Bessel-moment integration plus exact dimensional-shift reconstruction; no master alias inversion'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--endpoints',required=True);ap.add_argument('--endpoints-sha256',required=True)
    ap.add_argument('--working-digits',type=int,default=20400);ap.add_argument('--minimum-agreement-digits',type=int,default=20000);ap.add_argument('--output',required=True);args=ap.parse_args()
    output=Path(args.output)
    if output.exists():raise ValueError('Preserve prior independent comparisons; choose a new output path')
    if args.minimum_agreement_digits<1 or args.working_digits<args.minimum_agreement_digits+40:raise ValueError('A fixed comparison guard is required')
    ctx.dps=args.working_digits;ctx.threads=1
    jets,source=load_native_endpoints(args.endpoints,args.endpoints_sha256,{'native::PR4':(-4,1),'native::PR4d':(-4,1)})
    refs,ref_receipt=reference();checks=[];threshold=(arb(10)**-args.minimum_agreement_digits).lower()
    for symbol,jet in jets.items():
        values=fmft_values(jet,4)
        for p,x in values.items():
            y=refs[symbol][p]
            if not x.overlaps(y):raise ValueError(f'Independent flow/Bessel disagreement for {symbol} epsilon^{p}: '+(x-y).str(40))
            difference=abs(x-y).upper()
            if x.contains(0) or y.contains(0):
                if difference.upper()>=threshold:raise ValueError('Insufficient absolute accuracy in exact-zero reference comparison')
                capability={'absolute_accuracy_digits_lower_bound':args.minimum_agreement_digits}
            else:
                relative=difference/min(abs(x).lower(),abs(y).lower())
                if relative.upper()>=threshold:raise ValueError(f'Insufficient independent flow/Bessel precision for {symbol} epsilon^{p}')
                capability={'relative_accuracy_digits_lower_bound':int((-relative.log()/arb(10).log()).lower().floor().fmpz())}
            checks.append({'symbol':symbol,'epsilon_power':p,'bounded_balls_overlap':True,**capability})
    receipt={'schema':'vakint.four-loop-flow-independent-Bessel-comparison.v1','accepted':True,'source':source,'independent_reference':ref_receipt,
      'conversion':'native_raw to FMFTandMATAD with exp(4EulerGamma*epsilon) exactly once','required_comparison_digits':args.minimum_agreement_digits,
      'checks':checks,'working_decimal_digits':args.working_digits,'validator_sha256':sha(Path(__file__)),'whole_PR11d_accuracy_claimed':False}
    output.write_text(json.dumps(receipt,indent=2)+'\n');print('PASS:12independent bounded PR4/PR4d flow/Bessel comparisons')
if __name__=='__main__':main()
