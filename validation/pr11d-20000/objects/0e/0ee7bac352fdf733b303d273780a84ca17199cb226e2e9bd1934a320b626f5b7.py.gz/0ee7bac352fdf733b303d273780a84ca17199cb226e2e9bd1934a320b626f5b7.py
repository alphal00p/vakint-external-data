#!/usr/bin/env python3
"""Audit stored native inputs and a small independently solved rational IVP."""
from pathlib import Path
import hashlib,json,math,subprocess,time
from flint import fmpq,fmpq_mat,arb,ctx
from independent_checks import parsed,U
from flint import fmpq_poly

BASE=Path(__file__).resolve().parents[1];OUT=BASE/'endpoint-review/native';OUT.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def check_saved(path):
    d=json.loads(path.read_text());name=d['name'];cp=BASE/f'{name}-ordinary-polynomial.json';pp=BASE/f'{name}-endpoint-adjoints.json';bp=BASE/f'{name}-blocks.json'
    con=json.loads(cp.read_text());proof=json.loads(pp.read_text());blocks=json.loads(bp.read_text())['ordered_blocks']
    assert d['source_polynomial_sha256']==sha(cp) and d['endpoint_projector_proof_sha256']==sha(pp)
    assert d['native_source_sha256']==sha(BASE/'endpoint_native.c') and d['native_binary_sha256']==sha(BASE/'endpoint-native')
    inp=Path(d['native_input']);rawp=Path(d['native_output']);assert sha(inp)==d['native_input_metadata']['input_sha256'] and sha(rawp)==d['native_output_sha256']
    tokens=iter(inp.read_text().split());head=[int(next(tokens)) for _ in range(9)]
    dim,nb,degree,nd,count,order,bits,printdigits,rlog=head;base=con['dimension'];assert dim==6*base==d['dimension'] and order==d['order'] and bits==d['working_bits']
    bs=[tuple(base*k+i for i in b) for k in range(6) for b in reversed(blocks)];bi={i:k for k,b in enumerate(bs) for i in b}
    assert nb==len(bs) and [int(next(tokens)) for i in range(dim)]==[bi[i] for i in range(dim)]
    scale=fmpq(d['native_input_metadata']['exact_rational_integer_scale']);D=[fmpq(x) for x in con['denominator_coefficients']]
    assert degree==len(D)-1 and nd==con['numerator_degree']
    assert [fmpq(next(tokens)) for k in range(degree+1)]==[scale*x for x in D]
    got={}
    for _ in range(count):
        key=tuple(int(next(tokens)) for j in range(3));assert key not in got;got[key]=fmpq(next(tokens))
    expected={}
    for en in con['entries']:
        for k in range(en['epsilon_power'],6):
            i=base*k+en['column'];j=base*(k-en['epsilon_power'])+en['row']
            for t in en['terms']:
                key=(t['eta_power'],i,j);expected[key]=expected.get(key,fmpq(0))-scale*fmpq(int(t['numerator']),int(t['denominator']))
    expected={k:v for k,v in expected.items() if v};assert got==expected
    row=next(r for r in proof['records'] if r['symbol']==d['symbol'])['row_coefficients'][0]
    jets=[parsed(s,{'constant':U,'e':U(fmpq_poly([0,1]))}).jet() for s in row]
    assert [fmpq(next(tokens)) for i in range(dim)]==[jets[i][k] for k in range(6) for i in range(base)]
    assert list(tokens)==[]
    raw=json.loads(rawp.read_text());assert raw['order']==order and raw['dimension']==dim and raw['working_bits']==bits and raw['radius_power_of_two']==rlog
    width=max(degree,nd)+2;indices=[r['eta_power'] for r in raw['last_coefficients']]
    assert indices==list(range(max(0,order-width+1),order+1))
    assert all(len(r['values'])==dim for r in raw['last_coefficients']) and len(raw['polynomial_values'])==dim and len(d['complex_balls'])==dim
    required={n-p for n in range(order+1,order+max(nd,degree-1)+1) for p in range(nd+1) if 0<=n-p<=order}
    required|={n-p+1 for n in range(order+1,order+max(nd,degree-1)+1) for p in range(1,degree+1) if 1<=n-p+1<=order}
    assert required<=set(indices)
    ctx.prec=bits+64;minimum=None
    for re,im in d['complex_balls']:
        for s in (re,im):
            q=arb(s);assert q.is_finite()
            if not q.contains(0):minimum=min(minimum,q.rel_accuracy_bits()) if minimum is not None else q.rel_accuracy_bits()
    return {'path':str(path.resolve()),'sha256':sha(path),'symbol':d['symbol'],'dimension':dim,'order':order,'working_bits':bits,'scale':str(scale),
            'exact_unique_polynomial_terms':count,'exact_initial_row_entries':dim,'all_required_residual_coefficients_retained':True,
            'minimum_nonzero_component_relative_accuracy_bits':minimum,'maximum_tail_radius':d['maximum_tail_radius'],'all_input_output_source_hashes_match':True}

def exact_toy():
    # x=e^z S(1,z,z^2,z^3), y=z*x. Two dense size4 residue blocks.
    dim=8;S=fmpq_mat([[(i+1)**j for j in range(4)] for i in range(4)]);Si=S.inv()
    R=S*fmpq_mat([[(-i if i==j else 0) for j in range(4)] for i in range(4)])*Si
    L=S*fmpq_mat([[(1 if i==j else 2*i if i==j+1 else 0) for j in range(4)] for i in range(4)])*Si
    RR=[[fmpq(0)]*dim for _ in range(dim)];HH=[[fmpq(0)]*dim for _ in range(dim)]
    for b in range(2):
        for i in range(4):
            for j in range(4):RR[4*b+i][4*b+j]=R[i,j];HH[4*b+i][4*b+j]=L[i,j]
    for i in range(4):HH[4+i][i]=1
    # Common polynomial D=z*(1-z)*(1+z^2); nontrivial integer scaling.
    factor=[1,-1,1,-1];D=[0]+factor;N={}
    for k,a in enumerate(factor):
        for i in range(dim):
            for j in range(dim):
                N[k,i,j]=N.get((k,i,j),fmpq(0))+a*RR[i][j]
                N[k+1,i,j]=N.get((k+1,i,j),fmpq(0))+a*HH[i][j]
    N={k:v for k,v in N.items() if v};scale=7*math.lcm(*(int(v.q) for v in N.values()));order=37;bits=400;rlog=4
    lines=[f'{dim} 2 4 4 {len(N)} {order} {bits} 150 {rlog}','0 0 0 0 1 1 1 1']+[str(v*scale) for v in D]
    lines += [f'{k} {i} {j} {v*scale}' for (k,i,j),v in sorted(N.items())]
    initial=[1]*4+[0]*4;lines += list(map(str,initial));ip=OUT/'exact-toy.in';op=OUT/'exact-toy.native.json';ip.write_text('\n'.join(lines)+'\n')
    run=subprocess.run([str(BASE/'endpoint-native'),str(ip),str(op)],capture_output=True,text=True,timeout=10);assert run.returncode==0,run.stderr
    data=json.loads(op.read_text());ctx.prec=500
    def coefficient(n,i):
        if i>=4:return coefficient(n-1,i-4) if n>=1 else fmpq(0)
        return sum((fmpq((i+1)**j,math.factorial(n-j)) for j in range(min(3,n)+1)),fmpq(0))
    checks=0
    for row in data['last_coefficients']:
        for i,s in enumerate(row['values']):assert arb(s).contains(coefficient(row['eta_power'],i));checks+=1
    for i,(re,im) in enumerate(data['polynomial_values']):
        exact_re=fmpq(0);exact_im=fmpq(0)
        for n in range(order+1):
            term=coefficient(n,i)*fmpq(1,2**(rlog*n))
            if n%4==0:exact_re+=term
            elif n%4==1:exact_im+=term
            elif n%4==2:exact_re-=term
            else:exact_im-=term
        assert arb(re).contains(exact_re) and arb(im).contains(exact_im);checks+=2
    return {'dimension':dim,'blocks':[4,4],'order':order,'integer_scale':scale,'working_bits':bits,
            'independent_exact_coefficient_and_complex_sum_containments':checks,'native_seconds':data['native_seconds'],
            'input_sha256':sha(ip),'output_sha256':sha(op),'closed_solution':'x=e^z S(1,z,z^2,z^3), y=z*x; S_ij=(i+1)^j'}

if __name__=='__main__':
    start=time.monotonic();saved=[]
    paths=sorted(p for p in BASE.glob('*native-adjoint-*.json') if not p.name.endswith('.native.json'))
    for p in paths:saved.append(check_saved(p))
    toy=exact_toy();out={'schema':'vakint.ancestor.native-endpoint-independent-checks.v1','seconds':time.monotonic()-start,'source_sha256':sha(BASE/'endpoint_native.c'),'wrapper_sha256':sha(BASE/'native_endpoint.py'),'binary_sha256':sha(BASE/'endpoint-native'),'saved_inputs':saved,'exact_toy':toy}
    (OUT/'independent-checks.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',len(saved),'stored native inputs;',toy['independent_exact_coefficient_and_complex_sum_containments'],'exact toy enclosures;',out['seconds'],'seconds')
