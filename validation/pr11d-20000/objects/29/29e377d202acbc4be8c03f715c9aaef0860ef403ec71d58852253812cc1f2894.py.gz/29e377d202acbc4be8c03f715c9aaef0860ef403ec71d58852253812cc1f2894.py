#!/usr/bin/env python3
"""Compose the sealed unscaled X8 preparer with the exact reviewed RPF appender."""
from pathlib import Path
import argparse,contextlib,hashlib,importlib.util,io,json,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
if not __debug__:raise RuntimeError('Assertions required')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def explicit(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);assert Path(module.__file__).resolve()==path.resolve();return module
# The sealed generic preparer imports its native helper by name; place its exact
# authenticated directory first, and record all inherited helper pins below.
sys.path.insert(0,str(ROOT/'helper/jet-transport'))
parent=explicit('pr11d_x8_generic_segment',ROOT/'helper/jet-transport/prepare_generic_segment.py')
appender=explicit('pr11d_x8_rpf_appender',ROOT/'helper/jet-transport/append_rpf_scaled.py')
def main():
 parser=argparse.ArgumentParser(add_help=False);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--connection',type=Path,required=True);args,remaining=parser.parse_known_args()
 assert not args.output.exists() and not args.output.with_suffix('.json').exists(),'Saved input may not be overwritten'
 assert '--partial-fractions' not in remaining,'This wrapper appends RPF, never the older PF extension'
 connection=json.loads(args.connection.read_text());assert connection['dimension']==42 and connection['epsilon_jet_count']==6
 rpf=ROOT/'jet-transport/x8-ordinary-rational-pf.json';data=json.loads(rpf.read_text());assert data['source_polynomial_connection_sha256']==sha(args.connection)
 assert data['regular_epsilon_gauge']==connection['regular_epsilon_gauge'] and data['all_exact_polynomial_reconstruction_identities_verified'] is True
 assert sha(ROOT/'jet-transport/partial-fractions-regular-gauge.json')==data['source_linear_double_PF_sha256'] and sha(ROOT/'jet-transport/export_x8_rpf.py')==data['converter_sha256']
 prefix=args.output.with_suffix('.polynomial.in');assert not prefix.exists() and not prefix.with_suffix('.json').exists()
 sys.argv=[sys.argv[0]]+remaining+['--connection',str(args.connection),'--output',str(prefix)]
 with contextlib.redirect_stdout(io.StringIO()):parent.main()
 sys.argv=[sys.argv[0],'--input',str(prefix),'--metadata',str(prefix.with_suffix('.json')),'--rational-pf',str(rpf),'--output',str(args.output)]
 with contextlib.redirect_stdout(io.StringIO()):appender.main()
 path=args.output.with_suffix('.json');metadata=json.loads(path.read_text());metadata['constant_component_scale']=['1']*42
 dependencies=[Path(__file__),Path(parent.__file__),Path(appender.__file__),ROOT/'helper/frobenius-transport/native/prepare_v2.py',rpf,ROOT/'jet-transport/partial-fractions-regular-gauge.json',ROOT/'jet-transport/export_x8_rpf.py']
 metadata['implementation_dependency_sha256']={str(p.resolve()):sha(p) for p in dependencies};metadata['constant_scale_rule']='No eta-dependent or constant component gauge introduced; only the pre-existing regular epsilon unit gauge.'
 path.write_text(json.dumps(metadata,indent=2)+'\n');print('PreparedexactX8RPF',args.output,metadata['input_sha256'])
if __name__=='__main__':main()
