"""Exact rational Frobenius matching for epsilon-lifted ancestor connections.

Adapted independently from the read-only team's exact_rows.py recurrence.
No approximate boundary data enter the calculation.
"""
import argparse,hashlib,json,sys,time,resource
from pathlib import Path
sys.path.insert(0,'/shared/codex-1/vakint_rustred/workspace/precision-periods/pr11d/helper')
from flint import fmpq,fmpq_mat
from exact_system import parse
from endpoint_adjoint import eta_series


def kernel(matrix):
 rr,rank=matrix.rref();m,n=matrix.nrows(),matrix.ncols()
 pivots=[next(j for j in range(n) if rr[i,j]) for i in range(rank)]
 free=[j for j in range(n) if j not in pivots];out=fmpq_mat(n,len(free))
 for k,column in enumerate(free):
  out[column,k]=1
  for i,pivot in enumerate(pivots):out[pivot,k]=-rr[i,column]
 assert not matrix*out
 return out,len(free)


def main():
 ap=argparse.ArgumentParser();ap.add_argument('name');ap.add_argument('--loops',type=int,required=True);args=ap.parse_args()
 resource.setrlimit(resource.RLIMIT_AS,(12*2**30,12*2**30));resource.setrlimit(resource.RLIMIT_CPU,(600,610))
 here=Path(__file__).parent;name=args.name;source=here/f'{name}-augmented5.json.normalized.json';raw=here/f'{name}.json'
 data=json.load(open(source));input_data=json.load(open(raw));size=data['state_dimension'];dim=len(input_data['matrix'] if 'matrix' in input_data else input_data['differential_matrix']);assert size==6*dim
 started=time.monotonic()
 def expression(t):return parse(t,input_data['epsilon_symbol'],'pr11d_direct_helper::{}::z')
 def q(v):
  assert all(a==b==0 for a,b in v.num.to_dict()) and all(a==b==0 for a,b in v.den.to_dict())
  return v.num.to_dict().get((0,0),0)/v.den.to_dict()[(0,0)]
 residue=fmpq_mat([[q(expression(t)) for t in row] for row in data['residue']]);factors=residue.charpoly().factor()[1];multiplicities={}
 for factor,m in factors:
  assert factor.degree()==1;root=-factor[0]/factor[1];assert root.q==1;multiplicities[int(root)]=int(m)
 lower=min(multiplicities);upper=max(multiplicities)
 weights=[];scales=[]
 for i,row in enumerate(data['transformation']):
  nonzero=[(j,t) for j,t in enumerate(row) if t!='0'];assert len(nonzero)==1 and nonzero[0][0]==i
  v=expression(nonzero[0][1]);nd=v.num.to_dict();dd=v.den.to_dict();assert len(nd)==len(dd)==1
  (ne,nx),nc=next(iter(nd.items()));(de,dx),dc=next(iter(dd.items()));assert ne==de==0
  weights.append(int(nx-dx));scales.append(nc/dc)
 # All startup coefficients suffice to expose every free residue constant.
 order=upper-lower;coeffs=[[[0]*size for _ in range(size)] for _ in range(order+1)]
 for i,row in enumerate(data['matrix']):
  for j,text in enumerate(row):
   if text=='0':continue
   for k,value in enumerate(eta_series(expression(text),order)):coeffs[k][i][j]=q(value)
 matrices=[fmpq_mat(v) for v in coeffs];assert matrices[0]==residue
 identity=fmpq_mat([[int(i==j) for j in range(size)] for i in range(size)]);zero=fmpq_mat(size,size)
 vectors=[];blocks=[];nilpotence={};offset=0
 for root,multiplicity in sorted(multiplicities.items()):
  shifted=residue-identity*root;power=identity
  for degree in range(1,multiplicity+1):
   power=power*shifted;basis,nullity=kernel(power)
   if nullity==multiplicity:break
   assert nullity<multiplicity
  assert nullity==multiplicity
  b=basis.tolist();vectors.extend([[b[i][j] for i in range(size)] for j in range(multiplicity)]);blocks.append((root,offset,multiplicity));offset+=multiplicity;nilpotence[root]=degree
  print('residue',root,'multiplicity',multiplicity,'nilpotence',degree,flush=True)
 change=fmpq_mat([[vectors[j][i] for j in range(size)] for i in range(size)]);inverse=change.inv();A=[inverse*v*change for v in matrices];R=A[0]
 Ns=[]
 for root,start,width in blocks:
  Ns.append(fmpq_mat([[R[start+i,start+j]-int(i==j)*root for j in range(width)] for i in range(width)]))
  for i in range(start,start+width):assert all(not R[i,j] for j in range(size) if not start<=j<start+width)
 coefficients={};startup=[];rows=[];labels=[];maxlog=0;introduced=0
 for n in range(lower,upper+1):
  forcing=[]
  for step in range(1,n-lower+1):
   prev=coefficients[n-step]
   while len(forcing)<len(prev):forcing.append(zero)
   for ell,C in enumerate(prev):forcing[ell]=forcing[ell]+A[step]*C
  pieces=[]
  for (root,start,width),N in zip(blocks,Ns):
   zz=fmpq_mat(width,size);F=[fmpq_mat([[v[start+i,j] for j in range(size)] for i in range(width)]) for v in forcing]
   if root==n:
    current=[fmpq_mat([[int(start+i==j) for j in range(size)] for i in range(width)])];introduced+=width
    for ell in range(1,size+1):
     rhs=N*current[-1]+(F[ell-1] if ell<=len(F) else zz)
     if not rhs and ell>len(F):break
     current.append(rhs*fmpq(1,ell))
    else:raise RuntimeError('log recurrence failed')
   else:
    eye=fmpq_mat([[int(i==j) for j in range(width)] for i in range(width)]);resolvent=(eye*(n-root)-N).inv();current=[zz]*max(1,len(F));following=zz
    for ell in range(len(current)-1,-1,-1):
     rhs=(F[ell] if ell<len(F) else zz)-following*(ell+1);current[ell]=resolvent*rhs;following=current[ell]
   while len(current)>1 and not current[-1]:current.pop()
   pieces.append(current)
  logs=max(map(len,pieces));assembled=[]
  for ell in range(logs):
   rr=[]
   for (_,_,width),part in zip(blocks,pieces):rr.extend(part[ell].tolist() if ell<len(part) else [[0]*size for _ in range(width)])
   assembled.append(fmpq_mat(rr))
  for ell,C in enumerate(assembled):assert not(C*n-R*C+(assembled[ell+1]*(ell+1) if ell+1<len(assembled) else zero)-(forcing[ell] if ell<len(forcing) else zero))
  coefficients[n]=assembled;maxlog=max(maxlog,logs-1)
  for ell,C in enumerate(assembled):
   original=change*C;entries=[[i,j,str(v)] for i,row in enumerate(original.tolist()) for j,v in enumerate(row) if v]
   if entries:startup.append({'normalized_z_power':n,'log_power':ell,'entries':entries})
   for i,row in enumerate(original.tolist()):
    if any(row):rows.append([v*scales[i] for v in row]);labels.append({'component':i%dim,'epsilon_power':i//dim-args.loops,'integer_z_power':n+weights[i],'log_power':ell})
  print('power',n,'logs',logs,'seconds',time.monotonic()-started,flush=True)
 assert introduced==size
 # Prefer log0/1 and low absolute raw powers, limiting unnecessary region depths.
 order_rows=sorted(range(len(rows)),key=lambda i:(labels[i]['log_power']>1,labels[i]['log_power'],labels[i]['epsilon_power'],abs(labels[i]['integer_z_power']),labels[i]['component']))
 candidates=fmpq_mat([rows[i] for i in order_rows]);rr,rank=candidates.transpose().rref();assert rank==size
 pivots=[next(j for j in range(candidates.nrows()) if rr[i,j]) for i in range(rank)];selected=[order_rows[j] for j in pivots];square=fmpq_mat([rows[i] for i in selected]);inv=square.inv();assert square*inv==identity
 def strings(m):return [[str(v) for v in row] for row in m.tolist()]
 selected_groups=set((labels[i]['component'],labels[i]['integer_z_power']) for i in selected)
 scoped=[i for i,l in enumerate(labels) if (l['component'],l['integer_z_power']) in selected_groups]
 result={'schema':'vakint.ancestor.exact-Q-infinity-boundary-matching.v1','name':name,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'dimension':size,'base_dimension':dim,'loop_count':args.loops,'jet_count':6,'freeconstants':size,'selected_selectors':[labels[i] for i in selected],'boundary_matrix':strings(square),'boundary_inverse':strings(inv),'all_boundary_selectors':[labels[i] for i in scoped],'all_boundary_matrix':[[str(x) for x in rows[i]] for i in scoped],'other_prepared_rows_not_requested_count':len(rows)-len(scoped),'generalized_eigenspace_change':strings(change),'generalized_eigenspace_inverse':strings(inverse),'residue_blocks':[{'root':r,'start':a,'width':w} for r,a,w in blocks],'nilpotent_blocks':[strings(v) for v in Ns],'gauge_weights':weights,'gauge_scales':[str(v) for v in scales],'max_exact_log_degree':maxlog,'normalized_power_range':[lower,upper],'all_exact_recurrence_residuals_zero':True,'exact_inverse_product_identity_verified':True,'numerical_boundary_values_read':False,'seconds':time.monotonic()-started,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}
 inventory=here.parents[1]/'bessel'/'ancestor-boundary'/f'{name}-inventory.json'
 if inventory.exists():
  result['inventory_sha256']=hashlib.sha256(inventory.read_bytes()).hexdigest();result['inventory_path']=str(inventory)
 dest=here/f'{name}-matching.json';dest.write_text(json.dumps(result,indent=2)+'\n');seed={'schema':'vakint.ancestor.exact-infinity-startup.v1','source_matching_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'dimension':size,'normalized_power_range':[lower,upper],'coefficients':startup,'exact_recurrence_identity_verified':True,'numerical_boundary_values_read':False};(here/f'{name}-startup.json').write_text(json.dumps(seed,indent=2)+'\n')
 groups=sorted(set((l['component'],l['integer_z_power']) for l in result['selected_selectors']));(here/f'{name}-groups.json').write_text(json.dumps([{'component':i,'integer_power':str(n)} for i,n in groups],indent=2)+'\n');print('PASS rank',rank,'groups',len(groups),'maxlog',maxlog,'seconds',time.monotonic()-started,flush=True)

if __name__=='__main__':main()
