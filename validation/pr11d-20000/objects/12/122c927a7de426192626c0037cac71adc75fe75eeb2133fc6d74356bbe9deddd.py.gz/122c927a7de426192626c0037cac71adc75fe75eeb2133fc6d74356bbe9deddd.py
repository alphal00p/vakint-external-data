#!/usr/bin/env python3
"""Exact local constant diagonal scaling around the sealed generic preparer."""
from pathlib import Path
from fractions import Fraction as Q
import argparse,hashlib,json,math,sys
from flint import arb,acb,ctx,fmpq
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'helper/jet-transport'))
import prepare_generic_segment as parent
if not __debug__:raise RuntimeError('Assertions required')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
    parser=argparse.ArgumentParser(add_help=False);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--connection',type=Path,required=True);parser.add_argument('--center-imag',required=True);options,remaining=parser.parse_known_args()
    source=json.loads(options.connection.read_text());name=source['name'];dim=source['dimension'];jets=source['epsilon_jet_count'];assert name in ('three-loop-seven','pr9-22')
    matching=ROOT/'ancestor-flows'/f'{name}-matching.json';weights=json.loads(matching.read_text())['gauge_weights'][:dim];assert len(weights)==dim
    magnitude=abs(Q(options.center_imag));assert magnitude
    # A common scalar scale cancels from the connection; remove it to limit integer sizes.
    minimum=min(weights);weights=[w-minimum for w in weights];scales=[magnitude**(-w) for w in weights]
    sys.argv=[sys.argv[0]]+remaining+['--connection',str(options.connection),'--center-imag='+options.center_imag,'--output',str(options.output)]
    parent.main()
    metadata_path=options.output.with_suffix('.json');metadata=json.loads(metadata_path.read_text());ctx.prec=metadata['working_bits']
    rows=options.output.read_text().splitlines();header=list(map(int,rows[0].split()));d,j,degree,count,blocks,bits,digits,max_order,check=header;assert (d,j)==(dim,jets)
    assert arb(rows[1])>0
    offset=3+degree+1;couplings=[];multipliers=[]
    for _ in range(count):
        r,c,e=map(int,rows[offset].split());couplings.append((offset,r,c,e));multipliers.append(scales[c]/scales[r]);offset+=degree+2
    initial_offset=offset;assert len(rows)>=offset+dim*jets
    clear=math.lcm(*(x.denominator for x in multipliers));assert clear>=1
    ctx.prec=128;lower=arb(rows[1])*clear;rows[1]=lower.str(85,more=True);ctx.prec=bits
    for i in range(3,3+degree+1):
        a,b=map(int,rows[i].split());rows[i]=f'{a*clear} {b*clear}'
    identities=0
    for (position,r,c,e),ratio in zip(couplings,multipliers):
        scale=ratio*clear;assert scale.denominator==1
        for k in range(degree+1):
            index=position+1+k;a,b=map(int,rows[index].split());aa=a*scale.numerator;bb=b*scale.numerator
            assert Q(aa,clear)==a*ratio and Q(bb,clear)==b*ratio;identities+=1;rows[index]=f'{aa} {bb}'
    printed=math.ceil(bits*math.log10(2))+10
    for k in range(jets):
        for i in range(dim):
            index=initial_offset+k*dim+i;a,b=rows[index].split('|');value=acb(arb(a),arb(b))/fmpq(scales[i].numerator,scales[i].denominator)
            rows[index]=value.real.str(printed)+'|'+value.imag.str(printed)
    tail=initial_offset+dim*jets
    if len(rows)>tail:
        tag,poles,terms=rows[tail].split();assert tag=='PF_V1','Generalized decomposition requires a separately reviewed scaling adapter'
        old_den=int(rows[tail+1]);new_den=math.lcm(*(old_den*ratio.denominator for ratio in multipliers));rows[tail+1]=str(new_den)
        start=tail+3+int(poles)
        for index in range(start,start+int(terms)):
            r,c,e,kind,pole,number=map(int,rows[index].split());value=Q(number,old_den)*scales[c]/scales[r]*new_den;assert value.denominator==1
            rows[index]=f'{r} {c} {e} {kind} {pole} {value.numerator}'
    options.output.write_text('\n'.join(rows)+'\n')
    metadata.update({'schema':'vakint.generic.constant-scaled-ordinary-step.v1','input_sha256':sha(options.output),'constant_component_scale':[str(x) for x in scales],'constant_scale_weights':weights,'constant_scale_exact_coefficient_identities':identities,'clear_denominator_factor':str(clear),'scale_matching_sha256':sha(matching),'unscaled_preparer_sha256':sha(Path(parent.__file__)),'scaling_wrapper_sha256':sha(Path(__file__)),'output_basis':'original_raw_epsilon_jets_divided_by_regular_epsilon_gauge_and_constant_component_scale','basis_conversion':'Y_i=S_i*(Z_i-2epsilon*Z_i if regular_epsilon_gauge_weight_i==1 else Z_i)'})
    metadata_path.write_text(json.dumps(metadata,indent=2)+'\n')
if __name__=='__main__':main()
