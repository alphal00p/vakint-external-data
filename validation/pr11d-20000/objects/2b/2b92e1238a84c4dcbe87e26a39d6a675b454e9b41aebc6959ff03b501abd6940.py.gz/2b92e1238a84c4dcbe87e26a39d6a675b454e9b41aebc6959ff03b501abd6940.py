#!/usr/bin/env python3
"""Finite-field exact Frobenius rank proof for collapsed X8 infinity selectors.

No numerical boundary values are read.  Generalized eigenspaces of the rational
residue provide free constants. Polynomial-log recurrences retain all resonant
logs rather than imposing a physical log-width assumption.
"""
import argparse
import hashlib
import json
import resource
import sys
import time
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"helper"))
from flint import fmpq, fmpq_mat

from exact_system import CTX, Rat, parse
HERE=Path(__file__).resolve().parent
PREPARED=HERE.parent/"helper"
from endpoint_adjoint import eta_series

INVENTORY = Path('/shared/codex-1/vakint_rustred/workspace/precision-periods/bessel/pr11-boundary/inventory-full-v2.json')


def q_nullspace(matrix):
    rr,rank=matrix.rref();m,n=matrix.nrows(),matrix.ncols()
    pivots=[next(j for j in range(n) if rr[i,j]) for i in range(rank)]
    free=[j for j in range(n) if j not in pivots]
    out=fmpq_mat(n,n)
    for k,column in enumerate(free):
        out[column,k]=1
        for i,pivot in enumerate(pivots):out[pivot,k]=-rr[i,column]
    assert not matrix*out
    return out,len(free)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--prime',type=int,default=1000000007);args=ap.parse_args()
    resource.setrlimit(resource.RLIMIT_AS,(8*2**30,8*2**30))
    resource.setrlimit(resource.RLIMIT_CPU,(300,310))
    p=args.prime;started=time.monotonic()
    data=json.loads((PREPARED/'augmented5.json.normalized.json').read_text())
    inventory=json.loads(INVENTORY.read_text());groups=inventory['selected_integer_power_scope']
    size=data['state_dimension'];assert size==252 and len(groups)==37
    def mod_q(value):return value
    def constant(value):
        assert all(e==x==0 for e,x in value.num.to_dict())
        assert all(e==x==0 for e,x in value.den.to_dict())
        return mod_q(value.num.to_dict().get((0,0),0)/value.den.to_dict()[(0,0)])
    def expression(text):return parse(text,'masters_4l::{}::epsilon','pr11d_direct_helper::{}::z')
    weights=[];scales=[]
    for i,row in enumerate(data['transformation']):
        nonzero=[(j,v) for j,v in enumerate(row) if v!='0']
        assert len(nonzero)==1 and nonzero[0][0]==i
        v=expression(nonzero[0][1]);nd=v.num.to_dict();dd=v.den.to_dict()
        assert len(nd)==len(dd)==1
        (ne,nx),nc=next(iter(nd.items()));(de,dx),dc=next(iter(dd.items()))
        assert ne==de==0
        weights.append(int(nx-dx));scales.append(mod_q(nc/dc))
    selectors=[(42*k+g['component'],int(g['integer_power'])-weights[42*k+g['component']]) for k in range(6) for g in groups]
    upper=max(n for _,n in selectors);lower=-8
    assert min(n for _,n in selectors)>=lower
    order=upper-lower
    coeffs=[[[0]*size for _ in range(size)] for _ in range(order+1)]
    for i,row in enumerate(data['matrix']):
        for j,text in enumerate(row):
            if text=='0':continue
            values=eta_series(expression(text),order)
            for k,value in enumerate(values):coeffs[k][i][j]=constant(value)
    matrices=[fmpq_mat(values) for values in coeffs]
    residue=matrices[0]
    identity=fmpq_mat([[int(i==j) for j in range(size)] for i in range(size)])
    zero=fmpq_mat(size,size)
    # Independent exact-Q characteristic multiplicities certify good reduction.
    exact_residue=[]
    for row in data['residue']:
        values=[]
        for text in row:
            v=expression(text)
            values.append(v.num.to_dict().get((0,0),0)/v.den.to_dict()[(0,0)])
        exact_residue.append(values)
    factors=fmpq_mat(exact_residue).charpoly().factor()[1]
    multiplicities={}
    for factor,multiplicity in factors:
        assert factor.degree()==1
        root=-factor[0]/factor[1];assert root.q==1
        multiplicities[int(root)]=int(multiplicity)
    assert set(multiplicities)==set(range(-8,0))
    block_vectors=[];nilpotence={};offset=0;blocks=[]
    for root,multiplicity in sorted(multiplicities.items()):
        shifted=residue-identity*root;power=identity
        for degree in range(1,multiplicity+1):
            power=power*shifted
            kernel,nullity=q_nullspace(power)
            if nullity==multiplicity:break
            assert nullity<multiplicity,'bad prime changes residue multiplicity'
        assert nullity==multiplicity
        values=kernel.tolist()
        block_vectors.extend([[values[i][j] for i in range(size)] for j in range(multiplicity)])
        blocks.append((root,offset,multiplicity));offset+=multiplicity
        nilpotence[root]=degree
        print('residue block',root,'multiplicity',multiplicity,'nilpotence',degree,flush=True)
    change=fmpq_mat([[block_vectors[j][i] for j in range(size)] for i in range(size)])
    inverse=change.inv();transformed=[inverse*A*change for A in matrices]
    R=transformed[0]
    block_n=[]
    for root,start,width in blocks:
        block=fmpq_mat([[R[start+i,start+j]-int(i==j)*root for j in range(width)] for i in range(width)])
        block_n.append(block)
        for i in range(start,start+width):
            assert all(not R[i,j] for j in range(size) if not start<=j<start+width)
    coefficients={};rank_rows={};rank_labels={};introduced=0;max_log=0;startup=[]
    for exponent in range(lower,upper+1):
        forcing=[]
        for step in range(1,min(order,exponent-lower)+1):
            previous=coefficients[exponent-step]
            while len(forcing)<len(previous):forcing.append(zero)
            for log,C in enumerate(previous):forcing[log]=forcing[log]+transformed[step]*C
        pieces=[]
        for (root,start,width),nilpotent in zip(blocks,block_n):
            blockzero=fmpq_mat(width,size)
            F=[fmpq_mat([[v[start+i,j] for j in range(size)] for i in range(width)]) for v in forcing]
            if root==exponent:
                initial=fmpq_mat([[int(start+i==j) for j in range(size)] for i in range(width)])
                current=[initial];introduced+=width
                for log in range(1,size+1):
                    rhs=nilpotent*current[-1]+(F[log-1] if log<=len(F) else blockzero)
                    if not rhs and log>len(F):break
                    current.append(rhs*fmpq(1,log))
                else:raise RuntimeError('polynomial-log recurrence did not terminate')
            else:
                blockidentity=fmpq_mat([[int(i==j) for j in range(width)] for i in range(width)])
                resolvent=(blockidentity*(exponent-root)-nilpotent).inv()
                current=[blockzero]*max(1,len(F));next_coefficient=blockzero
                for log in range(len(current)-1,-1,-1):
                    rhs=(F[log] if log<len(F) else blockzero)-next_coefficient*(log+1)
                    current[log]=resolvent*rhs;next_coefficient=current[log]
            while len(current)>1 and not current[-1]:current.pop()
            pieces.append(current)
        logs=max(map(len,pieces));assembled=[]
        for log in range(logs):
            rows=[]
            for (_,_,width),piece in zip(blocks,pieces):
                rows.extend(piece[log].tolist() if log<len(piece) else [[0]*size for _ in range(width)])
            assembled.append(fmpq_mat(rows))
        # Verify every coefficient equation, including the terminal log degree.
        for log,C in enumerate(assembled):
            residual=C*exponent-R*C+(assembled[log+1]*(log+1) if log+1<len(assembled) else zero)-(forcing[log] if log<len(forcing) else zero)
            assert not residual,(exponent,log,'recurrence residual')
        coefficients[exponent]=assembled;max_log=max(max_log,logs-1)
        original_cache=[change*C for C in assembled]
        for log,original in enumerate(original_cache):
            entries=[[i,j,str(value)] for i,row in enumerate(original.tolist()) for j,value in enumerate(row) if value]
            if entries:startup.append({'normalized_z_power':exponent,'log_power':log,'entries':entries})
        requested=[i for i,n in selectors if n==exponent]
        if requested:
            for log,C in enumerate(assembled):
                original=original_cache[log]
                rank_rows.setdefault(log,[]).extend([[original[i,j]*scales[i] for j in range(size)] for i in requested])
                rank_labels.setdefault(log,[]).extend([{'component':i%42,'epsilon_power':i//42-4,'integer_z_power':exponent+weights[i],'log_power':log} for i in requested])
        print('power',exponent,'logs',logs,'freeconstants',introduced,'seconds',time.monotonic()-started,flush=True)
    assert introduced==size
    stacked=[];labels=[]
    all_stacked=[];all_labels=[]
    for log in sorted(rank_rows):
        all_stacked.extend(rank_rows[log]);all_labels.extend(rank_labels[log])
    for log in (0,1):
        stacked.extend(rank_rows.get(log,[]));labels.extend(rank_labels.get(log,[]))
    witness_source=PREPARED/'boundary-rank-p1000000007.json'
    witness=json.loads(witness_source.read_text())['injective_boundary_minor']
    def key(label):return tuple(label[x] for x in ('component','epsilon_power','integer_z_power','log_power'))
    lookup={key(label):i for i,label in enumerate(labels)}
    assert len(lookup)==len(labels)
    selected=[lookup[key(label)] for label in witness['selected_selectors']]
    square=fmpq_mat([stacked[i] for i in selected]);det=square.det();assert det
    square_inverse=square.inv();assert square*square_inverse==fmpq_mat([[int(i==j) for j in range(size)] for i in range(size)])
    def strings(matrix):return [[str(v) for v in row] for row in matrix.tolist()]
    result={'schema':'vakint.pr11d.exact-Q-infinity-boundary-matching.v1','source_sha256':hashlib.sha256((PREPARED/'augmented5.json.normalized.json').read_bytes()).hexdigest(),'inventory_sha256':hashlib.sha256(INVENTORY.read_bytes()).hexdigest(),'dimension':size,'basis':'Generalized residue eigenspaces over Q; independent exact-Q rref basis, not the modular basis','freeconstants':size,'selected_selectors':[labels[i] for i in selected],'boundary_matrix':strings(square),'all_boundary_selectors':all_labels,'all_boundary_matrix':[[str(x) for x in row] for row in all_stacked],'boundary_inverse':strings(square_inverse),'boundary_determinant':str(det),'generalized_eigenspace_change':strings(change),'generalized_eigenspace_inverse':strings(inverse),'residue_blocks':[{'root':r,'start':a,'width':w} for r,a,w in blocks],'nilpotent_blocks':[strings(v) for v in block_n],'gauge_weights':weights,'gauge_scales':[str(v) for v in scales],'max_exact_log_degree':max_log,'normalized_power_range':[lower,upper],'all_exact_recurrence_residuals_zero':True,'exact_inverse_product_identity_verified':True,'numerical_boundary_values_read':False,'seconds':time.monotonic()-started,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'scope':'Exact finite boundary matching only; no numerical master values or PR11d precision claimed.'}
    (HERE/'exact-boundary-matching.json').write_text(json.dumps(result,indent=2)+'\n')
    seed={'schema':'vakint.pr11d.exact-infinity-startup.v1','source_matching_sha256':hashlib.sha256((HERE/'exact-boundary-matching.json').read_bytes()).hexdigest(),'dimension':size,'normalized_power_range':[lower,upper],'coefficient_basis':'normalized_original_J = generalized_eigenspace_change * transformed_Frobenius_coefficients * c','original_gauge':'original_Y_i = gauge_scale_i * z^gauge_weight_i * normalized_J_i','coefficients':startup,'exact_recurrence_identity_verified':True,'numerical_boundary_values_read':False}
    (HERE/'exact-startup-coefficients.json').write_text(json.dumps(seed,indent=2)+'\n')
    print('EXACT252MATCHINGPASS',result['seconds'],'seconds','rss',result['peak_rss_bytes'],flush=True)


if __name__=='__main__':main()
