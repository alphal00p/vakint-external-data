#!/usr/bin/env python3
"""Strict native endpoint-ball import for the optional scientific hierarchy.

The caller supplies the accepted artifact digest. This imports existing ball
errors without reevaluation, extra Euler factors or numerical precision claims.
"""
import hashlib,json,re
from pathlib import Path
from flint import arb
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'pr11-boundary'))
from logjet_map import FactorJet

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load_native_endpoints(path,expected_sha256,required_support):
    path=Path(path)
    if not isinstance(expected_sha256,str) or not re.fullmatch('[0-9a-f]{64}',expected_sha256):
        raise ValueError('An explicit accepted source SHA-256 is required')
    actual=sha(path)
    if actual!=expected_sha256:raise ValueError('Endpoint source checksum mismatch')
    data=json.loads(path.read_bytes())
    if data.get('normalization')!='native_raw':raise ValueError('Endpoint input must use native_raw normalization')
    if data.get('error_quality')!='rigorous-bound':raise ValueError('Only rigorously bounded endpoint inputs may feed the guarded hierarchy')
    coefficients=data.get('coefficients')
    if not isinstance(coefficients,dict):raise ValueError('Canonical endpoint coefficient identities are required')
    values={};summaries=[]
    for symbol,(first,last) in required_support.items():
        if type(first) is not int or type(last) is not int or first>last:raise ValueError('Invalid canonical support contract')
        rows=coefficients.get(symbol)
        if not isinstance(rows,list) or len(rows)!=last-first+1:
            raise ValueError(f'{symbol}: every coefficient epsilon^{first} through epsilon^{last} must be explicit')
        powers=[r.get('epsilon_power') if isinstance(r,dict) else None for r in rows]
        if any(type(p) is not int for p in powers) or powers!=list(range(first,last+1)):
            raise ValueError(symbol+': missing, duplicate, reordered or noninteger coefficient order')
        balls=[]
        for row in rows:
            if not isinstance(row.get('ball'),str):raise ValueError(symbol+': an explicit real Arb enclosure is required')
            value=arb(row['ball'])
            if not value.is_finite():raise ValueError(symbol+': nonfinite coefficient enclosure')
            balls.append(value)
        values[symbol]=FactorJet(first,tuple(balls),
          'Accepted authenticated physical endpoint projection; canonical primitive Laurent support is supplied by the exact family/powers binding',
          symbol+'; accepted endpoint source '+actual)
        summaries.append({'symbol':symbol,'first_epsilon_power':first,'last_epsilon_power':last,
          'relative_accuracy_bits':[int(v.rel_accuracy_bits()) if not v.contains(0) else None for v in balls],
          'exact_zero_orders':[first+i for i,v in enumerate(balls) if v.is_zero()]})
    return values,{'source':str(path.resolve()),'sha256':actual,'normalization':'native_raw','error_quality':'rigorous-bound',
      'imported_support':summaries,'source_schema':data.get('schema'),'no_numerical_reevaluation':True,'no_Euler_conversion_applied':True}
