#!/usr/bin/env python3
"""Measure all frozen source enclosures; nominal precision is never a gate."""
import hashlib,json
from pathlib import Path
from flint import arb,ctx
HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def power(v):
    if v.is_zero():return None
    n=int((-v.upper().log()/arb(10).log()).lower().floor().fmpz())
    if not v.upper()<(arb(10)**-n).lower():raise ValueError('Nonrigorous decimal-error power')
    return n
def main():
    if not __debug__:raise RuntimeError('Acceptance cannot run under optimization')
    ctx.dps=21400;profiles={}
    for name in ['A','B']:
        directory=HERE/name;cp=directory/'x8-source.constants.json';bp=directory/'x8-source.boundary.json';data=json.loads(cp.read_text());boundary=json.loads(bp.read_text())
        assert data['boundary_input_sha256']==sha(bp)and len(data['free_constant_balls'])==252 and len(boundary['coefficients'])==1587
        rows=[]
        for index,text in enumerate(data['free_constant_balls']):
            v=arb(text)
            if not v.is_finite():raise ValueError('Nonfinite source constant')
            radius=v.rad();diameter=2*radius
            rows.append({'index':index,'exact_zero':v.is_zero(),'uncertain_zero':v.contains(0)and not v.is_zero(),'absolute_radius_upper_enclosure':radius.upper().str(45,more=True),'diameter_upper_enclosure':diameter.upper().str(45,more=True),'guaranteed_absolute_radius_decimal_power':power(radius),'guaranteed_diameter_decimal_power':power(diameter),'relative_accuracy_bits':None if v.contains(0)else int(v.rel_accuracy_bits())})
        maximum=max(arb(text).rad()for text in data['free_constant_balls']);profile={'profile':name,'boundary_sha256':sha(bp),'constants_sha256':sha(cp),'coefficient_count':1587,'constant_count':252,'maximum_constant_radius':maximum.upper().str(45,more=True),'all_radius_guaranteed_decimal_power':min(r['guaranteed_absolute_radius_decimal_power']for r in rows if r['guaranteed_absolute_radius_decimal_power']is not None),'all_diameter_guaranteed_decimal_power':min(r['guaranteed_diameter_decimal_power']for r in rows if r['guaranteed_diameter_decimal_power']is not None),'exact_zero_count':sum(r['exact_zero']for r in rows),'uncertain_zero_count':sum(r['uncertain_zero']for r in rows),'constants':rows,'working_digits_used_for_measurement':21400,'physical4Lsource_admission_pending':True,'whole_PR11d_precision_claimed':False}
        target=directory/'source-capability.json'
        if target.exists():raise ValueError('Never replace prior source measurements')
        target.write_text(json.dumps(profile,indent=2)+'\n');profiles[name]={k:v for k,v in profile.items()if k!='constants'};print(name,'maximumradius',profile['maximum_constant_radius'],'allradiuspower',profile['all_radius_guaranteed_decimal_power'],'alldiameterpower',profile['all_diameter_guaranteed_decimal_power'],'receipt',sha(target),flush=True)
    target=HERE/'source-capability-summary.json';assert not target.exists();target.write_text(json.dumps({'schema':'vakint.X8-production-source-capability.v1','profiles':profiles,'all252widths_recorded_per_profile':True,'validator_sha256':sha(__file__),'internal_working_precision_is_not_an_accuracy_claim':True},indent=2)+'\n')
if __name__=='__main__':main()
