"""Verify guarded AP exports by exact rationals and immutable source bindings."""
import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
sys.set_int_max_str_digits(0)
parser=argparse.ArgumentParser();parser.add_argument('--partial',action='store_true');args=parser.parse_args()
OUT=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def ratio(value):
    r=value['exact_binary_value'];assert int(r['denominator'])>0
    number=Fraction(int(r['numerator']),int(r['denominator']))
    assert number.denominator & (number.denominator-1)==0
    return number
receipt=json.loads((OUT/'receipt.json').read_text());requested=receipt['requested_decimal_precision'];assert requested==20600
assert receipt['passes_per_coefficient']==1 and not receipt['automatic_retry']
assert receipt['normalization']=='FMFTandMATAD' and not receipt['normalization_transform_applied']
assert sha(OUT/'evaluate.py')==receipt['script_sha256']
assert sha(OUT/'release-manifest.json')==receipt['release_manifest_sha256']
assert sha(OUT/'3L-manifest.json')==receipt['loop_manifest_sha256']
release=json.loads((OUT/'release-manifest.json').read_text());manifest=json.loads((OUT/'3L-manifest.json').read_text())
assert next(p for p in release['loop_packs'] if p['loop_count']==3)['manifest_sha256']==receipt['loop_manifest_sha256']
host=json.loads((OUT/'host-provenance.json').read_text());assert host['sha256']==receipt['extension_sha256'];assert host['compiler_artifact']['profile']['opt_level']=='3'
assert receipt['dependency_revision']=='c5fc2209c46a678d69726f61a4e16abf668a55c2'
assert set(host['dependency_cohort'])=={'symbolica','numerica','graphica'}
assert all(len(v)==1 and v[0]['source'].endswith('#'+receipt['dependency_revision']) for v in host['dependency_cohort'].values())
prior_receipt=json.loads((OUT.parent/'receipt.json').read_text())
assert prior_receipt.get('success') and not prior_receipt['failures']
prior_exports={entry['master']:entry for entry in prior_receipt['completed']}
expected={'3L-P13','3L-P14'};complete={r['master']:r for r in receipt['completed_masters']}
assert len(complete)==len(receipt['completed_masters'])
if not args.partial:assert receipt.get('success') and set(complete)==expected
assert set(complete)<=expected
checks=[]
for key in sorted(complete):
    path=OUT/(key+'.json');record=json.loads(path.read_text());assert sha(path)==complete[key]['sha256']
    assert record['complete'] and record['master']==key
    metadata=json.loads((OUT/'source'/key/'master-metadata.json').read_text())
    assert metadata==next(m for m in manifest['masters'] if m['name']==key[3:])
    assert hashlib.sha256(json.dumps(metadata,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()==record['master_metadata_sha256']
    assert record['master_id']==metadata['master_id'] and record['family_sha256']==metadata['family_sha256'] and record['powers']==metadata['powers']
    assert record['loop_count']==3 and record['provenance']['master_id']==metadata['master_id']
    assert record['exact_basis_expression']==metadata['exact_basis_expression']
    assert record['normalization']=='FMFTandMATAD' and record['normalization_formula']==metadata['graph_definition']['normalization']
    assert record['provenance']['version']==manifest['version'] and record['mass_squared']=='1'
    formula_path=OUT/'source'/key/'symbolic.json';assert sha(formula_path)==record['source_formula_sha256']==metadata['files']['symbolic.json']['sha256']
    formulas=dict(json.loads(formula_path.read_text()))
    accepted_path=OUT.parent/(key+'.json');assert sha(accepted_path)==record['prior_AP_inspection_sha256']==prior_exports[key]['sha256'];accepted={c['epsilon_power']:c for c in json.loads(accepted_path.read_text())['coefficients']}
    powers=[c['epsilon_power'] for c in record['coefficients']];assert powers==list(range(-3,3))==complete[key]['orders']
    for c in record['coefficients']:
        power=c['epsilon_power'];prior=accepted[power]
        assert c['formula_sha256']==hashlib.sha256(formulas[power].encode()).hexdigest()==prior['formula_sha256']
        assert c['available_precision']==prior['available_precision']=='ArbitraryPrecision'
        assert c['requested_decimal_precision']==requested and not c['warnings']
        real=c['precision']['real'];imag=c['precision']['imaginary'];center=ratio(c['numerical_value']);radius=ratio(real['absolute_error'])
        assert real['quality']=='Bounded' and real['significant_digits']>=requested
        bits=real['significant_bits'];assert 1<=bits<=c['numerical_value']['precision_bits']
        assert real['significant_digits']==((bits-1)*301029995663981195)//10**18
        assert radius>=0 and abs(center)>radius
        assert radius*(1<<(bits-1))<=abs(center)-radius
        assert radius*10**requested <= abs(center)-radius
        assert radius<Fraction(1,10**20580)
        assert imag['exact_zero'] and imag['quality']=='Bounded' and ratio(imag['absolute_error'])==0
        previous_center=ratio(prior['numerical_value']);previous_radius=ratio(prior['precision']['real']['absolute_error'])
        assert abs(center-previous_center)<=radius+previous_radius
        checks.append({'master':key,'epsilon_power':power,'achieved_digits':real['significant_digits'],'relative_digits_exactly_verified':requested,'absolute_radius_lt_1e_minus_20580':True,'prior_20280_interval_overlap':True,'source_formula_and_identity_binding':True})
assert checks
report={'complete':not args.partial,'master_count':len(complete),'coefficient_count':len(checks),'requested_decimal_precision':requested,'native_api':'public numerical_evaluation; one pass per exact formula','checks':checks,'verifier_sha256':sha(Path(__file__))}
(OUT/('validation-partial.json' if args.partial else 'validation.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2))
