#!/usr/bin/env python3
"""Bounded read-only reassembly and precision audit of guarded PR9 API boundary."""
import hashlib
import importlib.util
import json
import resource
import sys
import time
from decimal import Decimal,localcontext,ROUND_CEILING
from fractions import Fraction as Q
from pathlib import Path
from flint import arb,ctx,fmpq

if not __debug__:raise RuntimeError("Audit requires assertions")
sys.set_int_max_str_digits(300000)
HERE=Path(__file__).resolve().parent;PR11=HERE.parents[1];BASE=PR11.parent
BOUNDARY=BASE/"bessel/ancestor-boundary";GUARD=BOUNDARY/"guard20600";ANCESTOR=PR11/"ancestor-flows"
sys.path.insert(0,str(BOUNDARY))
import pr9_boundary as producer
from pr9_source_recipes import build
from endpoint_sources import load_native_endpoints
from logjet_map import FactorJet,MissingCoefficient,valuation
from expanded_boundary import ExpandedBoundary


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def upper_decimal(v):
    upper=v.upper();q=upper.fmpq()
    with localcontext() as c:
        c.prec=30;c.rounding=ROUND_CEILING
        value=Decimal(int(q.numerator))/Decimal(int(q.denominator));text=str(value)
        if arb(text).lower()<upper:text=str(value.next_plus(c))
    assert arb(text).lower()>=upper
    return text


def main():
    resource.setrlimit(resource.RLIMIT_AS,(2*2**30,2*2**30))
    resource.setrlimit(resource.RLIMIT_CPU,(60,65))
    start=time.monotonic();ctx.dps=20950;ctx.threads=1
    paths={
      "boundary":GUARD/"pr9-boundary-API20600-working20800.json",
      "guard_validation":GUARD/"pr9-boundary-API20600-working20800.guard-validation.json",
      "native_api_bridge":GUARD/"three-loop-API20600-native.json",
      "api_bridge_producer":GUARD/"api_native_bridge.py",
      "assembler":GUARD/"assemble.py",
      "endpoint_importer":BOUNDARY/"endpoint_sources.py","source_builder":BOUNDARY/"pr9_source_recipes.py",
      "inventory":BOUNDARY/"pr9-22-inventory.json","singlemass":BOUNDARY/"pr9-22-singlemass.json","products":BOUNDARY/"pr9-22-products.json",
      "matching":ANCESTOR/"pr9-22-matching.json","startup":ANCESTOR/"pr9-22-startup.json","polynomial":ANCESTOR/"pr9-22-polynomial.json",
      "matching_review":PR11/"helper/ancestor-matching-review/pr9-22-audit-receipt.json",
      "sunset":GUARD/"sunset21000/ratio21000-normalized.json",
      "sunset_source_review":BASE/"bessel/guard20600-source-review/sunset-audit.json",
      "API_source_review":BASE/"bessel/guard20600-source-review/API-audit.json",
      "provider_validation":PR11/"numerator-helper/ancestor-followup/validation.json",
      "api_export_validation":BASE/"lower-ancestors/guard20600/validation.json",
      "auditor":Path(__file__),
    }
    for name in ["source_recipes.py","gamma_ast.py","gamma_jets.py","expanded_boundary.py","logjet_map.py"]:paths[name]=BASE/"bessel/pr11-boundary"/name
    hashes={k:sha(p) for k,p in paths.items()}
    assert hashes["boundary"]=="217596105b32c1e49a104489db6d2811a9dacf97af3a6daacd4756b08b412838"
    assert hashes["guard_validation"]=="a192cd752954b5be41d0ed864a247d094a73a2467bc3dace0b3567d3e85c0d1a"
    assert hashes["native_api_bridge"]=="18f526a42f6942b6743b013e0288ff9c3e2b36b2ce990bbc8166b753fce743e6"
    data=read(paths["boundary"]);guard=read(paths["guard_validation"]);matching=read(paths["matching"]);bridge=read(paths["native_api_bridge"])
    assert data["normalization"]==bridge["normalization"]=="native_raw"
    assert data["error_quality"]==bridge["error_quality"]=="rigorous-bound"
    assert data["all_overdetermined_residuals_contain_zero"] and data["all_prepared_rows_checked"]
    assert data["coefficient_count"]==557 and data["free_constants"]==132
    assert not data["scientific_whole_master_accuracy_claimed"]
    assert bridge["producer_sha256"]==hashes["api_bridge_producer"]
    for path,digest in data["implementation_sha256"].items():assert sha(path)==digest
    assert data["matching_sha256"]==hashes["matching"]
    assert data["inventory_sha256"]==matching["inventory_sha256"]==hashes["inventory"]
    assert guard["accepted"] and guard["boundary_sha256"]==hashes["boundary"]
    assert guard["producer_sha256"]==hashes["assembler"] and guard["sunset_sha256"]==hashes["sunset"]
    assert guard["source_error_guard_power"]==data["source_error_guard_power"]==20550
    assert guard["source"]["sha256"]==hashes["native_api_bridge"] and guard["all132constants_finite"] and guard["all557rows_consistent"]
    assert guard["source"]["no_Euler_conversion_applied"]
    # Freeze and verify every actual accepted primitive, exact matching proof,
    # sunset proof and source recipe hash. No numerical source rerun.
    nested_pins={};historical_non_scientific_pin_changes=[]
    def pin(path,digest):
        path=Path(path).resolve();assert sha(path)==digest,(path,"stale source")
        if str(path) in nested_pins:assert nested_pins[str(path)]==digest
        nested_pins[str(path)]=digest
    for row in data["primitive_provenance"]:
        pin(row["source"],row["sha256"])
        assert row["normalization"]=="native_raw" and row["error_quality"]=="rigorous-bound"
    review=read(paths["matching_review"])
    assert review["accepted_for_exact_preparation_scope"]
    for row in review["artifact_sha256"].values():pin(row["path"],row["sha256"])
    expected_reviews={"sunset_source_review":"d2290a77c96a582767b254da53be3a65b02447e8638353979ce2cee5bde04223",
                      "API_source_review":"6b0a193343e2694cdd2557a9b36c7ea8434ce48c7c47c0070ccb680e9b5e5e7f"}
    for label,digest in expected_reviews.items():
        assert hashes[label]==digest
        review=read(paths[label]);assert review["accepted"]
        for path,digest in review["input_sha256"].items():pin(path,digest)
    api_review=read(paths["API_source_review"]);sunset_review=read(paths["sunset_source_review"])
    assert api_review["native_input_sha256"]==hashes["native_api_bridge"]
    assert api_review["Euler_conversion"]["applications"]==1
    assert api_review["sunset_source_acceptance_sha256"]==hashes["sunset_source_review"]
    assert len(api_review["native_output_checks"])==12 and all(row["full_exact_rational_source_box_contained"] and row["Euler_convolutions"]==1 for row in api_review["native_output_checks"])
    assert len(sunset_review["coefficient_checks"])==12 and all(row["independent_direct_Gamma_enclosure_contained"] for row in sunset_review["coefficient_checks"])
    provider=read(paths["provider_validation"]);assert provider["status"]=="PASS"
    provider_dir=paths["provider_validation"].parent
    for name,digest in provider["source_files_sha256"].items():pin(provider_dir/name,digest)
    child=read(provider_dir/"all-109-three-loop-trees.json")
    pin(provider_dir/"three-loop-bubbles.json",child["input_sha256"])
    pin(provider_dir/"native-child-result.json",child["native_reduction_sha256"])
    pin(provider_dir/"native-numerator-result.json",read(provider_dir/"all-19-numerator-trees.json")["native_reduction_sha256"])
    pin(provider_dir/"native-scalar-result.json",read(provider_dir/"all-scalar-trees.json")["native_reduction_sha256"])
    products=read(provider_dir/"product-seed-bindings.json");pin(products["source_path"],products["source_sha256"])
    api_validation=read(paths["api_export_validation"]);assert api_validation["complete"] and api_validation["coefficient_count"]==12
    expected_api={"native::L3_P13":"7b5ad1c7f23ec58f13cb7e54b2bde9ebf31861c9788eeea98b294397dfe41cce",
                  "native::L3_P14":"87218e53151c59d848fd09ac339608dff8289638ea3f089545a2b780f311b3c6"}
    assert set(bridge["canonical_alias_bindings"])==set(expected_api)
    for name,binding in bridge["canonical_alias_bindings"].items():
        assert binding["sha256"]==expected_api[name];pin(binding["source"],binding["sha256"])
        assert [r["epsilon_power"] for r in bridge["coefficients"][name]]==list(range(-3,3))
    assert bridge["source_digits_exactly_checked"]==20600
    assert all(row["relative_digits_exactly_verified"]>=20600 for row in api_review["source_checks"])
    # The bridge has already applied the sole Euler conversion; downstream
    # loaders import these exact same balls without applying another factor.
    imported,import_receipt=load_native_endpoints(paths["native_api_bridge"],hashes["native_api_bridge"],{"native::L3_P13":(-3,2),"native::L3_P14":(-3,2)})
    primitives=dict(imported)
    sunset=read(paths["sunset"])
    assert sunset["error_quality"]=="rigorous-bound" and sunset["validated_analytic_truncation_and_rounding"]
    sunset_rows=sunset["coefficients"]["native_raw"]
    assert [r["epsilon_power"] for r in sunset_rows]==list(range(-2,4))
    primitives["native::L2_P2"]=FactorJet(-2,tuple(arb(r["ball"]) for r in sunset_rows),"Independent accepted21000sunset source proof","native::L2_P2")
    assert import_receipt["no_Euler_conversion_applied"]
    assert data["primitive_provenance"][0]["source"]==str(paths["native_api_bridge"].resolve())
    assert data["primitive_provenance"][1]["source"]==str(paths["sunset"].resolve())
    for name in imported:
        for p in range(-3,3):
            a,b=imported[name].coefficient(p),primitives[name].coefficient(p)
            assert a.mid()==b.mid() and a.rad()==b.rad()
    factors,source_receipt=build()
    assert len(factors)==231 and source_receipt==data["source_recipe_receipt"]
    for group in [source_receipt["source_sha256"],source_receipt["X8_source_receipt"]["source_sha256"]]:
        for path,digest in group.items():pin(path,digest)
    assert source_receipt["native_singlemass_sha256"]==hashes["singlemass"] and source_receipt["native_products_sha256"]==hashes["products"]
    inventory=read(paths["inventory"]);requested={r["key"]:r for r in inventory["factors"]};assert set(factors)==set(requested)
    loop_counts={"native::L2_P2":2,"native::L3_P13":3,"native::L3_P14":3};monomial_count=0
    for name,expression in factors.items():
        row=requested[name];loops=row["loops"] if "loops" in row else len(row["family"]["loops"])
        for rational,slopes,keys in expression.terms:
            assert sum((b*n for b,n in slopes),Q(0))+sum(loop_counts[k] for k in keys)==loops
            monomial_count+=1
    plan=producer.load_plan(paths["inventory"],data["inventory_sha256"],"masters_4l::{}::epsilon")
    compiled=ExpandedBoundary(plan,factors,max_log_power=matching["max_exact_log_degree"])
    required,_=compiled.required_primitive_orders(primitives,last_epsilon_power=1)
    assert required==data["required_raw_primitive_through"]=={"native::L3_P13":2,"native::L2_P2":3,"native::L3_P14":2}
    for name,high in required.items():
        v=primitives[name];count=high-v.first_power;modified=dict(primitives)
        modified[name]=FactorJet(v.first_power,v.coefficients[:count],v.pole_bound_proof,v.source_identity)
        try:compiled.required_primitive_orders(modified,last_epsilon_power=1)
        except MissingCoefficient:pass
        else:raise AssertionError((name,"missing endpoint accepted"))
    lows=[]
    for (_,_,_,keys),r in plan.terms:
        if any(not factors[k].terms for k in keys):continue
        low=valuation(r)
        for k in keys:low+=min(valuation(rr)+sum(primitives[x].first_power for x in pp) for rr,ss,pp in factors[k].terms)
        lows.append(int(low))
    assert 1-min(lows)<=matching["max_exact_log_degree"]
    values=compiled.evaluate(primitives,first_epsilon_power=-4,last_epsilon_power=1)
    values={(i,int(a),p,l):v for (i,a,p,l),v in values.items()}
    key=producer.key;wanted=[key(row) for row in matching["all_boundary_selectors"]]
    assert len(wanted)==len(set(wanted))==557
    saved={}
    for row in data["coefficients"]:
        label=key(row);assert label not in saved;saved[label]=arb(row["real_ball"])
    assert set(saved)==set(wanted)
    assert all(values[k].is_finite() and saved[k].is_finite() and values[k].overlaps(saved[k]) for k in wanted)
    assert all(v.contains(0) for k,v in values.items() if k not in saved)
    rhs=[saved[key(row)] for row in matching["selected_selectors"]]
    fresh=[sum((rhs[j]*fmpq(value) for j,value in enumerate(row) if value!="0"),arb(0)) for row in matching["boundary_inverse"]]
    constants=[arb(v) for v in data["free_constant_balls"]];assert len(constants)==len(fresh)==132
    assert all(a.is_finite() and a.overlaps(b) for a,b in zip(constants,fresh))
    for label,row in zip(wanted,matching["all_boundary_matrix"]):
        residual=sum((fresh[j]*fmpq(value) for j,value in enumerate(row) if value!="0"),arb(0))-saved[label]
        assert residual.contains(0)
    target=(arb(10)**-20550).lower();precision={}
    for group,vs in [("saved_rows",[saved[k] for k in wanted]),("saved_constants",constants),("recomputed_constants",fresh)]:
        records=[]
        for i,v in enumerate(vs):
            assert v.is_finite() and v.rad().upper()<target and 2*v.rad().upper()<target
            record={"index":i,"exact_zero":v.is_zero(),"uncertain_zero":v.contains(0) and not v.is_zero(),"radius_upper":upper_decimal(v.rad())}
            if not v.is_exact() and not v.contains(0):record["relative_decimal_digits_lower_bound"]=int((-(v.rad()/abs(v).lower()).upper().log()/arb(10).log()).lower().floor().fmpz())
            records.append(record)
        precision[group]={"count":len(vs),"maximum_absolute_radius_upper":upper_decimal(max(v.rad() for v in vs)),"minimum_relative_decimal_digits_nonzero_inexact":min(r["relative_decimal_digits_lower_bound"] for r in records if "relative_decimal_digits_lower_bound" in r),"exact_zero_count":sum(r["exact_zero"] for r in records),"uncertain_zero_count":sum(r["uncertain_zero"] for r in records),"all_radius_and_diameter_below_10_to_minus20550":True,"records":records}
    assert arb(guard["maximum_constant_radius"]).is_finite() and arb(guard["maximum_constant_radius"]).upper()<(arb(10)**-20550).lower()
    # The guard records pre-serialization radii. Saved decimal balls can be slightly wider; both are checked independently.
    for k,p in paths.items():assert sha(p)==hashes[k],(k,"changed during audit")
    for path,digest in nested_pins.items():assert sha(path)==digest
    report={"schema":"vakint.pr9.API20600-boundary-independent-reassembly.v1","accepted":True,
      "scope":"Source bindings, exact support and raw normalization, full PR9 boundary reassembly/matching, and actual 20550-digit absolute input guard. Independent AP20600 bridge and21000sunset proofs are hash-bound here; no propagated endpoint or whole-period claim.",
      "absolute_source_guard_digits":20550,"final_transport_target_digits":20500,"audit_working_decimal_digits":20950,
      "boundary_sha256":hashes["boundary"],"guard_receipt_sha256":hashes["guard_validation"],"native_API_bridge_sha256":hashes["native_api_bridge"],
      "source_error_quality":"rigorous-bound","matching_exact_audit_and_source_pins_verified":True,"sunset_rigorous_source_chain_verified":True,
      "API_exports_match_accepted_hashes":True,"API_bridge_downstream_Euler_conversion_count":0,"API_to_raw_Euler_conversion_count":1,
      "source_recipe_count":231,"raw_Euler_weight_monomials_checked":monomial_count,"required_primitive_orders":required,
      "all_three_missing_endpoint_controls_rejected":True,"minimum_uncancelled_source_Laurent_support":min(lows),"maximum_log_needed_through_epsilon1":1-min(lows),
      "full_rows_reassembled":557,"constants_recomputed":132,"all557overdetermined_residuals_contain_zero":True,
      "precision":precision,"large_primitive_production_or_native_transport_duplicated":False,"producer_files_modified":False,
      "propagated_endpoint_or_whole_period_precision_claimed":False,
      "artifact_sha256":{k:{"path":str(p),"sha256":hashes[k]} for k,p in paths.items()},
      "nested_source_pins":[{"path":p,"sha256":digest} for p,digest in sorted(nested_pins.items())],
      "historical_non_scientific_pin_changes":historical_non_scientific_pin_changes,
      "seconds":time.monotonic()-start,"peak_rss_bytes":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024}
    (HERE/"boundary-reassembly-receipt.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({k:v for k,v in report.items() if k not in ["artifact_sha256","nested_source_pins","precision"]},indent=2))
    print(json.dumps({k:{kk:vv for kk,vv in v.items() if kk!="records"} for k,v in precision.items()},indent=2))


if __name__=="__main__":main()
