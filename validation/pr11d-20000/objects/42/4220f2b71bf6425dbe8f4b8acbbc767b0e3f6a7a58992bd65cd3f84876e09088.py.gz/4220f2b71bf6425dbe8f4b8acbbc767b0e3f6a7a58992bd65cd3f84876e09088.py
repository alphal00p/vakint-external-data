#!/usr/bin/env python3
"""Independent checker/data review; never invokes producer or native programs."""
import argparse,hashlib,json,resource,sys,time
from fractions import Fraction as Q
from pathlib import Path
from flint import arb,ctx
sys.set_int_max_str_digits(300000)
HERE=Path(__file__).resolve().parent; REVIEW=HERE.parent
PR11=REVIEW.parents[2]; PERIODS=PR11.parent
NATIVE=PR11/'helper/frobenius-transport/native'; BASE=PERIODS/'bessel/ancestor-boundary'
CHECKER_SHA='dabc9c8ddba36e33ac77f4b55fd1cdbde2884df318847ee280ccfd582ee9995d'
RUNNER_SHA='eb43160b64c01504099d8421387a649bfdebfde3cb0a480d3d575ef68f4e57c6'
EXPECTED={
 'initial':(NATIVE.parent/'pr9-API20280-eta256-guard20220-v1.json','e82c3c649f9e48df240d4be2b058e78148a75bde273197ca7299f6a26c13ed7f'),
 'source':(BASE/'pr9-boundary-API20280-working20400.json','8b35db3637aed6c4654a8b86bd3501b6357bff64c719aa52dc352b72eb4bc9b9'),
 'input':(NATIVE/'pr9-API20280-init-v1.in','826de190c795c5fd8a5b6b36bf63715a8b98a997e4825d8ec6aa222f3ee72ce8'),
 'output':(NATIVE/'pr9-API20280-init-v1-output.json','91186644e6a7c04862dab7c53127caaeea2cca71d6ff50b0839511cf18372b6b'),
 'native_source':(NATIVE/'contracted_v2.c','5f9c381280172f1d388a3661fb13a3a799848391c29b334e5c1ebc150879ff60'),
 'native_binary':(NATIVE/'contracted-native-v2','ff3d297816b301c010fb8ee4645207ecdec0f74cf8e7a8678b678d5bfb3175c3'),
 'source_proof':(PR11/'helper/pr9-api-boundary-review/pr9-source-review-receipt.json','2190357dd5232fe4d44b056ac555a711136f0f42af31ce3a30ce613e05b9282e'),
 'outward_proof':(PR11/'helper/pr9-proto1000-init-review/source-box-review.json','3a024807e6b37ee7b0aede682b31d8daa3f134da223c0cc90b7b8089c186066e')}
pins={}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p,d=None):
    p=Path(p);assert p.is_absolute() and p.is_file() and not p.is_symlink()
    h=sha(p)
    if d is not None:assert h==d,(str(p),h,d)
    assert str(p) not in pins or pins[str(p)]==h
    pins[str(p)]=h;return h
def read(p):
    def unique(rows):
        d={}
        for k,v in rows:assert k not in d;d[k]=v
        return d
    return json.loads(Path(p).read_text(),object_pairs_hook=unique,parse_constant=lambda s:(_ for _ in ()).throw(ValueError(s)))
def graph(data):
    if isinstance(data,list):
        for item in data:graph(item)
    elif isinstance(data,dict):
        if isinstance(data.get('path'),str) and isinstance(data.get('sha256'),str):pin(data['path'],data['sha256'])
        for k,v in data.items():
            if isinstance(k,str) and k.startswith('/') and isinstance(v,str) and len(v)==64:pin(k,v)
            elif isinstance(v,(dict,list)):graph(v)
def box(s):
    if s.startswith('['):
        assert s.endswith(']');c,r=s[1:-1].split('+/-');c=Q(c.strip() or '0');r=Q(r.strip())
    else:c,r=Q(s),Q(0)
    assert r>=0;return c,r
def save(name,data):
    p=HERE/name
    with p.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
    print(json.dumps({'path':str(p),'sha256':sha(p),'accepted':data.get('accepted'),'pins':len(data.get('source_pins',{}))}))
def initial_review():
    start=time.monotonic();pin(REVIEW/'admit_initial.py',CHECKER_SHA);pin(REVIEW/'replay.py',RUNNER_SHA)
    for p,d in EXPECTED.values():pin(p,d)
    prior_path=REVIEW/'source-checks-v2.json';prior=read(prior_path);pin(prior_path,'671afca71b06dbe3af1126d026043dd71549a1443f491de95139854bb50d8418')
    assert prior['implementation_sha256'][str(REVIEW/'admit_initial.py')]==CHECKER_SHA
    for p,d in prior['source_pins'].items():pin(p,d)
    source_proof=read(EXPECTED['source_proof'][0]);outward=read(EXPECTED['outward_proof'][0])
    graph(source_proof);graph(outward)
    for row in source_proof['receipts']:
        pin(row['path'],row['sha256']);graph(read(row['path']))
    assert source_proof['accepted_for_source_and_native_input_scope']
    assert source_proof['API_exports_full_metadata_formula_and_exact_binary_enclosure_chain_verified']
    assert source_proof['FMFT_to_raw_Euler_conversions']==1 and source_proof['downstream_additional_Euler_conversions']==0
    assert outward['accepted'] and not outward['overlap_used_as_acceptance']
    assert outward['source_working_decimal_digits']==20400
    assert outward['source_boundary_outward_strings_reproduced_exactly']==557
    assert outward['source_matched_constant_outward_strings_reproduced_exactly']==132
    assert outward['artifact_sha256']['source_boundary']['sha256']==EXPECTED['source'][1]
    source=read(EXPECTED['source'][0]);matching_path=PR11/'ancestor-flows/pr9-22-matching.json'
    pin(matching_path,source['matching_sha256']);matching=read(matching_path)
    exact_path=PR11/'helper/ancestor-matching-review/pr9-22-audit-receipt.json';exact=read(exact_path);graph(exact)
    assert exact['accepted_for_exact_preparation_scope'] and exact['dimension']==132
    assert exact['residue_root_multiplicities']=={'-4':30,'-3':72,'-2':24,'-1':6}
    assert exact['first_continuation_power']==0 and exact['generic_all_orders_log_degree_bound']==8
    key=lambda r:tuple(r[k] for k in ('component','integer_z_power','epsilon_power','log_power'))
    source_rows={key(r):box(r['real_ball']) for r in source['coefficients']}
    assert len(source_rows)==len(source['coefficients'])==557
    assert set(source_rows)=={key(r) for r in matching['all_boundary_selectors']}
    selected=[source_rows[key(r)] for r in matching['selected_selectors']]
    assert len(selected)==len(matching['boundary_inverse'])==132
    lines=EXPECTED['input'][0].read_text().splitlines();header=lines[0].split();h=list(map(int,header[1:]))
    dim,logs,nb,nc,nmin,nmax,dd,bd,np,nr,ns,bits,digits,maxorder,every=h
    assert header[0]=='FROB_V1' and (dim,logs,nb,nc,nmin,nmax,dd,bd,np,nr,ns,bits,digits)==(132,9,84,132,-4,-1,8,10,1297,809,38363,68100,20320)
    assert lines[1]=='0 -1 256'
    offset=5+(dd+1)+np*(bd+2)+1+nr+ns+dim
    assert len(lines)==offset+132;ctx.prec=bits
    checks=[]
    for i,row in enumerate(matching['boundary_inverse']):
        assert len(row)==132
        weights=[(j,Q(q)) for j,q in enumerate(row) if q!='0']
        center=sum((q*selected[j][0] for j,q in weights),Q(0))
        radius=sum((abs(q)*selected[j][1] for j,q in weights),Q(0))
        real,imag=lines[offset+i].split('|');assert imag=='0';value=arb(real);assert value.is_finite()
        mid,rad=Q(str(value.mid().fmpq())),Q(str(value.rad().fmpq()))
        assert mid-rad<=center-radius and center+radius<=mid+rad
        assert rad<Q(1,10**20240)
        checks.append({'index':i,'full_exact_matched_source_box_contained_in_actual_seed':True})
    initial=read(EXPECTED['initial'][0]);output=read(EXPECTED['output'][0])
    assert initial['values']==output['original_Y_values']
    for k,n in [('native_input_sha256','input'),('native_output_sha256','output'),('source_boundary_sha256','source'),('native_source_sha256','native_source'),('native_binary_sha256','native_binary')]:assert initial[k]==EXPECTED[n][1]
    for stem in ['original_source_equation','ordinary_polynomial_connection','source_boundary','independent_source_review','independent_three_loop_flow_crosscheck']:
        pin(initial[stem+'_path'],initial[stem+'_sha256'])
    assert initial['normalization']=='native_raw' and initial['basis']=='original_raw_epsilon_jets' and initial['eta_center']==['0','256']
    assert output['working_bits']==68100 and output['digits']==output['target_absolute_digits']==20320 and output['order']==16500
    assert output['local_tail_certified'] and output['exact_residue_identity_verified']
    for field in ['normalized_J_values','original_Y_values']:
        assert len(output[field])==132
        for real,imag in output[field]:assert box(real)[1]+box(imag)[1]<Q(1,10**20220)
    # Hand-audited code evidence is part of this script's fixed review statement.
    pin(__file__)
    for p,d in list(pins.items()):pin(p,d)
    report={'schema':'vakint.pr9.production-A.initial-independent-static-review.v1','accepted':False,'accepted_for_checker_and_frozen_artifact_scope':True,'status':'checker_and_frozen_data_passed_pending_fresh_invocation','validator_sha256':CHECKER_SHA,'runner_sha256':RUNNER_SHA,'initial_artifact_sha256':EXPECTED['initial'][1],'all_source_and_wrapper_bindings_verified':True,'all_132_exact_source_seed_boxes_verified':True,'fresh_same_input_same_binary_replay_verified':False,'seed_checks':checks,'source_pins':dict(sorted(pins.items())),'code_review_findings':[],
      'code_evidence':[
       {'path':str(REVIEW/'admit_initial.py'),'lines':[30,46,78,92,110,123,126,150],'conclusion':'Fixed source proof2190357 and outward proof3a024807 plus nested scientific pins bind the admitted physical boundary and exact prefix. The lower-precision proto seed portion is explicitly not reused.'},
       {'path':str(REVIEW/'admit_initial.py'),'lines':[151,179],'conclusion':'Duplicate/source coverage checks and strict132-row zip precede exact signed-rational center and absolute-weight radius propagation. Both endpoints must fit actual68100-bit seed binary balls; exact outward preparer strings also match. This reviewer independently reran all132 full-box inequalities without source production.'},
       {'path':str(REVIEW/'admit_initial.py'),'lines':[131,150,180,194],'conclusion':'Wrapper copies native Y exactly, binds code/binary/input/output, and applies a separate absolute total-radius gate.'},
       {'path':str(REVIEW/'replay.py'),'lines':[7,17,24,49],'conclusion':'Runner binds same input/binary/source/original output before and after a fresh non-overwriting subprocess invocation; all numerical and contract fields must match after excluding only five timing/RSS fields.'},
       {'path':str(REVIEW/'admit_initial.py'),'lines':[206,216,246],'conclusion':'Final admission fails closed unless the fresh invocation and independently pinned checker/data review both pass and bind this exact checker, initial artifact, source graph and invocation.'}],
      'limits':['Fresh invocation remains pending and is not accepted by this static receipt.','Source assembly/HPL/preparer/native execution was not repeated; accepted source proofs and exact-preparation mathematics were reused by frozen hashes.','The pinned source-checks-v2.json uses this exact reviewed checker; this review independently verifies actual seed containment and output decimal width.','No subsequent RPF/adjoint/endpoint or whole-master result, nor independent physical IBP derivation, is certified.'],
      'producer_files_modified':False,'native_preparer_or_source_production_executed':False,'seconds':time.monotonic()-start}
    save('static-review.json',report)
def finalize():
    static_path=HERE/'static-review.json';static=read(static_path)
    assert static['accepted_for_checker_and_frozen_artifact_scope'] and static['validator_sha256']==CHECKER_SHA
    for p,d in static['source_pins'].items():pin(p,d)
    pin(static_path);inv_path=REVIEW/'invocation.json';inv=read(inv_path);pin(inv_path)
    assert inv['accepted_same_input_same_binary_replay'] and inv['returncode']==0 and inv['all_numerical_history_and_contract_fields_equal']
    assert inv['runner_sha256']==RUNNER_SHA
    assert inv['command']==[str(EXPECTED['native_binary'][0]),str(EXPECTED['input'][0]),str(REVIEW/'replayed-native-output.json')]
    ep={str(EXPECTED[k][0]):EXPECTED[k][1] for k in ['input','output','native_source','native_binary']}
    assert inv['source_sha256_before']==inv['source_sha256_after']==ep and inv['source_files_unchanged']
    assert inv['environment_overrides']=={'OMP_NUM_THREADS':'4','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','OMP_DYNAMIC':'FALSE'}
    assert inv['address_space_limit_bytes']==2<<30 and len(set(inv['cpu_affinity']))==4
    for name,key in [('replay.py','runner_sha256'),('replayed-native-output.json','output_sha256'),('native.stderr','stderr_sha256'),('native.stdout','stdout_sha256')]:pin(REVIEW/name,inv[key])
    fresh=read(REVIEW/'replayed-native-output.json');original=read(EXPECTED['output'][0])
    excluded=['seconds','setup_seconds','initialization_seconds','certificate_seconds','peak_rss_bytes']
    assert inv['excluded_timing_and_resource_fields_only']==excluded
    assert {k:v for k,v in fresh.items() if k not in excluded}=={k:v for k,v in original.items() if k not in excluded}
    assert inv['compared_fields']==sorted(k for k in original if k not in excluded)
    assert not inv['unequal_fields']
    for field in ['normalized_J_values','original_Y_values']:
        assert len(fresh[field])==132 and fresh[field]==original[field]
        assert inv[field+'_count']==132 and inv[field+'_byte_identical_strings']
    report={'schema':'vakint.pr9.production-A.initial-independent-final-review.v1','accepted':True,'status':'passed_for_frozen_production_A_initial_admission_checker_and_data','validator_sha256':CHECKER_SHA,'initial_artifact_sha256':EXPECTED['initial'][1],'native_invocation_sha256':sha(inv_path),'all_source_and_wrapper_bindings_verified':True,'all_132_exact_source_seed_boxes_verified':True,'fresh_same_input_same_binary_replay_verified':True,'static_review_path':str(static_path),'static_review_sha256':sha(static_path),'source_pins':dict(sorted(pins.items())),'both_132_arrays_identical_to_frozen_original':True,'comparison_excluded_fields':excluded,'native_or_producer_execution_by_reviewer':False,'whole_master_or_independent_IBP_claimed':False}
    for p,d in pins.items():assert sha(p)==d
    save('review.json',report)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--finalize',action='store_true');args=parser.parse_args()
    resource.setrlimit(resource.RLIMIT_AS,(2<<30,2<<30));resource.setrlimit(resource.RLIMIT_CPU,(120,125))
    finalize() if args.finalize else initial_review()
