#!/usr/bin/env python3
"""Independent exact H5/H6 audit: labeled partitions and binomial PF formulas.

Does not import the producer's derive_h or mzv modules. Uses the original
summation index n, H_n, explicit exponential partitions, and an independently
assembled rational MZV linear system. Runtime is bounded externally.
"""
from collections import Counter, defaultdict
from fractions import Fraction as F
from functools import cache
from itertools import combinations, product
from math import comb, factorial
from pathlib import Path
import hashlib, json, time
from flint import fmpq, fmpq_mat

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent.parent/'p853'/'higher-order'

def incr(out,key,value):
    out[key]=out.get(key,F(0))+value
    if not out[key]: del out[key]

@cache
def ordered_blocks(labels):
    """Ordered set partitions of labeled harmonic factors, then forget labels."""
    if not labels: return {():1}
    out=Counter(); last=labels[-1]
    for w,c in ordered_blocks(labels[:-1]).items():
        for j in range(len(w)+1): out[w[:j]+(last,)+w[j:]]+=c
        for j in range(len(w)): out[w[:j]+(w[j]+last,)+w[j+1:]]+=c
    return dict(out)

@cache
def pf(a,b):
    """1/[n^a(n+1)^b], from the binomial expansions at 0 and -1."""
    assert a>0 and b>0
    terms=[(0,p,F((-1)**(a-p)*comb(b+a-p-1,a-p))) for p in range(1,a+1)]
    terms += [(1,p,F((-1)**a*comb(a+b-p-1,b-p))) for p in range(1,b+1)]
    # Verify polynomial equality after clearing the common denominator.
    polynomial=Counter()
    for center,p,c in terms:
        left=a-p if center==0 else a
        right=b if center==0 else b-p
        for j in range(right+1):polynomial[left+j]+=c*comb(right,j)
    assert {k:v for k,v in polynomial.items() if v}=={0:F(1)}
    return terms

def mul_expr(a,b):
    out={}
    for (hs,x,y),c in a.items():
        for (ks,u,v),d in b.items():incr(out,(tuple(sorted(hs+ks)),x+u,y+v),c*d)
    return out

def multiplicities(total,k=1):
    if k>total:
        yield {}
        return
    # Return partitions with multiplicities, with all allowed part sizes <= total.
    def rec(remaining,j):
        if j>total:
            if remaining==0:yield {}
            return
        for count in range(remaining//j+1):
            for tail in rec(remaining-count*j,j+1):
                if count:tail={j:count,**tail}
                yield tail
    yield from rec(total,1)

def harmonic_expression(q):
    # [e^q] exp(sum e^k L_k), by partitions, no differential recurrence.
    result={}
    for counts in multiplicities(q):
        term={((),0,0):F(1)}
        for k,m in counts.items():
            big=4**k+2**k
            lk={((k,),0,0):F(4**k-1,k), ((),k,0):F(1,k),
                ((),0,k):F(big,k), ((),0,0):F(-big,k)}
            for _ in range(m):term=mul_expr(term,lk)
            term={key:c/factorial(m) for key,c in term.items()}
        for key,c in term.items():incr(result,key,c)
    return result

def coefficient_mzv(order):
    mzv={}; constant=F(0); expr=harmonic_expression(order-1)
    for (hs,a,b),coef in expr.items():
        for word,mult in ordered_blocks(hs).items():
            for center,p,c in pf(a+1,b+2):
                c *= -coef*mult  # H=1-e sum(...)
                incr(mzv,(p,)+word,c)
                if center==0 and word:incr(mzv,(p+word[0],)+word[1:],c)
                if center==1 and not word:constant-=c
    assert all(w[0]>1 for w in mzv)
    return mzv,constant,len(expr)

def compositions(weight):
    # Cut positions in a row of 'weight' unit marks.
    if weight==0:return [()]
    out=[]
    for mask in range(1<<(weight-1)):
        cuts=[0]+[j+1 for j in range(weight-1) if (mask>>j)&1]+[weight]
        out.append(tuple(b-a for a,b in zip(cuts,cuts[1:])))
    return sorted(out)

def to_binary(w):return tuple(bit for k in w for bit in [0]*(k-1)+[1])
def from_binary(w):
    assert w[-1]==1
    out=[];start=0
    for j,b in enumerate(w):
        if b:out.append(j+1-start);start=j+1
    return tuple(out)

@cache
def shuffle_words(a,b):
    out=Counter();size=len(a)+len(b)
    for apos in combinations(range(size),len(a)):
        aset=set(apos);ia=iter(a);ib=iter(b)
        w=tuple(next(ia) if j in aset else next(ib) for j in range(size))
        out[from_binary(w)]+=1
    return out

@cache
def stuffle_words(a,b):
    # Enumerate monotone lattice paths; diagonal steps identify the two indices.
    stack=[(0,0,())];out=Counter()
    while stack:
        i,j,w=stack.pop()
        if i==len(a) and j==len(b):out[w]+=1
        if i<len(a):stack.append((i+1,j,w+(a[i],)))
        if j<len(b):stack.append((i,j+1,w+(b[j],)))
        if i<len(a) and j<len(b):stack.append((i+1,j+1,w+(a[i]+b[j],)))
    return out

def poly_mul(a,b):
    out={}
    for x,c in a.items():
        for y,d in b.items():incr(out,tuple(u+v for u,v in zip(x,y)),c*d)
    return out

def independent_reductions(maxweight=7):
    known={};evidence=[]
    for wt in range(2,maxweight+1):
        words=[w for w in compositions(wt) if w[0]>=2]
        mons=[m for m in product(range(4),range(3),range(2),range(2)) if sum(x*y for x,y in zip(m,(2,3,5,7)))==wt]
        rows=[]
        def addrow(lhs,rhs=None):
            rhs=rhs or {}
            assert all(w in words for w,c in lhs.items() if c)
            row=[F(lhs.get(w,0)) for w in words]+[-F(rhs.get(m,0)) for m in mons]
            rows.append([fmpq(c.numerator,c.denominator) for c in row])
        for w in words:
            d=from_binary(tuple(1-b for b in to_binary(w)[::-1]))
            lhs=Counter({w:1});lhs[d]-=1;addrow(lhs)
        for split in range(2,wt-1):
            for a in [w for w in compositions(split) if w[0]>=2]:
                for b in [w for w in compositions(wt-split) if w[0]>=2]:
                    rhs=poly_mul(known[a],known[b])
                    addrow(stuffle_words(a,b),rhs)
                    addrow(shuffle_words(to_binary(a),to_binary(b)),rhs)
        for b in [w for w in compositions(wt-1) if w[0]>=2]:
            lhs=stuffle_words((1,),b).copy()
            for w,c in shuffle_words((1,),to_binary(b)).items():lhs[w]-=c
            addrow(lhs)
        generator={2:{(1,0,0,0):F(1)},3:{(0,1,0,0):F(1)},
                   4:{(2,0,0,0):F(2,5)},5:{(0,0,1,0):F(1)},
                   6:{(3,0,0,0):F(8,35)},7:{(0,0,0,1):F(1)}}[wt]
        addrow({(wt,):1},generator)
        rr,rank=fmpq_mat(rows).rref()
        assert rank==len(words)
        for i,w in enumerate(words):
            assert all(rr[i,j]==int(i==j) for j in range(len(words)))
            known[w]={m:F(-int(rr[i,len(words)+j].numerator),int(rr[i,len(words)+j].denominator)) for j,m in enumerate(mons) if rr[i,len(words)+j]}
        evidence.append({'weight':wt,'convergent_words':len(words),'relations':len(rows),'augmented_rank':rank})
    return known,evidence

def encode_poly(poly):return [{'powers':list(m),'rational':[c.numerator,c.denominator]} for m,c in sorted(poly.items())]

def finite_sum_checks():
    # Compare harmonic expression to direct finite Pochhammer-product series.
    def conv(a,b,K):return [sum((a[j]*b[i-j] for j in range(i+1)),F(0)) for i in range(K+1)]
    K=5;checks=0
    for n in range(1,13):
        s=[F(1)]+[F(0)]*K
        for j in range(1,n):s=conv(s,[F(1),F(-1,j)]+[F(0)]*(K-1),K)
        s=conv(s,[F(1),F(-2)]+[F(0)]*(K-1),K)
        s=conv(s,[F(2,n+1)**k for k in range(K+1)],K)
        for j in range(2,n+2):s=conv(s,[F(4,j)**k for k in range(K+1)],K)
        hs={k:sum((F(1,j**k) for j in range(1,n+1)),F(0)) for k in range(1,K+1)}
        for q in range(K+1):
            val=F(0)
            for (word,a,b),c in harmonic_expression(q).items():
                val+=c*prod_f(hs[k] for k in word)/n**a/(n+1)**b
            assert val==s[q];checks+=1
    return checks

def prod_f(seq):
    out=F(1)
    for v in seq:out*=v
    return out

def main():
    start=time.monotonic();reductions,evidence=independent_reductions()
    rows=[]
    for order in range(1,7):
        terms,constant,count=coefficient_mzv(order)
        out={(0,0,0,0):constant} if constant else {}
        for word,c in terms.items():
            for mon,d in reductions[word].items():incr(out,mon,c*d)
        rows.append({'epsilon_power':order,'terms':encode_poly(out),
                     'before_MZV_reduction':[{'indices':list(w),'rational':[c.numerator,c.denominator]} for w,c in sorted(terms.items())],
                     'constant':[constant.numerator,constant.denominator],
                     'harmonic_monomial_count':count})
        print(order, out,flush=True)
    for filename in ['H-through-epsilon5.json','H-through-epsilon6.json']:
        source=json.loads((SOURCE/filename).read_text())
        for source_row in source['coefficients']:
            i=source_row['epsilon_power']-1
            got={tuple(t['powers']):tuple(t['rational']) for t in rows[i]['terms']}
            want={tuple(t['powers'])+(0,)*(4-len(t['powers'])):tuple(t['rational']) for t in source_row['terms']}
            assert got==want
        for filename,digest in source['source_sha256'].items():
            assert hashlib.sha256((SOURCE/filename).read_bytes()).hexdigest()==digest
    checked=finite_sum_checks()
    report={'schema':'vakint.p853.higher-H.independent-exact-replay.v1',
            'producer_modules_imported':False,'all_H1_through_H6_match':True,
            'producer_report_source_hashes_match':True,
            'finite_Pochhammer_coefficient_checks':checked,
            'monomial_order':['zeta2_power','zeta3_power','zeta5_power','zeta7_power'],
            'coefficients':rows,'MZV_reduction_evidence':evidence,
            'all_binomial_partial_fractions_cleared_denominator_verified':True,
            'all_divergent_leading_one_MZVs_cancel':True,
            'seconds':time.monotonic()-start,
            'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [SOURCE/f for f in ['derive_h.py','mzv.py','H-through-epsilon5.json','derive_h_weight7.py','mzv_weight7.py','H-through-epsilon6.json']]+[Path(__file__)]},
            'numerical_PR11d_accuracy_claimed':False}
    (HERE/'independent-exact.json').write_text(json.dumps(report,indent=2)+'\n')
    print('checks',checked,'seconds',report['seconds'],flush=True)

if __name__=='__main__':main()
