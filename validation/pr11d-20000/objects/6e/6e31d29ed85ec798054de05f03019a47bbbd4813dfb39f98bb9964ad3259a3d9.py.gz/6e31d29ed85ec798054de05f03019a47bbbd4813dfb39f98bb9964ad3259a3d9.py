#!/usr/bin/env python3
"""Exact matroid/Hepp-sector convergence certificate for physical dotted PR11d."""
from pathlib import Path
from fractions import Fraction as Q
from itertools import combinations
from math import isqrt
import json,hashlib
ROOT=Path(__file__).resolve().parent.parent
SOURCE=Path('/shared/codex-2/vacuum_masters/MASTERS/4L/artifacts/X8-Kira-derivative-closure-v1/prepared-system.json')
UID='L4_693719b1bc3d2f1d4d32c9312df66ced667a542591a2ada6f6498844fc5d0de1_p0_p2_p1_p1_p1_p1_p1_p1_p1_p0'
REFERENCE=Path('/shared/codex-2/vacuum_masters/MASTERS/4L')/UID/'artifacts'/(UID+'_reference_input.json')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
if not __debug__:raise RuntimeError('Exact acceptance requires assertions enabled')
def rank(rows):
 rows=[list(map(Q,row)) for row in rows];r=0
 for col in range(4):
  pivot=next((i for i in range(r,len(rows)) if rows[i][col]),None)
  if pivot is None:continue
  rows[r],rows[pivot]=rows[pivot],rows[r];value=rows[r][col];rows[r]=[v/value for v in rows[r]]
  for i in range(r+1,len(rows)):
   value=rows[i][col]
   if value:rows[i]=[a-value*b for a,b in zip(rows[i],rows[r])]
  r+=1
 return r
def determinant(rows):
 rows=[list(map(Q,row)) for row in rows];out=Q(1)
 for c in range(4):
  p=next((i for i in range(c,4) if rows[i][c]),None)
  if p is None:return Q(0)
  if p!=c:rows[p],rows[c]=rows[c],rows[p];out=-out
  v=rows[c][c];out*=v
  for i in range(c+1,4):
   q=rows[i][c]/v
   for j in range(c,4):rows[i][j]-=q*rows[c][j]
 return out

def main():
 source=json.loads(SOURCE.read_text());reference=json.loads(REFERENCE.read_text());family=source['family'];L=4
 assert reference['master_id']==UID and reference['loop_count']==4
 assert source['source_family_sha256']==family['sha256']==reference['family_sha256']
 powers=reference['powers'];assert powers==[0,2,1,1,1,1,1,1,1,0]
 assert len(family['coordinates'])==10 and len(family['denominators'])==len(powers)
 vectors=[]
 for prop in family['denominators']:
  assert Q(prop['constant'])==-1,'All undeformed physical masses must be unit positive'
  matrix=[[Q(0) for _ in range(L)] for _ in range(L)]
  for coord,coefficient in zip(family['coordinates'],prop['coefficients']):
   assert coord['kind']=='loop_loop';i,j=coord['left'],coord['right'];q=Q(coefficient)
   if i==j:matrix[i][j]=q
   else:matrix[i][j]=matrix[j][i]=q/2
  p=next(i for i in range(L) if matrix[i][i]);n=isqrt(matrix[p][p].numerator);d=isqrt(matrix[p][p].denominator)
  assert n*n==matrix[p][p].numerator and d*d==matrix[p][p].denominator
  v0=Q(n,d);vector=[matrix[p][i]/v0 for i in range(L)]
  assert all(matrix[i][j]==vector[i]*vector[j] for i in range(L) for j in range(L));vectors.append(vector)
 active=[i for i,p in enumerate(powers) if p>0];V=[vectors[i] for i in active];nu=[powers[i] for i in active]
 assert len(active)==8 and sum(nu)==9 and rank(V)==4
 reductions=[r for r in source['target_reductions'] if r['powers']==powers];assert len(reductions)==1
 reduced={tuple(t['powers']):t['coefficient'] for t in reductions[0]['terms']}
 expected={tuple(source['basis'][30]):'1',tuple(source['basis'][36]):'-1',tuple(source['basis'][37]):'-1*masters_4l::{}::epsilon',tuple(source['basis'][38]):'-1'}
 assert reduced==expected,'Physical target must be the actual projected PR11d combination'
 bases=[]
 for subset in combinations(range(8),4):
  coefficient=determinant([V[i] for i in subset])**2
  if coefficient:bases.append({'active_indices':list(subset),'coefficient':str(coefficient)})
 assert len(bases)==45 and all(Q(b['coefficient'])>0 for b in bases)
 checks=[]
 for mask in range(1,255):
  selected=[i for i in range(8) if mask>>i&1];outside=[V[i] for i in range(8) if not(mask>>i&1)]
  u=L-rank(outside);minimum=min(sum(i in selected for i in b['active_indices']) for b in bases)
  assert minimum==u,'Determinantal matroid face valuation mismatch'
  nu_sum=sum(nu[i] for i in selected);margin=nu_sum-2*u
  assert margin>0 and Q(margin)-Q(1,8)*u>0,'A UV face would prevent holomorphy near epsilon0'
  checks.append({'active_subset_mask':mask,'outside_rank':L-u,'U_face_valuation':u,'sum_propagator_powers':nu_sum,'D4_face_margin':margin,'closed_epsilon_disc_1_over_8_margin':str(Q(margin)-Q(1,8)*u)})
 global_margin=sum(nu)-2*L;assert global_margin==1 and Q(global_margin)-Q(L,8)>0
 result={'schema':'vakint.pr11d.exact-physical-finiteness-certificate.v1','status':'passed_all_254_proper_faces_and_overall_scaling','master_id':UID,'family_sha256':family['sha256'],'powers':powers,'original_X8_source_path':str(SOURCE),'original_X8_source_sha256':sha(SOURCE),'canonical_reference_input_path':str(REFERENCE),'canonical_reference_input_sha256':sha(REFERENCE),'validator_sha256':sha(Path(__file__)),'loop_count':4,'active_slot_indices':active,'ordered_active_vectors':[[str(q) for q in v] for v in V],'ordered_active_powers':nu,'positive_U_bases':bases,'UV_face_checks':checks,'overall_Gamma_argument_at_epsilon0':global_margin,'holomorphy_closed_epsilon_disc_radius':'1/8','all_physical_masses_positive_unit':True,'infrared_singularities_absent':True,'all_negative_Laurent_coefficients_exactly_zero':True,'FMFT_equals_native_finite_coefficient':True,'Minkowski_overall_sign':-1,'proof':['Cauchy-Binet gives U=sum_B det(V_B)^2 product_(i in B)alpha_i, all45basiscoefficientspositive. The independently checked face valuation is u(S)=4-rank(V_outsideS).','Partition the projective positive simplex into Hepp sectors. The matroid greedy basis simultaneously realizes every nested-prefix face valuation. Its positive monomial lower-bounds U on the sector, so each ordered scale integral is bounded by a product with exponent sum_(i in S)nu_i-(2-Re(epsilon))*u(S)-1. All254 proper faces have positive exponent+1, uniformly for |epsilon|<=1/8.','Overall Schwinger scaling supplies Gamma(N-4*(2-epsilon))=Gamma(1+4epsilon), holomorphic for the same disc. Unit masses remove projective mass-denominator zeros and large-distance IR divergences. Dominated holomorphic parameter integration therefore proves absence of all epsilon poles.','The physical projected target is checked exactly against the authenticated target_reductions row. Native and FMFT differ only by exp(4EulerGamma*epsilon); since the physical poles vanish exactly, their finite coefficients coincide. The total propagator power9 gives Wick sign(-1)^9=-1.'],'scope':'Exact physical target finiteness/normalization only; does not prove each generic raw42integral has poleorder<=4 and does not provide a numerical PR11d value or precision promotion.'}
 output=Path(__file__).resolve().parent/'certificate.json';assert not output.exists();output.write_text(json.dumps(result,indent=2)+'\n');print('Physical PR11d finite:254properfaces+overall scale; all poles exactlyzero;45positiveUterms')
if __name__=='__main__':main()
