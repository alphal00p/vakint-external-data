#!/usr/bin/env python3
"""Frozen-input RPF transport with verified requested and actual native worker counts."""
from pathlib import Path
from fractions import Fraction as Q
import argparse,hashlib,json,os,subprocess,sys,time
from flint import arb,acb,ctx,fmpq
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
PREPARE=HERE/'prepare_scaled_rpf.py'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,obj):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(obj,indent=2)+'\n');tmp.replace(path)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--initial',type=Path,required=True);ap.add_argument('--threads',type=int,choices=[1,2,4,8],default=4);ap.add_argument('--require-final-digits',type=int);ap.add_argument('--initial-contract',type=Path);ap.add_argument('--connection',type=Path,required=True);ap.add_argument('--partial-fractions',type=Path);ap.add_argument('--native',type=Path);ap.add_argument('--digits',type=int,required=True);ap.add_argument('--guard',type=int,default=180);ap.add_argument('--max-order',type=int,default=2500);ap.add_argument('--check-every',type=int,default=50);ap.add_argument('--substeps',type=int,default=4);ap.add_argument('--end-imag',default='1/16');ap.add_argument('--directory',type=Path,required=True);ap.add_argument('--step-timeout',type=int,default=300);args=ap.parse_args()
    assert __debug__ and args.digits>=32 and args.guard>=32 and args.substeps>=1
    args.directory.mkdir(parents=True,exist_ok=True);start=time.monotonic();ctx.dps=args.digits+args.guard;initial_hash=sha(args.initial);prepare_hash=sha(PREPARE)
    initial=json.loads(args.initial.read_text());connection=json.loads(args.connection.read_text());dim=connection['dimension'];jets=connection['epsilon_jet_count'];states=dim*jets
    assert initial['normalization']=='native_raw' and initial['error_quality']=='rigorous-bound'
    assert initial.get('physical_accuracy_certified',True) is not False
    assert (initial.get('local_truncation_rigorously_enclosed',False) or initial.get('local_tail_certified',False)) and len(initial['values'])==states
    assert sha(connection['source'])==connection['source_sha256'];assert jets==6
    assert dim in (7,22,42),'Explicit source support is required for this hierarchy'
    expected_min={7:-3,22:-4,42:-4}[dim]
    assert initial['epsilon_min_power']==expected_min and initial['epsilon_max_power']==expected_min+5
    contract_sha=None
    if args.initial_contract:
        contracts=json.loads(args.initial_contract.read_text())['boundaries'];items=[c for c in contracts if c['artifact_sha256']==initial_hash]
        assert len(items)==1,'Initial artifact not uniquely bound by source contract'
        contract=items[0];contract_sha=sha(args.initial_contract)
        assert sha(contract['artifact_path'])==initial_hash and sha(contract['original_source_equation_path'])==connection['source_sha256']==contract['original_source_equation_sha256']
        assert contract['ordinary_polynomial_connection_sha256']==sha(args.connection) and contract['basis']=='original_raw_epsilon_jets'
        for field,wanted in [('dimension',dim),('jets',jets),('epsilon_min_power',expected_min),('epsilon_max_power',expected_min+5),('normalization','native_raw'),('error_quality','rigorous-bound')]:assert contract[field]==wanted
        assert contract['eta_center']==initial['eta_center']
    else:
        assert initial.get('source_equation_sha256',initial.get('original_source_equation_sha256'))==connection['source_sha256'] and initial['basis']=='original_raw_epsilon_jets'
        if 'original_source_equation_path' in initial:assert sha(initial['original_source_equation_path'])==connection['source_sha256']
        if 'ordinary_polynomial_connection_sha256' in initial:assert initial['ordinary_polynomial_connection_sha256']==sha(args.connection)
        assert initial['dimension']==dim and initial.get('jets',jets)==jets
        if 'run_binding_sha256' in initial:assert sha(args.initial.parent/'run-binding.json')==initial['run_binding_sha256']
    for p,digest in initial.get('matching_and_startup_sources',{}).items():
        path=Path(p);path=path if path.is_absolute() else args.initial.parent/path
        assert sha(path)==digest,'Changed exact startup/matching source'
    
    assert initial['eta_center'][0]=='0';center=Q(initial['eta_center'][1]);end=Q(args.end_imag);assert center>end>0
    current=args.initial;steps=[];weights=connection['regular_epsilon_gauge']['weights'];assert len(weights)==dim
    destinations=[];top=center
    while top>end:
        bottom=max(end,top/2);h=(top-bottom)/args.substeps
        destinations.extend(top-h*k for k in range(1,args.substeps+1));top=bottom
    dependency_paths=[Path(__file__),PREPARE,HERE/'prepare_scaled_segment.py',ROOT/'helper/jet-transport/append_rpf_scaled.py',ROOT/'helper/jet-transport/prepare_generic_segment.py',ROOT/'helper/frobenius-transport/native/prepare_v2.py',args.connection,Path(connection['source']),ROOT/'ancestor-flows/pr9-22-ordinary-rational-pf.json']
    dependencies={str(p.resolve()):sha(p) for p in dependency_paths}
    native=args.native or ROOT/('helper/jet-transport/transport-pf-bounds' if args.partial_fractions else 'helper/jet-transport/transport-rpf')
    run_binding={'initial_sha256':initial_hash,'initial_contract_sha256':contract_sha,'driver_sha256':sha(Path(__file__)),'preparer_sha256':prepare_hash,'connection_sha256':sha(args.connection),'partial_fraction_sha256':sha(args.partial_fractions) if args.partial_fractions else None,'native_sha256':sha(native),'native_path':str(native.resolve()),'preparer_path':str(PREPARE.resolve()),'dimension':dim,'epsilon_jet_count':jets,'normalization':'native_raw','error_quality':'rigorous-bound','source_equation_sha256':connection['source_sha256'],'implementation_and_source_dependency_sha256':dependencies,'required_final_absolute_digits':args.require_final_digits,'native_worker_threads':args.threads,'local_target_digits':args.digits,'guard_digits':args.guard,'end_eta_imag':str(end),'substeps_per_halving':args.substeps}
    manifest_path=args.directory/'run-binding.json'
    if manifest_path.exists():assert json.loads(manifest_path.read_text())==run_binding,'Incompatible run directory reuse'
    else:save(manifest_path,run_binding)
    for destination in destinations:
        assert sha(args.initial)==initial_hash and sha(PREPARE)==prepare_hash and sha(native)==run_binding['native_sha256'],'Frozen initial/helper/native changed during run'
        assert all(sha(p)==pin for p,pin in dependencies.items()),'Frozen source dependency changed during run'
        index=len(steps);input_path=args.directory/f'step-{index:03}.in';output=args.directory/f'step-{index:03}-native.json';target=args.directory/f'step-{index:03}-boundary.json'
        boundary=json.loads(current.read_text());assert [Q(x) for x in boundary['eta_center']]==[Q(0),center] and len(boundary['values'])==states and boundary['error_quality']=='rigorous-bound'
        if target.exists():
            following=json.loads(target.read_text());result=json.loads(output.read_text());assert result['openmp_requested_threads']==args.threads and result['openmp_actual_threads']==args.threads,'Native worker count differs from frozen requested count'
            assert following['previous_boundary_sha256']==sha(current) and following['transport_input_sha256']==sha(input_path) and following['native_output_sha256']==sha(output) and result['local_tail_certified']
            assert following['run_binding_sha256']==sha(manifest_path) and [Q(x) for x in following['eta_center']]==[Q(0),destination]
            metadata=json.loads(input_path.with_suffix('.json').read_text())
            assert metadata['input_sha256']==sha(input_path) and metadata['initial_data_sha256']==sha(current)
            assert metadata['center']==['0',str(center)] and metadata['step']==['0',str(destination-center)]
            assert metadata['source_equation_sha256']==connection['source_sha256'] and metadata['polynomial_connection_sha256']==sha(args.connection)
            assert metadata['dimension']==dim and metadata['jets']==jets and metadata['normalization']=='native_raw' and metadata['source_error_quality']=='rigorous-bound'
            assert metadata['regular_epsilon_gauge']==connection['regular_epsilon_gauge'] and metadata['requested_digits']==args.digits
            assert metadata['rational_pf_source_sha256']==sha(ROOT/'ancestor-flows/pr9-22-ordinary-rational-pf.json')
            assert following['initial_boundary_sha256']==initial_hash and following['source_equation_sha256']==connection['source_sha256']
            raw_again=[];scales=[arb(fmpq(x)) for x in metadata['constant_component_scale']];U_again=[acb(arb(a),arb(b))*scales[i%dim] for i,(a,b) in enumerate(result['values'])]
            for k in range(jets):
                for i in range(dim):raw_again.append(U_again[k*dim+i]-2*U_again[(k-1)*dim+i] if k and weights[i] else U_again[k*dim+i])
            encoded=[[v.real.str(args.digits+args.guard+8,more=True),v.imag.str(args.digits+args.guard+8,more=True)] for v in raw_again]
            assert encoded==following['values'],'Saved following boundary does not match native output/gauge conversion'
    
        else:
            cmd=[sys.executable,str(PREPARE),'--connection',str(args.connection),'--initial-json',str(current),'--output',str(input_path),'--digits',str(args.digits),'--guard',str(args.guard),'--max-order',str(args.max_order),'--check-every',str(args.check_every),'--center-real=0','--center-imag='+str(center),'--step-real=0','--step-imag='+str(destination-center)]
            if args.partial_fractions:cmd+=['--partial-fractions',str(args.partial_fractions)]
            with (args.directory/f'step-{index:03}-prepare.log').open('w') as stream:subprocess.run(cmd,check=True,stdout=stream,stderr=subprocess.STDOUT)
            env={**os.environ,'OMP_NUM_THREADS':str(args.threads),'OPENBLAS_NUM_THREADS':'1'}
            with (args.directory/f'step-{index:03}.log').open('w') as stream:subprocess.run([str(native),str(input_path),str(output)],check=True,stdout=stream,stderr=subprocess.STDOUT,env=env,timeout=args.step_timeout)
            result=json.loads(output.read_text());assert result['openmp_requested_threads']==args.threads and result['openmp_actual_threads']==args.threads,'Native worker count differs from frozen requested count';assert result['local_tail_certified'] and len(result['values'])==states
            metadata=json.loads(input_path.with_suffix('.json').read_text());scales=[arb(fmpq(x)) for x in metadata['constant_component_scale']];U=[acb(arb(a),arb(b))*scales[i%dim] for i,(a,b) in enumerate(result['values'])];raw=[]
            for k in range(jets):
                for i in range(dim):raw.append(U[k*dim+i]-2*U[(k-1)*dim+i] if k and weights[i] else U[k*dim+i])
            following={'schema':'vakint.certified-ancestor-ordinary-boundary.v1','basis':'original_raw_epsilon_jets','dimension':dim,'epsilon_min_power':initial['epsilon_min_power'],'epsilon_max_power':initial['epsilon_max_power'],'normalization':'native_raw','eta_center':['0',str(destination)],'error_quality':'rigorous-bound','source_equation_sha256':connection['source_sha256'],'run_binding_sha256':sha(manifest_path),'initial_boundary_sha256':initial_hash,'previous_boundary_sha256':sha(current),'transport_input_sha256':sha(input_path),'native_output_sha256':sha(output),'local_truncation_rigorously_enclosed':True,'whole_PR11d_20000_accuracy_claimed':False,'values':[[v.real.str(args.digits+args.guard+8,more=True),v.imag.str(args.digits+args.guard+8,more=True)] for v in raw]}
            save(target,following)
        step={'index':index,'center':str(center),'destination':str(destination),'native_seconds':result['seconds'],'order':result['order'],'local_tail':result['tail_upper_enclosure'],'boundary_sha256':sha(target)};assert following['basis']=='original_raw_epsilon_jets' and following['dimension']==dim and following['epsilon_min_power']==expected_min and following['epsilon_max_power']==expected_min+5 and following['normalization']=='native_raw' and following['error_quality']=='rigorous-bound'
        assert len(following['values'])==states and all(len(v)==2 and all(arb(x).is_finite() for x in v) for v in following['values'])
        steps.append(step);print(step,flush=True)
        current=target;center=destination
        save(args.directory/'progress.json',{'schema':'vakint.certified-ancestor-transport-progress.v1','completed_steps':len(steps),'expected_steps':len(destinations),'last_boundary':str(current),'last_boundary_sha256':sha(current),'run_binding_sha256':sha(manifest_path),'steps':steps,'wall_seconds':time.monotonic()-start,'whole_PR11d_20000_accuracy_claimed':False})
    final=json.loads(current.read_text());balls=[acb(arb(a),arb(b)) for a,b in final['values']];width=max(max(z.real.rad(),z.imag.rad()) for z in balls)
    report={'schema':'vakint.certified-ancestor-rpf-ordinary-transport.v9','complete':True,'final_boundary':str(current),'final_boundary_sha256':sha(current),'run_binding_sha256':sha(manifest_path),'error_quality':'rigorous-bound','maximum_component_radius':width.str(35,more=True),'native_seconds':sum(s['native_seconds'] for s in steps),'wall_seconds':time.monotonic()-start,'steps':steps,'whole_PR11d_20000_accuracy_claimed':False}
    if args.require_final_digits is not None:report['all_final_component_radii_meet_target']=bool(width<arb(10)**(-args.require_final_digits));report['required_final_absolute_digits']=args.require_final_digits
    save(args.directory/'complete.json',report)
    if args.require_final_digits is not None and not report['all_final_component_radii_meet_target']:raise ValueError('Transport completed but final total-error acceptance gate failed; no precision claim')
    print('COMPLETE',report['maximum_component_radius'],'native seconds',report['native_seconds'],flush=True)
if __name__=='__main__':main()
