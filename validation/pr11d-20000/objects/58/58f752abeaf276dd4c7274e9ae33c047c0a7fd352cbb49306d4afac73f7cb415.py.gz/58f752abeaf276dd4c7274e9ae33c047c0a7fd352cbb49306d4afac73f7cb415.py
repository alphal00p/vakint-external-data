#!/usr/bin/env python3
"""Read-only exact admission of the complete compositional 4L A transport.

Physical initial-source admission, an actual INIT invocation and canonical graph
aliases are separately required before seal.py can admit the resulting sources.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import sys
import time
from fractions import Fraction as Q
from pathlib import Path
from flint import arb, acb, ctx

sys.dont_write_bytecode = True
if not __debug__:
    raise RuntimeError('Assertions are required')
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
COMMON = HERE.parent / 'ordinary-chain-acceptance-v1/common.py'
COMMON_SHA = 'fa246be34bb42c21d6112a666c5840f36a0ced54f5667cd7b9487a4acc22e3ef'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def module(name, path):
    path = Path(path).resolve()
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    if Path(value.__file__).resolve() != path:
        raise ValueError('Unexpected imported module origin')
    return value


def fresh_output(path):
    path = Path(path)
    out = path.resolve()
    if path.is_symlink() or out.exists() or not out.is_relative_to(HERE) or not out.parent.is_dir():
        raise ValueError('Output must be a fresh nonsymlink path in the dedicated admission directory')
    return out


def absolute(path):
    path = Path(path)
    return (path if path.is_absolute() else ROOT / path).resolve()


def destinations(start, end, substeps):
    points, top = [], start
    while top > end:
        bottom = max(end, top / 2)
        step = (top - bottom) / substeps
        points.extend(top - step * i for i in range(1, substeps + 1))
        top = bottom
    return points


def replay():
    started = time.monotonic()
    if sha(COMMON) != COMMON_SHA:
        raise ValueError('Reviewed read-only common helper changed')
    c = module('production_A_strict_reader', COMMON)
    config_path = HERE / 'lineage-contract.json'
    config = c.load(config_path)
    c.require(config['schema'] == 'vakint.PR9-production-A-frozen-lineage-contract.v1', 'Unknown lineage contract')
    sources = {str(COMMON): COMMON_SHA, str(Path(__file__)): sha(__file__), str(config_path): sha(config_path)}
    artifacts = {}
    for graph in ['source_pins', 'checker_implementation_sha256']:
        c.require(type(config[graph]) is dict and config[graph], 'Missing lineage source graph')
        for path, digest in config[graph].items():
            c.require(Path(path).is_absolute(), 'Source pins must be absolute')
            c.pin(path, digest, sources)
    checker_path = Path(config['checker_path']).resolve()
    c.require(sources.get(str(checker_path)) == sha(checker_path), 'Checker is not pinned before import')
    checker = module('production_A_reviewed_general_RPF', checker_path)
    polynomial_path = HERE.parent / 'pr9-22-ordinary-polynomial.json'
    rpf_path = HERE.parent / 'pr9-22-ordinary-rational-pf.json'
    matching_path = HERE.parent / 'pr9-22-matching.json'
    raw_path = HERE.parent / 'pr9-22.json'
    polynomial, matching = c.load(polynomial_path), c.load(matching_path)
    c.require(polynomial['source_sha256'] == sha(raw_path), 'Original equation binding differs')
    raw_check = checker.check_raw_to_polynomial(raw_path, polynomial_path)
    c.require(raw_check['exact_matrix_entries'] == 484 and raw_check['regular_unit_gauge_verified'] is True,
              'Incomplete exact original-to-regular matrix check')
    weights = matching['gauge_weights'][:22]
    c.require(len(weights) == 22 and all(type(w) is int for w in weights), 'Invalid exact scaling weights')
    weights = tuple(w - min(weights) for w in weights)
    initial_path = c.pin(config['initial_path'], config['initial_sha256'], artifacts)
    initial = c.load(initial_path)
    c.require(initial['basis'] == 'original_raw_epsilon_jets' and initial['dimension'] == 22
              and initial['jets'] == 6 and initial['epsilon_min_power'] == -4 and initial['epsilon_max_power'] == 1
              and initial['normalization'] == 'native_raw' and initial['error_quality'] == 'rigorous-bound'
              and initial['eta_center'] == ['0', '256'] and initial['local_tail_certified'] is True,
              'Initial ordinary-point conventions differ')
    previous = initial_path
    center, endpoint = Q(256), Q(1, 16)
    steps, segment_reports = [], []
    expected_counts = [2, 2, 1, 44]
    c.require([s['completed_steps'] for s in config['segments']] == expected_counts, 'Historical segment selection differs')
    common_policy = None
    for segment_index, segment in enumerate(config['segments']):
        directory = Path(segment['directory']).resolve()
        binding_path, progress_path = directory / 'run-binding.json', directory / 'progress.json'
        c.pin(binding_path, segment['run_binding_sha256'], artifacts)
        artifacts[str(progress_path)] = sha(progress_path)
        binding, progress = c.load(binding_path), c.load(progress_path)
        count = segment['completed_steps']
        c.require(binding['initial_sha256'] == sha(previous), 'Continuation does not start from preceding full boundary')
        expected = {'connection_sha256': sha(polynomial_path), 'source_equation_sha256': sha(raw_path),
                    'dimension': 22, 'epsilon_jet_count': 6, 'normalization': 'native_raw',
                    'error_quality': 'rigorous-bound', 'end_eta_imag': '1/16',
                    'initial_contract_sha256': None, 'partial_fraction_sha256': None,
                    'local_target_digits': 20400, 'guard_digits': 300,
                    'required_final_absolute_digits': 20050, 'substeps_per_halving': 4}
        for key, wanted in expected.items():
            c.require(type(binding[key]) is type(wanted) and binding[key] == wanted, 'Segment binding differs: ' + key)
        driver_names = ['run_v5.py', 'run_v5.py', 'run_rpf_v8.py', 'run_rpf_v9.py']
        driver = ROOT / 'hierarchy-transport' / driver_names[segment_index]
        c.require(binding['driver_sha256'] == sources[str(driver)], 'Wrong historical driver')
        dependencies = binding['implementation_and_source_dependency_sha256']
        expected_dependencies = {driver, ROOT / 'hierarchy-transport/prepare_scaled_rpf.py',
                                 ROOT / 'hierarchy-transport/prepare_scaled_segment.py',
                                 ROOT / 'helper/jet-transport/append_rpf_scaled.py',
                                 ROOT / 'helper/jet-transport/prepare_generic_segment.py',
                                 ROOT / 'helper/frobenius-transport/native/prepare_v2.py',
                                 polynomial_path, raw_path, rpf_path}
        c.require(set(map(Path, dependencies)) == expected_dependencies, 'Incomplete historical dependency graph')
        for path, digest in dependencies.items():
            c.require(sources.get(path) == digest, 'Run dependency differs from frozen contract')
        native_path = Path(binding['native_path']).resolve()
        c.require(sources.get(str(native_path)) == binding['native_sha256'], 'Native executable is not admitted')
        review = c.load(segment['native_review_path'])
        c.require(review['source_sha256'] == segment['native_source_sha256']
                  and review['binary_sha256'] == binding['native_sha256'], 'Native implementation review differs')
        c.require(binding['preparer_sha256'] == sources[str(ROOT / 'hierarchy-transport/prepare_scaled_rpf.py')]
                  and Path(binding['preparer_path']).resolve() == ROOT / 'hierarchy-transport/prepare_scaled_rpf.py',
                  'Historical preparation helper differs')
        if segment_index >= 2:
            c.require(type(binding['native_worker_threads']) is int and binding['native_worker_threads'] == 8,
                      'Historical requested worker metadata differs')
        points = destinations(center, endpoint, 4)
        c.require(count <= len(points), 'Segment exceeds its exact contour')
        c.require(progress['schema'] == 'vakint.certified-ancestor-transport-progress.v1'
                  and progress['completed_steps'] == count and progress['expected_steps'] == len(points)
                  and progress['run_binding_sha256'] == sha(binding_path)
                  and progress['whole_PR11d_20000_accuracy_claimed'] is False,
                  'Historical progress metadata differs')
        wanted_boundaries = {directory / f'step-{i:03}-boundary.json' for i in range(count)}
        c.require(set(directory.glob('step-*-boundary.json')) == wanted_boundaries,
                  'Orphan accepted boundary outside the frozen completed prefix')
        wanted_native = {directory / f'step-{i:03}-native.json' for i in range(count)}
        c.require(set(directory.glob('step-*-native.json')) == wanted_native,
                  'Unrecorded native result outside the completed prefix')
        local_steps = []
        segment_initial = previous
        for index, destination in enumerate(points[:count]):
            ip, mp, op, bp = [directory / f'step-{index:03}{suffix}'
                              for suffix in ['.in', '.json', '-native.json', '-boundary.json']]
            meta, native = c.load(mp), c.load(op)
            if segment_index == 3:
                for field, expected_worker in [('openmp_requested_threads', 8),
                                                ('openmp_actual_threads', 8), ('openmp_thread_cap', 16)]:
                    c.require(type(native[field]) is int and native[field] == expected_worker,
                              'Actual-eight-worker native profile differs: ' + field)
            c.require(meta['center'] == ['0', str(center)] and meta['step'] == ['0', str(destination - center)],
                      'Historical exact step ordering differs')
            c.require(meta['scale_matching_sha256'] == sha(matching_path), 'Unbound constant component scaling')
            header = list(map(int, ip.read_text().splitlines()[0].split()))
            c.require(len(header) == 9 and header[:3] == [22, 6, 10]
                      and header[5] == math.ceil(20700 * math.log2(10)) and header[6] == 20400
                      and header[7] >= 8 and header[8] >= 1, 'Historical native precision policy differs')
            policy = tuple(header[5:])
            c.require(common_policy is None or common_policy == policy, 'Operational policy changed at a continuation')
            common_policy = policy
            contract = checker.StepContract(dimension=22, jets=6, epsilon_min_power=-4,
                                            polynomial_sha256=sha(polynomial_path), rational_pf_sha256=sha(rpf_path),
                                            source_equation_sha256=sha(raw_path), working_bits=header[5],
                                            target_digits=20400, serialization_decimal_digits=20700,
                                            run_binding_sha256=sha(binding_path), initial_boundary_sha256=sha(segment_initial),
                                            component_scale_policy='imaginary_center_power', component_scale_weights=weights,
                                            expected_worker_threads=segment['expected_worker_threads'],
                                            mask_metadata_required=segment['mask_metadata_required'])
            checked = checker.check_step(ip, mp, previous, polynomial_path, rpf_path, op, bp, contract)
            c.require(checked['accepted'] is True and checked['input_full_box_containments'] == 132
                      and checked['output_full_box_containments'] == 132
                      and checked['original_outward_driver_serialization_byte_identical'] is True,
                      'Incomplete historical source/error preservation check')
            c.require(checked['mask_metadata_checked'] is segment['mask_metadata_required']
                      and checked['row_aggregation_checked'] is segment['row_metadata_required']
                      and checked['precision_schedule_metadata_checked'] is segment['schedule_metadata_required'],
                      'Wrong historical native metadata profile')
            for path, digest in checked['artifact_sha256'].items():
                c.require(path not in artifacts or artifacts[path] == digest, 'Conflicting retained artifact hash')
                artifacts[path] = digest
            record = {'global_index': len(steps), 'segment_index': segment_index, 'index': index,
                      'center': str(center), 'destination': str(destination), 'boundary_sha256': sha(bp),
                      'order': native['order'], 'native_seconds': native['seconds'],
                      'local_tail': native['tail_upper_enclosure'], 'exact_step_audit': checked}
            steps.append(record)
            local_steps.append(record)
            previous, center = bp, destination
            print('STEP', record['global_index'], segment_index, index, 'PASS', flush=True)
        c.require(absolute(progress['last_boundary']) == previous.resolve()
                  and progress['last_boundary_sha256'] == sha(previous), 'Historical progress terminal differs')
        c.require(len(progress['steps']) == count, 'Incomplete historical progress summary')
        for recorded, checked in zip(progress['steps'], local_steps):
            for key in ['index', 'center', 'destination', 'boundary_sha256', 'order', 'native_seconds', 'local_tail']:
                c.require(recorded[key] == checked[key], 'Historical progress summary changed: ' + key)
        if segment_index < 3:
            name = 'actual-worker-continuation.json' if segment_index == 2 else 'optimization-continuation.json'
            continuation_path = directory / name
            continuation = c.load(continuation_path)
            c.require(continuation['completed_steps'] == count
                      and absolute(continuation['last_boundary']) == previous.resolve()
                      and continuation['last_boundary_sha256'] == sha(previous), 'Immutable continuation seam differs')
            if segment_index == 0:
                c.require(continuation['old_run_binding_sha256'] == sha(binding_path), 'Old run binding differs at first seam')
            next_directory = config['segments'][segment_index + 1]['directory']
            key = 'new_directory' if segment_index == 2 else 'new_continuation_directory'
            c.require(absolute(continuation[key]) == Path(next_directory).resolve(), 'Continuation selects another lineage')
            c.require(absolute(continuation['new_engine']) == Path(c.load(Path(next_directory) / 'run-binding.json')['native_path']).resolve(),
                      'Continuation selects another native implementation')
            if 'new_driver' in continuation:
                next_driver = ROOT / 'hierarchy-transport' / driver_names[segment_index + 1]
                c.require(absolute(continuation['new_driver']) == next_driver,
                          'Continuation names another execution driver')
            for review_key in ['new_review', 'engine_review']:
                if review_key in continuation:
                    c.require(absolute(continuation[review_key])
                              == Path(config['segments'][segment_index + 1]['native_review_path']).resolve(),
                              'Continuation names another implementation review')
            if segment_index == 2:
                c.require(continuation['configured_requested_workers'] == 8
                          and continuation['observed_actual_workers_previous_base_kernel'] == 4,
                          'Historical worker correction is missing')
                c.require('omp_set_dynamic(0);if(omp_get_max_threads()>4)omp_set_num_threads(4);'
                          in Path(segment['native_source_path']).read_text(), 'Frozen historical base kernel does not have the recorded cap4')
            c.require(continuation['whole_PR11d_accuracy_claimed'] is False, 'Continuation promotes whole-period precision')
        segment_reports.append({'segment_index': segment_index, 'directory': str(directory), 'steps': count,
                                'initial_boundary_sha256': sha(segment_initial), 'final_boundary': str(previous.resolve()),
                                'final_boundary_sha256': sha(previous), 'run_binding_sha256': sha(binding_path),
                                'native_binary_sha256': binding['native_sha256'], 'native_source_sha256': segment['native_source_sha256'],
                                'mask_required': segment['mask_metadata_required'], 'row_aggregation_required': segment['row_metadata_required'],
                                'coefficient_schedule_required': segment['schedule_metadata_required'],
                                'native_actual_worker_metadata_checked': segment['expected_worker_threads']})
    c.require(len(steps) == 49 and center == endpoint, 'Compositional physical contour is incomplete')
    final_directory = Path(config['segments'][-1]['directory'])
    complete_path = final_directory / 'complete.json'
    complete = c.load(complete_path)
    artifacts[str(complete_path)] = sha(complete_path)
    c.require(complete['schema'] == 'vakint.certified-ancestor-rpf-ordinary-transport.v9'
              and complete['complete'] is True and complete['error_quality'] == 'rigorous-bound'
              and complete['whole_PR11d_20000_accuracy_claimed'] is False
              and absolute(complete['final_boundary']) == previous.resolve()
              and complete['final_boundary_sha256'] == sha(previous)
              and complete['run_binding_sha256'] == segment_reports[-1]['run_binding_sha256'], 'Completed final segment differs')
    c.require(complete['steps'] == c.load(final_directory / 'progress.json')['steps'], 'Completed final step summary differs')
    c.require(complete['native_seconds'] == sum(s['native_seconds'] for s in steps if s['segment_index'] == 3),
              'Completed final native timing differs')
    ctx.dps = 20700
    final = c.load(previous)
    values = [acb(arb(a), arb(b)) for a, b in final['values']]
    c.require(len(values) == 132 and all(z.is_finite() for z in values), 'Nonfinite/incomplete final raw vector')
    width = max(max(z.real.rad(), z.imag.rad()) for z in values)
    c.require(width.str(35, more=True) == complete['maximum_component_radius']
              and complete['required_final_absolute_digits'] == 20050
              and complete['all_final_component_radii_meet_target'] is True and width < arb(10) ** -20050,
              'Final physical-source total-error gate failed')
    for path, digest in {**sources, **artifacts}.items():
        c.require(sha(path) == digest, 'Retained source/artifact changed during replay: ' + path)
    return {'schema': 'vakint.PR9-production-A-chain-data-review.v1',
            'status': 'passed_actual_data_and_reviewed_native_certificate_chain', 'checker_sha256': sha(__file__),
            'source_pins': sources, 'artifact_sha256': artifacts,
            'initial_path': str(initial_path), 'initial_sha256': sha(initial_path),
            'raw_source_sha256': sha(raw_path), 'raw_to_regular_connection_check': raw_check,
            'segments': segment_reports, 'steps': steps, 'completed_step_count': 49,
            'final_boundary_path': str(previous.resolve()), 'final_boundary_sha256': sha(previous),
            'maximum_final_component_radius': complete['maximum_component_radius'],
            'all_final_component_absolute_radii_below': '1e-20050',
            'initial_physical_source_admitted_here': False,
            'historical_scheduled_segment_workers': {'configured_request': 8, 'continuation_recorded_actual': 4,
                                                     'frozen_source_exact_worker_cap': 4,
                                                     'native_output_actual_worker_metadata_available': False,
                                                     'qualification': 'The immutable continuation reports4 actual workers and the reviewed C source caps workers at4. The old native output does not record observed team size; no8-worker performance claim is made.'},
            'actual_eight_worker_steps_with_requested_and_actual_metadata': 44,
            'new_native_or_preparer_calls': 0, 'source_HPL_or_matching_reevaluation': False,
            'all_checks_use_exact_identity_full_containment_or_original_outward_replay': True,
            'whole_PR11d_20000_accuracy_claimed': False, 'data_precision_caps_modified': False,
            'seconds': time.monotonic() - started}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = fresh_output(args.output)
    result = replay()
    with output.open('x') as stream:
        stream.write(json.dumps(result, indent=2) + '\n')
    print('PASS', result['completed_step_count'], 'steps', sha(output), result['seconds'], 'seconds')


if __name__ == '__main__':
    main()
