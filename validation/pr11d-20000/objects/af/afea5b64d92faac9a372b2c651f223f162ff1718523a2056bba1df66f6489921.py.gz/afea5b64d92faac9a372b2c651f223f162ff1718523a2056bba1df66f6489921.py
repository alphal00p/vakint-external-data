"""Compare canonical raw endpoints to independent FMFT/MATAD tables once."""
import argparse,hashlib,json,math
from pathlib import Path
from flint import arb,ctx
if not __debug__:raise RuntimeError('Assertions required')
p=argparse.ArgumentParser();p.add_argument('input',type=Path);p.add_argument('--digits',type=int,default=300);p.add_argument('--output',type=Path,required=True);a=p.parse_args();ctx.dps=a.digits;d=json.load(open(a.input));loops=next(iter(d['target_bindings']))['raw_family_sha256'] if d['name']=='three-loop-seven' else None;L=3 if d['name']=='three-loop-seven' else 4;rows=[]
for symbol,coefficients in d['coefficients'].items():
 values=[arb(r['ball']) for r in coefficients];powers=[r['epsilon_power'] for r in coefficients];assert powers==list(range(-L,6-L));g=L*arb.const_euler();expo=[arb(1)]
 for n in range(1,6):expo.append(expo[-1]*g/n)
 fmft=[sum((values[k]*expo[n-k] for k in range(n+1)),arb(0)) for n in range(6)]
 name=symbol.split('_')[-1] if L==3 else symbol.split('::')[-1];external=Path('/shared/codex-1/vakint_rustred/vakint-external-data')/f'{L}L/masters/{name}/numerical.json';ref=dict(json.load(open(external)))
 for power,value in zip(powers,fmft):
  reference=arb(ref[power]);overlap=value.overlaps(reference);assert overlap,(symbol,power,value.str(80),reference.str(80));diff=abs(value.mid()-reference.mid());scale=max(arb(1),abs(reference).upper());agreement=int(max(0,float((-((diff+arb(10)**(-a.digits))/scale).log()/arb(10).log()).lower())))
  rows.append({'symbol':symbol,'epsilon_power':power,'computed_ball':value.str(80,more=True),'independent_reference_prefix':ref[power][:80],'overlap':bool(overlap),'midpoint_agreement_decimal_digits':agreement,'achieved_relative_accuracy_bits':int(value.rel_accuracy_bits()),'reference_sha256':hashlib.sha256(external.read_bytes()).hexdigest()})
report={'schema':'vakint.ancestor.independent-endpoint-comparison.v1','source_sha256':hashlib.sha256(a.input.read_bytes()).hexdigest(),'normalization_conversion':'FMFT=exp(L EulerGamma epsilon)*native_raw exactlyonce','checks':rows,'minimum_midpoint_agreement_decimal_digits':min(r['midpoint_agreement_decimal_digits'] for r in rows),'all_intervals_overlap':True,'whole_PR11d_accuracy_claimed':False};a.output.write_text(json.dumps(report,indent=2)+'\n');print('PASS',len(rows),'independentFMFTchecks;minimumagreement',report['minimum_midpoint_agreement_decimal_digits'])
