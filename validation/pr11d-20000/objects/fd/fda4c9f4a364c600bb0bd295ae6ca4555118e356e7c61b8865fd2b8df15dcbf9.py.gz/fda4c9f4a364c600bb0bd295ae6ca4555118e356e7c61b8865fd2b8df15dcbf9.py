#!/usr/bin/env python3
"""Independent20600guard source bridge; earlier accepted artifacts are untouched."""
import argparse,hashlib,json,sys,time
from pathlib import Path
from flint import arb,ctx
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from api_three_loop_native import rational,aa,POWERS,FAMILY,native_from_fmft
from endpoint_sources import sha
sys.set_int_max_str_digits(300000)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--API-root',required=True);ap.add_argument('--working-digits',type=int,default=20800)
    ap.add_argument('--minimum-source-digits',type=int,default=20600);ap.add_argument('--output',required=True);args=ap.parse_args()
    if not __debug__:raise RuntimeError('Source validation requires assertions enabled')
    output=Path(args.output)
    if output.exists():raise ValueError('Preserve earlier native guard sources')
    ctx.dps=args.working_digits;ctx.threads=1;start=time.monotonic();root=Path(args.API_root)
    validation=json.loads((root/'validation.json').read_bytes());run=json.loads((root/'receipt.json').read_bytes())
    if validation.get('complete') is not True or validation['master_count']!=2 or validation['coefficient_count']!=12:
        raise ValueError('Complete independent12coefficient API source acceptance required')
    if run.get('automatic_retry') is not False or run['passes_per_coefficient']!=1 or run['normalization_transform_applied'] is not False:
        raise ValueError('Unexpected source production/normalization contract')
    manifest=json.loads((root/'3L-manifest.json').read_bytes());complete={r['master']:r for r in run['completed_masters']}
    coefficients={};bindings={}
    for name in ['P13','P14']:
        key='3L-'+name;path=root/(key+'.json');data=json.loads(path.read_bytes());summary=complete[key]
        if sha(path)!=summary['sha256'] or data['complete'] is not True:raise ValueError('Accepted source artifact identity mismatch')
        source=root/'source'/key;metadata=json.loads((source/'master-metadata.json').read_bytes())
        encoded=json.dumps(metadata,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
        if hashlib.sha256(encoded).hexdigest()!=data['master_metadata_sha256'] or metadata!=next(r for r in manifest['masters'] if r['name']==name):
            raise ValueError('Canonical source metadata mismatch')
        expected_id='L3_'+FAMILY+''.join('_p'+str(n) for n in POWERS[name])
        if data['family_sha256']!=FAMILY or data['master_id']!=expected_id or data['powers']!=POWERS[name] or data['loop_count']!=3:
            raise ValueError('The source is not the required physical canonical3L integral')
        if data['normalization']!='FMFTandMATAD' or data['mass_squared']!='1' or data['provenance']['version']!=manifest['version']:
            raise ValueError('Canonical normalization, mass or version mismatch')
        formula=source/'symbolic.json'
        if sha(formula)!=data['source_formula_sha256'] or sha(formula)!=metadata['files']['symbolic.json']['sha256']:
            raise ValueError('Authenticated exact formula mismatch')
        formulas=dict(json.loads(formula.read_bytes()));values={}
        rows=data['coefficients']
        if [r['epsilon_power'] for r in rows]!=list(range(-3,3)):raise ValueError('Six contiguous explicit source orders required')
        for row in rows:
            p=row['epsilon_power'];real,imag=row['precision']['real'],row['precision']['imaginary']
            if row['formula_sha256']!=hashlib.sha256(formulas[p].encode()).hexdigest() or row['available_precision']!='ArbitraryPrecision':
                raise ValueError('The exact coefficient formula binding changed')
            if real['quality']!='Bounded' or imag['quality']!='Bounded' or row['warnings'] or not imag['exact_zero'] or rational(imag['absolute_error']):
                raise ValueError('A real, rigorously bounded source coefficient with no warnings is required')
            c,e=rational(row['numerical_value']),rational(real['absolute_error'])
            if e<0 or e*10**args.minimum_source_digits>abs(c)-e:raise ValueError('Exact rational source precision is insufficient')
            values[p]=aa(c)+arb(0,aa(e).upper())
        native=native_from_fmft(values,3);symbol='native::L3_'+name
        coefficients[symbol]=[{'epsilon_power':p,'ball':v.str(args.working_digits+12,more=True),'relative_accuracy_bits':int(v.rel_accuracy_bits())} for p,v in native.items()]
        bindings[symbol]={'source':str(path.resolve()),'sha256':sha(path),'master_id':expected_id,'family_sha256':FAMILY,'powers':POWERS[name],
          'version':manifest['version'],'metadata_sha256':data['master_metadata_sha256'],'formula_payload_sha256':sha(formula)}
    payload={'schema':'vakint.native-three-loop-guard20600-from-public-API.v1','normalization':'native_raw','error_quality':'rigorous-bound',
      'coefficients':coefficients,'canonical_alias_bindings':bindings,'API_acceptance_sha256':sha(root/'validation.json'),'API_run_receipt_sha256':sha(root/'receipt.json'),
      'API_loop_manifest_sha256':sha(root/'3L-manifest.json'),'native_conversion':'exp(-3*EulerGamma*epsilon) exactly once with exact input rational balls and outward Arb convolution',
      'source_digits_exactly_checked':args.minimum_source_digits,'working_decimal_digits':args.working_digits,'producer_sha256':sha(Path(__file__)),
      'mathematical_conversion_owner_sha256':sha(HERE.parent/'api_three_loop_native.py'),'seconds':time.monotonic()-start,'whole_PR11d_accuracy_claimed':False}
    output.write_text(json.dumps(payload,indent=2)+'\n');print('PASS:12bounded native20600source coefficients; seconds',time.monotonic()-start,flush=True)
if __name__=='__main__':main()
