#!/usr/bin/env python3
"""Additive byte-identical manifest relocation; no numerical replay or writes outside this directory."""
import hashlib
import itertools
import json
from fractions import Fraction as Q
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
ROUTING = ROOT / "ancestor-flows/four-loop-production-A-admission-v1/endpoint-replay/canonical-routing"
OLD_MANIFEST = Path("/shared/codex-1/vakint_rustred/vakint-external-data/4L/manifest.json")
SNAPSHOT = ROUTING / "immutable-inputs/4L-manifest-b40adfb8.json"
MANIFEST_SHA = "b40adfb858f4a10852d341aab0a8550de93e3c7526b953a6c4b21cbc7bb8f9b9"
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
PINS = {}


def pin(path, digest):
    path = Path(path).resolve()
    if path == OLD_MANIFEST:
        assert digest == MANIFEST_SHA
        path = SNAPSHOT
    assert sha(path) == digest, str(path)
    assert str(path) not in PINS or PINS[str(path)] == digest
    PINS[str(path)] = digest
    return path


def read(path, digest):
    return json.loads(pin(path, digest).read_text())


old_review_path = HERE / "review.json"
old_review = read(old_review_path, "1b144522d355ab16efb3d0ed744af6f498f9a70a7c53fb2940d081140f387b2d")
arithmetic = read(old_review["arithmetic_review"], old_review["arithmetic_review_sha256"])
old_witness = read(ROUTING / "witness.json", "9f16616a3aaed9ecc1a223b0f727e860787cd0fc383f29ed11715def80dcc662")
new_witness_path = ROUTING / "witness-snapshot.json"
new_witness = read(new_witness_path, "2381970b5a108eb7627dfc42ea49e43e843a32793652c025caa43237f4ed9586")
pin(ROUTING / "check.py", old_witness["validator_sha256"])
pin(ROUTING / "check_snapshot.py", "a37ff991d3ae20f6f34794be73bfa5a25e8588af2c0260224b2e9e56eb24501e")
assert new_witness["validator_sha256"] == sha(ROUTING / "check_snapshot.py")
old_code = (ROUTING / "check.py").read_text()
old_line = 'MANIFEST = Path("/shared/codex-1/vakint_rustred/vakint-external-data/4L/manifest.json")'
new_line = 'MANIFEST = HERE / "immutable-inputs/4L-manifest-b40adfb8.json"'
assert old_code.count(old_line) == 1
assert old_code.replace(old_line, new_line) == (ROUTING / "check_snapshot.py").read_text()
assert set(old_witness) == set(new_witness)
assert all(old_witness[key] == new_witness[key] for key in old_witness if key not in {"validator_sha256", "source_pins"})
for table in [old_review["source_and_implementation_pins"], arithmetic["source_and_implementation_pins"], old_witness["source_pins"], new_witness["source_pins"]]:
    for path, digest in table.items():
        pin(path, digest)
manifest = read(SNAPSHOT, MANIFEST_SHA)
assert str(OLD_MANIFEST) not in PINS

# Independently replay exact transformed quadratics from the actual snapshot.
proof = new_witness["proof"]
route = proof["PR9d_witness"]
family = next(row for row in manifest["families"] if row["sha256"] == proof["canonical_bindings"][-1]["family_sha256"])
coordinates = [(i, j) for i in range(4) for j in range(i, 4)]
assert [(row["left"], row["right"]) for row in family["coordinates"]] == coordinates
assert family["external_momenta"] == [] and family["power_shifts"] == ["0"]*10
matrices = []
for entry in family["denominators"]:
    assert entry["constant"] == "-1" and len(entry["coefficients"]) == 10
    matrix = [[Q(0) for _ in range(4)] for _ in range(4)]
    for (i, j), coefficient in zip(coordinates, entry["coefficients"]):
        matrix[i][j] = matrix[j][i] = Q(coefficient)/(1 if i == j else 2)
    matrices.append(matrix)
U = route["loop_matrix_k_equals_U_l"]
determinant = Q(0)
for permutation in itertools.permutations(range(4)):
    term = Q((-1)**sum(permutation[i] > permutation[j] for i in range(4) for j in range(i+1, 4)))
    for i in range(4):
        term *= U[i][permutation[i]]
    determinant += term
assert determinant == 1
source, target = route["source_powers"], route["canonical_powers"]
edges = route["active_slot_mapping"]
assert sorted(i for i,j,s in edges) == [i for i,p in enumerate(source) if p]
assert sorted(j for i,j,s in edges) == [i for i,p in enumerate(target) if p]
for old, new, sign in edges:
    assert source[old] == target[new] and sign in (-1,1)
    transformed = [[sum((Q(U[a][i])*matrices[old][a][b]*U[b][j] for a in range(4) for b in range(4)), Q(0)) for j in range(4)] for i in range(4)]
    assert transformed == matrices[new]
assert len(edges) == 7
pin(HERE / "close_review.py", old_review["checker_sha256"])
pin(HERE / "check_endpoint.py", arithmetic["checker_sha256"])

result = dict(old_review)
result["schema"] = "vakint.pr9.production-B.scoped-endpoint-snapshot-acceptance.v1"
result["canonical_routing_witness"] = str(new_witness_path)
result["canonical_routing_witness_sha256"] = sha(new_witness_path)
result["source_pin_relocation"] = {"original_path": str(OLD_MANIFEST), "replacement_path": str(SNAPSHOT), "sha256": MANIFEST_SHA}
result["historical_endpoint_review"] = str(old_review_path)
result["historical_endpoint_review_sha256"] = sha(old_review_path)
result["checker_sha256"] = sha(__file__)
result["snapshot_delta_review"] = {
    "original_manifest_bytes_recovered_exactly": True,
    "routing_checker_only_change_is_manifest_path": True,
    "routing_witness_proof_and_all_other_semantic_fields_identical": True,
    "independently_replayed_quadratic_identities_from_snapshot": 7,
    "independently_replayed_unimodular_determinant": 1,
    "all42_numeric_fields_and_width_bounds_unchanged": True,
    "live_manifest_not_waived_or_accepted_under_old_digest": True,
    "every_other_source_pin_checked_at_original_path": True,
    "no_native_HPL_or_projection_rerun": True,
    "old_receipts_preserved": True,
}
numeric_keys = ["endpoint_payload_sha256", "terminal_boundary_sha256", "coefficient_count", "per_coefficient_radius_bounds", "maximum_total_complex_l1_radius_upper", "maximum_total_complex_l1_diameter_upper", "all42_full_complex_ball_convolutions_contained", "original20400digit_projection_and20408digit_strings_byte_identical", "all42_strict_total_l1_radii_and_diameters_below_1e_minus20000"]
assert all(result[key] == old_review[key] for key in numeric_keys)
pin(Path(__file__), sha(__file__))
result["source_and_implementation_pins"] = PINS
for path, digest in PINS.items():
    assert sha(path) == digest
out = HERE / "review-snapshot.json"
with out.open("x") as stream:
    stream.write(json.dumps(result, indent=2) + "\n")
print(json.dumps({"receipt": str(out), "sha256": sha(out), "manifest_snapshot": str(SNAPSHOT)}))
