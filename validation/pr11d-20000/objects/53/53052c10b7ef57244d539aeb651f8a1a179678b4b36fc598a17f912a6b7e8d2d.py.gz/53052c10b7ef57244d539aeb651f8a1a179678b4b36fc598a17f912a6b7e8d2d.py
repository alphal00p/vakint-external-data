"""Exact epsilon-regular endpoint adjoints with canonical master identity bindings."""
import argparse,hashlib,json,sys
from pathlib import Path
sys.path.insert(0,'/shared/codex-1/vakint_rustred/workspace/precision-periods/pr11d/helper')
from exact_system import CTX,Rat,parse
from endpoint_adjoint import eta_series,epsilon_valuation,multiply,minus_root,zero_row
if not __debug__:raise RuntimeError('Assertions required')
ap=argparse.ArgumentParser();ap.add_argument('name',choices=['three-loop-seven','pr9-22']);a=ap.parse_args();here=Path(__file__).parent;source=here/f'{a.name}.json';d=json.load(open(source));n=len(d['basis']);e=Rat(CTX.gen(0));A=[[parse(v,d['epsilon_symbol'],d['variable']) for v in row] for row in d['differential_matrix']];order=7;coeff=[[[eta_series(v,order)[k] for v in row] for row in A] for k in range(order+1)];R=coeff[0]
if a.name=='three-loop-seven':
 roots=[Rat(0),Rat(1)-Rat(2)*e];loops=3;targets=[('native::L3_P13',4),('native::L3_P14',5)]
 manifest=Path('/shared/codex-1/vakint_rustred/vakint-external-data/3L/manifest.json');m=json.load(open(manifest));bindings=[]
 for symbol,i in targets:
  row=next(r for r in m['masters'] if r['name']==symbol.split('_')[-1]);assert row['family_sha256']==d['family']['sha256'] and row['powers']==d['basis'][i]
  bindings.append({'symbol':symbol,'component':i,'raw_family_sha256':d['family']['sha256'],'ordered_powers':d['basis'][i],'master_id':row['master_id'],'mapping':'literal identity of authenticated family and ordered powers; no extra basis-expression substitution','exact_basis_expression':row['exact_basis_expression'],'normalization':'native_raw; FMFT/MATAD differs by exp(3 EulerGamma epsilon) exactlyonce','manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest()})
else:
 roots=[Rat(0),-Rat(2)*e,Rat(1)-Rat(2)*e,Rat(3)/Rat(2)-Rat(3)*e];loops=4;targets=[('native::PR3',2),('native::PR4',8),('native::PR4d',17),('native::PR5',5),('native::PR7',10),('native::PR9',12),('native::PR9d',20)];bindings=json.load(open(here/'endpoint-depth-proof.json'))['records']
for i in range(n):
 row=[Rat(int(i==j)) for j in range(n)]
 for root in roots:row=minus_root(row,R,root)
 assert not any(v.num for v in row)
minimal=[Rat(1)]
for root in roots:
 nxt=[Rat(0)]*(len(minimal)+1)
 for i,v in enumerate(minimal):nxt[i]=nxt[i]-v*root;nxt[i+1]=nxt[i+1]+v
 minimal=nxt
records=[]
for symbol,i in targets:
 row=zero_row(n);row[i]=Rat(1);den=Rat(1)
 for root in roots[1:]:row=minus_root(row,R,root);den=den*-root
 row=[v/den for v in row];assert not any(v.num for v in multiply(row,R));assert all(epsilon_valuation(v) is None or epsilon_valuation(v)>=0 for v in row);rows=[row]
 for power in range(1,order+1):
  rhs=zero_row(n)
  for j in range(power):rhs=[a-b for a,b in zip(rhs,multiply(rows[j],coeff[power-j]))]
  quotient=[Rat(0)]*len(roots);quotient[-1]=minimal[-1]
  for j in range(len(roots)-2,-1,-1):quotient[j]=minimal[j+1]-Rat(power)*quotient[j+1]
  m_at=minimal[0]-Rat(power)*quotient[0];assert epsilon_valuation(m_at)==0
  inv=[-v/m_at for v in quotient];solved=zero_row(n);multiplied=rhs
  for v in inv:solved=[a+v*b for a,b in zip(solved,multiplied)];multiplied=multiply(multiplied,R)
  assert all(not(a-b).num for a,b in zip([Rat(power)*v+r for v,r in zip(solved,multiply(solved,R))],rhs));assert all(epsilon_valuation(v) is None or epsilon_valuation(v)>=0 for v in solved);rows.append(solved)
 records.append({'symbol':symbol,'component':i,'row_coefficients':[[str(v) for v in row] for row in rows],'epsilon_min_valuation_by_eta_order':[min((epsilon_valuation(v) for v in row if v.num),default=None) for row in rows]})
result={'schema':'vakint.ancestor.exact-endpoint-adjoints.v1','name':a.name,'dimension':n,'loop_count':loops,'epsilon_jet_count':6,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'formal_roots':[str(v) for v in roots],'squarefree_residue_annihilator_verified':True,'target_bindings':bindings,'definition':'Wprime=-WA; W0=targetrow P0 where P0 projects to formal generic epsilon exponentzero; targetendpoint=W(eta,epsilon) dot originalrawY(eta,epsilon)','endpoint_sector_convention':'Project to generic-epsilon exponentzero BEFOREepsilonexpansion; otherformalexponentsareexcluded, regardlessofcollision at epsilon0.','no_extra_epsilon_factor_required':True,'raw_epsilon_range':[-loops,5-loops],'records':records,'all_orders_epsilon_regularity_proof':'All Aregular coefficients are epsilonregular, all W0 are epsilonregular, and for every n>=1 all n+lambda have nonzero constantterm at epsilon0. The exact adjoint recurrence therefore preserves epsilonregularity at all orders.','numerical_integrals_evaluated':False};out=here/f'{a.name}-endpoint-adjoints.json';out.write_text(json.dumps(result,indent=2)+'\n');print('PASS',a.name,len(records),'canonicaltargets')
