#!/usr/bin/env python3
"""Checked real-ball matching of complete raw X8 infinity epsilon/log jets.

Every supplied coefficient is explicit. Missing coefficients never become zero.
The default requires every prepared selector, including higher logarithms.
"""
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping
import argparse,hashlib,json,time
from flint import arb,ctx,fmpq
HERE=Path(__file__).resolve().parent
FIELDS=('component','integer_z_power','epsilon_power','log_power')
def key(label):return tuple(int(label[name]) for name in FIELDS)
def label(k):return dict(zip(FIELDS,k))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def sparse(rows):return [[(j,fmpq(value)) for j,value in enumerate(row) if value!='0'] for row in rows]
def dot(row,vector):return sum((vector[j]*weight for j,weight in row),arb(0))
@dataclass(frozen=True)
class BoundarySolution:
    constants:tuple
    report:dict
class Matching:
    def __init__(self):
        path=HERE/'exact-boundary-matching.json';verify_path=HERE/'verification.json'
        verified=json.loads(verify_path.read_text())
        if verified['exact_matching_sha256']!=sha(path):raise ValueError('Exact matching payload does not match its verification receipt')
        self.data=json.loads(path.read_text());self.binding=sha(path)
        if self.data['dimension']!=252:raise ValueError('Expected the six-jet252state matching schema')
        self.selected=tuple(key(x) for x in self.data['selected_selectors'])
        self.all_keys=tuple(key(x) for x in self.data['all_boundary_selectors'])
        if len(self.selected)!=252 or len(set(self.selected))!=252 or len(set(self.all_keys))!=len(self.all_keys):raise ValueError('Duplicated or incomplete selector binding')
        self.inverse=sparse(self.data['boundary_inverse']);self.rows=sparse(self.data['all_boundary_matrix'])
        if len(self.inverse)!=252 or len(self.rows)!=len(self.all_keys):raise ValueError('Malformed matching matrix shape')
        self.positions={k:i for i,k in enumerate(self.all_keys)}
    def solve(self,boundary:Mapping,*,inventory_sha256:str,normalization:str,error_quality:str,require_all_prepared_rows:bool=True):
        start=time.monotonic()
        if inventory_sha256!=self.data['inventory_sha256']:raise ValueError('Boundary inventory checksum does not match the prepared selector snapshot')
        if normalization!='native_raw':raise ValueError('Boundary matching requires raw native coefficients without an Euler exponential; convert normalized ratios explicitly')
        if error_quality not in ('rigorous-bound','validated-digits-estimate'):raise ValueError('Explicit source error quality is required')
        if any(k not in self.positions for k in boundary):raise ValueError('Boundary contains selectors outside the prepared complete inventory')
        required=self.all_keys if require_all_prepared_rows else tuple(k for k in self.all_keys if k[3]<=1)
        missing=[k for k in required if k not in boundary]
        if missing:raise ValueError(f'Missing {len(missing)} explicit boundary coefficients; first selectors: {missing[:5]}')
        if any(not isinstance(value,arb) or not value.is_finite() for value in boundary.values()):raise ValueError('Each boundary coefficient must be a finite real Arb ball with source error included')
        rhs=tuple(boundary[k] for k in self.selected)
        constants=tuple(dot(row,rhs) for row in self.inverse)
        if any(not x.is_finite() for x in constants):raise ValueError('Nonfinite matched Frobenius constant')
        for k,value in boundary.items():
            residual=dot(self.rows[self.positions[k]],constants)-value
            if not residual.contains(0):raise ValueError(f'Inconsistent infinity boundary selector {k}; residual={residual.str(35)}')
        report={'schema':'vakint.pr11d.checked-real-ball-infinity-matching.v1','exact_matching_sha256':self.binding,'inventory_sha256':inventory_sha256,'normalization':normalization,'error_quality':error_quality,'checked_coefficients':len(boundary),'all_prepared_coefficients_checked':require_all_prepared_rows,'free_constants':252,'working_bits':ctx.prec,'seconds':time.monotonic()-start,'all_overdetermined_residuals_contain_zero':True,'whole_PR11d_accuracy_claimed':False}
        return BoundarySolution(constants,report)
def main():
    parser=argparse.ArgumentParser();parser.add_argument('input',type=Path);parser.add_argument('output',type=Path);parser.add_argument('--working-digits',type=int,required=True);args=parser.parse_args()
    if args.working_digits<32:raise ValueError('At least32workingdigits required')
    ctx.dps=args.working_digits;source=json.loads(args.input.read_text());boundary={}
    for row in source['coefficients']:
        k=key(row)
        if k in boundary:raise ValueError(f'Duplicate explicit selector {k}')
        boundary[k]=arb(row['real_ball'])
    result=Matching().solve(boundary,inventory_sha256=source['inventory_sha256'],normalization=source['normalization'],error_quality=source['error_quality'],require_all_prepared_rows=source.get('require_all_prepared_rows',True))
    output={**result.report,'input_sha256':sha(args.input),'free_constant_balls':[x.str(args.working_digits+8,more=True) for x in result.constants]}
    args.output.write_text(json.dumps(output,indent=2)+'\n');print('Matched252constants; checked',len(boundary),'explicit boundary rows')
if __name__=='__main__':main()
