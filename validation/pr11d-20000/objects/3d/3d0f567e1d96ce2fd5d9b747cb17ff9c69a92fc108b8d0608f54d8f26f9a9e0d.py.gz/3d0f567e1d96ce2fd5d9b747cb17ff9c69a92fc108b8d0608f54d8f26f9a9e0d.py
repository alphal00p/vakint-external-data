#!/usr/bin/env python3
"""Hypergeometric H epsilon coefficients by exact finite-harmonic algebra."""
from collections import Counter
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path
import hashlib,json,math
from flint import fmpq,fmpq_poly
from mzv import stuffle,relations,add
HERE=Path(__file__).resolve().parent
class RF:
    def __init__(self,n,d=1):
        if not isinstance(n,fmpq_poly):n=fmpq_poly([n])
        if not isinstance(d,fmpq_poly):d=fmpq_poly([d])
        assert d
        g=n.gcd(d);self.n=n//g;self.d=d//g
        lead=self.d[self.d.degree()];self.n=self.n/lead;self.d=self.d/lead
    def __add__(self,b):return RF(self.n*b.d+b.n*self.d,self.d*b.d)
    def __neg__(self):return RF(-self.n,self.d)
    def __sub__(self,b):return self+-b
    def __mul__(self,b):return RF(self.n*b.n,self.d*b.d)
    def __truediv__(self,b):return RF(self.n*b.d,self.d*b.n)
    def __pow__(self,k):return RF(self.n**k,self.d**k) if k>=0 else RF(self.d**-k,self.n**-k)
    def __bool__(self):return bool(self.n)
    def parts(self):
        assert self.n.degree()<self.d.degree()
        out=[];reconstructed=RF(0)
        for a in (0,1):
            mono=fmpq_poly([-a,1]);d=self.d;order=0
            while d and not d%mono:d=d//mono;order+=1
            if not order:continue
            def shift(poly):return [sum((poly[j]*math.comb(j,k)*a**(j-k) for j in range(k,poly.degree()+1)),fmpq(0)) for k in range(order)]
            num=shift(self.n);den=shift(d);co=[];assert den[0]
            for k in range(order):co.append((num[k]-sum((den[j]*co[k-j] for j in range(1,k+1)),fmpq(0)))/den[0])
            for k,c in enumerate(co):
                if c:
                    pole=order-k;out.append((a,pole,Q(int(c.numerator),int(c.denominator))));reconstructed=reconstructed+RF(c,mono**pole)
        assert not (reconstructed-self)
        return out
M=RF(fmpq_poly([0,1]));ONE=RF(1)
def add_h(a,b):
    out=a.copy()
    for w,c in b.items():out[w]=out.get(w,RF(0))+c
    return {w:c for w,c in out.items() if c}
def scale_h(a,q):return {w:c*RF(fmpq(q.numerator,q.denominator)) for w,c in a.items()}
def mul_h(a,b):
    out={}
    for u,c in a.items():
        for v,d in b.items():
            for w,n in stuffle(u,v).items():out[w]=out.get(w,RF(0))+c*d*RF(n)
    return {w:c for w,c in out.items() if c}
def log_coefficient(k):
    # m=n+1, H_{m-1}^{(k)} is represented by the one-index word(k,).
    rational=((M-ONE)**-k+RF(4**k+2**k)*(M**-k)-RF(4**k+2**k))/RF(k)
    return {(k,):RF(fmpq(4**k-1,k)),():rational}
def sum_harmonic(a):
    mzvs={};constant=Q(0)
    def term(word,c):mzvs[word]=mzvs.get(word,Q(0))+c
    for word,rational in a.items():
        for center,power,c in rational.parts():
            term((power,)+word,c)
            if center==0 and not word:constant-=c
            if center==1 and word:term((power+word[0],)+word[1:],c)
    mzvs={w:c for w,c in mzvs.items() if c}
    assert all(w[0]>=2 for w in mzvs),'uncancelled divergent zeta(1,...)'
    return mzvs,constant

def main():
    reductions,evidence=relations();series=[{():ONE}]
    outputs=[]
    base=ONE/((M-ONE)*M**2)
    for order in range(1,6):
        if order>1:
            target={}
            for k in range(1,order):target=add_h(target,scale_h(mul_h(log_coefficient(k),series[order-1-k]),Q(k,order-1)))
            series.append(target)
        coeff={w:c*base for w,c in series[order-1].items()};words,constant=sum_harmonic(coeff)
        result={(0,0,0):-constant} if constant else {}
        for word,c in words.items():result=add(result,reductions[word],-c)
        outputs.append(result)
        print('H epsilon',order, result,flush=True)
    expected=[{(1,0,0):Q(1),(0,0,0):Q(-2)},{(0,1,0):Q(9),(1,0,0):Q(-5),(0,0,0):Q(-3)},{(2,0,0):Q(101,5),(0,1,0):Q(-45),(1,0,0):Q(3),(0,0,0):Q(-6)},{(0,0,1):Q(207),(1,1,0):Q(18),(2,0,0):Q(-101),(0,1,0):Q(27),(1,0,0):Q(3),(0,0,0):Q(-15)}]
    assert outputs[:4]==expected
    report={'schema':'vakint.pr11d.p853-H-epsilon-extension.v1','definition':'H(epsilon)=3F2(1,-epsilon,1-2epsilon;2-4epsilon,2-2epsilon;1)','summand_identity':'H=1-epsilon*sum_{m>=2} exp(sum_{k>=1}epsilon^k*((4^k-1)H_{m-1}^{(k)}+(m-1)^(-k)+(4^k+2^k)*m^(-k)-(4^k+2^k))/k)/((m-1)m^2)','monomial_order':['zeta2_power','zeta3_power','zeta5_power'],'coefficients':[{'epsilon_power':k+1,'terms':[{'powers':m,'rational':[c.numerator,c.denominator]} for m,c in sorted(row.items())]} for k,row in enumerate(outputs)],'existing_Grozin_orders1through4_reproduced':True,'MZV_reduction_evidence':evidence,'all_partial_fraction_reconstructions_exact':True,'all_divergent_zeta1_terms_cancelled':True,'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),HERE/'mzv.py']},'numerical_PR11d_accuracy_claimed':False}
    (HERE/'H-through-epsilon5.json').write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__':main()
