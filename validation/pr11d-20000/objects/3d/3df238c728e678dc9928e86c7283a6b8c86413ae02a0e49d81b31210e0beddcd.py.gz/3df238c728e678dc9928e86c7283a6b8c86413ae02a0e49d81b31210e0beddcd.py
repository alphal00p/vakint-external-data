#!/usr/bin/env python3
"""Compose exact constant scaling with the independently reviewed RPF appender."""
from pathlib import Path
import argparse,contextlib,hashlib,io,json,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(HERE));import prepare_scaled_segment as scaled
sys.path.insert(0,str(ROOT/'helper/jet-transport'));import append_rpf_scaled as appender
if not __debug__:raise RuntimeError('Assertions required')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    parser=argparse.ArgumentParser(add_help=False);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--connection',type=Path,required=True);args,remaining=parser.parse_known_args()
    assert not args.output.exists() and not args.output.with_suffix('.json').exists(),'Saved RPF input may not be overwritten'
    connection=json.loads(args.connection.read_text());assert connection['name']=='pr9-22'
    rpf=ROOT/'ancestor-flows/pr9-22-ordinary-rational-pf.json';prefix=args.output.with_suffix('.polynomial.in')
    sys.argv=[sys.argv[0]]+remaining+['--connection',str(args.connection),'--output',str(prefix)]
    with contextlib.redirect_stdout(io.StringIO()):scaled.main()
    sys.argv=[sys.argv[0],'--input',str(prefix),'--metadata',str(prefix.with_suffix('.json')),'--rational-pf',str(rpf),'--output',str(args.output)]
    with contextlib.redirect_stdout(io.StringIO()):appender.main()
    path=args.output.with_suffix('.json');metadata=json.loads(path.read_text())
    dependencies=[Path(__file__),HERE/'prepare_scaled_segment.py',Path(appender.__file__),ROOT/'helper/jet-transport/prepare_generic_segment.py',ROOT/'helper/frobenius-transport/native/prepare_v2.py']
    metadata['implementation_dependency_sha256']={str(p.resolve()):sha(p) for p in dependencies};path.write_text(json.dumps(metadata,indent=2)+'\n')
    print('PreparedexactscaledRPF',args.output,metadata['input_sha256'])
if __name__=='__main__':main()
