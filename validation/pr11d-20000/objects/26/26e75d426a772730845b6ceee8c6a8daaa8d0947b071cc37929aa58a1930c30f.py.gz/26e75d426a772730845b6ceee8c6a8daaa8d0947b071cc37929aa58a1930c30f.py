"""Measure original-MMA solver stability without inflating source accuracy."""
from pathlib import Path
from fractions import Fraction as F
import ast,re,json,hashlib,math,sys
from flint import arb,acb,ctx
ROOT=Path(__file__).resolve().parent;ctx.dps=280
if not __debug__:raise RuntimeError('Acceptance comparison requires assertions enabled')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def mma(s):
 assert isinstance(s,str)
 text=re.sub(r'`{1,2}(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)','',s).replace('*^','e').replace('^','**')
 node=ast.parse(text,mode='eval').body
 def read(n):
  if isinstance(n,ast.Constant) and type(n.value) in [int,float]:
   exact=ast.get_source_segment(text,n)
   return acb(arb(exact))
  if isinstance(n,ast.Name) and n.id=='I':return acb(0,1)
  if isinstance(n,ast.UnaryOp):
   if isinstance(n.op,ast.USub):return -read(n.operand)
   if isinstance(n.op,ast.UAdd):return read(n.operand)
  if isinstance(n,ast.BinOp):
   a,b=read(n.left),read(n.right)
   if isinstance(n.op,ast.Add):return a+b
   if isinstance(n.op,ast.Sub):return a-b
   if isinstance(n.op,ast.Mult):return a*b
   if isinstance(n.op,ast.Div):return a/b
   if isinstance(n.op,ast.Pow):
    exponent=ast.literal_eval(n.right);assert type(exponent) is int;return a**exponent
  raise ValueError(ast.dump(n))
 result=read(node);assert result.is_finite();return result

def observed_digits(error):
 if error.is_zero():return None
 assert error.is_finite() and error>0
 return int((-error.log()/arb(10).log()).lower().floor().fmpz())
def norm(value):return abs(value).upper()
def compare(label,refine=None):
 p=ROOT/f'{label}-result.json';data=json.loads(p.read_text());assert data['segments']==48 and data['solver']=='Original AMFlow2.0 DESolver MMA CalcRun'
 assert data['source_error_quality']=='validated-digits-estimate' and not data['physical_accuracy_certified'] and not data['whole_PR11d_20000_accuracy_claimed']
 for name,field in [('input.json','input_sha256'),('exact-lift.wl','matrix_sha256'),('upstream/diffeq_solver/DESolver.m','solver_sha256')]:assert data[field]==sha(ROOT/name)
 answer=mma(data['finite_coefficient']);vector=list(map(mma,data['vector']));assert len(vector)==252
 input=json.loads((ROOT/'input.json').read_text());V=[acb(arb(pair[0]['center']),arb(pair[1]['center'])) for pair in input['endpoint_adjoint']]
 projection=sum((V[k*42+i]*vector[(5-k)*42+i] for k in range(6) for i in range(42)),acb(0))
 projection_difference=norm(projection-answer);assert projection_difference<arb(10)**(-data['working_digits']+30)
 native_path=ROOT.parent/'physical-prototype/result.json';native=json.loads(native_path.read_text());native_value=acb(arb(native['real_ball']),arb(native['imaginary_ball']))
 native_difference=norm(answer-native_value);native_digits=observed_digits(native_difference/max(arb(1),norm(native_value)))
 # This archived reference is first opened after the independent solve and is
 # never part of its initial vector, matrix, path or endpoint adjoint.
 ref_path=ROOT/'p17-reference-snapshot.json';reference=json.loads(ref_path.read_text());rows=reference if isinstance(reference,list) else reference['data'];ref=arb(next(r[1] for r in rows if r[0]==0))
 refdifference=abs(answer.real-ref).upper();refdigits=observed_digits(refdifference/max(arb(1),abs(ref).upper()));imagdigits=observed_digits(abs(answer.imag).upper()/max(arb(1),abs(answer.real).upper()))
 result={'schema':'vakint.pr11d.original-AMFlow-oracle-comparison.v1','label':label,'solver_result_sha256':sha(p),'input_quality':'validated-digits-estimate','physical_accuracy_certified':False,'whole_PR11d_20000_accuracy_claimed':False,'independence_scope':data['independence_scope'],'working_digits_are_not_source_accuracy':True,'finite_real_central_value':answer.real.mid().str(data['working_digits'],radius=False),'finite_imaginary_central_value':answer.imag.mid().str(data['working_digits'],radius=False),'printed_center_storage_digits':data['working_digits'],'central_parse_rounding_radius_is_not_a_physical_error_bound':True,'independent_projection_absolute_difference':projection_difference.str(35),'native_prototype_path':str(native_path),'native_prototype_sha256':sha(native_path),'native_prototype_absolute_complex_difference':native_difference.str(35),'native_prototype_observed_agreed_digits_lower_bound':native_digits,'archived_P17_reference_path':str(ref_path),'archived_P17_reference_sha256':sha(ref_path),'archived_reference_observed_real_agreed_digits_lower_bound':refdigits,'imaginary_suppression_digits_lower_bound':imagdigits,'normalization':data['normalization'],'scope':'Observed numerical agreement and refinement of original independent ordinary solver, sharing exact DE, estimated190-digit starting boundary and endpoint projection; not a rigorous independent physical-boundary validation.'}
 if refine:
  rpath=ROOT/f'{refine}-result.json';r=json.loads(rpath.read_text());assert r['segments']==48 and r['input_sha256']==data['input_sha256'] and r['matrix_sha256']==data['matrix_sha256'] and r['solver_sha256']==data['solver_sha256']
  assert r['solver']==data['solver'] and r['source_error_quality']==data['source_error_quality'] and r['normalization']==data['normalization'] and r['independence_scope']==data['independence_scope']
  assert not r['physical_accuracy_certified'] and not r['whole_PR11d_20000_accuracy_claimed']
  assert r['working_digits']>data['working_digits'] and r['taylor_order']>data['taylor_order']
  refined_vector=list(map(mma,r['vector']));assert len(refined_vector)==252
  value=mma(r['finite_coefficient']);refined_projection=sum((V[k*42+i]*refined_vector[(5-k)*42+i] for k in range(6) for i in range(42)),acb(0))
  assert norm(refined_projection-value)<arb(10)**(-r['working_digits']+30)
  delta=norm(answer-value);digits=observed_digits(delta/max(arb(1),norm(value)))
  result.update(refinement_label=refine,refinement_result_sha256=sha(rpath),refinement_scaled_complex_difference=delta.str(35),refinement_observed_agreed_digits_lower_bound=digits)
  assert digits>=70 and refdigits>=70 and native_digits>=70 and imagdigits>=70
  result['practical_70_digit_solver_crosscheck_passed']=True
 (ROOT/f'{label}-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
if __name__=='__main__':
 if len(sys.argv)>1:compare(sys.argv[1],sys.argv[2] if len(sys.argv)>2 else None)
 else:
  smoke=json.loads((ROOT/'smoke130c-result.json').read_text());assert len(list(map(mma,smoke['vector'])))==252;print('PASS all252 smoke vector numbers parsed without binary floating-point conversion')
