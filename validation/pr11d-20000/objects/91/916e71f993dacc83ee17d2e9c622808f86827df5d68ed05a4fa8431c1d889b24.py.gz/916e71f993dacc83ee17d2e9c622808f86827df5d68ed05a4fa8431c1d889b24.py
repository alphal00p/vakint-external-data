#!/usr/bin/env python3
"""Freeze the independently reviewed A49 checker, premises and actual data."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
PR11 = BASE.parents[1]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def strip_timings(value):
    if isinstance(value, dict):
        return {k: strip_timings(v) for k, v in value.items() if k != 'seconds'}
    if isinstance(value, list):
        return [strip_timings(v) for v in value]
    return value


def main():
    expected = {
        BASE / 'replay.py': '58f752abeaf276dd4c7274e9ae33c047c0a7fd352cbb49306d4afac73f7cb415',
        BASE / 'seal.py': '40d13722473b85ab97f63b4df8d553e925dbc81997225103874700374edf18da',
        BASE / 'lineage-contract.json': 'ae62ecdd69945bdcd46bf5ce5d22d580ba50ecf6cbee8cbf50813e64afed5923',
        BASE / 'chain-data-review-v2.json': '0a2ca69db70e42f6c75d768b78426c4e9f6470594f09209a6cf8b38a6a413a4c',
        BASE / 'endpoint-replay/replay-snapshot.json': 'd0c195c1d051a352fb35c96ee3b77d4ba8a22bf33a69a85365f3db2a604a807a',
        BASE / 'endpoint-replay/canonical-routing/witness-snapshot.json': '2381970b5a108eb7627dfc42ea49e43e843a32793652c025caa43237f4ed9586',
        BASE / 'initial-review/accepted.json': '236dcb57505efe6fed65e78a487e016465f3f3165b656765507212a086865ca0',
        BASE / 'initial-review/independent-review/review.json': 'b435262db6b92a8ebea4a9b6079e84bbcd9c170394f533ee1e7ab5b4bd5377d8',
        HERE / 'lineage/pole22/review.json': '5d84e2484d3c5ab73dc495d861d99301d37543f070281d0c1303dfe10970e7d7',
        HERE / 'pole22-parent-review.json': 'c85dbc614f36bc05fddb17ae6329a048ac7fe72f1539ed1d223eef3ff4cef201',
        HERE / 'independent-saved-replay.json': 'ae4f94f0e76bd732c2e21db523f2c83eeea25522b42cc5a737e3669600bae66a',
        HERE / 'endpoint-component-review.json': '1a19a4b07b464de346806d057adc473f6de50fdcb8c8c50f4fb920846b4bb539',
        HERE / 'lineage/review.json': 'f26352dc6c6964033b6acc20378a33291703ea20f86067caa7795b3fc2a36240',
        HERE / 'lineage/actual-data-v2.json': '90730a1b3d5d413b4bdd3890b90e82faee3f5e58e4e2d6968d60294980b85cd6',
        HERE / 'highlevel-guard-results-v2.json': 'bb9ab0e4facc91083a0b386c5f48931c31521399e5783734b85b6906c232c155',
        HERE / 'seal-guards/guard-rejections-v2.json': 'eea9146a8911e6caa827ae44313440bfcbd53b31521bc7ea918c825f9a4dd8db',
    }
    pins = {}

    def add(path, digest):
        p = Path(path)
        assert p.is_absolute() and p.resolve() == p and p.is_file(), str(p)
        assert sha(p) == digest, str(p)
        assert str(p) not in pins or pins[str(p)] == digest, 'Conflicting source pin: ' + str(p)
        pins[str(p)] = digest

    def graph(data, field):
        if field not in data:
            return
        values = data[field]
        assert isinstance(values, dict), field
        for key, value in values.items():
            if isinstance(value, dict):
                assert set(value) == {'path', 'sha256'}
                key, value = value['path'], value['sha256']
            add(key, value)

    for p, digest in expected.items():
        add(p, digest)
    chain = read(BASE / 'chain-data-review-v2.json')
    replay = read(HERE / 'independent-saved-replay.json')
    assert strip_timings(chain) == strip_timings(replay)
    endpoint = read(BASE / 'endpoint-replay/replay-snapshot.json')
    initial = read(BASE / 'initial-review/accepted.json')
    initial_review = read(BASE / 'initial-review/independent-review/review.json')
    assert initial['accepted'] is True and initial['source_only'] is False
    assert initial_review['accepted'] is True
    assert initial['independent_review_sha256'] == sha(BASE / 'initial-review/independent-review/review.json')
    assert initial['fresh_native_invocation_sha256'] == initial_review['native_invocation_sha256']
    invocation = read(initial['fresh_native_invocation_path'])
    add(initial['fresh_native_invocation_path'], initial['fresh_native_invocation_sha256'])
    assert invocation['accepted_same_input_same_binary_replay'] is True
    assert invocation['all_numerical_history_and_contract_fields_equal'] is True
    assert invocation['returncode'] == 0 and type(invocation['returncode']) is int
    assert initial['initial_artifact_sha256'] == chain['initial_sha256']
    assert endpoint['final_boundary_sha256'] == chain['final_boundary_sha256']
    ep_review = read(HERE / 'endpoint-component-review.json')
    assert ep_review['accepted_for_frozen_scope'] is True
    assert ep_review['endpoint_replay_sha256'] == sha(BASE / 'endpoint-replay/replay-snapshot.json')
    pole = read(HERE / 'lineage/pole22/review.json')
    assert pole['accepted'] is True and pole['raw_22_basis_pole_bound_verified'] is True
    assert pole['raw_source_sha256'] == chain['raw_source_sha256']
    assert read(HERE / 'pole22-parent-review.json')['certificate_sha256'] == sha(HERE / 'lineage/pole22/review.json')
    guards = read(HERE / 'seal-guards/guard-rejections-v2.json')
    assert guards['seal_sha256'] == sha(BASE / 'seal.py')
    assert guards['rejection_count'] == 105 and len(guards['positive_controls']) == 4
    assert guards['stale_actual_component_graph_pins'] == []
    highlevel = read(HERE / 'highlevel-guard-results-v2.json')
    assert highlevel['rejection_count'] == 30
    fields = ['source_pins', 'implementation_sha256', 'artifact_sha256',
              'source_and_checker_sha256', 'source_and_artifact_sha256']
    current_components = [chain, endpoint, initial, initial_review, ep_review, pole,
                          read(HERE / 'lineage/actual-data-v2.json'),
                          read(HERE / 'lineage/review.json'), highlevel, guards]
    for data in current_components:
        for field in fields:
            graph(data, field)
    # Preserve the already independently reviewed general theorem's declared
    # implementation and scientific source graph as part of the new application.
    general = read(PR11 / 'helper/physical-poles-review/review.json')
    graph(general, 'implementation_sha256')
    graph(general, 'transitive_source_sha256')
    config = read(BASE / 'lineage-contract.json')
    graph(config, 'checker_implementation_sha256')
    for p in [HERE / 'check_highlevel_guards.py', HERE / 'check_endpoint_component.py',
              HERE / 'seal-guards/guard_rejections_v2.py', Path(__file__).resolve()]:
        add(p, sha(p))
    implementations = {str(p): sha(p) for p in [BASE / 'replay.py', BASE / 'seal.py',
                         BASE / 'lineage-contract.json',
                         BASE.parent / 'ordinary-chain-acceptance-v1/common.py']}
    implementations.update(config['checker_implementation_sha256'])
    result = {
        'schema': 'vakint.production-A-whole-physical-source-independent-review.v1',
        'status': 'passed_for_frozen_production_A_physical_source_checker',
        'accepted': True,
        'checker_sha256': sha(BASE / 'replay.py'),
        'seal_sha256': sha(BASE / 'seal.py'),
        'lineage_contract_sha256': sha(BASE / 'lineage-contract.json'),
        'chain_data_review_sha256': sha(BASE / 'chain-data-review-v2.json'),
        'endpoint_replay_sha256': sha(BASE / 'endpoint-replay/replay-snapshot.json'),
        'initial_admission_sha256': sha(BASE / 'initial-review/accepted.json'),
        'endpoint_sha256': endpoint['endpoint_sha256'],
        'canonical_binding_proof_sha256': endpoint['canonical_binding_proof_sha256'],
        'raw_22_basis_pole_bound_verified': True,
        'raw_source_sha256': chain['raw_source_sha256'],
        'raw_22_pole_bound_certificate_path': str(HERE / 'lineage/pole22/review.json'),
        'raw_22_pole_bound_certificate_sha256': sha(HERE / 'lineage/pole22/review.json'),
        'implementation_sha256': implementations,
        'source_pins': dict(sorted(pins.items())),
        'independent_checks': {
            'saved_step_replay_count': 49,
            'saved_step_replay_matches_producer_receipt_except_audit_timings': True,
            'exact_raw_to_regular_matrix_entries': 484,
            'per_step_full_input_and_output_box_containments': 132,
            'independent_continuation_seams': 3,
            'historical_kernel_segment_step_counts': [2, 2, 1, 44],
            'mask_and_row_profiles': 47, 'coefficient_precision_schedule_profiles': 45,
            'explicit_requested8_actual8_cap16_records': 44,
            'highlevel_rejection_controls': 30,
            'aggregate_seal_rejection_controls': 105,
            'aggregate_seal_positive_controls': 4,
            'endpoint_independent_complex_products': 3234,
            'endpoint_full_component_containments': 84,
            'endpoint_rejection_controls': 10,
            'canonical_PR9d_exact_Fraction_quadratic_identities': 7,
            'canonical_PR9d_integer_Jacobian_absolute_value': 1,
            'selected22_scalar_rows': 21,
            'numerator_row_S4_unimodular_permutations': 24,
            'pinched_four_tadpole_factorizations': 3,
            'initial_independent_review_sha256': initial['independent_review_sha256'],
            'fresh_initial_invocation_sha256': initial['fresh_native_invocation_sha256'],
            'all_132_source_seed_boxes_and_normalized_raw_arrays_bound': True,
        },
        'scientific_closure': [
            'All21 scalar selected rows are massive four-loop denominator graphs satisfying the independently reviewed scalar UV-forest theorem. The sole numerator row has an exact S4 symmetry reduction to scalar I1, scalar I8 and four-tadpole products without epsilon-singular coefficients. Therefore the complete physical selected22 system is O(epsilon^-4) on Re(eta)>-1.',
            'The exact epsilon-regular unit-gauge connection has no negative epsilon powers. The common physical lower bound -4 therefore closes the six transported coefficients through epsilon^1; unknown higher coefficients cannot feed them.',
            'Each continuation starts from the complete preceding raw ball vector. Exact constant component scaling and inverse unit gauge preserve the full intervals. All49 source-bound residual certificates and original outward serializations were verified.',
            'Seven reviewed analytic endpoint operators convolve with the final transported vector in the original operation order. All42 complex coefficients and84 Cartesian serialized boxes reproduce and contain the computed intervals. Exact canonical bindings include the nonliteral PR9d routing.',
        ],
        'resolved_findings': [
            'The final44-step worker claim now explicitly requires requested8, actual8 and cap16; the preceding scheduled step remains qualified as requested8, source-capped4, without native actual-team metadata.',
            'A concurrently changed live manifest was rejected. New additive checker/receipt versions use the recovered exact b40 manifest bytes in an immutable snapshot. Mathematical function bodies and canonical proof payloads are unchanged.',
            'The raw22 numerator exception is covered by a new exact symmetry reduction and theorem application; the positive-only raw42 enumeration is not used as a substitute.',
        ],
        'findings': [],
        'total_error_guard': 'All admitted endpoint Cartesian component radii are strictly below1e-20050; this is a whole-source enclosure statement, not a local-tail-only assertion.',
        'historical_worker_qualification': chain['historical_scheduled_segment_workers'],
        'native_execution_scope': 'This reviewer ran no native, preparer, HPL or transport engine. The final initial admission incorporates a separately executed and independently reviewed same-input/same-binary4-worker reproduction. Later transport/adjoint output correctness inherits the reviewed frozen kernels and exact artifact/certificate bindings.',
        'IBP_scope': 'Inherits authenticated source IBP and selected-solution mappings. No independent IBP regeneration is claimed.',
        'source_graph_files_verified': len(pins),
        'native_preparer_HPL_or_transport_calls_by_this_review': 0,
        'producer_files_modified_by_this_review': False,
        'old_artifacts_preserved': True,
        'exact_zeros_not_inferred_from_small_intervals': True,
        'whole_PR11d_20000_accuracy_claimed': False,
        'PR11d_validated_decimal_cap': 200,
    }
    for path, digest in pins.items():
        assert sha(path) == digest
    target = HERE / 'review.json'
    with target.open('x') as stream:
        stream.write(json.dumps(result, indent=2) + '\n')
    print(str(target))
    print(sha(target))
    print('source pins', len(pins))


if __name__ == '__main__':
    main()
