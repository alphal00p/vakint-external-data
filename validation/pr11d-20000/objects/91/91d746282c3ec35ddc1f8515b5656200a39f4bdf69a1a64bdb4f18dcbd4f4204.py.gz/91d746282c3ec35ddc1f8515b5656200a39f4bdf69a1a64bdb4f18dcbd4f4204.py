"""Replay serialized X8 witnesses and seal their strictly limited scope."""
from replay import *
from symmetries import determinant, transform_expression
import datetime

def decoded_matrix(rows):
    t=tuple(tuple(Fraction(x) for x in row) for row in rows)
    assert abs(determinant(t))==1
    return t

def equation(index):
    seed=BASIS[index];row={}
    if seed[3]:
        n=list(seed);n[3]+=1;add(row,tuple(n),Rat(seed[3]))
    for n,c in zip(BASIS,DATA['differential_matrix'][index]):
        add(row,n,-parse(c,DATA['epsilon_symbol'],DATA['variable']))
    return row

def exact_equal(a,b):
    difference=a.copy();muladd(difference,b,-ONE)
    return not difference

def proof_row(proof,ident):
    if ident[0]=='ibp':
        _,n,i,j=ident;return ibp(tuple(n),i,j)
    if ident[0]=='routing':
        _,n,k=ident;p=tuple(n)
        t=decoded_matrix(proof['routing_matrices'][k])
        image=transform_expression(p,t)
        assert image is not None
        row={p:ONE};muladd(row,image,-ONE);return row
    if ident[0]=='positive-routing':
        _,a,b=ident;a=tuple(a);b=tuple(b)
        matching=[r for r in proof['positive_routings'] if tuple(r['source'])==a and tuple(r['target'])==b]
        assert len(matching)==1
        t=decoded_matrix(matching[0]['witness']['matrix'])
        assert exact_equal(transform_expression(a,t),{b:ONE})
        return {a:ONE,b:-ONE}
    raise AssertionError(ident)

def reconstruct(proof):
    row={}
    for term in proof['witness']:
        muladd(row,proof_row(proof,term['row']),parse(term['coefficient'],'e','x'))
    return row

def target_equation(index):
    target=DATA['target_reductions'][index]
    row={tuple(target['powers']):ONE}
    for term in target['terms']:
        add(row,tuple(term['powers']),-parse(term['coefficient'],DATA['epsilon_symbol'],DATA['variable']))
    return row

def main():
    inventory=json.loads((HERE/'source/inventory.json').read_text())
    for entry in inventory['files']:
        payload=(HERE/'source'/entry['path']).read_bytes()
        assert len(payload)==entry['bytes'] and hashlib.sha256(payload).hexdigest()==entry['sha256']
    log=(HERE/'source/kira.log').read_text()
    assert 'Kira will use the integral ordering: 2.' in log
    assert '1 2 3 4 5 6 7 8 0 9' in log
    declared={int(x) for x in (HERE/'source/trivialsector').read_text().replace('\n',',').split(',') if x.strip()}
    assert declared=={s for s in range(1024) if rank_sector(s)<4}
    files=['derivative-replay.json','derivative-expanded-replay.json']
    if (HERE/'derivative-dot-replay.json').exists():files.append('derivative-dot-replay.json')
    accepted={}
    for file in files:
        data=json.loads((HERE/file).read_text())
        for proof in data['proofs']:
            if not proof['proved']:continue
            index=proof['row']
            assert exact_equal(equation(index),reconstruct(proof)),(file,index)
            accepted[index]={'file':file,'proof':proof}
    # The P17 certificate has its own fixed pair of physical routing matrices.
    p17=json.loads((HERE/'target-physical-replay.json').read_text())
    p17_proof=p17['proofs'][2]
    from symmetries import physical_automorphisms
    p17_proof['routing_matrices']=[[[str(x) for x in row] for row in t] for perm,t in physical_automorphisms()]
    assert p17_proof['proved']
    actual=target_equation(2);generated=reconstruct(p17_proof)
    assert exact_equal(actual,generated)
    # First target is a separately serialized unimodular momentum substitution.
    t0=json.loads((HERE/'target-replay.json').read_text())[0]
    assert not t0['remainder'] and not t0['ibp_witness'] and len(t0['routing_witnesses'])==1
    r=t0['routing_witnesses'][0]
    t=decoded_matrix(r['witness']['matrix'])
    assert exact_equal(transform_expression(tuple(r['source']),t),{tuple(r['target']):ONE})
    assert not target_equation(1) # identity target
    # Deliberately broken witnesses must be detected, not normalized away.
    assert not exact_equal(actual,{k:v*Rat(2) for k,v in generated.items()})
    broken=[list(row) for row in t];broken[0][0]+=1
    rejected=False
    try:
        bt=decoded_matrix(broken)
        bad=transform_expression(tuple(r['source']),bt)
        rejected=bad is None or not exact_equal(bad,{tuple(r['target']):ONE})
    except AssertionError:
        rejected=True
    assert rejected
    all_files=files+['replay.py','target.py','target_physical.py','symmetries.py','routing.py','sector_symmetries.py',
                     'derivatives.py','validate.py','local_replay.py','verify_local.py','local-replay.json',
                     'local-replay-validation.json','target-replay.json','target-physical-replay.json',
                     'sector-symmetries.json','source/prepared-system.json','source/kira-round3.db','source/kira_target.m',
                     'source/inventory.json','../helper/exact_system.py','README.md','requirements.txt']
    hashes={s:hashlib.sha256((HERE/s).read_bytes()).hexdigest() for s in all_files}
    local=json.loads((HERE/'local-replay-validation.json').read_text())
    assert local['passed'] and local['witness_file_sha256']==hashes['local-replay.json']
    report={
        'schema':'vakint.pr11d.independent-exact-IBP-witness-replay.v1',
        'timestamp_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'independent_of_Kira_equation_generation_and_reduction':True,
        'mathematical_field':'Q(epsilon,eta), with d=4-2 epsilon',
        'source_family_sha256':DATA['source_family_sha256'],
        'source_system_sha256':hashes['source/prepared-system.json'],
        'deformation':'D3=k4^2-1-eta; other Dr=(vr.k)^2-1',
        'denominator_quadratic_rank':10,
        'IBP_definition':'integral d/dk_i . [k_j product_r Dr^(-n_r)] = 0, independently expanded from quadratic forms',
        'scaleless_sectors':'exact momentum rank<4, including polynomial numerator factors; agrees with all archived declarations',
        'routing_conditions':'exact GL(4,Z) loop changes with determinant +/-1 and every active massive quadratic checked, including ISP polynomials',
        'de_rows_total':42,'de_rows_independently_proved':sorted(accepted),
        'de_rows_still_trusting_external_Kira':[i for i in range(42) if i not in accepted],
        'target_relations_total':3,'target_relations_independently_proved':[0,1,2],
        'physical_P17_projection':'I[0,2,1,1,1,1,1,1,1,0] = B30-B36-epsilon B37-B38',
        'physical_P17_witness':p17_proof['witness'],
        'physical_P17_seed':list(BASIS[37]),
        'archived_raw_equations_independently_replayed':local['exact_rows_replayed'],
        'archived_raw_equations_without_local_certificate':local['remaining_rows'],
        'complete_independent_DE_validation':len(accepted)==42,
        'full_PR11d_independent_IBP_validation':False,
        'precision_cap_upgraded':False,
        'numeric_master_values_or_digits_used':False,
        'existing_nonzero_conditions_preserved':DATA['nonzero_conditions'],
        'applicability':'generic meromorphic identities; existing recorded source guards remain authoritative; no new pointwise campaign coverage claim',
        'remaining_scope':['listed coupled X8 DE rows','PR9 source reduction/compression not audited by this replay','boundary factorization/normalization and transport require their separate certificates'],
        'finite_universe_rank_alternative':{'database_integral_universe':2541,'closed_independent_IBP_rows':520,'represented_variables':1058,'full_rank_certificate':False},
        'negative_controls':['doubling P17 witness coefficient set rejected by exact subtraction','altered routing matrix rejected or fails active quadratic comparison'],
        'files_sha256':hashes,
    }
    (HERE/'REPLAY_RECEIPT.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('files_sha256','physical_P17_witness','existing_nonzero_conditions_preserved')},indent=2))

if __name__=='__main__':main()
