#!/usr/bin/env python3
"""Exact ordinary connection preparation for the ancestor flow hierarchy."""
import argparse,hashlib,json,math,sys
from fractions import Fraction as Q
from pathlib import Path
from flint import arb,acb,ctx,fmpq,fmpq_poly
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'frobenius-transport/native'))
from prepare_v2 import blocks
if not __debug__:raise RuntimeError('Assertions required')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(a,b):return a[0]+b[0],a[1]+b[1]
def mul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def aq(q):return arb(fmpq(q.numerator,q.denominator))
def cq(q):return acb(aq(q[0]),aq(q[1]))
def shift(coeff,c,h,degree):
    cp=[(Q(1),Q(0))];hp=cp[:]
    for _ in range(degree):cp.append(mul(cp[-1],c));hp.append(mul(hp[-1],h))
    out=[(Q(0),Q(0)) for _ in range(degree+1)]
    for n,q in enumerate(coeff):
        for k in range(n+1):
            v=mul(cp[n-k],hp[k]);a=q*math.comb(n,k);out[k]=add(out[k],(a*v[0],a*v[1]))
    return out
def scaled_pair(pair):
    den=math.lcm(*(x.denominator for x in pair));return [int(x*den) for x in pair]+[den]

def segment_polynomial_lower(original,center,step):
    polynomial=fmpq_poly([fmpq(Q(x).numerator,Q(x).denominator) for x in original])
    constant,factors=polynomial.factor();lower=abs(arb(constant));certificates=[]
    length=step[0]**2+step[1]**2;assert length>0
    for factor,multiplicity in factors:
        coeff=[Q(str(factor[k])) for k in range(factor.degree()+1)]
        if factor.degree()==1:
            root=-coeff[0]/coeff[1];delta=(center[0]-root,center[1])
            t=max(Q(0),min(Q(1),-(delta[0]*step[0]+delta[1]*step[1])/length))
            minimum=(delta[0]+t*step[0])**2+(delta[1]+t*step[1])**2
            if minimum<=0:raise ValueError('Segment crosses an exact rational denominator pole')
            bound=abs(aq(coeff[1]))*aq(minimum).sqrt()
            certificates.append({'kind':'linear','coefficients':list(map(str,coeff)),'multiplicity':multiplicity,'minimizing_parameter':str(t),'minimum_root_distance_squared':str(minimum)})
        elif factor.degree()==2 and center[0]==0 and step[0]==0:
            c,b,a=coeff;y0=center[1];y1=y0+step[1]
            low=min(y0*y0,y1*y1);high=max(y0*y0,y1*y1)
            if min(y0,y1)<=0<=max(y0,y1):low=Q(0)
            stationary=-(b*b-2*a*c)/(2*a*a);x=max(low,min(high,stationary))
            minimum=a*a*x*x+(b*b-2*a*c)*x+c*c
            if minimum<=0:raise ValueError('Segment crosses a quadratic denominator zero')
            bound=aq(minimum).sqrt()
            certificates.append({'kind':'quadratic-imaginary-axis','coefficients':list(map(str,coeff)),'multiplicity':multiplicity,'minimizing_y_squared':str(x),'minimum_factor_modulus_squared':str(minimum)})
        else:raise ValueError('No certified segment bound for this denominator factor and path')
        lower*=bound**multiplicity
    if not lower>0:raise ValueError('Unresolved positive factored denominator lower bound')
    return lower.lower(),certificates

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--connection',type=Path,required=True);ap.add_argument('--partial-fractions',type=Path);ap.add_argument('--initial-json',type=Path);ap.add_argument('--normalization',choices=['native_raw'],default='native_raw');ap.add_argument('--center-real',default='0');ap.add_argument('--center-imag',default='256');ap.add_argument('--step-real',default='0');ap.add_argument('--step-imag',default='-16');ap.add_argument('--digits',type=int,default=100);ap.add_argument('--guard',type=int,default=100);ap.add_argument('--max-order',type=int,default=1000);ap.add_argument('--check-every',type=int,default=20);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    source=json.loads(args.connection.read_text());assert sha(source['source'])==source['source_sha256']
    dim=source['dimension'];jets=source['epsilon_jet_count'];assert 1<=dim<=42 and 1<=jets<=6
    natural=max(len(source['denominator_coefficients'])-1,source['numerator_degree'])
    degree=8 if args.partial_fractions else natural
    assert natural<=degree<=16
    c=(Q(args.center_real),Q(args.center_imag));h=(Q(args.step_real),Q(args.step_imag));assert h!=(0,0)
    d=shift([Q(x) for x in source['denominator_coefficients']],c,h,degree);entries=[]
    for e in source['entries']:
        p=[Q(0)]*(degree+1)
        for term in e['terms']:p[term['eta_power']]=Q(int(term['numerator']),int(term['denominator']))
        entries.append((e['row'],e['column'],e['epsilon_power'],[mul(h,x) for x in shift(p,c,h,degree)]))
    bs,owners=blocks(dim,source['entries']);L=1
    for coefficients in [d]+[x[3] for x in entries]:
        for pair in coefficients:
            for q in pair:L=math.lcm(L,q.denominator)
    ctx.dps=100
    # Exact factor-wise segment minima, independent of cancellations in the
    # shifted polynomial. The polynomial equation remains the residual source.
    lower,segment_certificates=segment_polynomial_lower(source['denominator_coefficients'],c,h)
    lower=(lower*L).lower();bits=math.ceil((args.digits+args.guard)*math.log2(10));ctx.prec=bits
    weights=source['regular_epsilon_gauge']['weights'];assert len(weights)==dim and set(weights)<={0,1}
    if args.initial_json:
        initial=json.loads(args.initial_json.read_text());initial_values=initial.get('values',initial.get('original_Y_values'))
        assert len(initial_values)==dim*jets
        if 'eta_center' in initial:assert [Q(x) for x in initial['eta_center']]==list(c),'Initial center mismatch'
        if 'normalization' in initial:assert initial['normalization']==args.normalization
        raw=[acb(arb(re),arb(im)) for re,im in initial_values];assert all(x.is_finite() for x in raw)
        binding=sha(args.initial_json);quality=initial.get('error_quality','caller-must-bind-source-receipt')
    else:raw=[acb(1) for _ in range(dim*jets)];binding='synthetic all-one original jets';quality='synthetic'
    converted=[]
    for jet in range(jets):
        for i in range(dim):
            v=raw[jet*dim+i]
            if jet and weights[i]:v+=2*converted[(jet-1)*dim+i]
            converted.append(v)
    rows=[f'{dim} {jets} {degree} {len(entries)} {len(bs)} {bits} {args.digits} {args.max_order} {args.check_every}',lower.str(85),' '.join(str(owners[i]) for i in range(dim))]
    rows += [f'{int(re*L)} {int(im*L)}' for re,im in d]
    for row,col,jet,coeff in entries:rows += [f'{row} {col} {jet}']+[f'{int(re*L)} {int(im*L)}' for re,im in coeff]
    written=math.ceil(bits*math.log10(2))+10
    rows += [v.real.str(written)+'|'+v.imag.str(written) for v in converted]
    pf_binding=None
    if args.partial_fractions:
        pf=json.loads(args.partial_fractions.read_text());assert pf['source_polynomial_connection_sha256']==sha(args.connection)
        assert pf['regular_epsilon_gauge']==source['regular_epsilon_gauge']
        locations=[Q(x['location']) for x in pf['poles']];terms=[(e,t) for e in pf['residue_entries'] for t in e['terms']];den=int(pf['common_rational_denominator'])
        rows += [f'PF_V1 {len(locations)} {len(terms)}',str(den),' '.join(map(str,scaled_pair(h)))]
        for root in locations:rows.append(' '.join(map(str,scaled_pair((c[0]-root,c[1])))))
        for e,t in terms:
            value=Q(t['value'])*den;assert value.denominator==1 and t['pole_order'] in [0,1,2]
            index=locations.index(Q(t['pole'])) if t['pole_order'] else 0
            rows.append(f"{e['row']} {e['column']} {e['epsilon_power']} {t['pole_order']} {index} {value.numerator}")
        pf_binding=sha(args.partial_fractions)
    args.output.write_text('\n'.join(rows)+'\n')
    meta={'schema':'vakint.generic.ordinary-step-input.v1','dimension':dim,'jets':jets,'degree':degree,'center':[str(x) for x in c],'step':[str(x) for x in h],'normalization':args.normalization,'source_equation_sha256':source['source_sha256'],'polynomial_connection_sha256':sha(args.connection),'partial_fraction_sha256':pf_binding,'input_sha256':sha(args.output),'initial_data_sha256':binding,'source_error_quality':quality,'requested_digits':args.digits,'working_bits':bits,'regular_epsilon_gauge':source['regular_epsilon_gauge'],'denominator_bound_method':'Exact rational linear-factor segment minima and exact imaginary-axis quadratic minima, outward rounded','denominator_segment_certificates':segment_certificates,'denominator_scale':str(L),'denominator_lower_bound':lower.str(85),'physical_period_accuracy_claimed':False}
    args.output.with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2))
if __name__=='__main__':main()
