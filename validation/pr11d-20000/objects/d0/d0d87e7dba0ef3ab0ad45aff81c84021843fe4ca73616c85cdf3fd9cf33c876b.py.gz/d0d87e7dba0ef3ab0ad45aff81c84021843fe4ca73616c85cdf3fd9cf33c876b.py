"""Independently reconstruct every original-DE epsilon coefficient exactly."""
from pathlib import Path
import hashlib,json,sys
from fractions import Fraction as F
from flint import fmpq_poly,fmpq
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
# The parser is a checked exact rational-polynomial parser, not Symbolica's
# producer connection exporter. It accepts only arithmetic, exact integers,
# epsilon and eta; all other syntax is rejected.
namespace={"__file__":str(ROOT/"check_guards.py")};exec((ROOT/'check_guards.py').read_text().split('output=[]')[0],namespace)
parse=namespace['parse']
input=json.loads((ROOT/'input.json').read_text());connection_path=ROOT.parent/'jet-transport/polynomial-connection.json';connection=json.loads(connection_path.read_text());prepared_path=Path(connection['source']);prepared=json.loads(prepared_path.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def polynomial(poly,epsilon):
 terms={int(p[1]):F(str(c)) for p,c in poly.to_dict().items() if int(p[0])==epsilon}
 degree=max(terms,default=0)
 return fmpq_poly([fmpq(terms.get(i,F(0)).numerator,terms.get(i,F(0)).denominator) for i in range(degree+1)])
class R:
 def __init__(self,n,d=1):
  self.n=n if isinstance(n,fmpq_poly) else fmpq_poly(n);self.d=d if isinstance(d,fmpq_poly) else fmpq_poly(d);assert self.d
  g=self.n.gcd(self.d);self.n=self.n/g;self.d=self.d/g
 def __add__(self,o):return R(self.n*o.d+o.n*self.d,self.d*o.d)
 def __neg__(self):return R(-self.n,self.d)
 def __sub__(self,o):return self+-o
 def __mul__(self,o):return R(self.n*o.n,self.d*o.d)
 def __truediv__(self,o):return R(self.n*o.d,self.d*o.n)
 def equals(self,o):return not (self.n*o.d-o.n*self.d)
D=fmpq_poly([fmpq(v) for v in connection['denominator_coefficients']]);lookup={}
for entry in connection['entries']:
 vals={t['eta_power']:fmpq(int(t['numerator']),int(t['denominator'])) for t in entry['terms']};P=fmpq_poly([vals.get(j,0) for j in range(max(vals,default=0)+1)])
 lookup[entry['row'],entry['column'],entry['epsilon_power']]=R(P,D)
checks=0;nonzero=0
for i,row in enumerate(prepared['differential_matrix']):
 for j,text in enumerate(row):
  q=parse(text);d0=polynomial(q.d,0);assert d0,('negative epsilon valuation in originalDE',i,j)
  coeff=[]
  for k in range(6):
   v=R(polynomial(q.n,k))
   for r in range(1,k+1):v=v-R(polynomial(q.d,r))*coeff[k-r]
   v=v/R(d0);coeff.append(v)
   assert v.equals(lookup.get((i,j,k),R(0))),('exact epsilon coefficient mismatch',i,j,k)
   checks+=1;nonzero+=bool(v.n)
target=next(r for r in prepared['target_reductions'] if r['powers']==input['ordered_target_powers']);basis={tuple(p):i for i,p in enumerate(prepared['basis'])}
projection=[{'basis_index_zero_based':basis[tuple(term['powers'])],'coefficient':term['coefficient']} for term in target['terms']]
result={'schema':'vakint.pr11d.AMFlow-oracle-exact-lift-validation.v1','status':'PASS','original_dimension':42,'jet_count':6,'lifted_dimension':252,'exact_epsilon_coefficient_checks':checks,'nonzero_base_epsilon_coefficients':nonzero,'lifted_nonzero_count':3343,'target_ordered_powers':input['ordered_target_powers'],'target_reduction_projection':projection,'source_prepared_sha256':sha(prepared_path),'polynomial_connection_sha256':sha(connection_path),'independence':'Original matrix entries are reparsed and epsilon-expanded independently of the original connection exporter; all six coefficients agree by exact rational-polynomial cross multiplication.','no_numerical_evaluation_performed':True}
(ROOT/'lift-validation.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',checks,'originalDE epsilon coefficient identities; targetprojection',projection)
