#!/usr/bin/env python3
"""Read-only exact PF step reconstruction. Never imports or executes producers.

The whole-chain caller must separately authenticate implementation pins and
physical initial data. This module checks one frozen step's data consistency,
exact connection, interval preservation, and local-certificate metadata.
"""
import argparse,hashlib,json,math,time
from fractions import Fraction as Q
from pathlib import Path
from flint import arb,acb,ctx,fmpq,fmpq_poly

HERE=Path(__file__).resolve().parent
def require(ok,message):
    if not ok:raise ValueError(message)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def unique(pairs):
    out={}
    for k,v in pairs:require(k not in out,'Duplicate JSON key '+str(k));out[k]=v
    return out
def finite_float(x):
    v=float(x);require(math.isfinite(v),'Nonfinite JSON number');return v
def load(path):return json.loads(Path(path).read_bytes(),object_pairs_hook=unique,parse_float=finite_float,parse_constant=lambda s:(_ for _ in ()).throw(ValueError('Nonfinite JSON '+s)))
def integer(v,label):require(type(v) is int,'Expected integer '+label);return v
def pair(v,label):
    require(type(v) is list and len(v)==2 and all(type(x) is str for x in v),'Expected rational pair '+label)
    return tuple(Q(x) for x in v)
def real(s):
    require(type(s) is str,'Ball must be text');v=arb(s);require(v.is_finite(),'Nonfinite ball');return v
def decode(rows,count):
    require(type(rows) is list and len(rows)==count,'Wrong complex-vector length');out=[]
    for row in rows:require(type(row) is list and len(row)==2,'Wrong complex pair');out.append(acb(real(row[0]),real(row[1])))
    return out
def aq(q):q=Q(q);return arb(fmpq(q.numerator,q.denominator))
def add(a,b):return a[0]+b[0],a[1]+b[1]
def mul(a,b):return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def scaled(z):
    d=math.lcm(z[0].denominator,z[1].denominator);return [int(z[0]*d),int(z[1]*d),d]
def compose(coeff,center,step,degree):
    # Horner composition, independent of the producer's binomial expansion.
    result=[(Q(0),Q(0))]
    for q in reversed(coeff):
        nxt=[(Q(0),Q(0))]*(len(result)+1)
        for k,v in enumerate(result):nxt[k]=add(nxt[k],mul(center,v));nxt[k+1]=add(nxt[k+1],mul(step,v))
        nxt[0]=add(nxt[0],(q,Q(0)));result=nxt
    require(all(v==(0,0) for v in result[degree+1:]),'Shifted degree exceeds header')
    return (result+[(Q(0),Q(0))]*(degree+1))[:degree+1]
def block_owners(dim,entries):
    # SCCs from transitive closure, independent of producer Tarjan recursion.
    reach=[[i==j for j in range(dim)] for i in range(dim)]
    for e in entries:reach[e['column']][e['row']]=True
    for k in range(dim):
        for i in range(dim):
            if reach[i][k]:
                for j in range(dim):reach[i][j]=reach[i][j] or reach[k][j]
    remaining=set(range(dim));components=[]
    while remaining:
        i=min(remaining);c=sorted(j for j in remaining if reach[i][j] and reach[j][i]);components.append(c);remaining.difference_update(c)
    owner={i:k for k,c in enumerate(components) for i in c};arcs=set((owner[e['column']],owner[e['row']]) for e in entries if owner[e['column']]!=owner[e['row']]);todo=set(range(len(components)));ordered=[]
    while todo:
        ready=[k for k in todo if not any(a in todo and b==k for a,b in arcs)];require(ready,'SCC graph cycle')
        k=min(ready,key=lambda x:min(components[x]));ordered.append(components[k]);todo.remove(k)
    require(max(map(len,ordered))<=4,'Unsupported block size')
    return ordered,[next(k for k,c in enumerate(ordered) if i in c) for i in range(dim)]
def pole_minimum(center,step,root):
    delta=(center[0]-root,center[1]);norm=sum(x*x for x in step);require(norm>0,'Zero step')
    t=max(Q(0),min(Q(1),-sum(x*y for x,y in zip(delta,step))/norm))
    point=add(delta,(t*step[0],t*step[1]));square=sum(x*x for x in point);require(square>0,'Segment intersects pole')
    return t,square
def segment_bound(D,center,step):
    polynomial=fmpq_poly([fmpq(x.numerator,x.denominator) for x in D]);constant,factors=polynomial.factor();bound=abs(arb(constant));certs=[]
    for factor,multiplicity in factors:
        c=[Q(str(factor[k])) for k in range(factor.degree()+1)]
        if factor.degree()==1:
            t,square=pole_minimum(center,step,-c[0]/c[1]);factor_bound=abs(aq(c[1]))*aq(square).sqrt()
            cert={'kind':'linear','coefficients':list(map(str,c)),'multiplicity':int(multiplicity),'minimizing_parameter':str(t),'minimum_root_distance_squared':str(square)}
        elif factor.degree()==2 and center[0]==step[0]==0:
            z0,z1=center[1],center[1]+step[1];lo=Q(0) if min(z0,z1)<=0<=max(z0,z1) else min(z0*z0,z1*z1);hi=max(z0*z0,z1*z1)
            c0,c1,c2=c;stationary=(2*c2*c0-c1*c1)/(2*c2*c2);x=max(lo,min(hi,stationary));square=(c0-c2*x)**2+c1*c1*x;require(square>0,'Quadratic pole on segment');factor_bound=aq(square).sqrt()
            cert={'kind':'quadratic-imaginary-axis','coefficients':list(map(str,c)),'multiplicity':int(multiplicity),'minimizing_y_squared':str(x),'minimum_factor_modulus_squared':str(square)}
        else:raise ValueError('Unsupported certified denominator factor/path')
        bound*=factor_bound**int(multiplicity);certs.append(cert)
    require(bound>0,'Denominator factor product is not positive');return bound,certs
def gauge_contract(gauge,dim):
    weights=gauge['weights'];require(type(weights) is list and len(weights)==dim and all(type(w) is int and w in (0,1) for w in weights),'Unsupported epsilon gauge weights')
    require(gauge['transformation_independent_of_eta'] is True and gauge['epsilon_zero_gauge_is_identity'] is True,'Unsupported gauge properties')
    wanted='Y_i=(1-2*epsilon)^w_i*U_i' if any(weights) else 'Y_i=U_i'
    require(gauge['original_Y_equals_factor_power_times_transformed_U']==wanted,'Unknown raw/U gauge definition');return weights
def boundary_contract(data,dim,source_hash,point):
    lo={7:-3,42:-4}[dim]
    require(data['basis']=='original_raw_epsilon_jets' and data['normalization']=='native_raw' and data['error_quality']=='rigorous-bound','Boundary basis/normalization/error-quality mismatch')
    require(integer(data['dimension'],'boundary dimension')==dim and integer(data['epsilon_min_power'],'minimum power')==lo and integer(data['epsilon_max_power'],'maximum power')==lo+5,'Boundary dimension/Laurent range mismatch')
    if 'jets' in data:require(integer(data['jets'],'boundary jets')==6,'Boundary jet count mismatch')
    require(data.get('source_equation_sha256',data.get('original_source_equation_sha256'))==source_hash,'Boundary source binding mismatch')
    require(pair(data['eta_center'],'boundary center')==point,'Boundary center mismatch')
    require(data.get('physical_accuracy_certified',True) is not False,'Boundary explicitly lacks physical certification')
    require(data.get('local_truncation_rigorously_enclosed') is True or data.get('local_tail_certified') is True,'Boundary has no rigorous local-tail flag')

def _check_step(input_path,metadata_path,prior_path,connection_path,pf_path,result_path=None,following_path=None,binding_path=None):
    """Return an audit row; caller authenticates implementation and physical origin."""
    start=time.monotonic();paths=[Path(p).resolve() for p in [input_path,metadata_path,prior_path,connection_path,pf_path]]
    ip,mp,pp,cp,fp=paths;meta,prior,con,pf=map(load,[mp,pp,cp,fp]);hashes={str(p):sha(p) for p in paths}
    require(con['schema']=='vakint.pr11d.six-jet-polynomial-connection.v1','Unknown polynomial schema')
    dim=integer(con['dimension'],'dimension');jets=integer(con['epsilon_jet_count'],'jets');require(dim in (7,42) and jets==6,'Only reviewed3L/X8 six-jet systems supported');states=dim*jets
    source=Path(con['source']).resolve();require(sha(source)==con['source_sha256'],'Raw source file hash mismatch');hashes[str(source)]=sha(source)
    gauge=con['regular_epsilon_gauge'];weights=gauge_contract(gauge,dim)
    require(pf['schema']=='vakint.pr11d.partial-fraction-connection.v1','Unknown PF schema')
    require(pf['source_polynomial_connection_sha256']==hashes[str(cp)] and pf['regular_epsilon_gauge']==gauge,'PF polynomial/gauge binding mismatch')
    require(integer(pf['dimension'],'PF dimension')==dim and integer(pf['epsilon_jet_count'],'PF jets')==jets,'PF dimensions mismatch')
    require(meta['schema']=='vakint.generic.ordinary-step-input.v1','Unknown input metadata schema')
    center=pair(meta['center'],'center');step=pair(meta['step'],'step');destination=add(center,step);require(step!=(0,0),'Zero step')
    boundary_contract(prior,dim,con['source_sha256'],center)
    for key,expected in [('input_sha256',hashes[str(ip)]),('initial_data_sha256',hashes[str(pp)]),('polynomial_connection_sha256',hashes[str(cp)]),('partial_fraction_sha256',hashes[str(fp)]),('source_equation_sha256',con['source_sha256'])]:require(meta[key]==expected,'Metadata binding mismatch '+key)
    require(integer(meta['dimension'],'metadata dimension')==dim and integer(meta['jets'],'metadata jets')==jets and meta['normalization']=='native_raw' and meta['source_error_quality']=='rigorous-bound' and meta['regular_epsilon_gauge']==gauge,'Metadata contract mismatch')
    require(meta['denominator_bound_method']=='Exact rational linear-factor segment minima and exact imaginary-axis quadratic minima, outward rounded','Unknown denominator bound method')
    require(meta['physical_period_accuracy_claimed'] is False,'Input metadata promotes physical precision')
    binding=load(binding_path) if binding_path else None
    if binding:
        bp=Path(binding_path).resolve();hashes[str(bp)]=sha(bp)
        for k,x in [('connection_sha256',hashes[str(cp)]),('partial_fraction_sha256',hashes[str(fp)]),('source_equation_sha256',con['source_sha256']),('dimension',dim),('epsilon_jet_count',jets),('normalization','native_raw'),('error_quality','rigorous-bound')]:require(binding[k]==x,'Run binding mismatch '+k)
    lines=iter(ip.read_text().splitlines())
    def ints(count):
        vals=next(lines).split();require(len(vals)==count,'Wrong integer input row width');return [int(x) for x in vals]
    header=ints(9);hd,hj,degree,count,nb,bits,digits,maxorder,checkevery=header
    require((hd,hj,degree,count)==(dim,jets,8,len(con['entries'])) and bits>=64 and digits>=32 and maxorder>=8 and checkevery>=1,'Bad native input header')
    require(integer(meta['degree'],'metadata degree')==degree and integer(meta['working_bits'],'metadata bits')==bits and integer(meta['requested_digits'],'metadata digits')==digits,'Metadata/header disagreement')
    if binding:
        require(digits==binding['local_target_digits'],'Run target digits mismatch');require(bits==math.ceil((digits+binding['guard_digits'])*math.log2(10)),'Run working precision mismatch')
    lower_text=next(lines);ctx.prec=128;native_lower=real(lower_text);require(native_lower>0,'Nonpositive native denominator lower bound')
    ctx.prec=max(bits+128,512);lower=real(lower_text);require(lower_text==meta['denominator_lower_bound'],'Serialized lower bound differs from metadata');owners=ints(dim)
    ordered,expected_owners=block_owners(dim,con['entries']);require(nb==len(ordered) and owners==expected_owners,'SCC block ownership/order mismatch')
    D=[Q(x) for x in con['denominator_coefficients']];require(max(len(D)-1,con['numerator_degree'])<=degree,'Unsupported polynomial degree')
    shifted_D=compose(D,center,step,degree);expected=[];original_entries={}
    for e in con['entries']:
        key=(e['row'],e['column'],e['epsilon_power']);require(key not in original_entries and all(type(x) is int for x in key) and 0<=key[0]<dim and 0<=key[1]<dim and 0<=key[2]<jets,'Bad or duplicate polynomial coupling')
        co=[Q(0)]*(degree+1);powers=set()
        for term in e['terms']:
            k=term['eta_power'];require(type(k) is int and 0<=k<=degree and k not in powers,'Bad/duplicate numerator power');powers.add(k);co[k]=Q(int(term['numerator']),int(term['denominator']))
        original_entries[key]=fmpq_poly([fmpq(q.numerator,q.denominator) for q in co]);expected.append((key,[mul(step,z) for z in compose(co,center,step,degree)]))
    scale=math.lcm(*(q.denominator for co in [shifted_D]+[co for _,co in expected] for z in co for q in z));require(meta['denominator_scale']==str(scale),'Denominator integer scale mismatch')
    require([ints(2) for _ in range(degree+1)]==[[int(a*scale),int(b*scale)] for a,b in shifted_D],'Exact shifted denominator mismatch')
    for key,co in expected:
        require(ints(3)==list(key),'Polynomial coupling ordering mismatch');require([ints(2) for _ in range(degree+1)]==[[int(a*scale),int(b*scale)] for a,b in co],'Exact shifted numerator mismatch')
    factor_bound,certs=segment_bound(D,center,step);require(lower.lower()>0 and native_lower.lower()>0 and lower.lower()<=(factor_bound*scale).lower(),'Invalid segment denominator lower bound')
    require(meta['denominator_segment_certificates']==certs,'Exact factor segment certificates mismatch')
    prior_values=decode(prior['values'],states);converted=[]
    for k in range(jets):
        for i in range(dim):converted.append(sum((prior_values[(k-j)*dim+i]*(2**j) for j in range(k+1)),acb(0)) if weights[i] else prior_values[k*dim+i])
    serialized=[]
    for _ in range(states):
        v=next(lines).split('|');require(len(v)==2,'Bad serialized boundary pair');serialized.append(acb(real(v[0]),real(v[1])))
    require(all(a.contains(b) for a,b in zip(serialized,converted)),'Raw-to-U input conversion lost interval uncertainty')
    locations=[Q(p['location']) for p in pf['poles']];require(len(locations)==len(set(locations)) and all(type(p['maximum_order']) is int and p['maximum_order'] in (1,2) for p in pf['poles']),'Bad PF pole list')
    terms=[(e,t) for e in pf['residue_entries'] for t in e['terms']];require(next(lines)==f'PF_V1 {len(locations)} {len(terms)}','PF marker/count mismatch');den=int(pf['common_rational_denominator']);require(den>0 and ints(1)==[den] and ints(3)==scaled(step),'PF scale/step mismatch')
    for root in locations:require(ints(3)==scaled((center[0]-root,center[1])),'PF pole displacement mismatch')
    original_D=fmpq_poly([fmpq(q.numerator,q.denominator) for q in D]);rebuilt={};pf_bounds={};distance_certs=[]
    for a,root in enumerate(locations):
        t,q=pole_minimum(center,step,root);distance_certs.append({'pole_index':a,'minimizing_parameter':str(t),'minimum_distance_squared':str(q)})
    habs=aq(sum(q*q for q in step)).sqrt()
    for e,t in terms:
        key=(e['row'],e['column'],e['epsilon_power']);require(all(type(x) is int for x in key) and key in original_entries,'PF coupling absent from polynomial');kind=t['pole_order'];require(type(kind) is int and kind in (0,1,2),'Bad PF pole order');index=locations.index(Q(t['pole'])) if kind else 0;value=Q(t['value']);scaled_value=value*den;require(scaled_value.denominator==1,'PF multiplier is not integral')
        if kind:require(kind<=pf['poles'][index]['maximum_order'],'PF term exceeds declared pole order')
        require(ints(6)==list(key)+[kind,index,scaled_value.numerator],'PF serialized term mismatch')
        factor=fmpq_poly([-fmpq(locations[index].numerator,locations[index].denominator),1])**kind if kind else fmpq_poly([1]);quotient,remainder=divmod(original_D,factor);require(not remainder,'PF pole does not divide denominator')
        rebuilt[key]=rebuilt.get(key,fmpq_poly())+quotient*fmpq(value.numerator,value.denominator)
        bound=habs*abs(aq(value))
        if kind:bound/=aq(Q(distance_certs[index]['minimum_distance_squared'])).sqrt()**kind
        pf_bounds[key]=pf_bounds.get(key,arb(0))+bound
    require(not list(lines),'Trailing native input lines');require(all(rebuilt.get(k,fmpq_poly())==p for k,p in original_entries.items()),'Exact PF-to-polynomial identity failed')
    result_checks=None
    require((result_path is None)==(following_path is None),'Native result and following boundary must be supplied together')
    if result_path:
        rp=Path(result_path).resolve();np=Path(following_path).resolve();result=load(rp);following=load(np);hashes[str(rp)]=sha(rp);hashes[str(np)]=sha(np)
        boundary_contract(following,dim,con['source_sha256'],destination)
        require(result['schema']=='vakint.pr11d.arb-local-transport-pilot.v1' and result['local_tail_certified'] is True and result['no_PR11d_value_claimed'] is True,'Native local certification/schema mismatch')
        require(integer(result['working_bits'],'native bits')==bits and integer(result['target_absolute_digits'],'native digits')==digits,'Native precision mismatch');order=integer(result['order'],'native order');require(8<=order<=maxorder and (order%checkevery==0 or order==maxorder),'Native certification order inconsistent with input')
        tail=real(result['tail_upper_enclosure']);require(tail>=0 and tail.upper()<(arb(10)**(-digits)/16).lower(),'Native local tail fails target/16')
        require(result['connection_bound_method']=='exact rational segment pole distances' and result['pole_distance_certificates']==distance_certs,'Native PF distance certificates mismatch')
        poly_bounds={key:aq(sum(abs(a)+abs(b) for a,b in co)*scale)/native_lower for key,co in expected}
        def internal_max(bounds):
            vals=[sum((v for (i,j,k),v in bounds.items() if i==row and k==0 and owners[i]==owners[j]),arb(0)) for row in range(dim)]
            return max(v.upper() for v in vals)
        require(real(result['polynomial_maximum_internal_row_bound']).upper()>=internal_max(poly_bounds),'Native polynomial row bound too small')
        require(real(result['pf_maximum_internal_row_bound']).upper()>=internal_max(pf_bounds),'Native PF row bound too small')
        U=decode(result['values'],states);restored=[U[k*dim+i]-2*U[(k-1)*dim+i] if k and weights[i] else U[k*dim+i] for k in range(jets) for i in range(dim)];saved=decode(following['values'],states)
        require(all(a.contains(b) for a,b in zip(saved,restored)),'U-to-raw output conversion lost interval uncertainty')
        for k,x in [('previous_boundary_sha256',hashes[str(pp)]),('transport_input_sha256',hashes[str(ip)]),('native_output_sha256',hashes[str(rp)])]:require(following[k]==x,'Following boundary binding mismatch '+k)
        require(following['local_truncation_rigorously_enclosed'] is True and following['whole_PR11d_20000_accuracy_claimed'] is False,'Following boundary promotes precision or lacks tail')
        exact_reencoding=None
        if binding:
            require(following['run_binding_sha256']==hashes[str(bp)] and following['initial_boundary_sha256']==binding['initial_sha256'],'Following run binding mismatch')
            ctx.dps=digits+binding['guard_digits'];UU=decode(result['values'],states);raw=[UU[k*dim+i]-2*UU[(k-1)*dim+i] if k and weights[i] else UU[k*dim+i] for k in range(jets) for i in range(dim)]
            encoded=[[z.real.str(digits+binding['guard_digits']+8,more=True),z.imag.str(digits+binding['guard_digits']+8,more=True)] for z in raw];require(encoded==following['values'],'Following raw reencoding differs from driver');exact_reencoding=True
        result_checks={'native_order':order,'native_tail_upper_enclosure':result['tail_upper_enclosure'],'native_local_tail_below_target_over16':True,'native_exact_pole_minima_checked':len(distance_certs),'native_reported_row_bounds_dominate_independent_bounds':True,'output_raw_ball_containments':states,'driver_raw_serialization_exact_match':exact_reencoding}
    for p,digest in hashes.items():require(sha(p)==digest,'Source/input changed during check: '+p)
    return {'schema':'vakint.readonly.exact-PF-step-check.v1','status':'passed_step_data_reconstruction_only','dimension':dim,'jets':jets,'center':list(map(str,center)),'destination':list(map(str,destination)),'working_bits':bits,'target_digits':digits,'polynomial_entries':len(expected),'PF_terms':len(terms),'blocks':len(ordered),'maximum_block_size':max(map(len,ordered)),'denominator_scale':str(scale),'all_shifted_Gaussian_coefficients_exact':True,'all_PF_polynomial_identities_exact':True,'factor_segment_certificate_count':len(certs),'denominator_lower_bound_verified':True,'input_gauged_ball_containments':states,'nonzero_gauge_weights':sum(weights),'result_checks':result_checks,'artifact_sha256':hashes,'checker_sha256':sha(Path(__file__)),'seconds':time.monotonic()-start,'native_or_prefix_solve_invoked':False,'physical_initial_origin_validated':False,'implementation_pins_validated':False,'whole_PR11d_accuracy_claimed':False}

def check_step(input_path,metadata_path,prior_path,connection_path,pf_path,result_path=None,following_path=None,binding_path=None):
    """Read and check one step, restoring the caller's Arb precision afterward."""
    saved_precision=ctx.prec
    try:return _check_step(input_path,metadata_path,prior_path,connection_path,pf_path,result_path,following_path,binding_path)
    finally:ctx.prec=saved_precision

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True);ap.add_argument('--metadata',type=Path);ap.add_argument('--prior',type=Path,required=True);ap.add_argument('--connection',type=Path,required=True);ap.add_argument('--partial-fractions',type=Path,required=True);ap.add_argument('--native-result',type=Path);ap.add_argument('--following',type=Path);ap.add_argument('--run-binding',type=Path);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    output=a.output.resolve();require(output.is_relative_to(HERE) and not a.output.is_symlink() and not output.exists(),'Output must be a fresh reviewer-owned path')
    report=check_step(a.input,a.metadata or a.input.with_suffix('.json'),a.prior,a.connection,a.partial_fractions,a.native_result,a.following,a.run_binding)
    with output.open('x') as f:f.write(json.dumps(report,indent=2)+'\n')
    print('PASS exact PF step',report['dimension'],'states per jet;',report['seconds'],'seconds')
if __name__=='__main__':main()
