"""Observe expected pole cancellations in the independent transported vector."""
from pathlib import Path
import json,hashlib,sys
from flint import arb,acb
sys.dont_write_bytecode=True
from compare import mma
ROOT=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Acceptance pole checks require assertions enabled')
label=sys.argv[1];source=ROOT/f'{label}-result.json';data=json.loads(source.read_text());assert data['segments']==48
vector=list(map(mma,data['vector']));assert len(vector)==252
input=json.loads((ROOT/'input.json').read_text());V=[acb(arb(a[0]['center']),arb(a[1]['center'])) for a in input['endpoint_adjoint']];assert len(V)==252
rows=[]
for order in range(-5,0):
 value=sum((V[k*42+i]*vector[(order+5-k)*42+i] for k in range(order+6) for i in range(42)),acb(0));norm=abs(value).upper();assert norm<arb('1e-100')
 rows.append({'epsilon_order':order,'central_projected_complex_norm':norm.str(40),'consistent_with_expected_zero_through_decimal_digits':100,'exact_zero_claimed_from_numerics':False})
result={'schema':'vakint.pr11d.original-AMFlow-observed-pole-cancellations.v1','status':'all_five_apparent_poles_suppressed_below1e-100','label':label,'source_result_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'coefficients':rows,'scope':'Observed cancellation from original-MMA central values and shared endpoint adjoint. This is not an exact-zero proof or a physical-source error bound. The epsilon^-5 slot is an apparent adjoint projection pole; PR11d is finite.','source_error_quality':data['source_error_quality']}
(ROOT/f'{label}-pole-check.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS five apparent poles below1e-100; largest',max(arb(r['central_projected_complex_norm']) for r in rows).str(30))
