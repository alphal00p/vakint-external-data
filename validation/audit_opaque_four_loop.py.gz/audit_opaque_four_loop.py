import ast,decimal,importlib.util,json,re,time
from pathlib import Path
from symbolica import E,Float
ROOT=Path('/shared/codex-1/vakint_rustred');WORK=ROOT/'workspace/validation';DATA=ROOT/'vakint-external-data';SRC=ROOT/'gammaloop_vakint_rustred/crates/vakint/src'
spec=importlib.util.spec_from_file_location('helper',WORK/'export_known_laurent_coefficients.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
P=h.parse;EP=h.EP
decimal.getcontext().prec=120
source=(SRC/'fmft_numerics.rs').read_text();cut=source.index('pub static MASTERS_NUMERIC_SUBSTITUTIONS')
expansions=dict(re.findall(h.PAT,source[:cut]));numbers=dict(re.findall(h.PAT,source[cut:]));direct=dict(re.findall(h.PAT,(SRC/'matad_numerics.rs').read_text()))
for name in ['D6','T1ep','T1ep2']:
 if name not in numbers:numbers[name]=direct[name]
parameters={};uncertainties={};annotations={}
for name,value in numbers.items():
 annotations[name]=min([decimal.Decimal(x) for x in re.findall(r'`([0-9.]+)',value)],default=None)
 if re.fullmatch(r'[-+0-9.eE]+(?:`[0-9.]+)?',value):
  literal=re.sub(r'`[0-9.]+','',value);number=decimal.Decimal(literal)
  parameters[P(name)]=Float(literal,decimal_digits=110)
  uncertainties[name]=max(decimal.Decimal('0.5')*(decimal.Decimal(10)**number.as_tuple().exponent),abs(number)*(decimal.Decimal(10)**(-annotations[name])) if annotations[name] is not None else decimal.Decimal(0))
for line in (WORK/'hpl-values-200.tsv').read_text().splitlines():
 word,real,imag=line.split('\t')
 if tuple(ast.literal_eval(word))==(1,0):
  s2=P('-4*('+imag+')/(9*sqrt(3))').evaluate({},110).real.to_decimal()
  parameters[P('S2')]=Float(str(s2),decimal_digits=110)
  break
rules=[(P(k),P(v)) for k,v in expansions.items()]
manifest=json.loads((DATA/'4L/manifest.json').read_text());results=[];start=time.monotonic()
for master in manifest['masters']:
 selected=[c for c in master['coefficients'] if not c['symbolic'] and c['numerical']]
 if not selected:continue
 expression=P(master['exact_basis_expression'])
 for _ in range(3):
  old=expression
  for a,b in rules:expression=expression.replace(a,b)
  if expression==old:break
 coefficients=h.coefficient_map(expression,max(c['epsilon_power'] for c in selected))
 values=dict(json.loads((DATA/'4L'/master['files']['numerical.json']['path']).read_text()))
 for entry in selected:
  power=entry['epsilon_power'];formula=coefficients.get(power,P('0'));text=h.text(formula)
  row={'master_id':master['master_id'],'name':master['name'],'epsilon_power':power,'declared_external_digits':entry['significant_digits']}
  if 'Oep' in text:
   row['status']='legacy_order_unavailable';results.append(row);continue
  try:value=h.scalar(formula,parameters,100)
  except Exception as error:
   row['status']='unresolved_legacy_constant';row['detail']=str(error);results.append(row);continue
  uncertainty=decimal.Decimal(0);sources=[]
  for name,error in uncertainties.items():
   coefficient=formula.coefficient(P(name))
   if coefficient==0:continue
   weight=abs(h.scalar(coefficient,parameters,100));uncertainty+=weight*error
   sources.append({'name':name,'declared_digits':str(annotations[name]),'legacy_source_uncertainty':str(error)})
  actual=decimal.Decimal(values[power]);difference=abs(value-actual)
  tolerance=uncertainty+decimal.Decimal('1e-90')*(abs(value)+1)
  row.update({'status':'within_legacy_source_precision' if difference<=tolerance else 'outside_legacy_source_precision','legacy_value':str(value),'external_value':str(actual),'absolute_difference':str(difference),'legacy_source_precision_bound':str(uncertainty),'legacy_sources':sources})
  results.append(row)
print(json.dumps({'rows':len(results),'status_counts':{status:sum(x['status']==status for x in results) for status in sorted({x['status'] for x in results})},'elapsed_seconds':time.monotonic()-start},indent=2),flush=True)
(WORK/'opaque-four-loop-audit.json').write_text(json.dumps({'rows':results,'elapsed_seconds':time.monotonic()-start},indent=2)+'\n')
